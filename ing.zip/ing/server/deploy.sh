#!/bin/bash
# ==========================================================
# ing-陪伴 服务器一键部署脚本 (Ubuntu 22.04)
# 用法: chmod +x deploy.sh && sudo bash deploy.sh
# ==========================================================

set -e

echo "========================================"
echo "  ing-陪伴 后端一键部署"
echo "========================================"

DB_PASSWORD=$(openssl rand -base64 12)
APP_PORT=3000

echo "[1/6] 更新系统..."
apt update -y && apt upgrade -y

echo "[2/6] 安装 Node.js 20.x..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

echo "[3/6] 安装 MySQL 8.0..."
apt install -y mysql-server
systemctl start mysql
systemctl enable mysql

echo "[4/6] 配置数据库..."
mysql -u root <<SQL
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '$DB_PASSWORD';
FLUSH PRIVILEGES;
CREATE DATABASE IF NOT EXISTS ing_companion DEFAULT CHARSET utf8mb4 COLLATE utf8mb4_unicode_ci;
SQL
mysql -u root -p"$DB_PASSWORD" ing_companion < ./database.sql

echo "[5/6] 安装项目依赖..."
cd "$(dirname "$0")"
npm install --production

echo "[6/6] 配置环境变量并启动..."
cat > .env <<ENV
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=$DB_PASSWORD
DB_NAME=ing_companion
PORT=$APP_PORT
ENV

# 安装PM2保活
npm install -g pm2
pm2 start index.js --name ing-server
pm2 save
pm2 startup

# 防火墙放行
ufw allow $APP_PORT/tcp
ufw allow 22/tcp
ufw --force enable

echo ""
echo "========================================"
echo "  部署完成！"
echo "  数据库密码: $DB_PASSWORD (请妥善保管)"
echo "  API地址: http://$(hostname -I | awk '{print $1}'):$APP_PORT"
echo "  管理命令: pm2 status / pm2 logs ing-server"
echo "========================================"
