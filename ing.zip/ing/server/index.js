/**
 * ing-陪伴 云端后端服务
 * Node.js + Express + MySQL
 * 启动: npm start (监听3000端口)
 */

const express = require('express');
const http = require('http');
const cors = require('cors');
const mysql = require('mysql2/promise');
const jwt = require('jsonwebtoken');
const { createSocketServer, wsBroadcast, wsSendTo, wsBroadcastToRoom, wsBroadcastToUsers } = require('./socket');

const app = express();
const server = http.createServer(app);
const { getOnlineUsers, getOnlineCount } = createSocketServer(server);
const PORT = process.env.PORT || 3000;
const JWT_SECRET = 'ing_companion_secret_key_2024';

// MySQL连接池
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'ing_companion',
  waitForConnections: true,
  connectionLimit: 10,
  charset: 'utf8mb4',
});

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// JWT鉴权中间件
function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ code: 401, message: '未登录' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch { return res.status(401).json({ code: 401, message: '登录已过期' }); }
}

// 管理员鉴权
function adminMiddleware(req, res, next) {
  if (req.user?.role !== 'admin') return res.status(403).json({ code: 403, message: '无权限' });
  next();
}

// ==================== 健康检查 ====================
app.get('/api/health', async (req, res) => {
  try { await pool.query('SELECT 1'); res.json({ ok: true }); }
  catch { res.status(500).json({ ok: false }); }
});

// ==================== 版本更新 ====================
app.get('/api/version', async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM app_versions ORDER BY build_number DESC LIMIT 1');
  res.json({ code: 200, data: rows[0] || null });
});

// ==================== 账号 ====================

app.post('/api/auth/register', async (req, res) => {
  const { phone, password, username } = req.body;
  if (!phone || !password || !username) return res.json({ code: 400, message: '参数不完整' });
  const [exists] = await pool.query('SELECT id FROM users WHERE phone=?', [phone]);
  if (exists.length > 0) return res.json({ code: 400, message: '该手机号已注册' });

  const userId = 'user_' + phone.slice(-4) + '_' + Date.now();
  await pool.query('INSERT INTO users (id,username,phone,password,status) VALUES (?,?,?,?,?)', [userId, username, phone, password, 'pending']);
  const token = jwt.sign({ id: userId, username, phone, role: 'family' }, JWT_SECRET, { expiresIn: '30d' });
  res.json({ code: 200, message: '注册申请已提交，等待审核', data: { userId, status: 'pending', token } });
});

app.post('/api/auth/login', async (req, res) => {
  const { phone, password } = req.body;
  // 管理员账号
  if (phone === '00000001' && password === '030302040015') {
    const token = jwt.sign({ id: 'admin_001', username: '管理员', phone: '00000001', role: 'admin' }, JWT_SECRET, { expiresIn: '30d' });
    return res.json({ code: 200, message: '管理员登录成功', data: { user: { id: 'admin_001', username: '管理员', phone: '00000001', role: 'admin', status: 'active' }, token } });
  }
  // 普通用户
  const [users] = await pool.query('SELECT * FROM users WHERE phone=?', [phone]);
  if (users.length === 0) return res.json({ code: 404, message: '该手机号未注册' });
  const user = users[0];
  if (user.status === 'pending') return res.json({ code: 403, message: '账号等待审核中' });
  if (user.status === 'disabled') return res.json({ code: 403, message: '账号已被禁用' });

  // 【安全加固】登录失败锁定检查
  const now = new Date();
  if (user.locked_until && new Date(user.locked_until) > now) {
    const remainMin = Math.ceil((new Date(user.locked_until) - now) / 60000);
    return res.json({ code: 429, message: `密码错误次数过多，请${remainMin}分钟后重试` });
  }

  // 验证密码（支持当前密码 + 过渡期旧密码）
  const passwordMatch = user.password === password
    || (user.old_password && user.old_password === password)
    || (user.old_password_2 && user.old_password_2 === password);
  if (!passwordMatch) {
    // 【安全加固】记录登录失败次数
    const newCount = (user.login_attempts || 0) + 1;
    if (newCount >= 5) {
      await pool.query('UPDATE users SET login_attempts=?, locked_until=DATE_ADD(NOW(), INTERVAL 15 MINUTE) WHERE id=?', [newCount, user.id]);
      return res.json({ code: 429, message: '密码错误次数过多，请15分钟后重试' });
    }
    await pool.query('UPDATE users SET login_attempts=? WHERE id=?', [newCount, user.id]);
    return res.json({ code: 401, message: `密码错误，还剩${5 - newCount}次尝试机会` });
  }

  // 登录成功 → 清除锁定状态
  await pool.query('UPDATE users SET last_active=NOW(), login_attempts=0, locked_until=NULL WHERE id=?', [user.id]);
  const token = jwt.sign({ id: user.id, username: user.username, phone: user.phone, role: user.role }, JWT_SECRET, { expiresIn: '30d' });
  res.json({ code: 200, message: '登录成功', data: { user: { id: user.id, username: user.username, phone: user.phone, avatar: user.avatar, role: user.role, status: user.status }, token } });
});

// ==================== 管理员接口 ====================

app.get('/api/admin/users', authMiddleware, adminMiddleware, async (req, res) => {
  const { status, keyword } = req.query;
  let sql = 'SELECT id as userId,username,phone,role,status,real_name_status as realNameStatus,created_at as createdAt FROM users WHERE role!="admin"';
  const params = [];
  if (status) { sql += ' AND status=?'; params.push(status); }
  if (keyword) { sql += ' AND (username LIKE ? OR phone LIKE ?)'; params.push('%'+keyword+'%', '%'+keyword+'%'); }
  sql += ' ORDER BY created_at DESC LIMIT 200';
  const [rows] = await pool.query(sql, params);
  res.json({ code: 200, data: rows });
});

app.get('/api/admin/stats', authMiddleware, adminMiddleware, async (req, res) => {
  const [[{ total }]] = await pool.query('SELECT COUNT(*) as total FROM users WHERE role!="admin"');
  const [[{ sosToday }]] = await pool.query('SELECT COUNT(*) as sosToday FROM sos_records WHERE DATE(triggered_at)=CURDATE()');
  const [[{ posts }]] = await pool.query('SELECT COUNT(*) as posts FROM space_posts');
  res.json({ code: 200, data: { totalUsers: total, onlineUsers: 0, verifiedUsers: 0, unverifiedUsers: 0, sosToday, activeUsersToday: 0, newUsersThisWeek: 0, totalSpacePosts: posts } });
});

app.post('/api/admin/audit-register', authMiddleware, adminMiddleware, async (req, res) => {
  const { userId, approved } = req.body;
  await pool.query('UPDATE users SET status=? WHERE id=?', [approved ? 'active' : 'disabled', userId]);
  await pool.query('INSERT INTO admin_audit_logs (id,admin_id,admin_name,action,target_user_id,detail) VALUES (?,?,?,?,?,?)', ['aud_'+Date.now(), req.user.id, req.user.username, approved ? 'approve_register' : 'reject_register', userId, approved ? '通过注册' : '驳回注册']);
  // WS桥接：通知用户审核结果
  wsSendTo(userId, { type: 'admin:notify', targetUserId: userId, message: approved ? '您的账号已通过审核，欢迎加入！' : '您的账号未通过审核，请联系管理员。', fromAdmin: req.user.username });
  // 通知管理员角色房间
  wsBroadcastToRoom('role:admin', { type: 'admin:audit', adminName: req.user.username, targetUserId: userId, action: approved ? 'approve' : 'reject', timestamp: new Date().toISOString() });
  res.json({ code: 200, message: approved ? '审核通过' : '已驳回' });
});

// ==================== 密码管理（安全加固） ====================

// 修改密码（密码轮换：旧密码保留过渡期30天）
app.post('/api/auth/change-password', authMiddleware, async (req, res) => {
  const { phone, newPassword } = req.body;
  if (!newPassword || newPassword.length < 6) return res.json({ code: 400, message: '密码至少6位' });
  const [users] = await pool.query('SELECT * FROM users WHERE phone=? AND id=?', [phone, req.user.id]);
  if (users.length === 0) return res.json({ code: 404, message: '用户不存在' });
  const user = users[0];
  // 不能与当前密码相同
  if (user.password === newPassword) return res.json({ code: 400, message: '新密码不能与当前密码相同' });
  // 不能与过渡期旧密码相同
  if (user.old_password === newPassword || user.old_password_2 === newPassword) {
    return res.json({ code: 400, message: '新密码不能与近期使用过的密码相同' });
  }
  // 轮换：old_password_2 ← old_password ← current_password ← newPassword
  await pool.query('UPDATE users SET old_password_2=old_password, old_password=password, password=?, password_updated_at=NOW() WHERE id=?', [newPassword, req.user.id]);
  res.json({ code: 200, message: '密码修改成功' });
});

// 管理员重置用户密码
app.post('/api/admin/reset-password', authMiddleware, adminMiddleware, async (req, res) => {
  const { phone, newPassword } = req.body;
  if (!newPassword || newPassword.length < 6) return res.json({ code: 400, message: '新密码至少6位' });
  const [users] = await pool.query('SELECT id FROM users WHERE phone=?', [phone]);
  if (users.length === 0) return res.json({ code: 404, message: '用户不存在' });
  // 管理员重置：旧密码轮换 + 标记强制重登
  await pool.query('UPDATE users SET old_password_2=old_password, old_password=password, password=?, password_updated_at=NOW(), login_attempts=0, locked_until=NULL WHERE id=?', [newPassword, users[0].id]);
  await pool.query('INSERT INTO admin_audit_logs (id,admin_id,admin_name,action,target_user_id,detail) VALUES (?,?,?,?,?,?)', ['aud_'+Date.now(), req.user.id, req.user.username, 'reset_password', users[0].id, '管理员重置密码']);
  res.json({ code: 200, message: '密码已重置' });
});

// ==================== 实名认证 ====================
app.post('/api/realname/submit', authMiddleware, async (req, res) => {
  const { realName, idCardNumber } = req.body;
  await pool.query('INSERT INTO real_name_records (id,user_id,real_name,id_card_number) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE real_name=?,id_card_number=?,status="pending"', ['rn_'+Date.now(), req.user.id, realName, idCardNumber, realName, idCardNumber]);
  await pool.query('UPDATE users SET real_name_status="pending" WHERE id=?', [req.user.id]);
  res.json({ code: 200, message: '实名认证已提交' });
});

// ==================== 绑定关系 ====================
app.get('/api/bindings', authMiddleware, async (req, res) => {
  const [rows] = await pool.query('SELECT b.*, u.username as to_username, u.phone as to_phone, u.avatar as to_avatar FROM bindings b JOIN users u ON b.to_user_id=u.id WHERE b.from_user_id=?', [req.user.id]);
  res.json({ code: 200, data: rows });
});

app.post('/api/bindings', authMiddleware, async (req, res) => {
  const { toPhone, type, message } = req.body;
  const [users] = await pool.query('SELECT id,username,phone FROM users WHERE phone=?', [toPhone]);
  if (users.length === 0) return res.json({ code: 404, message: '未找到该用户' });
  // 恋人限制
  if (type === 'lover') {
    const [existing] = await pool.query('SELECT id FROM bindings WHERE from_user_id=? AND type="lover" AND status="accepted"', [req.user.id]);
    if (existing.length > 0) return res.json({ code: 400, message: '已有恋人绑定' });
  }
  await pool.query('INSERT INTO bindings (id,from_user_id,to_user_id,type,message) VALUES (?,?,?,?,?)', ['b_' + Date.now(), req.user.id, users[0].id, type, message || '']);
  // WS桥接：通知目标用户有新的绑定请求
  wsSendTo(users[0].id, { type: 'binding:change', fromUserId: req.user.id, fromUsername: req.user.username, toUserId: users[0].id, changeType: 'request', bindingType: type, message: message || '' });
  res.json({ code: 200, message: '绑定请求已发送' });
});

// 响应绑定请求（接受/拒绝）
app.post('/api/bindings/:id/respond', authMiddleware, async (req, res) => {
  const { accept } = req.body;
  const [rows] = await pool.query('SELECT * FROM bindings WHERE id=? AND to_user_id=? AND status="pending"', [req.params.id, req.user.id]);
  if (rows.length === 0) return res.json({ code: 404, message: '未找到待处理的绑定请求' });
  const binding = rows[0];
  const newStatus = accept ? 'accepted' : 'rejected';
  await pool.query('UPDATE bindings SET status=?, updated_at=NOW() WHERE id=?', [newStatus, req.params.id]);
  // WS通知发起方
  wsSendTo(binding.from_user_id, { type: 'binding:change', fromUserId: req.user.id, fromUsername: req.user.username, toUserId: binding.from_user_id, changeType: newStatus, bindingType: binding.type });
  res.json({ code: 200, message: accept ? '已接受绑定' : '已拒绝绑定' });
});

// 取消/解除绑定
app.delete('/api/bindings/:id', authMiddleware, async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM bindings WHERE id=? AND (from_user_id=? OR to_user_id=?)', [req.params.id, req.user.id, req.user.id]);
  if (rows.length === 0) return res.json({ code: 404, message: '未找到绑定关系' });
  await pool.query('DELETE FROM bindings WHERE id=?', [req.params.id]);
  const binding = rows[0];
  const otherId = binding.from_user_id === req.user.id ? binding.to_user_id : binding.from_user_id;
  wsSendTo(otherId, { type: 'binding:change', fromUserId: req.user.id, fromUsername: req.user.username, toUserId: otherId, changeType: 'cancelled', bindingType: binding.type });
  res.json({ code: 200, message: '已解除绑定' });
});

// 用户通知列表
app.get('/api/notifications', authMiddleware, async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM notifications WHERE to_user_id=? ORDER BY created_at DESC LIMIT 100', [req.user.id]);
  res.json({ code: 200, data: rows });
});

// ==================== SOS ====================
app.post('/api/sos/trigger', authMiddleware, async (req, res) => {
  const { latitude, longitude, address, isSilent } = req.body;
  const id = 'sos_' + Date.now();
  await pool.query('INSERT INTO sos_records (id,user_id,username,phone,latitude,longitude,address,is_silent) VALUES (?,?,?,?,?,?,?,?)', [id, req.user.id, req.user.username, req.user.phone, latitude, longitude, address, isSilent ? 1 : 0]);
  // WS桥接：全员紧急广播
  wsBroadcast({ type: 'sos:new', alertId: id, senderId: req.user.id, senderName: req.user.username, senderPhone: req.user.phone, latitude, longitude, address, triggeredAt: new Date().toISOString(), isSilent: !!isSilent });
  res.json({ code: 200, data: { id, senderId: req.user.id, senderName: req.user.username, senderPhone: req.user.phone, location: { latitude, longitude }, address, triggeredAt: new Date().toISOString(), status: 'active' } });
});

app.get('/api/admin/sos', authMiddleware, adminMiddleware, async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM sos_records ORDER BY triggered_at DESC LIMIT 500');
  res.json({ code: 200, data: rows.map(r => ({ id: r.id, senderId: r.user_id, senderName: r.username, senderPhone: r.phone, location: { latitude: r.latitude, longitude: r.longitude }, address: r.address, triggeredAt: r.triggered_at, status: r.status, sosStatus: r.sos_status, isSilent: !!r.is_silent, resolvedAt: r.resolved_at, resolvedBy: r.resolved_by })) });
});

app.post('/api/admin/sos/resolve', authMiddleware, adminMiddleware, async (req, res) => {
  const { id, status } = req.body;
  await pool.query('UPDATE sos_records SET sos_status=?, status="resolved", resolved_at=NOW(), resolved_by=? WHERE id=?', [status, req.user.username, id]);
  res.json({ code: 200, message: '已更新' });
});

// ==================== 定位上报 ====================
app.post('/api/location/report', authMiddleware, async (req, res) => {
  const { latitude, longitude, address } = req.body;
  await pool.query('INSERT INTO location_history (id,user_id,latitude,longitude,address) VALUES (?,?,?,?,?)', ['loc_' + Date.now(), req.user.id, latitude, longitude, address]);
  // WS桥接：定位同步给绑定关系用户
  wsBroadcastToRoom('user:' + req.user.id, { type: 'location:update', userId: req.user.id, username: req.user.username, latitude, longitude, address, timestamp: new Date().toISOString() });
  res.json({ code: 200, message: 'ok' });
});

// ==================== 空间动态 ====================
app.get('/api/space/posts/:userId', authMiddleware, async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM space_posts WHERE user_id=? ORDER BY created_at DESC LIMIT 100', [req.params.userId]);
  res.json({ code: 200, data: rows.map(r => ({ id: r.id, authorId: r.user_id, authorName: r.author_name, content: r.content, visibility: r.visibility, media: r.media ? JSON.parse(r.media) : [], likes: r.likes || 0, createdAt: r.created_at })) });
});

app.post('/api/space/posts', authMiddleware, async (req, res) => {
  const { content, media, visibility } = req.body;
  const id = 'sp_' + Date.now();
  await pool.query('INSERT INTO space_posts (id,user_id,author_name,content,visibility,media) VALUES (?,?,?,?,?,?)', [id, req.user.id, req.user.username, content, visibility || 'friends_only', media ? JSON.stringify(media) : null]);
  // WS桥接：新动态全员推送
  wsBroadcast({ type: 'space:newPost', postId: id, authorId: req.user.id, authorName: req.user.username, content, visibility: visibility || 'friends_only', media: media || [], createdAt: new Date().toISOString() });
  res.json({ code: 200, data: { id, authorId: req.user.id, authorName: req.user.username, content, visibility, media: media || [], likes: 0, createdAt: new Date().toISOString() } });
});

app.delete('/api/space/posts/:id', authMiddleware, async (req, res) => {
  await pool.query('DELETE FROM space_posts WHERE id=? AND user_id=?', [req.params.id, req.user.id]);
  res.json({ code: 200, message: '已删除' });
});

// ==================== 公告 ====================
app.get('/api/announcements', async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM announcements ORDER BY published_at DESC LIMIT 20');
  res.json({ code: 200, data: rows });
});

app.post('/api/admin/announcements', authMiddleware, adminMiddleware, async (req, res) => {
  const { title, content, level } = req.body;
  await pool.query('INSERT INTO announcements (id,title,content,level,published_by) VALUES (?,?,?,?,?)', ['ann_' + Date.now(), title, content, level || 'normal', req.user.username]);
  // WS桥接：公告全员广播
  wsBroadcast({ type: 'announcement:new', title, content, level: level || 'normal', publishedBy: req.user.username, publishedAt: new Date().toISOString() });
  res.json({ code: 200, message: '公告已发布' });
});

// ==================== 意见反馈 ====================
app.post('/api/feedback', authMiddleware, async (req, res) => {
  const { content, contact } = req.body;
  await pool.query('INSERT INTO feedbacks (id,user_id,username,content,contact) VALUES (?,?,?,?,?)', ['fb_' + Date.now(), req.user.id, req.user.username, content, contact || '']);
  res.json({ code: 200, message: '反馈已提交' });
});

app.get('/api/admin/feedbacks', authMiddleware, adminMiddleware, async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM feedbacks ORDER BY created_at DESC LIMIT 200');
  res.json({ code: 200, data: rows });
});

// ==================== 抽奖 ====================
app.get('/api/lottery/config', async (req, res) => {
  const [[cfg]] = await pool.query('SELECT * FROM lottery_config LIMIT 1');
  const [prizes] = await pool.query('SELECT * FROM lottery_prizes');
  res.json({ code: 200, data: { ...cfg, prizes: prizes.map(p => ({ id: p.id, name: p.name, type: p.type, totalCount: p.total_count, remainingCount: p.remaining_count, probability: parseFloat(p.probability) })), maxDrawsPerDay: cfg.max_draws_per_day, startAt: cfg.start_at, endAt: cfg.end_at } });
});

app.post('/api/admin/lottery/config', authMiddleware, adminMiddleware, async (req, res) => {
  const { status, maxDrawsPerDay, startAt, endAt, prizes } = req.body;
  await pool.query('UPDATE lottery_config SET status=?, max_draws_per_day=?, start_at=?, end_at=?, updated_at=NOW() WHERE id="cfg_1"',
    [status, maxDrawsPerDay, startAt || null, endAt || null]);
  if (prizes && Array.isArray(prizes)) {
    await pool.query('DELETE FROM lottery_prizes');
    for (const p of prizes) {
      await pool.query(
        'INSERT INTO lottery_prizes (id,name,type,total_count,remaining_count,probability) VALUES (?,?,?,?,?,?)',
        [p.id || 'pz_' + Date.now(), p.name, p.type || 'virtual', p.totalCount, p.remainingCount ?? p.totalCount, p.probability],
      );
    }
  }
  res.json({ code: 200, message: '配置已更新' });
});

app.post('/api/lottery/draw', authMiddleware, async (req, res) => {
  // 检查专属规则
  const [rules] = await pool.query('SELECT * FROM user_lottery_rules WHERE user_id=? AND is_active=1', [req.user.id]);
  let prizes;
  let isExclusive = false;
  if (rules.length > 0) {
    prizes = [{ name: rules[0].prize_name, probability: parseFloat(rules[0].probability) }];
    isExclusive = true;
  } else {
    const [global] = await pool.query('SELECT * FROM lottery_prizes WHERE remaining_count > 0');
    if (global.length === 0) {
      return res.json({ code: 500, message: '所有奖品库存已耗尽' });
    }
    prizes = global.map(p => ({ id: p.id, name: p.name, probability: parseFloat(p.probability) }));
  }

  // 概率加权随机算法
  const totalProb = prizes.reduce((sum, p) => sum + p.probability, 0);
  if (totalProb <= 0) {
    return res.json({ code: 500, message: '奖品概率配置异常' });
  }
  const rand = Math.random() * totalProb;
  let accumulated = 0;
  let won = prizes[prizes.length - 1].name; // 浮点精度兜底
  let wonId = prizes[prizes.length - 1].id;
  for (const p of prizes) {
    accumulated += p.probability;
    if (rand < accumulated) { won = p.name; wonId = p.id; break; }
  }

  // 库存扣减：非专属规则时递减对应奖品的 remaining_count
  if (!isExclusive && wonId && !won.includes('谢谢')) {
    await pool.query(
      'UPDATE lottery_prizes SET remaining_count = GREATEST(remaining_count - 1, 0) WHERE id = ? AND remaining_count > 0',
      [wonId],
    );
  }

  await pool.query(
    'INSERT INTO lottery_records (id,user_id,username,prize_name,prize_type) VALUES (?,?,?,?,?)',
    ['lr_' + Date.now(), req.user.id, req.user.username, won, 'virtual'],
  );
  res.json({ code: 200, data: { prize: won, won: !won.includes('谢谢') } });
});

app.get('/api/lottery/records', authMiddleware, async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM lottery_records WHERE user_id=? ORDER BY won_at DESC LIMIT 100', [req.user.id]);
  res.json({ code: 200, data: rows });
});

app.get('/api/admin/lottery/records', authMiddleware, adminMiddleware, async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const pageSize = Math.min(parseInt(req.query.pageSize) || 20, 100);
  const offset = (page - 1) * pageSize;
  const [[{ total }]] = await pool.query('SELECT COUNT(*) as total FROM lottery_records');
  const [rows] = await pool.query('SELECT * FROM lottery_records ORDER BY won_at DESC LIMIT ? OFFSET ?', [pageSize, offset]);
  res.json({ code: 200, data: { records: rows, total } });
});

app.put('/api/admin/lottery/prizes/stock', authMiddleware, adminMiddleware, async (req, res) => {
  const { prizeId, delta } = req.body; // delta 为整数，+N 表示补货，-N 表示扣减
  await pool.query('UPDATE lottery_prizes SET remaining_count = GREATEST(remaining_count + ?, 0) WHERE id = ?', [delta, prizeId]);
  res.json({ code: 200, message: '库存已更新' });
});

app.get('/api/admin/lottery/rules', authMiddleware, adminMiddleware, async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM user_lottery_rules');
  res.json({ code: 200, data: rows });
});

app.post('/api/admin/lottery/rules', authMiddleware, adminMiddleware, async (req, res) => {
  const { userId, prizeName, probability, maxDraws, isActive } = req.body;
  await pool.query(
    'INSERT INTO user_lottery_rules (id,user_id,prize_name,probability,max_draws,is_active) VALUES (?,?,?,?,?,?) ON DUPLICATE KEY UPDATE prize_name=?,probability=?,max_draws=?,is_active=?',
    ['ulr_' + Date.now(), userId, prizeName, probability, maxDraws || 3, isActive !== false ? 1 : 0, prizeName, probability, maxDraws || 3, isActive !== false ? 1 : 0],
  );
  res.json({ code: 200, message: '专属规则已设置' });
});

// ==================== 手机使用数据 ====================
app.post('/api/phone-usage/report', authMiddleware, async (req, res) => {
  const { screenTimePerDay, appUsageMinutes, chargeCount, appStartCount, batteryHealth } = req.body;
  await pool.query('INSERT INTO phone_usage (user_id,username,phone,screen_time_per_day,app_usage_minutes,charge_count,app_start_count,battery_health,data_updated_at) VALUES (?,?,?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE screen_time_per_day=?,app_usage_minutes=?,charge_count=?,app_start_count=?,battery_health=?,data_updated_at=NOW()', [req.user.id, req.user.username, req.user.phone, screenTimePerDay, appUsageMinutes, chargeCount, appStartCount, batteryHealth, screenTimePerDay, appUsageMinutes, chargeCount, appStartCount, batteryHealth]);
  res.json({ code: 200, message: 'ok' });
});

app.get('/api/admin/phone-usage', authMiddleware, adminMiddleware, async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM phone_usage');
  res.json({ code: 200, data: rows });
});

// ==================== 相册 ====================
app.get('/api/album/:userId', authMiddleware, async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM album_items WHERE user_id=? ORDER BY added_at DESC', [req.params.userId]);
  res.json({ code: 200, data: rows });
});

app.post('/api/album', authMiddleware, async (req, res) => {
  const { uri, type, permission } = req.body;
  await pool.query('INSERT INTO album_items (id,user_id,uri,type,permission) VALUES (?,?,?,?,?)', ['alb_' + Date.now(), req.user.id, uri, type || 'image', permission || 'friends_only']);
  res.json({ code: 200, message: '已添加' });
});

// ==================== 签到 ====================
app.post('/api/checkin', authMiddleware, async (req, res) => {
  const today = new Date().toISOString().slice(0, 10);
  const [existing] = await pool.query('SELECT * FROM checkin_records WHERE user_id=? AND checkin_date=?', [req.user.id, today]);
  if (existing.length > 0) return res.json({ code: 400, message: '今日已签到' });
  // 计算连续天数
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  const [prev] = await pool.query('SELECT streak FROM checkin_records WHERE user_id=? AND checkin_date=?', [req.user.id, yesterday]);
  const streak = prev.length > 0 ? prev[0].streak + 1 : 1;
  await pool.query('INSERT INTO checkin_records (id,user_id,checkin_date,streak) VALUES (?,?,?,?)', ['ci_' + Date.now(), req.user.id, today, streak]);
  res.json({ code: 200, data: { success: true, streak, totalChances: streak } });
});

// ==================== 访客记录 ====================
app.post('/api/visit/:ownerId', authMiddleware, async (req, res) => {
  if (req.user.id !== req.params.ownerId) {
    await pool.query('INSERT INTO visit_records (id,owner_id,visitor_id,visitor_name) VALUES (?,?,?,?)', ['vr_' + Date.now(), req.params.ownerId, req.user.id, req.user.username]);
    // WS桥接：访客通知被访问者
    wsSendTo(req.params.ownerId, { type: 'visit:new', ownerId: req.params.ownerId, visitorId: req.user.id, visitorName: req.user.username, visitedAt: new Date().toISOString() });
  }
  res.json({ code: 200, message: 'ok' });
});

app.get('/api/visit/:ownerId', authMiddleware, async (req, res) => {
  const [[{ total }]] = await pool.query('SELECT COUNT(*) as total FROM visit_records WHERE owner_id=?', [req.params.ownerId]);
  const [list] = await pool.query('SELECT visitor_id as visitorId, visitor_name as visitorName, visited_at as visitedAt FROM visit_records WHERE owner_id=? ORDER BY visited_at DESC LIMIT 50', [req.params.ownerId]);
  res.json({ code: 200, data: { totalVisits: total, visitorList: list } });
});

// ==================== 编辑资料 ====================
app.get('/api/profile/:userId', authMiddleware, async (req, res) => {
  const [users] = await pool.query('SELECT id as userId,username,avatar,bio,birthday,last_birthday_edit as lastBirthdayEdit,gender,location,level,total_minutes as totalMinutes,created_at as createdAt FROM users WHERE id=?', [req.params.userId]);
  if (users.length === 0) return res.json({ code: 404, message: '未找到' });
  res.json({ code: 200, data: users[0] });
});

app.put('/api/profile/:userId', authMiddleware, async (req, res) => {
  const { bio, birthday, gender, location, avatar } = req.body;
  await pool.query('UPDATE users SET bio=?,birthday=?,gender=?,location=?,avatar=? WHERE id=?', [bio, birthday, gender, location, avatar, req.params.userId]);
  res.json({ code: 200, message: '更新成功' });
});

// ==================== 上传 ====================
const multer = require('multer');
const upload = multer({ dest: '/tmp/ing_uploads/', limits: { fileSize: 10 * 1024 * 1024 } });
app.post('/api/upload', authMiddleware, upload.single('file'), (req, res) => {
  res.json({ code: 200, data: { uri: req.file.path } });
});

// ==================== 启动 ====================
// ==================== 在线用户 ====================
app.get('/api/online-users', (req, res) => {
  res.json({ code: 200, data: { users: getOnlineUsers(), count: getOnlineCount() } });
});

server.listen(PORT, () => console.log(`[Server] ing-陪伴后端已启动: http://localhost:${PORT} (WebSocket已启用)`));
