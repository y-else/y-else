/**
 * WebSocket 实时通信服务 (v2 — JWT鉴权 + 协议Ping-Pong + 房间 + REST桥接)
 */

const WebSocket = require('ws');
const jwt = require('jsonwebtoken');

const JWT_SECRET = 'ing_companion_secret_key_2024';
const OFFLINE_TIMEOUT = 30000;
const PING_INTERVAL = 20000;       // 服务端主动ping间隔
const PONG_TIMEOUT = 10000;        // 等待pong超时
const HEARTBEAT_ACK_TIMEOUT = 35000; // 客户端应用层心跳超时

const onlineUsers = new Map();
/** 房间：{ roomName -> Set<userId> } */
const rooms = new Map();

// ====== 离线扫描 ======

function startOfflineScanner(wss) {
  setInterval(() => {
    const now = Date.now();
    onlineUsers.forEach((user, userId) => {
      if (now - user.lastHeartbeat > HEARTBEAT_ACK_TIMEOUT) {
        user.isAlive = false;
        user.ws.terminate();
        onlineUsers.delete(userId);
        leaveAllRooms(userId);
        broadcast(wss, { type: 'user:status', userId, status: 'offline', username: user.username });
      }
    });
  }, 15000);
}

// ====== 房间管理 ======

function joinRoom(userId, roomName) {
  if (!rooms.has(roomName)) rooms.set(roomName, new Set());
  rooms.get(roomName).add(userId);
}

function leaveRoom(userId, roomName) {
  const s = rooms.get(roomName);
  if (s) { s.delete(userId); if (s.size === 0) rooms.delete(roomName); }
}

function leaveAllRooms(userId) {
  rooms.forEach((s, name) => { s.delete(userId); if (s.size === 0) rooms.delete(name); });
}

function broadcastToRoom(roomName, data) {
  const members = rooms.get(roomName);
  if (!members) return;
  broadcastToUsers(Array.from(members), data);
}

// ====== 广播与定向 ======

function broadcast(wss, data) {
  const msg = JSON.stringify(data);
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) client.send(msg);
  });
}

function sendTo(userId, data) {
  const user = onlineUsers.get(userId);
  if (user && user.ws.readyState === WebSocket.OPEN) {
    user.ws.send(JSON.stringify(data));
  }
}

function broadcastToUsers(userIds, data) {
  const msg = JSON.stringify(data);
  userIds.forEach((uid) => {
    const user = onlineUsers.get(uid);
    if (user && user.ws.readyState === WebSocket.OPEN) user.ws.send(msg);
  });
}

// ====== 跨实例桥接导出（供 index.js REST端点调用） ======

let _broadcastRef = null;
let _sendToRef = null;
let _broadcastToRoomRef = null;
let _broadcastToUsersRef = null;
let _getOnlineUsersRef = null;
let _getOnlineCountRef = null;

function createSocketServer(httpServer) {
  const wss = new WebSocket.Server({
    server: httpServer,
    path: '/ws',
    // JWT鉴权：连接建立前校验token
    verifyClient: (info, cb) => {
      const url = new URL(info.req.url, 'http://localhost');
      const token = url.searchParams.get('token');
      if (!token) { cb(false, 401, '未登录'); return; }
      try {
        const user = jwt.verify(token, JWT_SECRET);
        info.req._authUser = user; // 存入请求上下文
        cb(true);
      } catch { cb(false, 401, '登录已过期'); }
    },
  });

  // 定时扫描离线用户
  startOfflineScanner(wss);

  // 服务端协议级Ping-Pong
  const pingInterval = setInterval(() => {
    wss.clients.forEach((ws) => {
      if (ws._alive === false) {
        ws.terminate();
        return;
      }
      ws._alive = false;
      ws.ping();
    });
  }, PING_INTERVAL);

  wss.on('close', () => clearInterval(pingInterval));

  wss.on('connection', (ws, req) => {
    const authUser = req._authUser;
    ws._alive = true;
    ws._userId = authUser.id;
    ws._username = authUser.username;
    ws._role = authUser.role || 'family';

    // 响应协议级pong
    ws.on('pong', () => { ws._alive = true; });

    ws.on('message', (raw) => {
      try {
        const data = JSON.parse(raw.toString());
        // 校验消息中的userId必须与认证身份一致（防冒充）
        if (data.userId && data.userId !== authUser.id) return;

        switch (data.type) {
          case 'user:online': {
            const prev = onlineUsers.get(authUser.id);
            onlineUsers.set(authUser.id, {
              ws, userId: authUser.id, username: authUser.username,
              phone: authUser.phone || '', status: 'online', lastHeartbeat: Date.now(),
              role: authUser.role,
            });
            // 加入角色房间
            joinRoom(authUser.id, 'role:' + (authUser.role || 'family'));
            joinRoom(authUser.id, 'user:' + authUser.id); // 个人房间
            broadcast(wss, { type: 'user:status', userId: authUser.id, status: 'online', username: authUser.username });
            // 发送心跳确认
            sendTo(authUser.id, { type: 'heartbeat:ack', serverTime: Date.now() });
            break;
          }
          case 'heartbeat': {
            const user = onlineUsers.get(authUser.id);
            if (user) {
              user.lastHeartbeat = Date.now();
              // 回传心跳确认（客户端据此判断服务端存活）
              ws.send(JSON.stringify({ type: 'heartbeat:ack', serverTime: Date.now() }));
            }
            break;
          }
          case 'location:update':
            // 推送给有绑定关系的在线用户（自己所在的所有房间成员）
            broadcastToRoom('user:' + authUser.id, { type: 'location:update', userId: authUser.id, username: authUser.username, ...data });
            break;
          case 'sos:trigger':
            // 全员紧急广播
            broadcast(wss, { type: 'sos:new', ...data, senderId: authUser.id, senderName: authUser.username });
            break;
          case 'space:newPost':
            // 推送给所有在线用户（动态公开可见）
            broadcast(wss, { type: 'space:newPost', ...data, authorId: authUser.id, authorName: authUser.username });
            break;
          case 'visit:new':
            if (data.ownerId) sendTo(data.ownerId, { type: 'visit:new', ...data, visitorId: authUser.id, visitorName: authUser.username });
            break;
          case 'binding:change':
            if (data.toUserId) sendTo(data.toUserId, { type: 'binding:change', ...data, fromUserId: authUser.id, fromUsername: authUser.username });
            break;
          case 'admin:notify': {
            const { targetUserId, message } = data;
            // 仅管理员可发送
            if (authUser.role !== 'admin') return;
            if (targetUserId) {
              sendTo(targetUserId, { type: 'admin:notify', targetUserId, message, fromAdmin: authUser.username });
            } else {
              // targetUserId为空 → 全员广播
              broadcast(wss, { type: 'admin:notify', message, fromAdmin: authUser.username });
            }
            break;
          }
        }
      } catch {}
    });

    ws.on('close', () => {
      const uid = authUser.id;
      const user = onlineUsers.get(uid);
      // 仅当onlineUsers中记录的ws与此ws一致时才清除（防止重连覆盖）
      if (user && user.ws === ws) {
        onlineUsers.delete(uid);
        leaveAllRooms(uid);
        broadcast(wss, { type: 'user:status', userId: uid, status: 'offline', username: authUser.username });
      }
    });

    ws.on('error', () => {});
  });

  // ====== 导出桥接引用 ======
  _broadcastRef = (data) => broadcast(wss, data);
  _sendToRef = sendTo;
  _broadcastToRoomRef = (room, data) => broadcastToRoom(room, data);
  _broadcastToUsersRef = (userIds, data) => broadcastToUsers(userIds, data);
  _getOnlineUsersRef = () => {
    const list = [];
    onlineUsers.forEach((u) => list.push({ userId: u.userId, username: u.username, phone: u.phone, status: u.status }));
    return list;
  };
  _getOnlineCountRef = () => onlineUsers.size;

  return {
    wss,
    getOnlineUsers: _getOnlineUsersRef,
    getOnlineCount: _getOnlineCountRef,
  };
}

// ====== 供 index.js REST 端点调用的桥接函数 ======

function wsBroadcast(data) { if (_broadcastRef) _broadcastRef(data); }
function wsSendTo(userId, data) { if (_sendToRef) _sendToRef(userId, data); }
function wsBroadcastToRoom(room, data) { if (_broadcastToRoomRef) _broadcastToRoomRef(room, data); }
function wsBroadcastToUsers(userIds, data) { if (_broadcastToUsersRef) _broadcastToUsersRef(userIds, data); }

module.exports = {
  createSocketServer,
  wsBroadcast,
  wsSendTo,
  wsBroadcastToRoom,
  wsBroadcastToUsers,
};
