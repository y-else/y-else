-- =====================================================
-- ing-陪伴 云端数据库完整建表脚本 (MySQL 8.0+)
-- 执行: mysql -u root -p < database.sql
-- =====================================================

CREATE DATABASE IF NOT EXISTS ing_companion DEFAULT CHARSET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ing_companion;

CREATE TABLE users (
  id VARCHAR(64) PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  phone VARCHAR(20) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  avatar VARCHAR(500) DEFAULT NULL,
  role ENUM('family','friend','lover','admin') DEFAULT 'family',
  status ENUM('active','disabled','deleted','pending') DEFAULT 'pending',
  real_name_status ENUM('unverified','pending','verified','rejected') DEFAULT 'unverified',
  bio VARCHAR(500) DEFAULT '',
  birthday DATE DEFAULT NULL,
  last_birthday_edit DATETIME DEFAULT NULL,
  gender ENUM('male','female','hidden') DEFAULT 'hidden',
  location VARCHAR(200) DEFAULT '',
  level INT DEFAULT 1,
  total_minutes INT DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  last_active DATETIME DEFAULT CURRENT_TIMESTAMP,
  -- 安全加固字段
  login_attempts INT DEFAULT 0 COMMENT '连续登录失败次数',
  locked_until DATETIME DEFAULT NULL COMMENT '锁定截止时间',
  old_password VARCHAR(255) DEFAULT NULL COMMENT '轮换过渡期旧密码（上一次）',
  old_password_2 VARCHAR(255) DEFAULT NULL COMMENT '轮换过渡期旧密码（上上次）',
  password_updated_at DATETIME DEFAULT NULL COMMENT '上次改密时间',
  INDEX idx_phone (phone),
  INDEX idx_status (status)
) ENGINE=InnoDB;

INSERT INTO users (id, username, phone, password, role, status) VALUES ('admin_001', '管理员', '00000001', '030302040015', 'admin', 'active');

CREATE TABLE real_name_records (
  id VARCHAR(64) PRIMARY KEY,
  user_id VARCHAR(64) NOT NULL,
  real_name VARCHAR(50) NOT NULL,
  id_card_number VARCHAR(20) NOT NULL,
  status ENUM('pending','verified','rejected') DEFAULT 'pending',
  front_image_uri VARCHAR(500) DEFAULT NULL,
  back_image_uri VARCHAR(500) DEFAULT NULL,
  submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  verified_at DATETIME DEFAULT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE sos_records (
  id VARCHAR(64) PRIMARY KEY,
  user_id VARCHAR(64) NOT NULL,
  username VARCHAR(50) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  latitude DOUBLE NOT NULL,
  longitude DOUBLE NOT NULL,
  address VARCHAR(500) DEFAULT NULL,
  status ENUM('active','resolved') DEFAULT 'active',
  sos_status ENUM('pending','processing','resolved','false_alarm','cancelled') DEFAULT 'pending',
  is_silent TINYINT(1) DEFAULT 0,
  triggered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME DEFAULT NULL,
  resolved_by VARCHAR(64) DEFAULT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_status (sos_status),
  INDEX idx_time (triggered_at)
) ENGINE=InnoDB;

CREATE TABLE location_history (
  id VARCHAR(64) PRIMARY KEY,
  user_id VARCHAR(64) NOT NULL,
  latitude DOUBLE NOT NULL,
  longitude DOUBLE NOT NULL,
  address VARCHAR(500) DEFAULT NULL,
  accuracy DOUBLE DEFAULT NULL,
  speed DOUBLE DEFAULT NULL,
  recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_time (user_id, recorded_at)
) ENGINE=InnoDB;

CREATE TABLE phone_usage (
  user_id VARCHAR(64) PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  screen_time_per_day INT DEFAULT 0,
  app_usage_minutes INT DEFAULT 0,
  charge_count INT DEFAULT 0,
  app_start_count INT DEFAULT 0,
  app_stop_count INT DEFAULT 0,
  last_charge_at DATETIME DEFAULT NULL,
  battery_health VARCHAR(20) DEFAULT '未知',
  data_updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE feedbacks (
  id VARCHAR(64) PRIMARY KEY,
  user_id VARCHAR(64) NOT NULL,
  username VARCHAR(50) NOT NULL,
  content TEXT NOT NULL,
  contact VARCHAR(100) DEFAULT '',
  status ENUM('pending','resolved') DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE announcements (
  id VARCHAR(64) PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  content TEXT NOT NULL,
  level ENUM('normal','important','urgent') DEFAULT 'normal',
  published_by VARCHAR(50) NOT NULL,
  published_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE lottery_config (
  id VARCHAR(64) PRIMARY KEY,
  status ENUM('active','inactive') DEFAULT 'inactive',
  max_draws_per_day INT DEFAULT 3,
  start_at DATETIME DEFAULT NULL,
  end_at DATETIME DEFAULT NULL,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;
INSERT INTO lottery_config VALUES ('cfg_1','active',3,NOW(),DATE_ADD(NOW(),INTERVAL 365 DAY),NOW());

CREATE TABLE lottery_prizes (
  id VARCHAR(64) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  type ENUM('virtual','physical') DEFAULT 'virtual',
  total_count INT DEFAULT 10,
  remaining_count INT DEFAULT 10,
  probability DECIMAL(4,3) DEFAULT 0.100
) ENGINE=InnoDB;
INSERT INTO lottery_prizes VALUES ('pz_1','手机一部','physical',3,3,0.01),('pz_2','耳机一副','physical',10,10,0.05),('pz_3','VIP会员30天','virtual',50,50,0.15),('pz_4','优惠券5元','virtual',100,100,0.20),('pz_5','谢谢参与','virtual',9999,9999,0.59);

CREATE TABLE user_lottery_rules (
  id VARCHAR(64) PRIMARY KEY,
  user_id VARCHAR(64) NOT NULL UNIQUE,
  prize_name VARCHAR(100) NOT NULL,
  probability DECIMAL(4,3) DEFAULT 0.500,
  max_draws INT DEFAULT 3,
  is_active TINYINT(1) DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE lottery_records (
  id VARCHAR(64) PRIMARY KEY,
  user_id VARCHAR(64) NOT NULL,
  username VARCHAR(50) NOT NULL,
  prize_name VARCHAR(100) NOT NULL,
  prize_type ENUM('virtual','physical') DEFAULT 'virtual',
  won_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE checkin_records (
  id VARCHAR(64) PRIMARY KEY,
  user_id VARCHAR(64) NOT NULL,
  checkin_date DATE NOT NULL,
  streak INT DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_date (user_id, checkin_date)
) ENGINE=InnoDB;

CREATE TABLE space_posts (
  id VARCHAR(64) PRIMARY KEY,
  user_id VARCHAR(64) NOT NULL,
  author_name VARCHAR(50) NOT NULL,
  content TEXT,
  visibility ENUM('public','friends_only','private') DEFAULT 'friends_only',
  media JSON DEFAULT NULL,
  likes INT DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_time (user_id, created_at DESC)
) ENGINE=InnoDB;

CREATE TABLE album_items (
  id VARCHAR(64) PRIMARY KEY,
  user_id VARCHAR(64) NOT NULL,
  uri VARCHAR(500) NOT NULL,
  type ENUM('image','video') DEFAULT 'image',
  permission ENUM('public','friends_only','private') DEFAULT 'friends_only',
  added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE visit_records (
  id VARCHAR(64) PRIMARY KEY,
  owner_id VARCHAR(64) NOT NULL,
  visitor_id VARCHAR(64) NOT NULL,
  visitor_name VARCHAR(50) NOT NULL,
  visited_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (visitor_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_owner (owner_id, visited_at DESC),
  INDEX idx_visitor (visitor_id)
) ENGINE=InnoDB;

CREATE TABLE admin_audit_logs (
  id VARCHAR(64) PRIMARY KEY,
  admin_id VARCHAR(64) NOT NULL,
  admin_name VARCHAR(50) NOT NULL,
  action VARCHAR(50) NOT NULL,
  target_user_id VARCHAR(64) DEFAULT NULL,
  target_username VARCHAR(50) DEFAULT NULL,
  detail TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_admin (admin_id, created_at DESC),
  INDEX idx_target (target_user_id)
) ENGINE=InnoDB;

CREATE TABLE app_versions (
  id VARCHAR(64) PRIMARY KEY,
  version VARCHAR(20) NOT NULL,
  build_number INT NOT NULL,
  release_notes TEXT,
  download_url VARCHAR(500) DEFAULT NULL,
  force_update TINYINT(1) DEFAULT 0,
  released_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
INSERT INTO app_versions VALUES ('v1','1.0.0',1,'首次发布',NULL,0,NOW());

CREATE TABLE admin_tokens (
  admin_id VARCHAR(64) PRIMARY KEY,
  token VARCHAR(100) NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
INSERT INTO admin_tokens VALUES ('admin_001','admin_token_secure_2024',NOW());

-- 绑定关系表（index.js /api/bindings 引用，v2审计补全）
CREATE TABLE bindings (
  id VARCHAR(64) PRIMARY KEY,
  from_user_id VARCHAR(64) NOT NULL,
  to_user_id VARCHAR(64) NOT NULL,
  type ENUM('family','friend','lover') NOT NULL DEFAULT 'friend',
  status ENUM('pending','accepted','rejected','cancelled') NOT NULL DEFAULT 'pending',
  message VARCHAR(500) DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (to_user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_from_user (from_user_id, status),
  INDEX idx_to_user (to_user_id, status),
  INDEX idx_type_status (type, status)
) ENGINE=InnoDB;

-- 内容举报表
CREATE TABLE content_reports (
  id VARCHAR(64) PRIMARY KEY,
  reporter_id VARCHAR(64) NOT NULL,
  reporter_name VARCHAR(50) NOT NULL,
  target_type ENUM('post','comment','user','photo') NOT NULL,
  target_id VARCHAR(64) NOT NULL,
  reason VARCHAR(500) NOT NULL,
  status ENUM('pending','reviewed','dismissed') DEFAULT 'pending',
  reviewed_by VARCHAR(50) DEFAULT NULL,
  review_note VARCHAR(500) DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  reviewed_at DATETIME DEFAULT NULL,
  FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_status (status),
  INDEX idx_target (target_type, target_id)
) ENGINE=InnoDB;

CREATE TABLE verification_codes (
  id VARCHAR(64) PRIMARY KEY,
  phone VARCHAR(20) NOT NULL,
  code VARCHAR(6) NOT NULL,
  type ENUM('register','reset_password') NOT NULL,
  is_used TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_phone_type (phone, type, is_used)
) ENGINE=InnoDB;

-- 通知消息表（系统通知持久化）
CREATE TABLE notifications (
  id VARCHAR(64) PRIMARY KEY,
  from_user_id VARCHAR(64) DEFAULT NULL,
  from_username VARCHAR(50) DEFAULT NULL,
  to_user_id VARCHAR(64) NOT NULL,
  to_username VARCHAR(50) NOT NULL,
  type VARCHAR(30) NOT NULL COMMENT 'bind_request|bind_accepted|bind_rejected|system|admin_notify',
  relation_type VARCHAR(20) DEFAULT NULL,
  message TEXT NOT NULL,
  is_read TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (to_user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_to_user_unread (to_user_id, is_read, created_at DESC)
) ENGINE=InnoDB;

-- 已注销用户留存表（保留30天便于恢复）
CREATE TABLE deactivated_users (
  user_id VARCHAR(64) PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  reason VARCHAR(500) DEFAULT '',
  deactivated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  scheduled_purge_at DATETIME DEFAULT (DATE_ADD(CURRENT_TIMESTAMP, INTERVAL 30 DAY)),
  INDEX idx_purge (scheduled_purge_at)
) ENGINE=InnoDB;
