/**
 * 认证状态管理 Context
 * 功能：登录/登出、多账号切换、免密登录、实名认证状态、版本更新重登
 * 全局权限上下文控制未实名功能限制
 */

import React, { createContext, useContext, useReducer, useEffect, useCallback, type ReactNode } from 'react';

import type { UserProfile, SavedAccount, RealNameInfo, AuthLog, LoginAction } from '../types';
import * as storage from '../services/storage';
import * as authApi from '../services/auth';
import { appendAuthLog } from '../services/storage';
import { isAdminPhone } from '../services/apiConfig';

// 从 app.json 动态获取当前版本号
import appJson from '../../app.json';
const CURRENT_APP_VERSION = appJson.expo.version;

// ---- State ----

interface AuthState {
  user: UserProfile | null;
  isLoggedIn: boolean;
  savedAccounts: SavedAccount[];
  realNameInfo: RealNameInfo | null;
  isRealNameVerified: boolean;
  isLoading: boolean;
  privacyAgreed: boolean;
  lastAppVersion: string | null;
}

const initialState: AuthState = {
  user: null,
  isLoggedIn: false,
  savedAccounts: [],
  realNameInfo: null,
  isRealNameVerified: false,
  isLoading: true,
  privacyAgreed: false,
  lastAppVersion: null,
};

// ---- Actions ----

type AuthAction =
  | { type: 'RESTORE_SESSION'; user: UserProfile; token: string; realName: RealNameInfo | null; savedAccounts: SavedAccount[]; privacyAgreed: boolean; lastVersion: string | null }
  | { type: 'LOGIN'; user: UserProfile; token: string }
  | { type: 'LOGOUT' }
  | { type: 'UPDATE_USER'; user: Partial<UserProfile> }
  | { type: 'SET_REAL_NAME'; info: RealNameInfo }
  | { type: 'SWITCH_ACCOUNT'; user: UserProfile; token: string }
  | { type: 'REMOVE_ACCOUNT'; userId: string }
  | { type: 'SET_PRIVACY_AGREED' }
  | { type: 'SET_LAST_VERSION'; version: string }
  | { type: 'SET_LOADING'; isLoading: boolean };

function authReducer(state: AuthState, action: AuthAction): AuthState {
  switch (action.type) {
    case 'RESTORE_SESSION':
      return {
        ...state,
        user: action.user,
        isLoggedIn: true,
        savedAccounts: action.savedAccounts,
        realNameInfo: action.realName,
        isRealNameVerified: action.realName?.status === 'verified',
        privacyAgreed: action.privacyAgreed,
        lastAppVersion: action.lastVersion,
        isLoading: false,
      };
    case 'LOGIN': {
      const existingAccount = state.savedAccounts.find((a) => a.userId === action.user.id);
      const newAccount: SavedAccount = {
        userId: action.user.id,
        phone: action.user.phone,
        username: action.user.username,
        avatar: action.user.avatar,
        token: action.token,
        lastLoginAt: new Date().toISOString(),
        passwordChanged: false, // 登录成功即表示密码有效，清除标记
      };
      const updated = [...state.savedAccounts];
      const idx = updated.findIndex((a) => a.userId === action.user.id);
      if (idx >= 0) updated[idx] = newAccount;
      else updated.push(newAccount);
      return {
        ...state,
        user: action.user,
        isLoggedIn: true,
        savedAccounts: updated,
        isLoading: false,
      };
    }
    case 'LOGOUT':
      return {
        ...state,
        user: null,
        isLoggedIn: false,
        realNameInfo: null,
        isRealNameVerified: false,
        isLoading: false,
      };
    case 'UPDATE_USER':
      if (!state.user) return state;
      return {
        ...state,
        user: { ...state.user, ...action.user, updatedAt: new Date().toISOString() },
      };
    case 'SET_REAL_NAME':
      return {
        ...state,
        realNameInfo: action.info,
        isRealNameVerified: action.info.status === 'verified',
      };
    case 'SWITCH_ACCOUNT':
      return {
        ...state,
        user: action.user,
        isLoggedIn: true,
        realNameInfo: null, // 切换后需重新获取实名状态
        isRealNameVerified: false,
        isLoading: false,
      };
    case 'REMOVE_ACCOUNT':
      return {
        ...state,
        savedAccounts: state.savedAccounts.filter((a) => a.userId !== action.userId),
      };
    case 'SET_PRIVACY_AGREED':
      return { ...state, privacyAgreed: true };
    case 'SET_LAST_VERSION':
      return { ...state, lastAppVersion: action.version };
    case 'SET_LOADING':
      return { ...state, isLoading: action.isLoading };
    default:
      return state;
  }
}

// ---- Context ----

interface AuthContextValue {
  state: AuthState;
  login: (phone: string, password: string, role?: string) => Promise<{ success: boolean; message: string }>;
  logout: () => Promise<void>;
  register: (params: { phone: string; password: string; username: string; smsCode: string; avatarUri?: string }) => Promise<{ success: boolean; message: string }>;
  switchAccount: (account: SavedAccount) => Promise<void>;
  /** 从切换页面直接切换（同时更新已保存账号的lastLoginAt） */
  switchToAccount: (account: SavedAccount) => Promise<{ success: boolean; message: string }>;
  removeSavedAccount: (userId: string) => Promise<void>;
  submitRealName: (params: { realName: string; idCardNumber: string; frontImageUri?: string; backImageUri?: string }) => Promise<{ success: boolean; message: string }>;
  checkRealNameStatus: () => Promise<void>;
  agreePrivacy: () => Promise<void>;
  updateLastVersion: (version: string) => Promise<void>;
  forceReLogin: () => Promise<void>;
  /** 检查是否需要版本更新后强制重登 */
  checkVersionAndForceRelogin: () => Promise<boolean>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

// ---- Provider ----

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(authReducer, initialState);

  // 启动时恢复登录态（免密登录）
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const userId = await storage.getCurrentUserId();
        const accounts = await storage.getSavedAccounts();
        const privacyAgreed = await storage.getPrivacyAgreed();
        const lastVersion = await storage.getLastAppVersion();

        if (cancelled) return;

        if (userId) {
          const account = accounts.find((a) => a.userId === userId);
          if (account) {
            const isAdmin = isAdminPhone(account.phone);

            if (isAdmin) {
              // 管理员：直接从已保存的账号数据恢复（已通过密码验证才保存的）
              const adminUser: UserProfile = {
                id: account.userId,
                username: account.username,
                phone: account.phone,
                avatar: account.avatar,
                role: 'admin',
                status: 'active',
                createdAt: account.lastLoginAt,
                updatedAt: new Date().toISOString(),
              };
              const token = account.token || 'admin_token_' + Date.now();
              const adminRealName: RealNameInfo = {
                userId: account.userId,
                realName: '系统管理员',
                idCardNumber: '000000000000000000',
                status: 'verified',
                submittedAt: new Date().toISOString(),
                verifiedAt: new Date().toISOString(),
                frontImageUri: null,
                backImageUri: null,
              };
              if (!cancelled) {
                dispatch({ type: 'RESTORE_SESSION', user: adminUser, token, realName: adminRealName, savedAccounts: accounts, privacyAgreed, lastVersion });
              }
              return;
            }

            // 普通用户：通过 authApi.login + sessionToken 恢复
            const resp = await authApi.login({
              phone: account.phone,
              password: '',
              role: undefined,
              sessionToken: account.token,
            });

            if (!cancelled && resp.code === 200 && resp.data) {
              let realName: RealNameInfo | null = null;
              try {
                const rnResp = await authApi.getRealNameStatus(userId);
                if (rnResp.data) realName = rnResp.data;
              } catch { /* 静默 */ }

              if (!cancelled) {
                dispatch({ type: 'RESTORE_SESSION', user: resp.data.user, token: resp.data.token, realName, savedAccounts: accounts, privacyAgreed, lastVersion });
              }
              return;
            }
          }
        }
        if (!cancelled) {
          dispatch({ type: 'SET_LOADING', isLoading: false });
        }
      } catch {
        if (!cancelled) {
          dispatch({ type: 'SET_LOADING', isLoading: false });
        }
      }
    })();
    return () => { cancelled = true; };
  }, []);

  // ---- 操作日志 ----

  const recordLog = useCallback(async (action: LoginAction, userId: string, phone: string, detail: string, success: boolean) => {
    const log: AuthLog = {
      id: 'log_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
      userId,
      phone,
      action,
      ip: '0.0.0.0',
      deviceInfo: 'React Native (Android)',
      timestamp: new Date().toISOString(),
      success,
      detail,
    };
    await appendAuthLog(log);
  }, []);

  // ---- 登录 ----

  const login = useCallback(async (phone: string, password: string, role?: string) => {
    const resp = await authApi.login({ phone, password, role: role as 'admin' | undefined });
    if (resp.code === 200 && resp.data) {
      dispatch({ type: 'LOGIN', user: resp.data.user, token: resp.data.token });
      await storage.saveAccount({
        userId: resp.data.user.id,
        phone: resp.data.user.phone,
        username: resp.data.user.username,
        avatar: resp.data.user.avatar,
        token: resp.data.token,
        lastLoginAt: new Date().toISOString(),
      });
      await storage.setCurrentUserId(resp.data.user.id);
      // 管理员免实名认证 — 自动设置为已认证
      if (resp.data.user.role === 'admin') {
        const adminRealName: RealNameInfo = {
          userId: resp.data.user.id,
          realName: '系统管理员',
          idCardNumber: '000000000000000000',
          status: 'verified',
          submittedAt: new Date().toISOString(),
          verifiedAt: new Date().toISOString(),
          frontImageUri: null,
          backImageUri: null,
        };
        dispatch({ type: 'SET_REAL_NAME', info: adminRealName });
      } else {
        // 普通用户登录后恢复实名认证状态（修复：永久保持）
        try {
          const rnResp = await authApi.getRealNameStatus(resp.data.user.id);
          if (rnResp.data) {
            dispatch({ type: 'SET_REAL_NAME', info: rnResp.data });
          }
        } catch { /* 静默 */ }
      }
      await recordLog('login', resp.data.user.id, phone, resp.message, true);
      return { success: true, message: resp.message };
    }
    await recordLog('login', '', phone, resp.message, false);
    return { success: false, message: resp.message };
  }, [recordLog]);

  // ---- 登出 ----

  const logout = useCallback(async () => {
    if (state.user) {
      await recordLog('logout', state.user.id, state.user.phone, '用户登出', true);
      await storage.setCurrentUserId(null);
      // 管理员登出时清除密令，防止泄露
      if (state.user.role === 'admin') {
        try {
          const { clearToken } = await import('../services/adminToken');
          await clearToken();
        } catch { /* 静默 */ }
      }
    }
    dispatch({ type: 'LOGOUT' });
  }, [state.user, recordLog]);

  // ---- 注册 ----

  const register = useCallback(async (params: { phone: string; password: string; username: string; smsCode: string; avatarUri?: string }) => {
    const resp = await authApi.register(params);
    if (resp.code === 200 && resp.data) {
      await recordLog('register', resp.data.userId, params.phone, `用户注册: ${params.username}`, true);
      return { success: true, message: resp.message };
    }
    await recordLog('register', '', params.phone, `注册失败: ${resp.message}`, false);
    return { success: false, message: resp.message };
  }, [recordLog]);

  // ---- 切换账号 ----

  const switchAccount = useCallback(async (account: SavedAccount) => {
    const isAdmin = isAdminPhone(account.phone);

    if (isAdmin) {
      // 管理员直接从已保存数据恢复（已通过密码验证才保存的）
      const adminUser: UserProfile = {
        id: account.userId,
        username: account.username,
        phone: account.phone,
        avatar: account.avatar,
        role: 'admin',
        status: 'active',
        createdAt: account.lastLoginAt,
        updatedAt: new Date().toISOString(),
      };
      const token = account.token || 'admin_token_' + Date.now();
      await storage.saveAccount({ ...account, lastLoginAt: new Date().toISOString() });
      await storage.setCurrentUserId(account.userId);
      dispatch({ type: 'SWITCH_ACCOUNT', user: adminUser, token });
      dispatch({
        type: 'SET_REAL_NAME',
        info: {
          userId: account.userId,
          realName: '系统管理员',
          idCardNumber: '000000000000000000',
          status: 'verified',
          submittedAt: new Date().toISOString(),
          verifiedAt: new Date().toISOString(),
          frontImageUri: null,
          backImageUri: null,
        },
      });
      await recordLog('login', account.userId, account.phone, '切换管理员账号', true);
      return;
    }

    // 普通用户通过 authApi.login + sessionToken 恢复
    const resp = await authApi.login({
      phone: account.phone,
      password: '',
      role: undefined,
      sessionToken: account.token,
    });
    if (resp.code === 200 && resp.data) {
      await storage.saveAccount({ ...account, lastLoginAt: new Date().toISOString() });
      await storage.setCurrentUserId(account.userId);
      dispatch({ type: 'SWITCH_ACCOUNT', user: resp.data.user, token: resp.data.token });

      if (resp.data.user.role !== 'admin') {
        const rnResp = await authApi.getRealNameStatus(account.userId);
        if (rnResp.data) {
          dispatch({ type: 'SET_REAL_NAME', info: rnResp.data });
        }
      } else {
        dispatch({
          type: 'SET_REAL_NAME',
          info: {
            userId: resp.data.user.id,
            realName: '系统管理员',
            idCardNumber: '000000000000000000',
            status: 'verified',
            submittedAt: new Date().toISOString(),
            verifiedAt: new Date().toISOString(),
            frontImageUri: null,
            backImageUri: null,
          },
        });
      }
      await recordLog('login', account.userId, account.phone, '切换账号登录', true);
    }
  }, [recordLog]);

  // ---- 从切换页面直接切换（供 AccountSwitchScreen 使用） ----

  const switchToAccount = useCallback(async (account: SavedAccount): Promise<{ success: boolean; message: string }> => {
    // 检查是否需要重新登录
    if (account.passwordChanged) {
      return { success: false, message: '密码已变更，请重新输入密码登录' };
    }

    const isAdmin = isAdminPhone(account.phone);

    if (isAdmin) {
      // 管理员不支持免密切换
      return { success: false, message: '管理员不支持免密切换，请重新输入密码登录' };
    }

    // 普通用户通过 sessionToken 恢复
    const resp = await authApi.login({
      phone: account.phone,
      password: '',
      role: undefined,
      sessionToken: account.token,
    });

    if (resp.code === 200 && resp.data) {
      await storage.saveAccount({ ...account, lastLoginAt: new Date().toISOString(), passwordChanged: false });
      await storage.setCurrentUserId(account.userId);
      dispatch({ type: 'SWITCH_ACCOUNT', user: resp.data.user, token: resp.data.token });

      // 获取实名状态
      try {
        const rnResp = await authApi.getRealNameStatus(account.userId);
        if (rnResp.data) {
          dispatch({ type: 'SET_REAL_NAME', info: rnResp.data });
        }
      } catch { /* 静默 */ }

      await recordLog('login', account.userId, account.phone, '切换账号登录', true);
      return { success: true, message: '切换成功' };
    }

    return { success: false, message: resp.message || '切换失败，请重新登录' };
  }, [recordLog]);

  // ---- 移除保存的账号 ----

  const removeSavedAccount = useCallback(async (userId: string) => {
    await storage.removeAccount(userId);
    // 同步清除该用户的公告已读记录
    try {
      const { clearReadHistory } = await import('../services/announcement');
      await clearReadHistory(userId);
    } catch { /* 静默 */ }
    dispatch({ type: 'REMOVE_ACCOUNT', userId });
  }, []);

  // ---- 实名认证 ----

  const submitRealName = useCallback(async (params: { realName: string; idCardNumber: string; frontImageUri?: string; backImageUri?: string }) => {
    if (!state.user) return { success: false, message: '未登录' };
    const resp = await authApi.submitRealName(state.user.id, params);
    if (resp.code === 200 && resp.data) {
      dispatch({ type: 'SET_REAL_NAME', info: resp.data });
      await recordLog('realname_submit', state.user.id, state.user.phone, `实名认证提交: ${params.realName}`, true);
      return { success: true, message: resp.message };
    }
    return { success: false, message: resp.message };
  }, [state.user, recordLog]);

  const checkRealNameStatus = useCallback(async () => {
    if (!state.user) return;
    const resp = await authApi.getRealNameStatus(state.user.id);
    if (resp.data) {
      dispatch({ type: 'SET_REAL_NAME', info: resp.data });
    }
  }, [state.user]);

  // ---- 隐私政策 ----

  const agreePrivacy = useCallback(async () => {
    await storage.setPrivacyAgreed(CURRENT_APP_VERSION);
    dispatch({ type: 'SET_PRIVACY_AGREED' });
  }, []);

  // ---- 版本管理 ----

  const updateLastVersion = useCallback(async (version: string) => {
    await storage.setLastAppVersion(version);
    dispatch({ type: 'SET_LAST_VERSION', version });
  }, []);

  // 版本更新后强制重新登录
  const forceReLogin = useCallback(async () => {
    await storage.clearAuthData();
    dispatch({ type: 'LOGOUT' });
  }, []);

  // 检查版本号：如果存储的版本与当前版本不同，强制重新登录
  const checkVersionAndForceRelogin = useCallback(async (): Promise<boolean> => {
    const lastVersion = await storage.getLastAppVersion();
    if (lastVersion && lastVersion !== CURRENT_APP_VERSION) {
      await forceReLogin();
      return true;
    }
    return false;
  }, [forceReLogin]);

  return (
    <AuthContext.Provider
      value={{
        state,
        login,
        logout,
        register,
        switchAccount,
        switchToAccount,
        removeSavedAccount,
        submitRealName,
        checkRealNameStatus,
        agreePrivacy,
        updateLastVersion,
        forceReLogin,
        checkVersionAndForceRelogin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// ---- Hook ----

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

export default AuthContext;
