/**
 * 全局颜色常量 v2
 * 社交陪伴APP — ing 视觉规范（保持向后兼容）
 */

const Colors = {
  // 品牌主色
  primary: '#4A90E2',

  // 角色色
  family: '#5CB85C',
  friend: '#F0AD4E',
  lover: '#E74C3C',
  admin: '#7B68EE',

  // 背景色
  bgPrimary: '#F5F6F8',
  bgWhite: '#FFFFFF',

  // 文字色
  textPrimary: '#1A1A2E',
  textSecondary: '#5A5A72',
  textHint: '#999999',

  // 分割线
  divider: '#E8E9ED',

  // 状态色（新增）
  success: '#52C41A',
  warning: '#FAAD14',
  error: '#FF4D4F',

  // 功能色
  white: '#FFFFFF',
  black: '#000000',
  transparent: 'transparent',
} as const;

export default Colors;
