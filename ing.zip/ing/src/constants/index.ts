import Colors from './colors';
import Typography from './typography';
import Spacing from './spacing';
import BorderRadius from './borderRadius';

/**
 * 全局样式常量 — 集中导出
 */
const Theme = {
  Colors,
  Typography,
  Spacing,
  BorderRadius,
} as const;

export { Colors, Typography, Spacing, BorderRadius };
export default Theme;
