/**
 * 圆角半径常量
 */

const BorderRadius = {
  /** 输入框圆角 4px */
  input: 4,
  /** 卡片/按钮/弹窗圆角 8px */
  card: 8,
} as const;

export default BorderRadius;
