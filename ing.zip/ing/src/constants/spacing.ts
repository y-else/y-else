/**
 * 间距常量（以 8px 为单位）
 */

const Spacing = {
  /** 4px — 半单位 */
  xs: 4,
  /** 8px — 基础单位 */
  sm: 8,
  /** 12px — 卡片间距 */
  md: 12,
  /** 16px — 左右内边距 / 板块间距 */
  lg: 16,
  /** 24px — 上下内边距 */
  xl: 24,
  /** 32px */
  xxl: 32,
} as const;

export default Spacing;
