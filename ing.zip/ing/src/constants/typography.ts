/**
 * 字体大小常量（pt）
 */

const Typography = {
  title: 18,
  subtitle: 16,
  body: 14,
  caption: 12,
} as const;

export default Typography;
