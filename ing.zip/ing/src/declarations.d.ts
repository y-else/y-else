/**
 * 全局类型声明
 * 解决第三方模块缺少类型声明的问题
 */

declare module '@expo/vector-icons' {
  import { ComponentClass, FunctionComponent } from 'react';
  import { TextStyle, ViewStyle, GestureResponderEvent } from 'react-native';

  interface IconProps {
    name: string;
    size?: number;
    color?: string;
    style?: TextStyle | ViewStyle;
    onPress?: (event: GestureResponderEvent) => void;
  }

  export const Ionicons: React.FC<IconProps>;
  export const MaterialIcons: React.FC<IconProps>;
  export const FontAwesome: React.FC<IconProps>;
  export const MaterialCommunityIcons: React.FC<IconProps>;
  export const Feather: React.FC<IconProps>;
  export const AntDesign: React.FC<IconProps>;
}

declare module 'react-native-safe-area-context' {
  import { ReactNode, ComponentType, Context, Consumer, FC, ForwardRefExoticComponent, RefAttributes } from 'react';
  import { ViewProps } from 'react-native';

  interface SafeAreaProviderProps {
    children?: ReactNode;
    initialMetrics?: object;
  }

  interface SafeAreaViewProps extends ViewProps {
    children?: ReactNode;
    edges?: ('top' | 'bottom' | 'left' | 'right')[];
    mode?: 'padding' | 'margin';
  }

  interface SafeAreaInsets {
    top: number;
    right: number;
    bottom: number;
    left: number;
  }

  interface SafeAreaFrame {
    x: number;
    y: number;
    width: number;
    height: number;
  }

  export const SafeAreaInsetsContext: Context<SafeAreaInsets | null>;
  export const SafeAreaFrameContext: Context<SafeAreaFrame | null>;
  export const SafeAreaConsumer: Consumer<SafeAreaInsets | null>;
  export const SafeAreaContext: Context<SafeAreaInsets | null>;

  export const SafeAreaProvider: FC<SafeAreaProviderProps>;
  export const SafeAreaView: ForwardRefExoticComponent<SafeAreaViewProps & RefAttributes<any>>;
  export function useSafeAreaInsets(): SafeAreaInsets;
  export function useSafeAreaFrame(): SafeAreaFrame;
  export function withSafeAreaInsets<T>(WrappedComponent: ComponentType<T & { insets: SafeAreaInsets }>): ForwardRefExoticComponent<T & RefAttributes<unknown>>;
}

declare module 'expo-location' {
  export interface LocationObject {
    coords: { latitude: number; longitude: number; altitude: number | null; accuracy: number | null; altitudeAccuracy: number | null; heading: number | null; speed: number | null };
    timestamp: number;
    mocked?: boolean;
  }

  export interface LocationGeocodedLocation {
    latitude: number;
    longitude: number;
    altitude?: number | null;
    accuracy?: number | null;
  }

  export interface LocationGeocodedAddress {
    street?: string;
    city?: string;
    region?: string;
    country?: string;
    postalCode?: string;
    name?: string;
    isoCountryCode?: string;
  }

  export interface LocationTaskResult {
    locations: LocationObject[];
  }

  export namespace Accuracy {
    const Lowest: number;
    const Low: number;
    const Balanced: number;
    const High: number;
    const Highest: number;
    const BestForNavigation: number;
  }

  export namespace LocationAccuracy {
    const Lowest: number;
    const Low: number;
    const Balanced: number;
    const High: number;
    const Highest: number;
    const BestForNavigation: number;
  }

  export interface LocationOptions {
    accuracy?: number;
    timeInterval?: number;
    distanceInterval?: number;
  }

  export interface LocationTaskOptions {
    accuracy?: number;
    timeInterval?: number;
    distanceInterval?: number;
    foregroundService?: {
      notificationTitle: string;
      notificationBody: string;
      notificationColor?: string;
    };
  }

  export interface LocationSubscription {
    remove: () => void;
  }

  export type PermissionStatus = 'granted' | 'denied' | 'undetermined';
  export type PermissionExpiration = 'never' | number;

  export interface PermissionResponse {
    status: PermissionStatus;
    expires: PermissionExpiration;
    granted: boolean;
    canAskAgain: boolean;
  }

  export function requestForegroundPermissionsAsync(): Promise<PermissionResponse>;
  export function requestBackgroundPermissionsAsync(): Promise<PermissionResponse>;
  export function getForegroundPermissionsAsync(): Promise<PermissionResponse>;
  export function getBackgroundPermissionsAsync(): Promise<PermissionResponse>;
  export function getCurrentPositionAsync(options?: LocationOptions): Promise<LocationObject>;
  export function watchPositionAsync(options: LocationOptions, callback: (location: LocationObject) => void): Promise<LocationSubscription>;
  export function startLocationUpdatesAsync(taskName: string, options?: LocationTaskOptions): Promise<void>;
  export function stopLocationUpdatesAsync(taskName: string): Promise<void>;
  export function hasStartedLocationUpdatesAsync(taskName: string): Promise<boolean>;
  export function reverseGeocodeAsync(location: LocationGeocodedLocation): Promise<LocationGeocodedAddress[]>;
  export function geocodeAsync(address: string): Promise<LocationGeocodedLocation[]>;
  export function enableNetworkProviderAsync(): Promise<void>;
}

declare module 'expo-image-picker' {
  export namespace MediaTypeOptions {
    const All: 'All';
    const Videos: 'Videos';
    const Images: 'Images';
  }

  export interface ImagePickerResult {
    canceled: boolean;
    assets: ImagePickerAsset[];
  }

  export interface ImagePickerAsset {
    uri: string;
    width: number;
    height: number;
    type?: 'image' | 'video';
    fileName?: string;
    fileSize?: number;
    duration?: number;
  }

  export type ImagePickerOptions = {
    mediaTypes?: 'All' | 'Videos' | 'Images';
    allowsEditing?: boolean;
    aspect?: [number, number];
    quality?: number;
    videoMaxDuration?: number;
    allowsMultipleSelection?: boolean;
  };

  export function launchImageLibraryAsync(options?: ImagePickerOptions): Promise<ImagePickerResult>;
  export function launchCameraAsync(options?: ImagePickerOptions): Promise<ImagePickerResult>;
  export function requestMediaLibraryPermissionsAsync(): Promise<{ status: 'granted' | 'denied' | 'undetermined'; granted: boolean; expires: 'never' | number; canAskAgain: boolean }>;
  export function requestCameraPermissionsAsync(): Promise<{ status: 'granted' | 'denied' | 'undetermined'; granted: boolean; expires: 'never' | number; canAskAgain: boolean }>;
}

declare module 'expo-splash-screen' {
  export function preventAutoHideAsync(): Promise<boolean>;
  export function hideAsync(): Promise<boolean>;
}

declare module 'expo-task-manager' {
  export interface TaskManagerTaskExecutor {
    (data: { data: any; error: Error | null }): void;
  }

  export function defineTask(taskName: string, taskExecutor: TaskManagerTaskExecutor): void;
  export function isTaskRegisteredAsync(taskName: string): Promise<boolean>;
  export function unregisterTaskAsync(taskName: string): Promise<void>;
  export function getRegisteredTasksAsync(): Promise<any[]>;
}

declare module 'expo-haptics' {
  export namespace ImpactFeedbackStyle {
    const Light: 'light';
    const Medium: 'medium';
    const Heavy: 'heavy';
  }

  export namespace NotificationFeedbackType {
    const Success: 'success';
    const Warning: 'warning';
    const Error: 'error';
  }

  export function impactAsync(style?: 'light' | 'medium' | 'heavy'): Promise<void>;
  export function notificationAsync(type?: 'success' | 'warning' | 'error'): Promise<void>;
  export function selectionAsync(): Promise<void>;
}

declare module 'expo-status-bar' {
  import React from 'react';
  interface StatusBarProps {
    style?: 'auto' | 'inverted' | 'light' | 'dark';
    animated?: boolean;
    hidden?: boolean;
    backgroundColor?: string;
    translucent?: boolean;
    networkActivityIndicatorVisible?: boolean;
  }
  const StatusBar: React.FC<StatusBarProps>;
  export { StatusBar };
  export default StatusBar;
}

declare module 'expo-modules-core' {
  export interface EventEmitter {
    addListener<T>(eventName: string, listener: (event: T) => void): { remove: () => void };
  }
}

declare module 'react-native-maps' {
  import React from 'react';
  import { ViewProps, ImageURISource } from 'react-native';

  export interface Region {
    latitude: number;
    longitude: number;
    latitudeDelta: number;
    longitudeDelta: number;
  }

  export interface LatLng {
    latitude: number;
    longitude: number;
  }

  export interface MapEvent {
    coordinate: LatLng;
    position: { x: number; y: number };
  }

  export interface MarkerProps {
    coordinate: LatLng;
    title?: string;
    description?: string;
    pinColor?: string;
    opacity?: number;
    children?: React.ReactNode;
    onPress?: (event: MapEvent) => void;
    identifier?: string;
  }

  export interface CalloutProps {
    children?: React.ReactNode;
    onPress?: (event: MapEvent) => void;
  }

  export interface MapViewProps extends ViewProps {
    style?: any;
    initialRegion?: Region;
    region?: Region;
    showsUserLocation?: boolean;
    showsMyLocationButton?: boolean;
    toolbarEnabled?: boolean;
    children?: React.ReactNode;
    onRegionChange?: (region: Region) => void;
    onPress?: (event: MapEvent) => void;
    provider?: 'google' | null;
  }

  export interface PolylineProps {
    coordinates: LatLng[];
    strokeColor?: string;
    strokeWidth?: number;
  }

  export const PROVIDER_GOOGLE: 'google';
  export const PROVIDER_DEFAULT: null;

  const MapView: React.FC<MapViewProps> & {
    animateToRegion: (region: Region, duration?: number) => void;
    fitToCoordinates: (coordinates: LatLng[], options?: any) => void;
  };
  export default MapView;

  export const Marker: React.FC<MarkerProps>;
  export const Callout: React.FC<CalloutProps>;
  export const Polyline: React.FC<PolylineProps>;
}

declare module 'react-native-modal' {
  import React from 'react';
  import { ViewProps } from 'react-native';
  interface ModalProps extends ViewProps {
    isVisible: boolean;
    backdropOpacity?: number;
    animationIn?: string;
    animationOut?: string;
    avoidKeyboard?: boolean;
    children?: React.ReactNode;
    onBackdropPress?: () => void;
    onSwipeComplete?: () => void;
  }
  const Modal: React.FC<ModalProps>;
  export default Modal;
}

// expo-secure-store（可选依赖，动态导入降级）
declare module 'expo-secure-store' {
  export const AFTER_FIRST_UNLOCK: number;
  export const AFTER_FIRST_UNLOCK_THIS_DEVICE_ONLY: number;
  export const ALWAYS: number;
  export const WHEN_UNLOCKED: number;
  export const WHEN_UNLOCKED_THIS_DEVICE_ONLY: number;
  export const ALWAYS_THIS_DEVICE_ONLY: number;

  export function setItemAsync(key: string, value: string, options?: { keychainAccessible?: number; keychainService?: string }): Promise<void>;
  export function getItemAsync(key: string, options?: { keychainService?: string }): Promise<string | null>;
  export function deleteItemAsync(key: string, options?: { keychainService?: string }): Promise<void>;
}

// expo-notifications（可选依赖，动态导入降级）
declare module 'expo-notifications' {
  export type PermissionStatus = 'granted' | 'denied' | 'undetermined';

  export interface NotificationPermissionsStatus {
    status: PermissionStatus;
    granted: boolean;
    expires: 'never' | number;
    canAskAgain: boolean;
  }

  export function getPermissionsAsync(): Promise<NotificationPermissionsStatus>;
  export function requestPermissionsAsync(): Promise<NotificationPermissionsStatus>;
}

declare module '*.png' { const value: string; export default value; }
declare module '*.jpg' { const value: string; export default value; }
declare module '*.svg' { const value: string; export default value; }
declare module '*.css' { const value: any; export default value; }
