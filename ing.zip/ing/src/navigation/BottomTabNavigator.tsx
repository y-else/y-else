/**
 * 底部导航（4项精简版 + 未读角标）
 * 首页 → 通讯录 → 定位 → 我的
 */

import React, { useEffect, useState, useRef } from 'react';
import { StyleSheet, AppState } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography } from '../constants';
import {
  HomeScreen, ContactsScreen, LocationScreen, ProfileScreen,
} from '../screens';
import type { MainStackParamList } from './AppNavigator';
import type { Contact } from '../types';

type TabParamList = {
  Home: undefined;
  Contacts: undefined;
  Location: undefined;
  Profile: undefined;
};

const Tab = createBottomTabNavigator<TabParamList>();

type TabIconName = React.ComponentProps<typeof Ionicons>['name'];

const TAB_CONFIG: {
  name: keyof TabParamList; label: string; icon: TabIconName; activeIcon: TabIconName;
}[] = [
  { name: 'Home', label: '首页', icon: 'home-outline', activeIcon: 'home' },
  { name: 'Contacts', label: '通讯录', icon: 'people-outline', activeIcon: 'people' },
  { name: 'Location', label: '定位', icon: 'location-outline', activeIcon: 'location' },
  { name: 'Profile', label: '我的', icon: 'person-outline', activeIcon: 'person' },
];

const ContactsWrapper: React.FC = () => {
  const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>();
  return <ContactsScreen onNavigateDetail={(contact: Contact) => navigation.navigate('ContactDetail', { contact })} />;
};

const TAB_SCREENS: Record<keyof TabParamList, React.FC> = {
  Home: HomeScreen,
  Contacts: ContactsWrapper,
  Location: LocationScreen,
  Profile: ProfileScreen,
};

/** 用户端角标：首页显示所有未读汇总 */
async function getUserBadgeTotal(): Promise<number> {
  try {
    const { getUserTotalUnread } = await import('../services/unreadBadge');
    return await getUserTotalUnread();
  } catch { return 0; }
}

const BottomTabNavigator: React.FC = () => {
  const [userBadge, setUserBadge] = useState(0);
  const appStateRef = useRef(AppState.currentState);

  const refreshBadges = async () => {
    const total = await getUserBadgeTotal();
    setUserBadge(total);
  };

  useEffect(() => {
    refreshBadges();
    // 每30秒刷新角标
    const interval = setInterval(refreshBadges, 30000);
    return () => clearInterval(interval);
  }, []);

  // 前后台切换时刷新
  useEffect(() => {
    const sub = AppState.addEventListener('change', (state) => {
      if (appStateRef.current.match(/inactive|background/) && state === 'active') {
        refreshBadges();
      }
      appStateRef.current = state;
    });
    return () => sub.remove();
  }, []);

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarActiveTintColor: Colors.primary,
        tabBarInactiveTintColor: Colors.textHint,
        tabBarLabelStyle: styles.label,
      }}
    >
      {TAB_CONFIG.map(({ name, label, icon, activeIcon }) => (
        <Tab.Screen key={name} name={name} component={TAB_SCREENS[name]}
          options={{
            tabBarLabel: label,
            tabBarIcon: ({ color, focused, size }) => (
              <Ionicons name={focused ? activeIcon : icon} size={size} color={color} />
            ),
            tabBarBadge: name === 'Home' && userBadge > 0 ? userBadge : undefined,
            tabBarBadgeStyle: styles.badge,
          }}
        />
      ))}
    </Tab.Navigator>
  );
};

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: Colors.bgWhite,
    borderTopColor: Colors.divider,
    borderTopWidth: StyleSheet.hairlineWidth,
    height: 60,
    paddingTop: 6,
    shadowColor: '#000', shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.04, shadowRadius: 4, elevation: 8,
  },
  label: { fontSize: Typography.caption, marginBottom: 6 },
  badge: {
    backgroundColor: Colors.lover, fontSize: 10, fontWeight: '700',
    minWidth: 18, height: 18, lineHeight: 18,
  },
});

export default BottomTabNavigator;
