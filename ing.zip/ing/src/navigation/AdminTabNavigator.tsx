/**
 * 管理员专属底部标签导航器
 * 4个标签：管理（统计+快捷入口）、用户（列表+审核）、监测（手机使用）、系统（密令+改密）
 */

import React from 'react';
import { StyleSheet } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography } from '../constants';
import {
  AdminDashboardScreen,
  AdminUsersScreen,
  AdminPhoneUsageScreen,
  AdminSettingsScreen,
} from '../screens';
import type { MainStackParamList } from './AppNavigator';

type AdminTabParamList = {
  AdminDashboardTab: undefined;
  AdminUsersTab: undefined;
  AdminMonitorTab: undefined;
  AdminSettingsTab: undefined;
};

const Tab = createBottomTabNavigator<AdminTabParamList>();

type TabIconName = React.ComponentProps<typeof Ionicons>['name'];

const TAB_CONFIG: {
  name: keyof AdminTabParamList;
  label: string;
  icon: TabIconName;
  activeIcon: TabIconName;
}[] = [
  { name: 'AdminDashboardTab', label: '管理', icon: 'grid-outline', activeIcon: 'grid' },
  { name: 'AdminUsersTab', label: '用户', icon: 'people-outline', activeIcon: 'people' },
  { name: 'AdminMonitorTab', label: '监测', icon: 'pulse-outline', activeIcon: 'pulse' },
  { name: 'AdminSettingsTab', label: '系统', icon: 'settings-outline', activeIcon: 'settings' },
];

// 管理面板（统计+快捷入口+登出）
const AdminDashboardWrapper: React.FC = () => {
  const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>();
  return (
    <AdminDashboardScreen
      onBack={() => navigation.goBack()}
      onViewUser={(userId, username) => navigation.navigate('AdminUserDetail', { userId, username })}
      onNavigateAnnouncement={() => navigation.navigate('AdminAnnouncement')}
      onNavigateLottery={() => navigation.navigate('AdminLottery')}
      onNavigateAuditLogs={() => navigation.navigate('AdminLocation')}
      onNavigatePhoneUsage={() => navigation.navigate('AdminPhoneUsage')}
      onNavigateRedemption={() => navigation.navigate('AdminRedemption')}
      onNavigateSOS={() => navigation.navigate('AdminSOS')}
      onNavigateContentReview={() => navigation.navigate('AdminContentReview')}
      onNavigateFeedback={() => navigation.navigate('AdminFeedback')}
    />
  );
};

// 用户管理（列表+搜索+审核+长按操作）
const AdminUsersWrapper: React.FC = () => {
  const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>();
  return (
    <AdminUsersScreen
      onBack={() => navigation.goBack()}
      onViewUser={(userId, username) => navigation.navigate('AdminUserDetail', { userId, username })}
      onViewUserProfile={(userId, username) => navigation.navigate('AdminUserProfile', { userId, username })}
    />
  );
};

// 监测页面（手机使用数据）
const AdminMonitorWrapper: React.FC = () => {
  const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>();
  return <AdminPhoneUsageScreen onBack={() => navigation.goBack()} />;
};

// 系统设置（密令+密码修改）
const AdminSettingsWrapper: React.FC = () => {
  const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>();
  return <AdminSettingsScreen onBack={() => navigation.goBack()} />;
};

const TAB_SCREENS: Record<keyof AdminTabParamList, React.FC> = {
  AdminDashboardTab: AdminDashboardWrapper,
  AdminUsersTab: AdminUsersWrapper,
  AdminMonitorTab: AdminMonitorWrapper,
  AdminSettingsTab: AdminSettingsWrapper,
};

const AdminTabNavigator: React.FC = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarActiveTintColor: Colors.admin,
        tabBarInactiveTintColor: Colors.textHint,
        tabBarLabelStyle: styles.label,
      }}
    >
      {TAB_CONFIG.map(({ name, label, icon, activeIcon }) => (
        <Tab.Screen
          key={name}
          name={name}
          component={TAB_SCREENS[name]}
          options={{
            tabBarLabel: label,
            tabBarIcon: ({ color, focused, size }) => (
              <Ionicons
                name={focused ? activeIcon : icon}
                size={size}
                color={color}
              />
            ),
          }}
        />
      ))}
    </Tab.Navigator>
  );
};

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: Colors.bgWhite,
    borderTopColor: Colors.divider,
    borderTopWidth: StyleSheet.hairlineWidth,
    height: 60,
    paddingTop: 6,
  },
  label: {
    fontSize: Typography.caption,
    marginBottom: 6,
  },
});

export default AdminTabNavigator;
