/**
 * 根导航器
 * 未登录 → AuthStack / 已登录 → MainTabs
 * 隐私政策守卫 / 公告弹窗 / 实名认证强制跳转 / 版本更新强制重登
 */

import React, { useEffect, useState, useRef } from 'react';
import { View, ActivityIndicator, StyleSheet, BackHandler, Alert } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useAuth } from '../context/AuthContext';
import {
  connectWebSocket,
  disconnectWebSocket,
  destroyWebSocketResources,
  onSOSAlert,
  onAdminNotification,
  onConnectionStateChange,
  getConnectionState,
} from '../services/websocketClient';
import type { WSConnectionState } from '../services/websocketClient';
import { Colors } from '../constants';
import BottomTabNavigator from './BottomTabNavigator';
import AdminTabNavigator from './AdminTabNavigator';
import {
  LoginScreen,
  RegisterScreen,
  ForgotPasswordScreen,
  RealNameScreen,
  BindScreen,
  ContactDetailScreen,
  DiaryScreen,
  AdminLocationScreen,
  UserProfileScreen,
  EditProfileScreen,
  PersonalSpaceScreen,
  AlbumScreen,
  AdminDashboardScreen,
  AdminUserDetailScreen,
  AdminAnnouncementScreen,
  AdminLotteryScreen,
  AdminPhoneUsageScreen,
  AdminRedemptionScreen,
  AdminUserProfileScreen,
  AdminSOSScreen,
  AdminContentReviewScreen,
  AdminFeedbackScreen,
  LotteryScreen,
  AccountSwitchScreen,
  ScheduleScreen,
  MessageScreen,
  SettingsScreen,
  MyFeedbackScreen,
  HealthScreen,
  TravelScreen,
} from '../screens';
import {
  PrivacyPolicyModal,
  AnnouncementModal,
} from '../components';
import { checkAppVersion } from '../services/auth';
import { getUnreadAnnouncements } from '../services/announcement';
import type { Announcement, Contact } from '../types';

// ====== 路由参数类型 ======

export type AuthStackParamList = {
  Login: undefined;
  Register: undefined;
  ForgotPassword: undefined;
  RealName: { isMandatory: boolean } | undefined;
};

export type MainStackParamList = {
  MainTabs: undefined;
  RealName: { isMandatory: boolean } | undefined;
  Bind: undefined;
  ContactDetail: { contact: Contact };
  Diary: { contact: Contact };
  AdminLocation: undefined;
  UserProfile: { userId: string };
  EditProfile: { userId: string };
  PersonalSpace: { ownerId: string; ownerName: string };
  Album: { ownerId: string; ownerName: string };
  AdminDashboard: undefined;
  AdminUserDetail: { userId: string; username: string };
  AdminAnnouncement: undefined;
  AdminLottery: undefined;
  AdminPhoneUsage: undefined;
  AdminRedemption: undefined;
  AdminUserProfile: { userId: string; username: string };
  AdminSOS: undefined;
  AdminContentReview: undefined;
  AdminFeedback: undefined;
  Lottery: undefined;
  AccountSwitch: undefined;
  AccountRegister: undefined;
  Schedule: undefined;
  Message: undefined;
  Health: undefined;
  Travel: undefined;
  Settings: undefined;
  MyFeedback: undefined;
};

const AuthStack = createNativeStackNavigator<AuthStackParamList>();
const MainStack = createNativeStackNavigator<MainStackParamList>();

// ---- 认证路由栈 ----

const AuthNavigator: React.FC = () => (
  <AuthStack.Navigator screenOptions={{ headerShown: false }}>
    <AuthStack.Screen name="Login">
      {(props) => (
        <LoginScreen
          onNavigateRegister={() => props.navigation.navigate('Register')}
          onNavigateForgotPassword={() => props.navigation.navigate('ForgotPassword')}
        />
      )}
    </AuthStack.Screen>
    <AuthStack.Screen name="Register">
      {(props) => (
        <RegisterScreen
          onNavigateLogin={() => props.navigation.goBack()}
        />
      )}
    </AuthStack.Screen>
    <AuthStack.Screen name="ForgotPassword">
      {(props) => (
        <ForgotPasswordScreen onNavigateLogin={() => props.navigation.goBack()} />
      )}
    </AuthStack.Screen>
    <AuthStack.Screen name="RealName">
      {(props) => (
        <RealNameScreen
          isMandatory={props.route.params?.isMandatory ?? true}
          onComplete={() => props.navigation.goBack()}
        />
      )}
    </AuthStack.Screen>
  </AuthStack.Navigator>
);

// ---- 主路由栈 ----

const AdminMainTabs: React.FC = () => <AdminTabNavigator />;

/** 管理员路由守卫：非管理员访问时回退到首页 */
const AdminRouteGuard: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { state } = useAuth();
  if (state.user?.role !== 'admin') {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color={Colors.primary} />
      </View>
    );
  }
  return <>{children}</>;
};

const MainNavigator: React.FC = () => {
  const { state, logout } = useAuth();
  const user = state.user;
  const isAdmin = user?.role === 'admin';
  const MainTabsComponent = isAdmin ? AdminMainTabs : BottomTabNavigator;

  return (
    <MainStack.Navigator screenOptions={{ headerShown: false }}>
      <MainStack.Screen name="MainTabs" component={MainTabsComponent} />
      <MainStack.Screen name="RealName">
        {(props) => (
          <RealNameScreen
            isMandatory={props.route.params?.isMandatory ?? true}
            onComplete={() => props.navigation.goBack()}
          />
        )}
      </MainStack.Screen>
      <MainStack.Screen name="Bind">
        {(props) => (
          <BindScreen
            onBack={() => props.navigation.goBack()}
            defaultType={(props.route.params as any)?.defaultType}
            currentUserId={user?.id || ''}
            currentUsername={user?.username}
            currentPhone={user?.phone}
          />
        )}
      </MainStack.Screen>
      <MainStack.Screen name="ContactDetail">
        {(props) => (
          <ContactDetailScreen
            contact={props.route.params.contact}
            onBack={() => props.navigation.goBack()}
            onNavigateDiary={(contact: Contact) => props.navigation.navigate('Diary', { contact })}
          />
        )}
      </MainStack.Screen>
      <MainStack.Screen name="Diary">
        {(props) => (
          <DiaryScreen
            contact={props.route.params.contact}
            currentUserId={user?.id || 'unknown'}
            currentUsername={user?.username || '我'}
            onBack={() => props.navigation.goBack()}
          />
        )}
      </MainStack.Screen>
      <MainStack.Screen name="AdminLocation">
        {(props) => (
          <AdminRouteGuard>
            <AdminLocationScreen onBack={() => props.navigation.goBack()} />
          </AdminRouteGuard>
        )}
      </MainStack.Screen>
      <MainStack.Screen name="UserProfile">
        {(props) => (
          <UserProfileScreen
            userId={props.route.params.userId}
            onBack={() => props.navigation.goBack()}
            onEditProfile={() => props.navigation.navigate('EditProfile', { userId: props.route.params.userId })}
          />
        )}
      </MainStack.Screen>
      <MainStack.Screen name="EditProfile">
        {(props) => (
          <EditProfileScreen
            userId={props.route.params.userId}
            onBack={() => props.navigation.goBack()}
          />
        )}
      </MainStack.Screen>
      <MainStack.Screen name="PersonalSpace">
        {(props) => (
          <PersonalSpaceScreen
            ownerId={props.route.params.ownerId}
            ownerName={props.route.params.ownerName}
            onBack={() => props.navigation.goBack()}
            onNavigateAlbum={(ownerId, ownerName) =>
              props.navigation.navigate('Album', { ownerId, ownerName })
            }
            onNavigateEdit={(userId) =>
              props.navigation.navigate('EditProfile', { userId })
            }
          />
        )}
      </MainStack.Screen>
      <MainStack.Screen name="Album">
        {(props) => (
          <AlbumScreen
            ownerId={props.route.params.ownerId}
            ownerName={props.route.params.ownerName}
            onBack={() => props.navigation.goBack()}
          />
        )}
      </MainStack.Screen>
      <MainStack.Screen name="AdminDashboard">
        {(props) => (
          <AdminRouteGuard>
            <AdminDashboardScreen
              onBack={() => props.navigation.goBack()}
              onViewUser={(userId, username) => props.navigation.navigate('AdminUserDetail', { userId, username })}
              onNavigateAnnouncement={() => props.navigation.navigate('AdminAnnouncement')}
              onNavigateLottery={() => props.navigation.navigate('AdminLottery')}
              onNavigateAuditLogs={() => props.navigation.navigate('AdminLocation')}
              onNavigatePhoneUsage={() => props.navigation.navigate('AdminPhoneUsage')}
              onNavigateRedemption={() => props.navigation.navigate('AdminRedemption')}
              onNavigateSOS={() => props.navigation.navigate('AdminSOS')}
              onNavigateContentReview={() => props.navigation.navigate('AdminContentReview')}
              onNavigateFeedback={() => props.navigation.navigate('AdminFeedback')}
            />
          </AdminRouteGuard>
        )}
      </MainStack.Screen>
      <MainStack.Screen name="AdminUserDetail">
        {(props) => (
          <AdminRouteGuard>
            <AdminUserDetailScreen
              userId={props.route.params.userId}
              username={props.route.params.username}
              onBack={() => props.navigation.goBack()}
            />
          </AdminRouteGuard>
        )}
      </MainStack.Screen>
      <MainStack.Screen name="AdminAnnouncement">
        {(props) => <AdminRouteGuard><AdminAnnouncementScreen onBack={() => props.navigation.goBack()} /></AdminRouteGuard>}
      </MainStack.Screen>
      <MainStack.Screen name="AdminLottery">
        {(props) => <AdminRouteGuard><AdminLotteryScreen onBack={() => props.navigation.goBack()} /></AdminRouteGuard>}
      </MainStack.Screen>
      <MainStack.Screen name="AdminPhoneUsage">
        {(props) => <AdminRouteGuard><AdminPhoneUsageScreen onBack={() => props.navigation.goBack()} /></AdminRouteGuard>}
      </MainStack.Screen>
      <MainStack.Screen name="AdminRedemption">
        {(props) => <AdminRouteGuard><AdminRedemptionScreen onBack={() => props.navigation.goBack()} /></AdminRouteGuard>}
      </MainStack.Screen>
      <MainStack.Screen name="AdminSOS">
        {(props) => <AdminRouteGuard><AdminSOSScreen onBack={() => props.navigation.goBack()} /></AdminRouteGuard>}
      </MainStack.Screen>
      <MainStack.Screen name="AdminContentReview">
        {(props) => <AdminRouteGuard><AdminContentReviewScreen onBack={() => props.navigation.goBack()} /></AdminRouteGuard>}
      </MainStack.Screen>
      <MainStack.Screen name="AdminFeedback">
        {(props) => <AdminRouteGuard><AdminFeedbackScreen onBack={() => props.navigation.goBack()} /></AdminRouteGuard>}
      </MainStack.Screen>
      <MainStack.Screen name="AdminUserProfile">
        {(props) => (
          <AdminRouteGuard>
            <AdminUserProfileScreen
              userId={props.route.params.userId}
              username={props.route.params.username}
              onBack={() => props.navigation.goBack()}
              onNavigateUserDetail={(userId, username) => props.navigation.navigate('AdminUserDetail', { userId, username })}
            />
          </AdminRouteGuard>
        )}
      </MainStack.Screen>
      <MainStack.Screen name="Schedule">
        {(props) => <ScheduleScreen onBack={() => props.navigation.goBack()} />}
      </MainStack.Screen>
      <MainStack.Screen name="Lottery">
        {(props) => <LotteryScreen onBack={() => props.navigation.goBack()} />}
      </MainStack.Screen>
      <MainStack.Screen name="AccountSwitch">
        {(props) => (
          <AccountSwitchScreen
            onBack={() => props.navigation.goBack()}
            onAddAccount={async () => {
              // 登出当前账号后自动跳转到登录页（AuthNavigator）
              await logout();
            }}
          />
        )}
      </MainStack.Screen>
      <MainStack.Screen name="AccountRegister">
        {(props) => <RegisterScreen onNavigateLogin={() => props.navigation.goBack()} />}
      </MainStack.Screen>
      <MainStack.Screen name="Message">
        {(props) => <MessageScreen onBack={() => props.navigation.goBack()} />}
      </MainStack.Screen>
      <MainStack.Screen name="Health">
        {(props) => <HealthScreen onBack={() => props.navigation.goBack()} />}
      </MainStack.Screen>
      <MainStack.Screen name="Travel">
        {(props) => <TravelScreen onBack={() => props.navigation.goBack()} />}
      </MainStack.Screen>
      <MainStack.Screen name="Settings">
        {(props) => <SettingsScreen />}
      </MainStack.Screen>
      <MainStack.Screen name="MyFeedback">
        {(props) => <MyFeedbackScreen onBack={() => props.navigation.goBack()} />}
      </MainStack.Screen>
    </MainStack.Navigator>
  );
};

// ---- 根组件 ----

const AppNavigator: React.FC = () => {
  const { state, agreePrivacy, updateLastVersion, checkVersionAndForceRelogin, logout } = useAuth();
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [privacyChecked, setPrivacyChecked] = useState(false);
  const [privacyRejected, setPrivacyRejected] = useState(false);
  const [showAnnouncement, setShowAnnouncement] = useState(false);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [showRealNameMandatory, setShowRealNameMandatory] = useState(false);
  const versionCheckDone = useRef(false);

  // WebSocket 连接管理（登录→连接，登出→断开，带token鉴权）
  useEffect(() => {
    const user = state.user;
    if (!state.isLoading) {
      if (user) {
        // 从已保存账号中查找当前用户的token
        const account = state.savedAccounts.find((a) => a.userId === user.id);
        connectWebSocket(user.id, user.username, user.phone, account?.token);
      } else {
        disconnectWebSocket();
      }
    }
    return () => { destroyWebSocketResources(); };
  }, [state.isLoading, state.user?.id]);

  // 根级SOS实时推送监听（覆盖所有页面，非仅首页）
  useEffect(() => {
    if (!state.user) return;
    const unsub = onSOSAlert((data: any) => {
      // SOS事件由全局事件总线转发（不在此处管理UI状态）
    });
    return () => { if (typeof unsub === 'function') unsub(); };
  }, [state.user]);

  // 根级管理员通知监听
  useEffect(() => {
    if (!state.user) return;
    const unsub = onAdminNotification((data: any) => {
      // 管理员通知由全局事件总线转发
    });
    return () => { if (typeof unsub === 'function') unsub(); };
  }, [state.user]);

  // 隐私政策弹窗
  useEffect(() => {
    if (!state.isLoading) {
      if (!state.privacyAgreed) {
        setShowPrivacy(true);
      }
      setPrivacyChecked(true);
    }
  }, [state.isLoading, state.privacyAgreed]);

  // 拒绝隐私政策 → 拦截页面，并禁用Android返回键
  useEffect(() => {
    if (privacyRejected) {
      const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
        // 阻止返回，显示退出确认
        Alert.alert('提示', '您需要同意隐私政策才能使用本应用', [
          { text: '退出应用', style: 'destructive', onPress: () => BackHandler.exitApp() },
          { text: '重新查看', onPress: () => setPrivacyRejected(false) },
        ]);
        return true; // 阻止默认行为
      });
      return () => backHandler.remove();
    }
  }, [privacyRejected]);

  // 登录后显示公告（按用户隔离未读状态）
  useEffect(() => {
    if (state.isLoggedIn && state.user && privacyChecked && !showPrivacy) {
      const userId = state.user.id;
      (async () => {
        try {
          const unread = await getUnreadAnnouncements(userId);
          if (unread.length > 0) { setAnnouncements(unread); setShowAnnouncement(true); }
        } catch { /* 静默 */ }
      })();
    }
  }, [state.isLoggedIn, state.user?.id, privacyChecked, showPrivacy]);

  // 版本检测 + 强制重登检查
  useEffect(() => {
    if (versionCheckDone.current) return;
    (async () => {
      try {
        const resp = await checkAppVersion();
        if (resp.code === 200 && resp.data) {
          await updateLastVersion(resp.data.version);
        }
        // 检查是否需要版本更新后强制重登
        await checkVersionAndForceRelogin();
      } catch { /* 静默 */ }
      versionCheckDone.current = true;
    })();
  }, []);

  // 登录后检测实名认证状态：未认证 → 强制跳转实名页（管理员除外）
  useEffect(() => {
    if (state.isLoggedIn && !state.isLoading && privacyChecked && !showPrivacy) {
      const isAdmin = state.user?.role === 'admin';
      if (!isAdmin && !state.isRealNameVerified) {
        setShowRealNameMandatory(true);
      } else {
        setShowRealNameMandatory(false);
      }
    }
  }, [state.isLoggedIn, state.isLoading, privacyChecked, showPrivacy, state.isRealNameVerified, state.user?.role]);

  // 加载中
  if (state.isLoading || !privacyChecked) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color={Colors.primary} />
      </View>
    );
  }

  // 拒绝隐私政策 → 显示拦截页面
  if (privacyRejected) {
    return (
      <View style={styles.rejectedContainer}>
        <PrivacyPolicyModal
          visible={true}
          onAgree={async () => {
            await agreePrivacy();
            setShowPrivacy(false);
            setPrivacyRejected(false);
          }}
          onDisagree={() => {
            // 已经拒绝过，再次拒绝 → 退出应用
            Alert.alert('无法继续', '您必须同意隐私政策才能使用本应用。', [
              { text: '退出应用', style: 'destructive', onPress: () => BackHandler.exitApp() },
              { text: '同意隐私政策', onPress: async () => {
                await agreePrivacy();
                setShowPrivacy(false);
                setPrivacyRejected(false);
              }},
            ]);
          }}
        />
      </View>
    );
  }

  // 未登录时也显示隐私弹窗
  // 已登录根据实名状态决定显示内容
  const showMainContent = state.isLoggedIn && !showRealNameMandatory;

  return (
    <>
      <PrivacyPolicyModal
        visible={showPrivacy}
        onAgree={async () => { await agreePrivacy(); setShowPrivacy(false); }}
        onDisagree={() => {
          setShowPrivacy(false);
          setPrivacyRejected(true);
        }}
      />
      <AnnouncementModal
        announcements={announcements}
        visible={showAnnouncement && !showPrivacy}
        userId={state.user?.id || ''}
        onCloseAll={() => { setShowAnnouncement(false); setAnnouncements([]); }}
      />
      {showRealNameMandatory ? (
        <RealNameScreen
          isMandatory={true}
          onComplete={() => setShowRealNameMandatory(false)}
        />
      ) : showMainContent ? (
        <MainNavigator />
      ) : !state.isLoggedIn ? (
        <AuthNavigator />
      ) : (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={Colors.primary} />
        </View>
      )}
    </>
  );
};

const styles = StyleSheet.create({
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: Colors.bgPrimary },
  rejectedContainer: { flex: 1, backgroundColor: Colors.bgPrimary },
});

export default AppNavigator;
