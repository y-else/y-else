/**
 * 管理员查看用户完整资料（纯只读）
 * 个人资料 / 空间动态 / 相册 / 留言墙 / 权限 / 绑定 / 兑换记录 /
 * SOS记录 / 定位轨迹 / 注册记录 / 手机使用数据
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert,
  RefreshControl, Image, FlatList,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card, Button } from '../components';
import { useAuth } from '../context/AuthContext';
import { getPublicProfile } from '../services/profile';
import { getSpacePosts } from '../services/profile';
import { getAlbum } from '../services/profile';
import { getWallMessages as getWallMsgs } from '../services/profile';
import { getUserBinding } from '../services/bindingService';
import { getAllRedemptionRecords } from '../services/redemptionCode';
import { getUserFullData } from '../services/admin';
import { getInteractionSettings } from '../services/settings';
import type {
  PublicProfile, SpacePost, AlbumItem, WallMessage,
  AdminBinding, RedemptionRecord, InteractionSettings,
} from '../types';

interface AdminUserProfileScreenProps {
  userId: string;
  username: string;
  onBack: () => void;
  onNavigateUserDetail: (userId: string, username: string) => void;
}

const AdminUserProfileScreen: React.FC<AdminUserProfileScreenProps> = ({
  userId, username, onBack, onNavigateUserDetail,
}) => {
  const { state } = useAuth();
  const viewerId = state.user?.id || 'admin_001';

  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<PublicProfile | null>(null);
  const [spacePosts, setSpacePosts] = useState<SpacePost[]>([]);
  const [albumItems, setAlbumItems] = useState<AlbumItem[]>([]);
  const [wallMessages, setWallMessages] = useState<WallMessage[]>([]);
  const [binding, setBinding] = useState<AdminBinding | null>(null);
  const [redemptionRecords, setRedemptionRecords] = useState<RedemptionRecord[]>([]);
  const [permissions, setPermissions] = useState<InteractionSettings | null>(null);
  const [userData, setUserData] = useState<any>(null);
  const [refreshing, setRefreshing] = useState(false);

  // 展开控制
  const [showProfile, setShowProfile] = useState(true);
  const [showSpace, setShowSpace] = useState(true);
  const [showAlbum, setShowAlbum] = useState(false);
  const [showWall, setShowWall] = useState(false);
  const [showPerms, setShowPerms] = useState(false);
  const [showBinding, setShowBinding] = useState(false);
  const [showRedeem, setShowRedeem] = useState(false);
  const [showSOS, setShowSOS] = useState(false);
  const [showLocation, setShowLocation] = useState(false);
  const [showPhone, setShowPhone] = useState(false);

  const loadAll = useCallback(async () => {
    setLoading(true);
    const [p, posts, album, wall, bind, records, uData, perms] = await Promise.all([
      getPublicProfile(userId).catch(() => null),
      getSpacePosts(userId, viewerId).then((r) => r.posts).catch(() => []),
      getAlbum(userId, viewerId).catch(() => []),
      getWallMsgs(userId).catch(() => []),
      getUserBinding(userId).catch(() => null),
      getAllRedemptionRecords().catch(() => []),
      getUserFullData(userId).catch(() => null),
      (async () => {
        try {
          const s = await getInteractionSettings();
          return s;
        } catch { return null; }
      })(),
    ]);
    setProfile(p);
    setSpacePosts(posts);
    setAlbumItems(album);
    setWallMessages(wall);
    setBinding(bind);
    setRedemptionRecords((records || []).filter((r: RedemptionRecord) => r.userId === userId));
    setUserData(uData);
    setPermissions(perms);
    setLoading(false);
  }, [userId, viewerId]);

  useEffect(() => { loadAll(); }, [loadAll]);

  const handleRefresh = async () => { setRefreshing(true); await loadAll(); setRefreshing(false); };

  // 只读提示
  const readOnlyAlert = () => {
    Alert.alert('只读模式', '管理员仅可查看用户数据，无法修改、删除或编辑。', [{ text: '知道了' }]);
  };

  // 渲染可折叠区块
  const renderSection = (title: string, icon: string, color: string, show: boolean, setShow: (v: boolean) => void, content: React.ReactNode) => (
    <Card style={styles.sectionCard}>
      <TouchableOpacity style={styles.sectionHeader} onPress={() => setShow(!show)} activeOpacity={0.7}>
        <View style={styles.sectionTitleRow}>
          <Ionicons name={icon as any} size={18} color={color} />
          <Text style={styles.sectionTitle}>{title}</Text>
        </View>
        <Ionicons name={show ? 'chevron-up' : 'chevron-down'} size={16} color={Colors.textHint} />
      </TouchableOpacity>
      {show && <View style={styles.sectionBody}>{content}</View>}
    </Card>
  );

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={styles.headerTitle}>{username}</Text>
          <View style={styles.readOnlyTag}>
            <Ionicons name="eye-outline" size={12} color={Colors.textHint} />
            <Text style={styles.readOnlyText}>只读</Text>
          </View>
        </View>
        <TouchableOpacity onPress={() => onNavigateUserDetail(userId, username)}>
          <Text style={styles.manageLink}>管理</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.container}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={[Colors.primary]} />}
      >
        {/* 1. 个人资料 */}
        {renderSection('个人资料', 'person', Colors.primary, showProfile, setShowProfile,
          profile ? (
            <View>
              <View style={styles.avatarRow}>
                <View style={styles.avatarLg}>
                  {profile.avatar ? (
                    <Image source={{ uri: profile.avatar }} style={styles.avatarImg} />
                  ) : (
                    <Ionicons name="person" size={36} color={Colors.textHint} />
                  )}
                </View>
                <View style={styles.profileInfo}>
                  <Text style={styles.profileRow}>昵称: {profile.username || username}</Text>
                  <Text style={styles.profileRow}>等级: LV.{profile.level} · {profile.totalMinutes}分钟</Text>
                  <Text style={styles.profileRow}>性别: {profile.gender === 'male' ? '男' : profile.gender === 'female' ? '女' : '未设'}</Text>
                  {profile.birthday && <Text style={styles.profileRow}>生日: {profile.birthday}</Text>}
                  {profile.bio ? <Text style={styles.profileRow}>简介: {profile.bio}</Text> : <Text style={styles.profileRow}>简介: 未填写</Text>}
                  <Text style={styles.profileRow}>所在地: {profile.location || '未设置'}</Text>
                  <Text style={styles.profileRow}>注册时间: {new Date(profile.createdAt).toLocaleString('zh-CN')}</Text>
                  <Text style={styles.profileRow}>最后活跃: {userData?.basicInfo?.updatedAt ? new Date(userData.basicInfo.updatedAt).toLocaleString('zh-CN') : '未知'}</Text>
                </View>
              </View>
            </View>
          ) : loading ? <Text style={styles.emptyHint}>加载中...</Text> : <Text style={styles.emptyHint}>暂无公开资料</Text>
        )}

        {/* 2. 权限配置 */}
        {renderSection('互动权限', 'toggle', Colors.admin, showPerms, setShowPerms,
          permissions ? (
            <View>
              {[
                { key: 'quickMessage', label: '快捷消息' },
                { key: 'vibration', label: '振动提醒' },
                { key: 'popupNotify', label: '弹窗提醒' },
                { key: 'sosAlert', label: 'SOS求救' },
                { key: 'onlineStatus', label: '在线状态可见' },
                { key: 'locationVisible', label: '定位可见' },
                { key: 'messageReceive', label: '消息接收' },
              ].map(({ key, label }) => (
                <View key={key} style={styles.permRow}>
                  <Text style={styles.permLabel}>{label}</Text>
                  <View style={[styles.permBadge, { backgroundColor: (permissions as any)[key] ? Colors.family + '20' : Colors.textHint + '20' }]}>
                    <Text style={[styles.permText, { color: (permissions as any)[key] ? Colors.family : Colors.textHint }]}>
                      {(permissions as any)[key] ? '已开启' : '已关闭'}
                    </Text>
                  </View>
                </View>
              ))}
            </View>
          ) : <Text style={styles.emptyHint}>未获取到权限数据</Text>
        )}

        {/* 3. 管理员绑定 */}
        {renderSection('管理员绑定', 'link', Colors.admin, showBinding, setShowBinding,
          binding ? (
            <View>
              <Text style={styles.rowText}>已绑定管理员: {binding.adminName}</Text>
              <Text style={styles.rowText}>绑定时间: {new Date(binding.boundAt).toLocaleString('zh-CN')}</Text>
              <Text style={[styles.rowText, !binding.isActive && { color: Colors.lover }]}>
                状态: {binding.isActive ? '绑定有效' : '已失效'}
              </Text>
            </View>
          ) : <Text style={styles.emptyHint}>未绑定管理员</Text>
        )}

        {/* 4. 兑换记录 */}
        {renderSection('兑换记录', 'pricetags', Colors.friend, showRedeem, setShowRedeem,
          redemptionRecords.length === 0 ? (
            <Text style={styles.emptyHint}>无兑换记录</Text>
          ) : (
            redemptionRecords.map((r) => (
              <View key={r.id} style={styles.recordItem}>
                <Text style={styles.recordTitle}>{r.rewardName} ({r.rewardType === 'physical' ? '实物' : '虚拟'})</Text>
                <Text style={styles.recordMeta}>兑换码: {r.code} · {new Date(r.redeemedAt).toLocaleString('zh-CN')}</Text>
                {r.shippingAddress && (
                  <Text style={styles.recordMeta}>
                    收货: {r.shippingAddress.name} {r.shippingAddress.phone} {r.shippingAddress.province}{r.shippingAddress.city}{r.shippingAddress.district} {r.shippingAddress.detail}
                  </Text>
                )}
                <Text style={[styles.recordMeta, r.status === 'cancelled' && { color: Colors.lover }]}>
                  状态: {r.status === 'success' ? '已兑换' : '已取消'}
                </Text>
              </View>
            ))
          )
        )}

        {/* 5. SOS记录 */}
        {renderSection('SOS求救记录', 'warning', Colors.lover, showSOS, setShowSOS,
          userData?.sosRecords?.length > 0 ? (
            userData.sosRecords.map((sos: any, i: number) => (
              <View key={i} style={styles.recordItem}>
                <Text style={styles.recordTitle}>SOS #{i + 1}</Text>
                <Text style={styles.recordMeta}>时间: {new Date(sos.triggeredAt || sos.createdAt).toLocaleString('zh-CN')}</Text>
                <Text style={styles.recordMeta}>状态: {sos.status === 'active' ? '活跃' : '已解决'}</Text>
                {sos.address && <Text style={styles.recordMeta}>位置: {sos.address}</Text>}
              </View>
            ))
          ) : <Text style={styles.emptyHint}>无SOS记录</Text>
        )}

        {/* 6. 定位轨迹 */}
        {renderSection('定位轨迹', 'location', Colors.primary, showLocation, setShowLocation,
          userData?.locationHistory?.length > 0 ? (
            userData.locationHistory.map((pt: any, i: number) => (
              <View key={i} style={styles.recordItem}>
                <Text style={styles.recordMeta}>{new Date(pt.timestamp).toLocaleString('zh-CN')}</Text>
                {pt.address && <Text style={styles.recordMeta}>地址: {pt.address}</Text>}
                <Text style={styles.recordMeta}>坐标: {pt.latitude.toFixed(5)}, {pt.longitude.toFixed(5)}</Text>
              </View>
            ))
          ) : <Text style={styles.emptyHint}>无定位记录</Text>
        )}

        {/* 7. 手机使用数据 */}
        {renderSection('手机使用数据', 'phone-portrait', '#7B68EE', showPhone, setShowPhone,
          userData?.phoneUsage ? (
            <View>
              <Text style={styles.rowText}>日均屏幕: {userData.phoneUsage.screenTimePerDay}分钟</Text>
              <Text style={styles.rowText}>APP使用: {userData.phoneUsage.appUsageMinutes}分钟</Text>
              <Text style={styles.rowText}>充电次数: {userData.phoneUsage.chargeCount}次</Text>
              <Text style={styles.rowText}>APP启动: {userData.phoneUsage.appStartCount}次</Text>
              <Text style={styles.rowText}>电池健康: {userData.phoneUsage.batteryHealth}</Text>
              <Text style={styles.rowText}>数据更新: {new Date(userData.phoneUsage.dataUpdatedAt).toLocaleString('zh-CN')}</Text>
            </View>
          ) : <Text style={styles.emptyHint}>无手机使用数据</Text>
        )}

        {/* 8. 个人空间动态 */}
        {renderSection(`个人空间 (${spacePosts.length})`, 'images', Colors.primary, showSpace, setShowSpace,
          spacePosts.length === 0 ? (
            <Text style={styles.emptyHint}>暂无动态</Text>
          ) : (
            spacePosts.map((post) => (
              <View key={post.id} style={styles.postCard}>
                <View style={styles.postHeader}>
                  <Text style={styles.postAuthor}>{post.authorName}</Text>
                  <Text style={styles.postTime}>{new Date(post.createdAt).toLocaleString('zh-CN')}</Text>
                </View>
                {post.content ? <Text style={styles.postContent}>{post.content}</Text> : null}
                {post.media.length > 0 && (
                  <View style={styles.mediaRow}>
                    {post.media.slice(0, 4).map((m: any, i: number) => (
                      <View key={i} style={styles.mediaThumb}>
                        <Ionicons name={m.type === 'video' ? 'videocam' : 'image'} size={24} color={Colors.textHint} />
                      </View>
                    ))}
                    {post.media.length > 4 && <Text style={styles.mediaMore}>+{post.media.length - 4}</Text>}
                  </View>
                )}
                <View style={styles.postFooter}>
                  <Text style={styles.postMeta}>❤️ {post.likes?.length || 0} 赞</Text>
                  <Text style={styles.postMeta}>💬 {post.comments?.length || 0} 评论</Text>
                  <View style={[styles.visTag, { backgroundColor: post.visibility === 'public' ? Colors.family + '20' : post.visibility === 'friends_only' ? Colors.friend + '20' : Colors.textHint + '20' }]}>
                    <Text style={[styles.visText, { color: post.visibility === 'public' ? Colors.family : post.visibility === 'friends_only' ? Colors.friend : Colors.textHint }]}>
                      {post.visibility === 'public' ? '公开' : post.visibility === 'friends_only' ? '好友可见' : '私密'}
                    </Text>
                  </View>
                </View>
              </View>
            ))
          )
        )}

        {/* 9. 相册 */}
        {renderSection(`相册 (${albumItems.length})`, 'albums', Colors.friend, showAlbum, setShowAlbum,
          albumItems.length === 0 ? (
            <Text style={styles.emptyHint}>暂无照片</Text>
          ) : (
            <View style={styles.albumGrid}>
              {albumItems.map((item) => (
                <View key={item.id} style={styles.albumItem}>
                  <View style={styles.albumThumb}>
                    {item.type === 'video' ? (
                      <Ionicons name="videocam" size={28} color={Colors.textHint} />
                    ) : (
                      <Ionicons name="image" size={28} color={Colors.textHint} />
                    )}
                  </View>
                  <Text style={styles.albumDate}>{new Date(item.addedAt).toLocaleDateString('zh-CN')}</Text>
                  <Text style={styles.albumPerm}>
                    {item.permission === 'public' ? '公开' : item.permission === 'friends_only' ? '好友' : '私密'}
                  </Text>
                </View>
              ))}
            </View>
          )
        )}

        {/* 10. 留言墙 */}
        {renderSection(`留言墙 (${wallMessages.length})`, 'chatbubbles', Colors.friend, showWall, setShowWall,
          wallMessages.length === 0 ? (
            <Text style={styles.emptyHint}>暂无留言</Text>
          ) : (
            wallMessages.map((msg) => (
              <View key={msg.id} style={styles.recordItem}>
                <Text style={styles.recordTitle}>{msg.authorName}</Text>
                <Text style={styles.recordMeta}>{msg.content}</Text>
                <Text style={styles.recordMeta}>{new Date(msg.createdAt).toLocaleString('zh-CN')}</Text>
              </View>
            ))
          )
        )}

        {/* 底部只读声明 */}
        <Text style={styles.readOnlyFooter}>
          ⓘ 管理员查看模式 · 所有数据只读 · 无法修改或删除
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerCenter: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  readOnlyTag: { flexDirection: 'row', alignItems: 'center', gap: 2, backgroundColor: Colors.bgPrimary, paddingHorizontal: 6, paddingVertical: 1, borderRadius: 4 },
  readOnlyText: { fontSize: 10, color: Colors.textHint },
  manageLink: { fontSize: Typography.body, color: Colors.admin, fontWeight: '500' },
  container: { padding: Spacing.lg },
  // 区块
  sectionCard: { marginBottom: Spacing.md },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: Spacing.xs },
  sectionTitleRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  sectionTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  sectionBody: { paddingTop: Spacing.md },
  // 资料
  avatarRow: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.md },
  avatarLg: {
    width: 64, height: 64, borderRadius: 32, backgroundColor: Colors.bgPrimary,
    alignItems: 'center', justifyContent: 'center',
  },
  avatarImg: { width: 64, height: 64, borderRadius: 32 },
  profileInfo: { flex: 1 },
  profileRow: { fontSize: Typography.body, color: Colors.textSecondary, marginBottom: 4, lineHeight: 20 },
  // 权限
  permRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: Spacing.sm, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider },
  permLabel: { fontSize: Typography.body, color: Colors.textPrimary },
  permBadge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 4 },
  permText: { fontSize: Typography.caption, fontWeight: '500' },
  // 通用
  rowText: { fontSize: Typography.body, color: Colors.textSecondary, marginBottom: 4, lineHeight: 20 },
  emptyHint: { fontSize: Typography.caption, color: Colors.textHint, textAlign: 'center', paddingVertical: Spacing.lg },
  // 记录
  recordItem: {
    backgroundColor: Colors.bgPrimary, borderRadius: BorderRadius.input,
    padding: Spacing.md, marginBottom: Spacing.sm,
  },
  recordTitle: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary, marginBottom: 2 },
  recordMeta: { fontSize: Typography.caption, color: Colors.textHint, lineHeight: 18 },
  // 空间动态
  postCard: {
    backgroundColor: Colors.bgPrimary, borderRadius: BorderRadius.card,
    padding: Spacing.md, marginBottom: Spacing.sm,
  },
  postHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: Spacing.xs },
  postAuthor: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  postTime: { fontSize: 10, color: Colors.textHint },
  postContent: { fontSize: Typography.body, color: Colors.textSecondary, lineHeight: 20, marginBottom: Spacing.sm },
  mediaRow: { flexDirection: 'row', gap: Spacing.xs, marginBottom: Spacing.sm },
  mediaThumb: {
    width: 64, height: 64, borderRadius: 4, backgroundColor: Colors.bgWhite,
    alignItems: 'center', justifyContent: 'center',
  },
  mediaMore: { fontSize: Typography.caption, color: Colors.textHint, alignSelf: 'center' },
  postFooter: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  postMeta: { fontSize: Typography.caption, color: Colors.textHint },
  visTag: { paddingHorizontal: 6, paddingVertical: 1, borderRadius: 3 },
  visText: { fontSize: 10 },
  // 相册
  albumGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  albumItem: {
    width: '31%', backgroundColor: Colors.bgPrimary, borderRadius: BorderRadius.card,
    padding: Spacing.sm, alignItems: 'center',
  },
  albumThumb: {
    width: '100%', aspectRatio: 1, backgroundColor: Colors.bgWhite,
    borderRadius: 4, alignItems: 'center', justifyContent: 'center',
    marginBottom: 4,
  },
  albumDate: { fontSize: 10, color: Colors.textHint },
  albumPerm: { fontSize: 10, color: Colors.textHint },
  // 底部
  readOnlyFooter: {
    fontSize: Typography.caption, color: Colors.textHint,
    textAlign: 'center', paddingVertical: Spacing.xl,
  },
});

export default AdminUserProfileScreen;
