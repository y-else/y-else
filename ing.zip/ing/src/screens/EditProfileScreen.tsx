/**
 * 编辑资料页面（生日三级下拉选择版）
 * 头像/昵称/简介/性别/所在地/生日年月日独立选择
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert,
  TextInput, Modal as RNModal, FlatList,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Button, AvatarPicker, DatePicker } from '../components';
import { useAuth } from '../context/AuthContext';
import { getPublicProfile, updateProfile } from '../services/profile';
import type { PublicProfile } from '../types';

interface EditProfileScreenProps {
  userId: string;
  onBack: () => void;
}

const GENDERS = [
  { key: 'male' as const, label: '男', icon: 'man' as const },
  { key: 'female' as const, label: '女', icon: 'woman' as const },
  { key: 'hidden' as const, label: '保密', icon: 'eye-off' as const },
];

// 省市数据（二级联动）
const PROVINCES: Record<string, string[]> = {
  '北京': ['东城区','西城区','朝阳区','海淀区'], '上海': ['黄浦区','徐汇区','浦东新区'], '广东': ['广州','深圳','东莞','佛山'], '浙江': ['杭州','宁波','温州'], '江苏': ['南京','苏州','无锡'], '四川': ['成都','绵阳'], '湖北': ['武汉','宜昌'], '山东': ['济南','青岛'], '福建': ['福州','厦门'], '其他': ['其他'],
};

const EditProfileScreen: React.FC<EditProfileScreenProps> = ({ userId, onBack }) => {
  const { state } = useAuth();
  const isAdmin = state.user?.role === 'admin';
  const mountedRef = useRef(true);

  const [profile, setProfile] = useState<PublicProfile | null>(null);
  const [nickname, setNickname] = useState('');
  const [bio, setBio] = useState('');
  const [gender, setGender] = useState<PublicProfile['gender']>('hidden');
  const [province, setProvince] = useState(''); const [city, setCity] = useState('');
  const [avatar, setAvatar] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showProvincePicker, setShowProvincePicker] = useState(false);
  const [showCityPicker, setShowCityPicker] = useState(false);

  // 生日（统一DatePicker）
  const [birthYear, setBirthYear] = useState('');
  const [birthMonth, setBirthMonth] = useState('');
  const [birthDay, setBirthDay] = useState('');
  const [showBirthdayPicker, setShowBirthdayPicker] = useState(false);

  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  useEffect(() => {
    (async () => {
      const p = await getPublicProfile(userId);
      if (!mountedRef.current) return;
      if (p) {
        setProfile(p);
        setNickname(p.username || '');
        setBio(p.bio);
        setGender(p.gender);
        setAvatar(p.avatar);
        // 解析省市
        if (p.location && p.location.includes('-')) {
          const [pName, cName] = p.location.split('-');
          setProvince(pName); setCity(cName);
        }
        // 解析已有生日
        if (p.birthday) {
          const parts = p.birthday.split('-');
          if (parts.length === 3) {
            setBirthYear(parts[0]);
            setBirthMonth(parts[1]);
            setBirthDay(parts[2]);
          }
        }
      }
    })();
  }, [userId]);

  const handleSave = async () => {
    if (!nickname.trim()) { Alert.alert('提示', '昵称不能为空'); return; }
    setLoading(true);
    const birthday = birthYear && birthMonth && birthDay
      ? `${birthYear}-${birthMonth.padStart(2, '0')}-${birthDay.padStart(2, '0')}`
      : undefined;

    const locStr = province && city ? `${province}-${city}` : '';
    const result = await updateProfile(userId, {
      username: nickname.trim(),
      bio: bio.trim(),
      birthday,
      gender,
      location: locStr,
      avatar: avatar || undefined,
    });
    if (!mountedRef.current) return;
    setLoading(false);
    if (result.success) {
      Alert.alert('保存成功', result.message, [{ text: '返回', onPress: onBack }]);
    } else {
      Alert.alert('修改失败', result.message);
    }
  };

  // 生日DatePicker确认回调
  const handleBirthdayConfirm = (dateStr: string) => {
    const [y, m, d] = dateStr.split('-');
    setBirthYear(y);
    setBirthMonth(m);
    setBirthDay(d);
    setShowBirthdayPicker(false);
  };

  // 管理员免完善个人信息，不可进入编辑资料页
  if (isAdmin) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <View style={styles.topBar}>
          <TouchableOpacity onPress={onBack}>
            <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
          </TouchableOpacity>
          <Text style={styles.title}>编辑资料</Text>
          <View style={{ width: 24 }} />
        </View>
        <View style={styles.adminBlock}>
          <Ionicons name="shield" size={48} color={Colors.admin} />
          <Text style={styles.adminBlockTitle}>管理员账号</Text>
          <Text style={styles.adminBlockDesc}>管理员账号无需完善个人资料</Text>
          <Button title="返回" onPress={onBack} variant="ghost" />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.container}>
        {/* 头部 */}
        <View style={styles.topBar}>
          <TouchableOpacity onPress={onBack}>
            <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
          </TouchableOpacity>
          <Text style={styles.title}>编辑资料</Text>
          <View style={{ width: 24 }} />
        </View>

        {/* 头像 */}
        <AvatarPicker uri={avatar} onPick={setAvatar} size={80} />

        {/* 昵称可随时编辑（F2修复） */}
        <View style={styles.fieldGroup}>
          <Text style={styles.fieldLabel}>昵称</Text>
          <TextInput
            style={styles.input}
            placeholder="输入昵称"
            placeholderTextColor={Colors.textHint}
            value={nickname}
            onChangeText={setNickname}
            maxLength={20}
          />
        </View>

        <View style={styles.fieldGroup}>
          <Text style={styles.fieldLabel}>个人简介</Text>
          <TextInput
            style={styles.textArea}
            placeholder="介绍一下自己..."
            placeholderTextColor={Colors.textHint}
            value={bio}
            onChangeText={setBio}
            multiline
            numberOfLines={3}
          />
        </View>

        {/* 生日（统一DatePicker） */}
        <View style={styles.fieldGroup}>
          <Text style={styles.fieldLabel}>生日</Text>
          {profile?.lastBirthdayEdit && (
            <Text style={styles.hint}>
              上次修改: {new Date(profile.lastBirthdayEdit).toLocaleDateString('zh-CN')}（一年仅可改一次）
            </Text>
          )}
          <TouchableOpacity
            style={[styles.selectBox, birthYear ? styles.selectBoxFilled : null]}
            onPress={() => setShowBirthdayPicker(true)}
          >
            <Text style={[styles.selectText, !birthYear && styles.selectPlaceholder]}>
              {birthYear ? `${birthYear}-${birthMonth.padStart(2, '0')}-${birthDay.padStart(2, '0')}` : '请选择生日'}
            </Text>
            <Ionicons name="calendar-outline" size={16} color={Colors.textHint} />
          </TouchableOpacity>
        </View>

        {/* 性别 */}
        <View style={styles.fieldGroup}>
          <Text style={styles.fieldLabel}>性别</Text>
          <View style={styles.genderRow}>
            {GENDERS.map((g) => (
              <TouchableOpacity
                key={g.key}
                style={[styles.genderBtn, gender === g.key && { backgroundColor: Colors.primary, borderColor: Colors.primary }]}
                onPress={() => setGender(g.key)}
              >
                <Ionicons name={g.icon} size={16} color={gender === g.key ? '#FFF' : Colors.textSecondary} />
                <Text style={[styles.genderText, gender === g.key && { color: '#FFF' }]}>{g.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* 所在地：省市二级联动下拉 */}
        <View style={styles.fieldGroup}>
          <Text style={styles.fieldLabel}>所在地</Text>
          <View style={styles.birthdayRow}>
            <TouchableOpacity style={[styles.selectBox, province ? styles.selectBoxFilled : null]} onPress={() => setShowProvincePicker(true)}>
              <Text style={[styles.selectText, !province && styles.selectPlaceholder]}>{province || '省'}</Text>
              <Ionicons name="chevron-down" size={14} color={Colors.textHint} />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.selectBox, city ? styles.selectBoxFilled : null]} onPress={() => province ? setShowCityPicker(true) : null}>
              <Text style={[styles.selectText, !city && styles.selectPlaceholder]}>{city || '市'}</Text>
              <Ionicons name="chevron-down" size={14} color={Colors.textHint} />
            </TouchableOpacity>
          </View>
          {/* 省Picker */}
          <RNModal visible={showProvincePicker} transparent animationType="fade" onRequestClose={() => setShowProvincePicker(false)}>
            <TouchableOpacity style={styles.pickerOverlay} activeOpacity={1} onPress={() => setShowProvincePicker(false)}>
              <View style={styles.pickerBox}>
                <View style={styles.pickerHeader}><Text style={styles.pickerTitle}>选择省/直辖市</Text><TouchableOpacity onPress={() => setShowProvincePicker(false)}><Ionicons name="close" size={22} color={Colors.textPrimary} /></TouchableOpacity></View>
                <FlatList data={Object.keys(PROVINCES)} keyExtractor={(item) => item} style={{ maxHeight: 280 }} renderItem={({ item }) => (
                  <TouchableOpacity style={[styles.pickerItem, province === item && styles.pickerItemActive]} onPress={() => { setProvince(item); setCity(''); setShowProvincePicker(false); }}>
                    <Text style={[styles.pickerItemText, province === item && { color: Colors.primary, fontWeight: '600' }]}>{item}</Text>
                    {province === item && <Ionicons name="checkmark" size={18} color={Colors.primary} />}
                  </TouchableOpacity>
                )} />
              </View>
            </TouchableOpacity>
          </RNModal>
          {/* 市Picker */}
          <RNModal visible={showCityPicker} transparent animationType="fade" onRequestClose={() => setShowCityPicker(false)}>
            <TouchableOpacity style={styles.pickerOverlay} activeOpacity={1} onPress={() => setShowCityPicker(false)}>
              <View style={styles.pickerBox}>
                <View style={styles.pickerHeader}><Text style={styles.pickerTitle}>选择城市</Text><TouchableOpacity onPress={() => setShowCityPicker(false)}><Ionicons name="close" size={22} color={Colors.textPrimary} /></TouchableOpacity></View>
                <FlatList data={PROVINCES[province] || []} keyExtractor={(item) => item} style={{ maxHeight: 280 }} renderItem={({ item }) => (
                  <TouchableOpacity style={[styles.pickerItem, city === item && styles.pickerItemActive]} onPress={() => { setCity(item); setShowCityPicker(false); }}>
                    <Text style={[styles.pickerItemText, city === item && { color: Colors.primary, fontWeight: '600' }]}>{item}</Text>
                    {city === item && <Ionicons name="checkmark" size={18} color={Colors.primary} />}
                  </TouchableOpacity>
                )} />
              </View>
            </TouchableOpacity>
          </RNModal>
        </View>

        <Button title="保存修改" onPress={handleSave} loading={loading} style={styles.saveBtn} />
      </ScrollView>

      <DatePicker
        visible={showBirthdayPicker}
        value={birthYear ? `${birthYear}-${birthMonth.padStart(2, '0')}-${birthDay.padStart(2, '0')}` : ''}
        onConfirm={handleBirthdayConfirm}
        onClose={() => setShowBirthdayPicker(false)}
        title="选择生日"
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgWhite },
  container: { paddingHorizontal: Spacing.lg, paddingBottom: Spacing.xl * 2 },
  adminBlock: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: Spacing.xl },
  adminBlockTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary, marginTop: Spacing.lg },
  adminBlockDesc: { fontSize: Typography.body, color: Colors.textSecondary, marginTop: Spacing.sm, marginBottom: Spacing.xl },
  topBar: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: Spacing.md, marginBottom: Spacing.lg,
  },
  title: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  // 字段
  fieldGroup: { marginBottom: Spacing.lg },
  fieldLabel: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary, marginBottom: Spacing.sm },
  textArea: {
    borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input,
    padding: Spacing.md, fontSize: Typography.body, color: Colors.textPrimary,
    minHeight: 80, textAlignVertical: 'top',
  },
  input: {
    borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input,
    padding: Spacing.md, fontSize: Typography.body, color: Colors.textPrimary,
  },
  hint: { fontSize: Typography.caption, color: Colors.textHint, marginBottom: Spacing.xs },
  // 生日三级下拉
  birthdayRow: { flexDirection: 'row', gap: Spacing.sm },
  selectBox: {
    flex: 1, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input,
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.md,
    backgroundColor: Colors.bgWhite,
  },
  selectBoxFilled: { borderColor: Colors.primary },
  selectText: { fontSize: Typography.body, color: Colors.textPrimary },
  selectPlaceholder: { color: Colors.textHint },
  // 性别
  genderRow: { flexDirection: 'row', gap: Spacing.sm },
  genderBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4,
    paddingVertical: Spacing.sm, borderRadius: BorderRadius.card,
    borderWidth: 1.5, borderColor: Colors.divider,
  },
  genderText: { fontSize: Typography.body, color: Colors.textSecondary },
  saveBtn: { marginTop: Spacing.xl },
  // 省市Picker弹窗（保留）
  pickerOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center', alignItems: 'center',
    padding: Spacing.xl,
  },
  pickerBox: {
    backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    width: '100%', maxWidth: 340, maxHeight: 360,
    overflow: 'hidden',
  },
  pickerHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  pickerTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  pickerItem: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  pickerItemActive: { backgroundColor: Colors.primary + '0C' },
  pickerItemText: { fontSize: Typography.body, color: Colors.textPrimary },
  pickerItemTextActive: { color: Colors.primary, fontWeight: '600' },
});

export default EditProfileScreen;
