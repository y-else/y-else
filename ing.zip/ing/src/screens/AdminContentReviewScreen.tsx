/**
 * 管理员内容审核面板
 * 举报筛选/搜索/批量处理/审核备注/联动内容删除
 *
 * 修复:
 * - 批量选择+批量标记已处理/驳回
 * - 搜索框（举报人/内容/原因）
 * - 审核备注输入弹窗
 * - 使用服务层 handleReportedContent 联动删除
 * - 使用 getAllReportsFiltered 统一筛选逻辑
 * - 举报统计卡片
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Alert, RefreshControl,
  TextInput, Modal as RNModal,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { useAuth } from '../context/AuthContext';
import {
  getAllReportsFiltered, reviewReport, batchReviewReports,
  handleReportedContent, getReportStats,
} from '../services/contentReport';
import type { ContentReport, ReportStatus, ReportStats } from '../services/contentReport';

interface Props { onBack: () => void; }

const TARGET_LABELS: Record<string, string> = {
  space_post: '空间动态', wall_message: '留言', album_item: '相册',
  diary: '日记', user: '用户',
};

const AdminContentReviewScreen: React.FC<Props> = ({ onBack }) => {
  const { state } = useAuth();
  const adminName = state.user?.username || '管理员';
  const [reports, setReports] = useState<ContentReport[]>([]);
  const [stats, setStats] = useState<ReportStats>({ total: 0, pending: 0, reviewed: 0, dismissed: 0 });
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState<ReportStatus | 'all'>('pending');
  const [search, setSearch] = useState('');

  // 批量选择
  const [selectMode, setSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // 审核备注弹窗
  const [noteModalVisible, setNoteModalVisible] = useState(false);
  const [noteText, setNoteText] = useState('');
  const [pendingAction, setPendingAction] = useState<{
    type: 'single' | 'batch';
    report?: ContentReport;
    action: 'reviewed' | 'dismissed';
  } | null>(null);

  const load = useCallback(async () => {
    const s = await getReportStats();
    setStats(s);

    const data = await getAllReportsFiltered(
      filter === 'all' ? undefined : filter,
      search || undefined,
    );
    setReports(data);
  }, [filter, search]);

  useEffect(() => { load(); }, [load]);

  const handleRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  // 打开审核备注弹窗
  const openNoteModal = (type: 'single' | 'batch', action: 'reviewed' | 'dismissed', report?: ContentReport) => {
    setPendingAction({ type, report, action });
    setNoteText(action === 'reviewed' ? '管理员审核通过，内容已处理' : '举报不成立，驳回');
    setNoteModalVisible(true);
  };

  // 确认审核（带备注）
  const confirmReview = async () => {
    if (!pendingAction) return;

    if (pendingAction.type === 'single' && pendingAction.report) {
      await reviewReport(pendingAction.report.id, pendingAction.action, adminName, noteText.trim());

      if (pendingAction.action === 'reviewed') {
        await handleReportedContent(pendingAction.report);
      }
      Alert.alert('已完成', pendingAction.action === 'reviewed' ? '举报已处理，相关内容已下架' : '举报已驳回');
    } else if (pendingAction.type === 'batch') {
      const ids = Array.from(selectedIds);
      if (ids.length === 0) { Alert.alert('提示', '请先选择举报'); return; }

      const { processed } = await batchReviewReports(ids, pendingAction.action, adminName, noteText.trim());

      // 批量处理后联动删除内容
      if (pendingAction.action === 'reviewed') {
        for (const id of ids) {
          const r = reports.find((r) => r.id === id);
          if (r) await handleReportedContent(r);
        }
      }

      Alert.alert('批量处理完成', `已处理 ${processed} 条举报`);
      setSelectMode(false);
      setSelectedIds(new Set());
    }

    setNoteModalVisible(false);
    setPendingAction(null);
    await load();
  };

  // 切换选择
  const toggleSelect = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id); else next.add(id);
    setSelectedIds(next);
  };

  const toggleSelectAll = () => {
    const pendingReports = reports.filter((r) => r.status === 'pending');
    if (selectedIds.size === pendingReports.length && pendingReports.length > 0) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(pendingReports.map((r) => r.id)));
    }
  };

  const exitSelectMode = () => {
    setSelectMode(false);
    setSelectedIds(new Set());
  };

  // 简化版单个审核（无备注）
  const handleQuickReview = (report: ContentReport, action: 'reviewed' | 'dismissed') => {
    openNoteModal('single', action, report);
  };

  const pendingCount = stats.pending;

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      {/* 头部 */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>内容审核</Text>
        <View style={styles.headerRight}>
          {selectMode ? (
            <>
              <TouchableOpacity onPress={toggleSelectAll} style={styles.headerBtn}>
                <Text style={styles.headerBtnText}>
                  {selectedIds.size === reports.filter((r) => r.status === 'pending').length && reports.filter((r) => r.status === 'pending').length > 0 ? '取消全选' : '全选'}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={exitSelectMode} style={styles.headerBtn}>
                <Ionicons name="close" size={20} color={Colors.lover} />
              </TouchableOpacity>
            </>
          ) : (
            <>
              <Text style={styles.headerCount}>{pendingCount}待处理</Text>
              <TouchableOpacity onPress={() => setSelectMode(true)} style={styles.headerBtn}>
                <Ionicons name="checkbox-outline" size={20} color={Colors.primary} />
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>

      {/* 统计卡片 */}
      <View style={styles.statsRow}>
        {[
          { label: '待处理', count: stats.pending, color: Colors.friend },
          { label: '已处理', count: stats.reviewed, color: Colors.family },
          { label: '已驳回', count: stats.dismissed, color: Colors.lover },
          { label: '总计', count: stats.total, color: Colors.admin },
        ].map((item) => (
          <TouchableOpacity
            key={item.label}
            style={[styles.statChip, filter === (item.label === '待处理' ? 'pending' : item.label === '已处理' ? 'reviewed' : item.label === '已驳回' ? 'dismissed' : 'all') && { backgroundColor: item.color + '20', borderColor: item.color }]}
            onPress={() => setFilter(item.label === '待处理' ? 'pending' : item.label === '已处理' ? 'reviewed' : item.label === '已驳回' ? 'dismissed' : 'all')}
          >
            <Text style={[styles.statNum, { color: item.color }]}>{item.count}</Text>
            <Text style={styles.statLabel}>{item.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* 搜索框 */}
      <View style={styles.searchRow}>
        <Ionicons name="search" size={18} color={Colors.textHint} />
        <TextInput
          style={styles.searchInput}
          placeholder="搜索举报人/内容/原因..."
          placeholderTextColor={Colors.textHint}
          value={search}
          onChangeText={setSearch}
          returnKeyType="search"
        />
        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch('')}>
            <Ionicons name="close-circle" size={18} color={Colors.textHint} />
          </TouchableOpacity>
        )}
      </View>

      {/* 筛选标签 */}
      <View style={styles.filterRow}>
        {[
          { key: 'pending' as const, label: '待处理' },
          { key: 'reviewed' as const, label: '已处理' },
          { key: 'dismissed' as const, label: '已驳回' },
          { key: 'all' as const, label: '全部' },
        ].map((f) => (
          <TouchableOpacity
            key={f.key}
            style={[styles.fBtn, filter === f.key && { backgroundColor: Colors.admin, borderColor: Colors.admin }]}
            onPress={() => setFilter(f.key)}
          >
            <Text style={[styles.fText, filter === f.key && { color: '#FFF' }]}>{f.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* 列表 */}
      <FlatList
        data={reports}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
        renderItem={({ item }) => {
          const isSelected = selectedIds.has(item.id);
          return (
            <TouchableOpacity
              style={[
                styles.card,
                item.status === 'pending' && styles.cardPending,
                isSelected && styles.cardSelected,
              ] as any}
              onPress={() => {
                if (selectMode && item.status === 'pending') {
                  toggleSelect(item.id);
                }
              }}
              onLongPress={() => {
                if (!selectMode && item.status === 'pending') {
                  setSelectMode(true);
                  setSelectedIds(new Set([item.id]));
                }
              }}
              activeOpacity={0.7}
            >
              {/* 选择框 */}
              {selectMode && item.status === 'pending' && (
                <View style={styles.checkWrap}>
                  <Ionicons
                    name={isSelected ? 'checkbox' : 'square-outline'}
                    size={22}
                    color={isSelected ? Colors.primary : Colors.textHint}
                  />
                </View>
              )}

              <View style={styles.cardContent}>
                <View style={styles.cardHeader}>
                  <Text style={styles.reporter}>{item.reporterName}</Text>
                  <View style={[styles.tag, {
                    backgroundColor: item.status === 'pending' ? Colors.friend + '20' :
                      item.status === 'reviewed' ? Colors.family + '20' : Colors.textHint + '20',
                  }]}>
                    <Text style={[styles.tagText, {
                      color: item.status === 'pending' ? Colors.friend :
                        item.status === 'reviewed' ? Colors.family : Colors.textHint,
                    }]}>
                      {item.status === 'pending' ? '待处理' : item.status === 'reviewed' ? '已处理' : '已驳回'}
                    </Text>
                  </View>
                </View>

                <Text style={styles.targetType}>
                  举报{TARGET_LABELS[item.targetType] || item.targetType}
                  <Text style={styles.targetId}> · ID:{item.targetId}</Text>
                </Text>
                <Text style={styles.preview} numberOfLines={2}>{item.targetPreview}</Text>
                <Text style={styles.reason}>原因：{item.reason}</Text>
                <Text style={styles.time}>{new Date(item.createdAt).toLocaleString('zh-CN')}</Text>

                {item.reviewedAt && (
                  <Text style={styles.reviewInfo}>
                    处理人：{item.reviewedBy} · {new Date(item.reviewedAt).toLocaleString('zh-CN')}
                    {item.reviewNote ? ` | ${item.reviewNote}` : ''}
                  </Text>
                )}

                {item.status === 'pending' && !selectMode && (
                  <View style={styles.actions}>
                    <TouchableOpacity style={styles.actionBtn} onPress={() => handleQuickReview(item, 'reviewed')}>
                      <Ionicons name="checkmark-circle" size={18} color={Colors.family} />
                      <Text style={[styles.actionText, { color: Colors.family }]}>已处理</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.actionBtn} onPress={() => handleQuickReview(item, 'dismissed')}>
                      <Ionicons name="close-circle" size={18} color={Colors.lover} />
                      <Text style={[styles.actionText, { color: Colors.lover }]}>驳回</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            </TouchableOpacity>
          );
        }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="shield-checkmark" size={48} color={Colors.textHint} />
            <Text style={styles.emptyText}>
              {search ? '未找到匹配的举报' : '暂无举报记录'}
            </Text>
          </View>
        }
      />

      {/* 批量操作栏 */}
      {selectMode && selectedIds.size > 0 && (
        <View style={styles.batchBar}>
          <Text style={styles.batchCount}>已选 {selectedIds.size} 条</Text>
          <View style={styles.batchActions}>
            <TouchableOpacity
              style={[styles.batchBtn, { backgroundColor: Colors.family }]}
              onPress={() => openNoteModal('batch', 'reviewed')}
            >
              <Ionicons name="checkmark-circle" size={18} color="#FFF" />
              <Text style={styles.batchBtnText}>批量已处理</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.batchBtn, { backgroundColor: Colors.lover }]}
              onPress={() => openNoteModal('batch', 'dismissed')}
            >
              <Ionicons name="close-circle" size={18} color="#FFF" />
              <Text style={styles.batchBtnText}>批量驳回</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* 审核备注弹窗 */}
      <RNModal visible={noteModalVisible} transparent animationType="fade">
        <View style={styles.noteOverlay}>
          <View style={styles.noteBox}>
            <Text style={styles.noteTitle}>
              {pendingAction?.action === 'reviewed' ? '标记已处理' : '驳回举报'}
            </Text>
            <Text style={styles.noteHint}>审核备注（可选）：</Text>
            <TextInput
              style={styles.noteInput}
              placeholder="输入审核备注..."
              placeholderTextColor={Colors.textHint}
              value={noteText}
              onChangeText={setNoteText}
              multiline
              numberOfLines={3}
            />
            <View style={styles.noteBtns}>
              <TouchableOpacity
                style={styles.noteCancelBtn}
                onPress={() => { setNoteModalVisible(false); setPendingAction(null); }}
              >
                <Text style={styles.noteCancelText}>取消</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.noteConfirmBtn, { backgroundColor: pendingAction?.action === 'reviewed' ? Colors.family : Colors.lover }]}
                onPress={confirmReview}
              >
                <Text style={styles.noteConfirmText}>确认</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </RNModal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  headerCount: { fontSize: Typography.caption, color: Colors.friend },
  headerBtn: { padding: 4 },
  headerBtnText: { fontSize: Typography.caption, color: Colors.primary, fontWeight: '500' },

  // 统计
  statsRow: {
    flexDirection: 'row', padding: Spacing.md, backgroundColor: Colors.bgWhite, gap: Spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  statChip: {
    flex: 1, alignItems: 'center', paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.input, borderWidth: 1, borderColor: Colors.divider,
  },
  statNum: { fontSize: Typography.subtitle, fontWeight: '700' },
  statLabel: { fontSize: 10, color: Colors.textHint, marginTop: 1 },

  // 搜索
  searchRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: Colors.bgWhite, marginHorizontal: 0,
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  searchInput: { flex: 1, fontSize: Typography.body, color: Colors.textPrimary, paddingVertical: 4 },

  // 筛选
  filterRow: {
    flexDirection: 'row', padding: Spacing.md, backgroundColor: Colors.bgWhite, gap: Spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  fBtn: {
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.input, borderWidth: 1, borderColor: Colors.divider,
  },
  fText: { fontSize: Typography.caption, color: Colors.textSecondary },

  // 列表
  list: { padding: Spacing.lg },
  card: {
    flexDirection: 'row',
    backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    padding: Spacing.lg, marginBottom: Spacing.sm,
    borderLeftWidth: 3, borderLeftColor: Colors.divider,
  },
  cardPending: { borderLeftColor: Colors.friend },
  cardSelected: { borderWidth: 2, borderColor: Colors.primary, borderLeftWidth: 3 },
  checkWrap: { marginRight: Spacing.md, justifyContent: 'center' },
  cardContent: { flex: 1 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  reporter: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary },
  tag: { paddingHorizontal: 6, paddingVertical: 1, borderRadius: 3 },
  tagText: { fontSize: 10, fontWeight: '500' },
  targetType: { fontSize: Typography.caption, color: Colors.textHint, marginBottom: 4 },
  targetId: { fontFamily: 'monospace', fontSize: 10 },
  preview: { fontSize: Typography.body, color: Colors.textSecondary, marginBottom: 4, lineHeight: 20 },
  reason: { fontSize: Typography.caption, color: Colors.lover, marginBottom: 4 },
  time: { fontSize: 10, color: Colors.textHint },
  reviewInfo: { fontSize: 10, color: Colors.family, marginTop: 4 },
  actions: { flexDirection: 'row', gap: Spacing.lg, marginTop: Spacing.md, paddingTop: Spacing.sm, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider },
  actionBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  actionText: { fontSize: Typography.caption, fontWeight: '500' },
  empty: { alignItems: 'center', paddingVertical: Spacing.xl * 3 },
  emptyText: { fontSize: Typography.body, color: Colors.textHint, marginTop: Spacing.md },

  // 批量操作栏
  batchBar: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    backgroundColor: Colors.bgWhite, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider,
  },
  batchCount: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary },
  batchActions: { flexDirection: 'row', gap: Spacing.sm },
  batchBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.input,
  },
  batchBtnText: { fontSize: Typography.caption, color: '#FFF', fontWeight: '600' },

  // 备注弹窗
  noteOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center', alignItems: 'center',
    padding: Spacing.lg,
  },
  noteBox: {
    width: '100%', backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    padding: Spacing.lg,
  },
  noteTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.md },
  noteHint: { fontSize: Typography.body, color: Colors.textSecondary, marginBottom: Spacing.sm },
  noteInput: {
    borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input,
    padding: Spacing.md, fontSize: Typography.body, color: Colors.textPrimary,
    minHeight: 80, textAlignVertical: 'top', marginBottom: Spacing.lg,
  },
  noteBtns: { flexDirection: 'row', gap: Spacing.md },
  noteCancelBtn: {
    flex: 1, alignItems: 'center', paddingVertical: Spacing.md,
    borderRadius: BorderRadius.input, borderWidth: 1, borderColor: Colors.divider,
  },
  noteCancelText: { fontSize: Typography.body, color: Colors.textSecondary },
  noteConfirmBtn: {
    flex: 1, alignItems: 'center', paddingVertical: Spacing.md,
    borderRadius: BorderRadius.input,
  },
  noteConfirmText: { fontSize: Typography.body, color: '#FFF', fontWeight: '600' },
});

export default AdminContentReviewScreen;
