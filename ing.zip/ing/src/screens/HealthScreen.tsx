/**
 * 健康页面（增强版）
 * 作息打卡、心情记录、身体备注、编辑、分享、好友动态、管理员台账
 *
 * 修复:
 * - 新增编辑健康记录功能
 * - 好友动态支持展开更多
 * - 管理员按类型筛选
 * - mountedRef 防内存泄漏
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert,
  TextInput, RefreshControl,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card, Button, Modal, TimePicker } from '../components';
import { useAuth } from '../context/AuthContext';
import {
  getMyHealthRecords, createHealthRecord, updateHealthRecord, deleteHealthRecord,
  shareHealthStatus, unshareHealthStatus, getFriendsHealthUpdates, getAllHealthRecords,
  getHealthRecordsByType,
} from '../services/health';
import { getContacts } from '../services/contacts';
import { MOOD_OPTIONS, type HealthRecord, type MoodType, type HealthRecordType } from '../types';

interface HealthScreenProps {
  onBack: () => void;
}

const HealthScreen: React.FC<HealthScreenProps> = ({ onBack }) => {
  const { state } = useAuth();
  const user = state.user;
  const isAdmin = user?.role === 'admin';

  const [records, setRecords] = useState<HealthRecord[]>([]);
  const [friendsRecords, setFriendsRecords] = useState<HealthRecord[]>([]);
  const [friendsExpanded, setFriendsExpanded] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [editingRecord, setEditingRecord] = useState<HealthRecord | null>(null);

  // 管理员筛选
  const [adminTypeFilter, setAdminTypeFilter] = useState<HealthRecordType | 'all'>('all');

  // 表单
  const [recordType, setRecordType] = useState<HealthRecordType>('checkin');
  const [selectedMood, setSelectedMood] = useState<MoodType | null>(null);
  const [bodyNote, setBodyNote] = useState('');
  // 默认为当前北京时间
  const getBeijingTime = () => {
    const now = new Date();
    const beijing = new Date(now.getTime() + (8 * 60 - now.getTimezoneOffset()) * 60000);
    return `${String(beijing.getHours()).padStart(2, '0')}:${String(beijing.getMinutes()).padStart(2, '0')}`;
  };
  const [checkinTime, setCheckinTime] = useState(getBeijingTime());
  const [showCheckinTimePicker, setShowCheckinTimePicker] = useState(false);
  const [isShared, setIsShared] = useState(true);

  const mountedRef = useRef(true);
  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  const loadData = useCallback(async () => {
    if (!user) return;
    if (isAdmin) {
      if (adminTypeFilter === 'all') {
        const all = await getAllHealthRecords();
        if (mountedRef.current) setRecords(all);
      } else {
        const filtered = await getHealthRecordsByType(adminTypeFilter);
        if (mountedRef.current) setRecords(filtered);
      }
    } else {
      const mine = await getMyHealthRecords(user.id);
      if (mountedRef.current) setRecords(mine);
      const friends = await getFriendsHealthUpdates(user.id);
      if (mountedRef.current) setFriendsRecords(friends);
    }
  }, [user, isAdmin, adminTypeFilter]);

  useEffect(() => { loadData(); }, [loadData]);

  const handleRefresh = async () => { setRefreshing(true); await loadData(); setRefreshing(false); };

  const resetForm = () => {
    setRecordType('checkin'); setSelectedMood(null); setBodyNote('');
    setCheckinTime('08:00'); setIsShared(true); setEditingRecord(null);
  };

  const handleCreate = async () => {
    if (!user) return;
    if (recordType === 'mood' && !selectedMood) { Alert.alert('提示', '请选择心情'); return; }
    await createHealthRecord({
      userId: user.id, username: user.username,
      type: recordType,
      mood: selectedMood || undefined,
      bodyNote: bodyNote.trim() || undefined,
      checkinTime: recordType === 'checkin' ? checkinTime : undefined,
      isShared,
      visibleTo: [],
    });
    resetForm();
    setShowCreate(false);
    await loadData();
  };

  const handleEdit = (record: HealthRecord) => {
    setEditingRecord(record);
    setRecordType(record.type);
    setSelectedMood(record.mood || null);
    setBodyNote(record.bodyNote || '');
    setCheckinTime(record.checkinTime || '08:00');
    setIsShared(record.isShared);
    setShowCreate(true);
  };

  const handleUpdate = async () => {
    if (!editingRecord) return;
    if (recordType === 'mood' && !selectedMood) { Alert.alert('提示', '请选择心情'); return; }
    await updateHealthRecord(editingRecord.id, {
      mood: selectedMood || undefined,
      bodyNote: bodyNote.trim() || undefined,
      checkinTime: recordType === 'checkin' ? checkinTime : undefined,
      isShared,
    });
    resetForm();
    setShowCreate(false);
    await loadData();
  };

  const handleDelete = (id: string) => {
    Alert.alert('删除记录', '确定删除此健康记录？', [
      { text: '取消', style: 'cancel' },
      { text: '删除', style: 'destructive', onPress: async () => { await deleteHealthRecord(id); await loadData(); } },
    ]);
  };

  const handleShare = async (record: HealthRecord) => {
    const contacts = await getContacts();
    const bound = contacts.filter((c) => !c.isBlocked);
    if (bound.length === 0) { Alert.alert('提示', '暂无已绑定好友可分享'); return; }
    const options: Array<{ text: string; onPress?: () => void; style?: 'cancel' | 'destructive' | 'default' }> = bound.map((c) => ({
      text: `${c.username}${record.visibleTo.includes(c.userId) ? ' (已分享)' : ''}`,
      onPress: async () => {
        if (record.visibleTo.includes(c.userId)) {
          await unshareHealthStatus(record.id, c.userId);
          Alert.alert('已取消', `已取消对 ${c.username} 的分享`);
        } else {
          await shareHealthStatus(record.id, c.userId);
          Alert.alert('分享成功', `健康状态已分享给 ${c.username}`);
        }
        await loadData();
      },
    }));
    options.push({ text: '取消', style: 'cancel' });
    Alert.alert('分享/取消分享', '选择好友（已分享的点击取消）：', options);
  };

  const getMoodInfo = (mood?: MoodType) => MOOD_OPTIONS.find((m) => m.type === mood);
  const getRecordIcon = (type: HealthRecordType) => {
    if (type === 'checkin') return { name: 'sunny-outline', color: Colors.friend };
    if (type === 'mood') return { name: 'heart-outline', color: Colors.lover };
    return { name: 'fitness-outline', color: Colors.primary };
  };
  const getRecordLabel = (type: HealthRecordType) => {
    if (type === 'checkin') return '作息打卡';
    if (type === 'mood') return '心情记录';
    return '身体备注';
  };

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return `${d.getMonth() + 1}月${d.getDate()}日 ${d.toTimeString().slice(0, 5)}`;
  };

  const displayedFriends = friendsExpanded ? friendsRecords : friendsRecords.slice(0, 3);

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>健康</Text>
        {!isAdmin && (
          <TouchableOpacity onPress={() => { resetForm(); setShowCreate(true); }}>
            <Ionicons name="add-circle" size={28} color={Colors.primary} />
          </TouchableOpacity>
        )}
        {isAdmin && <View style={{ width: 28 }} />}
      </View>

      <ScrollView
        contentContainerStyle={styles.container}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={[Colors.primary]} />}
      >
        {/* 管理员筛选栏 */}
        {isAdmin && (
          <View style={styles.filterRow}>
            {[
              { key: 'all' as const, label: '全部' },
              { key: 'checkin' as const, label: '打卡' },
              { key: 'mood' as const, label: '心情' },
              { key: 'body_note' as const, label: '备注' },
            ].map((f) => (
              <TouchableOpacity
                key={f.key}
                style={[styles.filterBtn, adminTypeFilter === f.key && styles.filterBtnActive]}
                onPress={() => setAdminTypeFilter(f.key)}
              >
                <Text style={[styles.filterBtnText, adminTypeFilter === f.key && styles.filterBtnTextActive]}>
                  {f.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* 好友动态（非管理员） */}
        {!isAdmin && friendsRecords.length > 0 && (
          <>
            <Text style={styles.sectionTitle}>好友健康动态</Text>
            {displayedFriends.map((r) => (
              <Card key={r.id} style={styles.friendCard}>
                <View style={styles.friendHeader}>
                  <Text style={styles.friendName}>{r.username}</Text>
                  <Text style={styles.friendTime}>{formatDate(r.createdAt)}</Text>
                </View>
                {r.type === 'mood' && r.mood && (
                  <View style={styles.moodDisplay}>
                    <Text style={styles.moodEmoji}>{getMoodInfo(r.mood)?.emoji}</Text>
                    <Text style={styles.moodLabel}>{getMoodInfo(r.mood)?.label}</Text>
                  </View>
                )}
                {r.type === 'checkin' && r.checkinTime && (
                  <Text style={styles.checkinText}>打卡 {r.checkinTime}</Text>
                )}
                {r.bodyNote && <Text style={styles.bodyText}>{r.bodyNote}</Text>}
              </Card>
            ))}
            {friendsRecords.length > 3 && (
              <TouchableOpacity
                style={styles.expandBtn}
                onPress={() => setFriendsExpanded(!friendsExpanded)}
              >
                <Text style={styles.expandBtnText}>
                  {friendsExpanded ? '收起' : `查看全部 (${friendsRecords.length}条)`}
                </Text>
                <Ionicons
                  name={friendsExpanded ? 'chevron-up' : 'chevron-down'}
                  size={14}
                  color={Colors.primary}
                />
              </TouchableOpacity>
            )}
          </>
        )}

        {/* 我的记录 / 全站台账(管理员) */}
        <Text style={styles.sectionTitle}>{isAdmin ? '全站健康台账' : '我的健康记录'}</Text>
        {records.length === 0 ? (
          <View style={styles.empty}>
            <Ionicons name="heart-outline" size={48} color={Colors.textHint} />
            <Text style={styles.emptyText}>{isAdmin ? '暂无用户记录' : '暂无健康记录'}</Text>
          </View>
        ) : (
          records.map((r) => {
            const icon = getRecordIcon(r.type);
            const moodInfo = r.mood ? getMoodInfo(r.mood) : null;
            return (
              <Card key={r.id} style={styles.recordCard}>
                <View style={styles.recordHeader}>
                  <View style={[styles.recordIcon, { backgroundColor: icon.color + '20' }]}>
                    <Ionicons name={icon.name as any} size={18} color={icon.color} />
                  </View>
                  <View style={styles.recordInfo}>
                    <Text style={styles.recordLabel}>
                      {r.username} · {getRecordLabel(r.type)}
                      {r.isShared && <Text style={styles.sharedMark}> 已分享</Text>}
                    </Text>
                    <Text style={styles.recordTime}>{formatDate(r.createdAt)}</Text>
                  </View>
                  {!isAdmin && (
                    <View style={styles.recordActions}>
                      <TouchableOpacity onPress={() => handleEdit(r)} style={styles.actionBtn}>
                        <Ionicons name="create-outline" size={16} color={Colors.textSecondary} />
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => handleShare(r)} style={styles.actionBtn}>
                        <Ionicons name="share-outline" size={16} color={Colors.primary} />
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => handleDelete(r.id)} style={styles.actionBtn}>
                        <Ionicons name="trash-outline" size={16} color={Colors.lover} />
                      </TouchableOpacity>
                    </View>
                  )}
                </View>
                {r.type === 'mood' && moodInfo && (
                  <View style={styles.moodRow}>
                    <Text style={styles.moodEmoji}>{moodInfo.emoji}</Text>
                    <Text style={[styles.moodLabel, { color: moodInfo.color }]}>{moodInfo.label}</Text>
                  </View>
                )}
                {r.type === 'checkin' && r.checkinTime && (
                  <Text style={styles.checkinRow}>作息打卡：{r.checkinTime}</Text>
                )}
                {r.bodyNote && <Text style={styles.bodyRow}>备注：{r.bodyNote}</Text>}
              </Card>
            );
          })
        )}
        <View style={{ height: 40 }} />
      </ScrollView>

      {/* 新建/编辑弹窗 */}
      <Modal
        visible={showCreate}
        title={editingRecord ? '编辑健康记录' : '新建健康记录'}
        onClose={() => { setShowCreate(false); resetForm(); }}
        confirmText={editingRecord ? '保存修改' : '保存'}
        onConfirm={editingRecord ? handleUpdate : handleCreate}
      >
        {/* 编辑模式下类型不可变 */}
        {!editingRecord && (
          <>
            <Text style={styles.formLabel}>记录类型</Text>
            <View style={styles.typeRow}>
              {[
                { key: 'checkin' as HealthRecordType, label: '作息打卡', icon: 'sunny-outline' },
                { key: 'mood' as HealthRecordType, label: '心情记录', icon: 'heart-outline' },
                { key: 'body_note' as HealthRecordType, label: '身体备注', icon: 'fitness-outline' },
              ].map((t) => (
                <TouchableOpacity
                  key={t.key}
                  style={[styles.typeBtn, recordType === t.key && { backgroundColor: Colors.primary, borderColor: Colors.primary }]}
                  onPress={() => setRecordType(t.key)}
                >
                  <Ionicons name={t.icon as any} size={14} color={recordType === t.key ? '#FFF' : Colors.primary} />
                  <Text style={[styles.typeBtnText, recordType === t.key && { color: '#FFF' }]}>{t.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </>
        )}

        {editingRecord && (
          <Text style={styles.editTypeHint}>类型：{getRecordLabel(recordType)}（不可更改）</Text>
        )}

        {/* 心情选择 */}
        {(recordType === 'mood') && (
          <>
            <Text style={styles.formLabel}>心情</Text>
            <View style={styles.moodGrid}>
              {MOOD_OPTIONS.map((m) => (
                <TouchableOpacity
                  key={m.type}
                  style={[styles.moodBtn, selectedMood === m.type && { backgroundColor: m.color + '20', borderColor: m.color }]}
                  onPress={() => setSelectedMood(m.type)}
                >
                  <Text style={styles.moodEmojiLarge}>{m.emoji}</Text>
                  <Text style={[styles.moodName, selectedMood === m.type && { color: m.color }]}>{m.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </>
        )}

        {/* 打卡时间 */}
        {recordType === 'checkin' && (
          <>
            <Text style={styles.formLabel}>打卡时间</Text>
            <TouchableOpacity style={styles.formInput} onPress={() => setShowCheckinTimePicker(true)} activeOpacity={0.6}>
              <Text style={checkinTime ? styles.formInputText : styles.formPlaceholder}>{checkinTime || '请选择时间'}</Text>
            </TouchableOpacity>
          </>
        )}

        {/* 身体备注 */}
        {(recordType === 'body_note' || recordType === 'checkin') && (
          <>
            <Text style={styles.formLabel}>备注</Text>
            <TextInput style={[styles.formInput, styles.formArea]} placeholder="身体状态备注（选填）" placeholderTextColor={Colors.textHint} value={bodyNote} onChangeText={setBodyNote} multiline numberOfLines={3} />
          </>
        )}

        <TouchableOpacity
          style={styles.shareToggle}
          onPress={() => setIsShared(!isShared)}
          activeOpacity={0.7}
        >
          <Ionicons name={isShared ? 'earth' : 'lock-closed'} size={18} color={isShared ? Colors.primary : Colors.textHint} />
          <Text style={styles.shareToggleText}>{isShared ? '公开分享' : '仅自己可见'}</Text>
          <Ionicons name="chevron-forward" size={14} color={Colors.textHint} />
        </TouchableOpacity>
      </Modal>
      <TimePicker visible={showCheckinTimePicker} value={checkinTime} onConfirm={(v) => { setCheckinTime(v); setShowCheckinTimePicker(false); }} onClose={() => setShowCheckinTimePicker(false)} title="选择打卡时间" />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  container: { padding: Spacing.lg },
  // 管理员筛选
  filterRow: { flexDirection: 'row', gap: Spacing.sm, marginBottom: Spacing.md },
  filterBtn: {
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.input, backgroundColor: Colors.bgWhite,
    borderWidth: 1, borderColor: Colors.divider,
  },
  filterBtnActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  filterBtnText: { fontSize: Typography.caption, color: Colors.textSecondary },
  filterBtnTextActive: { color: Colors.white, fontWeight: '500' },
  sectionTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.md, marginTop: Spacing.lg },
  // 好友动态
  friendCard: { marginBottom: Spacing.sm },
  friendHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: Spacing.sm },
  friendName: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  friendTime: { fontSize: Typography.caption, color: Colors.textHint },
  moodDisplay: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
  moodLabel: { fontSize: Typography.body, color: Colors.textSecondary },
  moodEmoji: { fontSize: 20 },
  checkinText: { fontSize: Typography.body, color: Colors.family },
  bodyText: { fontSize: Typography.caption, color: Colors.textSecondary, marginTop: 4 },
  expandBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: Spacing.xs, paddingVertical: Spacing.md,
  },
  expandBtnText: { fontSize: Typography.caption, color: Colors.primary },
  // 记录列表
  recordCard: { marginBottom: Spacing.sm },
  recordHeader: { flexDirection: 'row', alignItems: 'center' },
  recordIcon: {
    width: 36, height: 36, borderRadius: 18,
    alignItems: 'center', justifyContent: 'center', marginRight: Spacing.md,
  },
  recordInfo: { flex: 1 },
  recordLabel: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  recordTime: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  sharedMark: { fontSize: Typography.caption, color: Colors.family },
  recordActions: { flexDirection: 'row', gap: Spacing.sm },
  actionBtn: { padding: 4 },
  moodRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, marginTop: Spacing.sm, paddingLeft: 44 },
  checkinRow: { fontSize: Typography.body, color: Colors.family, marginTop: Spacing.sm, paddingLeft: 44 },
  bodyRow: { fontSize: Typography.caption, color: Colors.textSecondary, marginTop: 4, paddingLeft: 44 },
  // 空状态
  empty: { alignItems: 'center', paddingVertical: Spacing.xl * 2, gap: Spacing.lg },
  emptyText: { fontSize: Typography.body, color: Colors.textHint },
  // 弹窗
  formLabel: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary, marginBottom: Spacing.xs, marginTop: Spacing.sm },
  editTypeHint: { fontSize: Typography.caption, color: Colors.textHint, marginTop: Spacing.sm, marginBottom: Spacing.sm },
  formInput: {
    borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input,
    padding: Spacing.md, justifyContent: 'center', minHeight: 44,
  },
  formInputText: { fontSize: Typography.body, color: Colors.textPrimary },
  formPlaceholder: { fontSize: Typography.body, color: Colors.textHint },
  formArea: { minHeight: 80, textAlignVertical: 'top' },
  typeRow: { flexDirection: 'row', gap: Spacing.sm },
  typeBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4,
    paddingVertical: Spacing.sm, borderRadius: BorderRadius.card, borderWidth: 1,
    borderColor: Colors.divider, backgroundColor: Colors.bgWhite,
  },
  typeBtnText: { fontSize: Typography.caption, fontWeight: '500' },
  moodGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  moodBtn: {
    alignItems: 'center', paddingVertical: Spacing.md, paddingHorizontal: Spacing.lg,
    borderRadius: BorderRadius.card, borderWidth: 1, borderColor: Colors.divider,
    backgroundColor: Colors.bgWhite, width: '30%',
  },
  moodEmojiLarge: { fontSize: 28, marginBottom: 4 },
  moodName: { fontSize: Typography.caption, color: Colors.textSecondary },
  shareToggle: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    paddingVertical: Spacing.md, marginTop: Spacing.lg,
    borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider,
  },
  shareToggleText: { flex: 1, fontSize: Typography.body, color: Colors.textPrimary },
});

export default HealthScreen;
