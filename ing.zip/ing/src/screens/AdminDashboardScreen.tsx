/**
 * 管理员后台主面板（统计+快捷入口+审计日志+登出）
 * 用户列表/注册审核已拆分至 AdminUsersScreen
 *
 * 修复:
 * - 6项统计数据（含本周新增）
 * - 操作日志内联展示（修正导航错误）
 * - 刷新时异常处理
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, RefreshControl,
  FlatList,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card } from '../components';
import { useAuth } from '../context/AuthContext';
import { getAdminStats, getAuditLogs } from '../services/admin';
import type { AdminStats, AdminOperationLog } from '../types';

interface AdminDashboardScreenProps {
  onBack: () => void;
  onViewUser: (userId: string, username: string) => void;
  onNavigateAnnouncement: () => void;
  onNavigateLottery: () => void;
  onNavigateAuditLogs: () => void;
  onNavigatePhoneUsage: () => void;
  onNavigateRedemption: () => void;
  onNavigateSOS: () => void;
  onNavigateContentReview: () => void;
  onNavigateFeedback: () => void;
}

const AdminDashboardScreen: React.FC<AdminDashboardScreenProps> = ({
  onBack, onNavigateAnnouncement, onNavigateLottery, onNavigateAuditLogs,
  onNavigatePhoneUsage, onNavigateRedemption, onNavigateSOS, onNavigateContentReview, onNavigateFeedback,
}) => {
  const { state, logout } = useAuth();
  const adminName = state.user?.username || '管理员';
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [showAuditLogs, setShowAuditLogs] = useState(false);
  const [auditLogs, setAuditLogs] = useState<AdminOperationLog[]>([]);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      const s = await getAdminStats();
      setStats(s);
    } catch (e) {
      console.warn('[仪表盘] 加载统计失败:', e);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await loadData();
    } catch { /* 忽略 */ }
    setRefreshing(false);
  };

  // 查看操作日志（内联展示）
  const handleViewAuditLogs = async () => {
    if (showAuditLogs) {
      setShowAuditLogs(false);
      return;
    }
    const logs = await getAuditLogs();
    setAuditLogs(logs);
    setShowAuditLogs(true);
  };

  // 登出
  const handleLogout = () => {
    Alert.alert('退出登录', '确定退出管理员后台？', [
      { text: '取消', style: 'cancel' },
      {
        text: '退出',
        style: 'destructive',
        onPress: () => logout(),
      },
    ]);
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      {/* 头部 + 登出按钮 */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Ionicons name="shield" size={18} color={Colors.admin} />
          <Text style={styles.headerTitle}>管理员后台</Text>
        </View>
        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout} activeOpacity={0.7}>
          <Ionicons name="log-out-outline" size={20} color={Colors.lover} />
          <Text style={styles.logoutText}>退出</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={[Colors.primary]} />
        }
      >
        {/* 管理员身份卡片 */}
        <View style={styles.adminCard}>
          <View style={[styles.adminGradientBg, { backgroundColor: Colors.admin + '10' }]} />
          <View style={styles.adminRow}>
            <View style={styles.adminAvatar}>
              <Ionicons name="shield" size={32} color={Colors.admin} />
            </View>
            <View style={styles.adminInfo}>
              <Text style={styles.adminName}>{adminName}</Text>
              <Text style={styles.adminRole}>系统管理员 · 超级权限</Text>
            </View>
            <TouchableOpacity style={styles.logoutBtnInline} onPress={handleLogout}>
              <Ionicons name="log-out-outline" size={18} color={Colors.lover} />
            </TouchableOpacity>
          </View>
        </View>

        {/* 统计面板 — 6项数据 */}
        {stats && (
          <>
            <Text style={styles.sectionLabel}>数据概览</Text>
            <View style={styles.statsGrid}>
              <View style={[styles.statCard, { borderLeftColor: Colors.primary }]}>
                <Text style={[styles.statNum, { color: Colors.primary }]}>{stats.totalUsers}</Text>
                <Text style={styles.statLabel}>总用户</Text>
              </View>
              <View style={[styles.statCard, { borderLeftColor: Colors.family }]}>
                <Text style={[styles.statNum, { color: Colors.family }]}>{stats.onlineUsers}</Text>
                <Text style={styles.statLabel}>在线</Text>
              </View>
              <View style={[styles.statCard, { borderLeftColor: Colors.lover }]}>
                <Text style={[styles.statNum, { color: Colors.lover }]}>{stats.sosToday}</Text>
                <Text style={styles.statLabel}>今日SOS</Text>
              </View>
              <View style={[styles.statCard, { borderLeftColor: Colors.friend }]}>
                <Text style={[styles.statNum, { color: Colors.friend }]}>{stats.activeUsersToday}</Text>
                <Text style={styles.statLabel}>今日活跃</Text>
              </View>
              <View style={[styles.statCard, { borderLeftColor: Colors.admin }]}>
                <Text style={[styles.statNum, { color: Colors.admin }]}>{stats.newUsersThisWeek}</Text>
                <Text style={styles.statLabel}>本周新增</Text>
              </View>
              <View style={[styles.statCard, { borderLeftColor: '#7B68EE' }]}>
                <Text style={[styles.statNum, { color: '#7B68EE' }]}>{stats.totalSpacePosts}</Text>
                <Text style={styles.statLabel}>空间动态</Text>
              </View>
            </View>

            {/* 实名统计行 */}
            <View style={styles.verifyRow}>
              <View style={[styles.verifyCard, { backgroundColor: Colors.family + '10' }]}>
                <Text style={[styles.verifyNum, { color: Colors.family }]}>{stats.verifiedUsers}</Text>
                <Text style={styles.verifyLabel}>已实名</Text>
              </View>
              <View style={[styles.verifyCard, { backgroundColor: Colors.textHint + '15' }]}>
                <Text style={[styles.verifyNum, { color: Colors.textHint }]}>{stats.unverifiedUsers}</Text>
                <Text style={styles.verifyLabel}>未实名</Text>
              </View>
            </View>
          </>
        )}

        {/* 快捷功能入口 */}
        <Text style={styles.sectionLabel}>快捷管理</Text>
        <View style={styles.quickGrid}>
          {[
            { label: '发布公告', icon: 'megaphone' as const, desc: '系统公告推送', onPress: onNavigateAnnouncement, color: Colors.friend },
            { label: '抽奖管理', icon: 'gift' as const, desc: '奖品/概率配置', onPress: onNavigateLottery, color: Colors.lover },
            { label: '操作日志', icon: 'document-text' as const, desc: '审计记录查看', onPress: handleViewAuditLogs, color: Colors.admin },
            { label: '手机监测', icon: 'phone-portrait' as const, desc: '全站使用数据', onPress: onNavigatePhoneUsage, color: '#7B68EE' },
            { label: '兑换码', icon: 'pricetags' as const, desc: '生成/管理兑换码', onPress: onNavigateRedemption, color: Colors.friend },
            { label: 'SOS管理', icon: 'warning' as const, desc: '全站SOS记录', onPress: onNavigateSOS, color: Colors.lover },
            { label: '内容审核', icon: 'shield-checkmark' as const, desc: '举报内容处理', onPress: onNavigateContentReview, color: '#FF6B35' },
            { label: '用户反馈', icon: 'chatbubbles' as const, desc: '反馈与联系消息', onPress: onNavigateFeedback, color: Colors.primary },
          ].map((item) => (
            <TouchableOpacity
              key={item.label}
              style={styles.quickCard}
              onPress={item.onPress}
              activeOpacity={0.7}
            >
              <View style={[styles.quickIcon, { backgroundColor: item.color + '15' }]}>
                <Ionicons name={item.icon} size={28} color={item.color} />
              </View>
              <Text style={styles.quickLabel}>{item.label}</Text>
              <Text style={styles.quickDesc}>{item.desc}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* 审计日志内联展示 */}
        {showAuditLogs && (
          <Card style={styles.auditSection}>
            <View style={styles.auditHeader}>
              <Text style={styles.auditTitle}>操作日志 ({auditLogs.length})</Text>
              <TouchableOpacity onPress={() => setShowAuditLogs(false)}>
                <Ionicons name="close" size={20} color={Colors.textHint} />
              </TouchableOpacity>
            </View>
            {auditLogs.length === 0 ? (
              <Text style={styles.emptyHint}>暂无操作日志</Text>
            ) : (
              auditLogs.slice(0, 50).map((log) => (
                <View key={log.id} style={styles.auditItem}>
                  <View style={styles.auditDot} />
                  <View style={styles.auditContent}>
                    <Text style={styles.auditAction}>
                      {log.action === 'reset_password' ? '重置密码' :
                       log.action === 'force_unbind' ? '强制解绑' :
                       log.action === 'approve_register' ? '通过注册' :
                       log.action === 'reject_register' ? '驳回注册' :
                       log.action === 'publish_announcement' ? '发布公告' :
                       log.action === 'update_lottery' ? '更新抽奖' :
                       log.action === 'update_permission' ? '更新权限' :
                       log.action === 'delete_user' ? '注销用户' :
                       log.action === 'edit_user_info' ? '编辑用户' :
                       log.action}
                      {log.targetUsername ? ` · ${log.targetUsername}` : ''}
                    </Text>
                    <Text style={styles.auditMeta}>
                      {log.adminName} · {new Date(log.timestamp).toLocaleString('zh-CN')}
                    </Text>
                    {log.detail ? (
                      <Text style={styles.auditDetail} numberOfLines={1}>{log.detail}</Text>
                    ) : null}
                  </View>
                </View>
              ))
            )}
          </Card>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerCenter: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  logoutBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.input, borderWidth: 1, borderColor: Colors.lover + '60',
  },
  logoutText: { fontSize: Typography.caption, color: Colors.lover, fontWeight: '500' },
  adminCard: {
    margin: Spacing.lg, marginBottom: 0,
    backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    padding: Spacing.lg, overflow: 'hidden',
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06, shadowRadius: 6, elevation: 2,
  },
  adminGradientBg: {
    position: 'absolute', top: 0, left: 0, right: 0, height: 80,
  },
  adminRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  adminAvatar: {
    width: 52, height: 52, borderRadius: 26,
    backgroundColor: Colors.admin + '18', alignItems: 'center', justifyContent: 'center',
  },
  adminInfo: { flex: 1 },
  adminName: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  adminRole: { fontSize: Typography.caption, color: Colors.admin, marginTop: 2 },
  logoutBtnInline: { padding: 4 },
  sectionLabel: {
    fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary,
    paddingHorizontal: Spacing.lg, marginTop: Spacing.lg, marginBottom: Spacing.md,
  },
  // 统计
  statsGrid: {
    flexDirection: 'row', flexWrap: 'wrap',
    paddingHorizontal: Spacing.lg, gap: Spacing.sm,
  },
  statCard: {
    width: '31%', backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    borderLeftWidth: 3,
    padding: Spacing.md, marginBottom: Spacing.xs,
  },
  statNum: { fontSize: Typography.title, fontWeight: '700' },
  statLabel: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  verifyRow: {
    flexDirection: 'row', paddingHorizontal: Spacing.lg, gap: Spacing.sm, marginTop: Spacing.sm,
  },
  verifyCard: {
    flex: 1, borderRadius: BorderRadius.card, padding: Spacing.md,
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
  },
  verifyNum: { fontSize: Typography.subtitle, fontWeight: '700' },
  verifyLabel: { fontSize: Typography.caption, color: Colors.textHint },
  // 快捷功能
  quickGrid: {
    flexDirection: 'row', flexWrap: 'wrap',
    paddingHorizontal: Spacing.lg, gap: Spacing.md,
  },
  quickCard: {
    width: '46%', backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    padding: Spacing.lg, marginBottom: Spacing.sm, alignItems: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04, shadowRadius: 3, elevation: 1,
  },
  quickIcon: {
    width: 56, height: 56, borderRadius: 28,
    alignItems: 'center', justifyContent: 'center', marginBottom: Spacing.sm,
  },
  quickLabel: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary, marginBottom: 2 },
  quickDesc: { fontSize: Typography.caption, color: Colors.textHint, textAlign: 'center' },
  // 审计日志
  auditSection: { marginHorizontal: Spacing.lg, marginTop: Spacing.lg },
  auditHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    marginBottom: Spacing.md,
  },
  auditTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  auditItem: {
    flexDirection: 'row', gap: Spacing.sm,
    paddingVertical: Spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  auditDot: {
    width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.admin,
    marginTop: 6,
  },
  auditContent: { flex: 1 },
  auditAction: { fontSize: Typography.caption, fontWeight: '500', color: Colors.textPrimary },
  auditMeta: { fontSize: 10, color: Colors.textHint, marginTop: 1 },
  auditDetail: { fontSize: 10, color: Colors.textHint, marginTop: 1 },
  emptyHint: {
    fontSize: Typography.caption, color: Colors.textHint,
    textAlign: 'center', paddingVertical: Spacing.lg,
  },
});

export default AdminDashboardScreen;
