/**
 * 管理员抽奖管理系统（完整版）
 * 全局配置 / 奖品CRUD / 概率校验 / 指定用户专属配置 / 中奖记录 / 申请审核
 *
 * 核心修复:
 * - 新增"中奖记录"Tab，支持分页查看所有用户中奖记录
 * - 新增活动时间范围配置UI(startAt/endAt)
 * - 奖品编辑时正确处理remainingCount
 * - 使用类型安全的admin service接口
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, TextInput, Switch,
  FlatList, PanResponder, type GestureResponderEvent, type PanResponderGestureState,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Button, Card, Modal, SearchBar, DateTimePicker } from '../components';
import { useAuth } from '../context/AuthContext';
import {
  getLotteryConfig, updateLotteryConfig,
  getLotteryApplications, processLotteryApplication,
  getAllUsersBrief,
  getLotteryRecords,
  getUserLotteryRules, saveUserLotteryRules,
} from '../services/admin';
import type { LotteryConfig, LotteryPrize } from '../types';

// ====== 类型 ======

interface PrizeEdit {
  id: string; name: string; type: 'virtual' | 'physical';
  totalCount: number; remainingCount: number;
  probability: number; probStr: string;
}
interface UserRule {
  id: string; userId: string; username: string; phone: string;
  prizes: PrizeEdit[]; maxDrawsPerDay: number; isActive: boolean;
}
interface LotteryRecordItem {
  id: string; userId: string; username: string; prizeName: string; wonAt: string;
}

// ====== 概率滑块组件 ======
// 替代 TextInput 输入概率，触摸/拖拽设置 0-100%，减少输入错误
interface ProbSliderProps {
  value: number; // 0~1 概率值
  onValueChange: (prob: number) => void;
}

const ProbSlider: React.FC<ProbSliderProps> = ({ value, onValueChange }) => {
  const barRef = useRef<View>(null);
  const barWidth = useRef(0);

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: (e: GestureResponderEvent) => {
        updateFromTouch(e.nativeEvent.locationX);
      },
      onPanResponderMove: (e: GestureResponderEvent) => {
        updateFromTouch(e.nativeEvent.locationX);
      },
      onPanResponderRelease: () => {},
    }),
  ).current;

  const updateFromTouch = (x: number) => {
    if (barWidth.current <= 0) return;
    const ratio = Math.max(0, Math.min(1, x / barWidth.current));
    // 按1%精度取整后转概率
    const pct = Math.round(ratio * 100);
    onValueChange(pct / 100);
  };

  const pct = Math.round(value * 100);

  return (
    <View style={sliderStyles.container}>
      <View
        ref={(ref) => {
          barRef.current = ref as any;
          if (ref) {
            ref.measure((_x, _y, width) => { barWidth.current = width; });
          }
        }}
        style={sliderStyles.track}
        {...panResponder.panHandlers}
      >
        <View style={[sliderStyles.fill, { width: `${Math.min(100, pct)}%` as any }]} />
        <View style={[sliderStyles.thumb, { left: `${Math.min(100, pct)}%` as any }]} />
      </View>
      <View style={sliderStyles.labels}>
        <Text style={sliderStyles.labelText}>0%</Text>
        <Text style={sliderStyles.valueText}>{pct}%</Text>
        <Text style={sliderStyles.labelText}>100%</Text>
      </View>
    </View>
  );
};

const sliderStyles = StyleSheet.create({
  container: { marginBottom: Spacing.sm },
  track: {
    height: 32, borderRadius: 16, backgroundColor: Colors.divider,
    justifyContent: 'center', position: 'relative', overflow: 'visible',
  },
  fill: {
    position: 'absolute', left: 0, top: 0, bottom: 0,
    backgroundColor: Colors.admin, borderRadius: 16,
    minWidth: 16,
  },
  thumb: {
    position: 'absolute', top: -4,
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: Colors.admin,
    borderWidth: 3, borderColor: Colors.bgWhite,
    marginLeft: -20,
    elevation: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.2, shadowRadius: 2,
  },
  labels: {
    flexDirection: 'row', justifyContent: 'space-between',
    marginTop: 4, paddingHorizontal: 2,
  },
  labelText: { fontSize: 10, color: Colors.textHint },
  valueText: { fontSize: 12, fontWeight: '700', color: Colors.admin },
});

interface Props { onBack: () => void; }

const AdminLotteryScreen: React.FC<Props> = ({ onBack }) => {
  const { state } = useAuth();
  const [tab, setTab] = useState<'global' | 'users' | 'records' | 'applications'>('global');

  // ====== 全局配置 ======
  const [config, setConfig] = useState<LotteryConfig | null>(null);
  const [isActive, setIsActive] = useState(false);
  const [maxDraws, setMaxDraws] = useState('3');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [showStartDatePicker, setShowStartDatePicker] = useState(false);
  const [showEndDatePicker, setShowEndDatePicker] = useState(false);
  const [prizes, setPrizes] = useState<PrizeEdit[]>([]);
  const [saving, setSaving] = useState(false);

  // ====== 奖品编辑弹窗 ======
  const [showPrizeModal, setShowPrizeModal] = useState(false);
  const [editingPrize, setEditingPrize] = useState<PrizeEdit | null>(null);
  const [prizeForm, setPrizeForm] = useState({ name: '', type: 'virtual' as 'virtual' | 'physical', totalCount: '10', probStr: '0.1' });

  // ====== 申请 ======
  const [applications, setApplications] = useState<any[]>([]);

  // ====== 用户专属 ======
  const [userRules, setUserRules] = useState<UserRule[]>([]);
  const [showUserRuleModal, setShowUserRuleModal] = useState(false);
  const [editingRule, setEditingRule] = useState<UserRule | null>(null);
  const [ruleForm, setRuleForm] = useState({
    userId: '', username: '', phone: '',
    prizeProbStr: '', prizeName: '',
    maxDraws: '3', isActive: true,
  });
  const [userSearchResults, setUserSearchResults] = useState<any[]>([]);

  // ====== 中奖记录 ======
  const [lotteryRecords, setLotteryRecords] = useState<LotteryRecordItem[]>([]);
  const [recordsTotal, setRecordsTotal] = useState(0);
  const [recordsPage, setRecordsPage] = useState(1);
  const [loadingRecords, setLoadingRecords] = useState(false);

  // 加载
  const loadAll = useCallback(async () => {
    const c = await getLotteryConfig();
    setConfig(c);
    setIsActive(c.status === 'active');
    setMaxDraws(String(c.maxDrawsPerDay || 3));
    // 格式化时间为 YYYY-MM-DD HH:mm
    setStartDate(c.startAt ? formatDateTime(c.startAt) : '');
    setEndDate(c.endAt ? formatDateTime(c.endAt) : '');
    setPrizes(c.prizes?.map((p: LotteryPrize) => ({
      id: p.id, name: p.name, type: p.type || 'virtual',
      totalCount: p.totalCount || 10, remainingCount: p.remainingCount ?? p.totalCount ?? 10,
      probability: p.probability || 0, probStr: String(p.probability || 0),
    })) || []);
    const apps = await getLotteryApplications(); setApplications(apps);
    const rules = await getUserLotteryRules();
    setUserRules(rules.map((r: any) => ({
      ...r,
      prizes: (r.prizes || []).map((p: any) => ({
        id: p.id, name: p.name, type: p.type || 'virtual',
        totalCount: p.totalCount || 1, remainingCount: p.remainingCount ?? p.totalCount ?? 1,
        probability: p.probability || 0, probStr: String(p.probability || 0),
      })),
    })));
    // 加载中奖记录
    loadRecords(1);
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  const loadRecords = async (page: number) => {
    setLoadingRecords(true);
    const { records, total } = await getLotteryRecords(page, 20);
    setLotteryRecords(records);
    setRecordsTotal(total);
    setRecordsPage(page);
    setLoadingRecords(false);
  };

  // 格式化 ISO → YYYY-MM-DD HH:mm
  const formatDateTime = (iso: string): string => {
    try {
      const d = new Date(iso);
      if (isNaN(d.getTime())) return '';
      const pad = (n: number) => String(n).padStart(2, '0');
      return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
    } catch { return ''; }
  };

  // 解析 YYYY-MM-DD HH:mm → ISO
  const parseDateTime = (str: string): string => {
    try {
      const d = new Date(str);
      if (isNaN(d.getTime())) return '';
      return d.toISOString();
    } catch { return ''; }
  };

  // ====== 概率校验 ======
  const getProbSum = (list: PrizeEdit[]): number =>
    list.reduce((s, p) => s + (parseFloat(p.probStr) || 0), 0);

  // ====== 全局奖品CRUD ======
  const handleAddPrize = () => {
    setEditingPrize(null);
    setPrizeForm({ name: '', type: 'virtual', totalCount: '10', probStr: '0.1' });
    setShowPrizeModal(true);
  };
  const handleEditPrize = (p: PrizeEdit) => {
    setEditingPrize(p);
    setPrizeForm({ name: p.name, type: p.type, totalCount: String(p.totalCount), probStr: p.probStr });
    setShowPrizeModal(true);
  };
  const handleSavePrize = () => {
    if (!prizeForm.name.trim()) { Alert.alert('提示', '请输入奖品名称'); return; }
    const prob = parseFloat(prizeForm.probStr);
    if (isNaN(prob) || prob < 0 || prob > 1) { Alert.alert('提示', '概率需在0~1之间'); return; }
    const newTotal = parseInt(prizeForm.totalCount) || 10;

    if (editingPrize) {
      setPrizes((prev) => prev.map((p) => {
        if (p.id !== editingPrize.id) return p;
        // 修复: totalCount变化时调整remainingCount
        const delta = newTotal - p.totalCount;
        const newRemaining = Math.max(0, (p.remainingCount ?? p.totalCount) + delta);
        return {
          ...p,
          name: prizeForm.name.trim(),
          type: prizeForm.type,
          totalCount: newTotal,
          remainingCount: newRemaining,
          probStr: prizeForm.probStr,
          probability: prob,
        };
      }));
    } else {
      const newP: PrizeEdit = {
        id: 'pz_' + Date.now(),
        name: prizeForm.name.trim(), type: prizeForm.type,
        totalCount: newTotal, remainingCount: newTotal,
        probability: prob, probStr: prizeForm.probStr,
      };
      setPrizes((prev) => [...prev, newP]);
    }
    setShowPrizeModal(false);
  };
  const handleDeletePrize = (id: string) => {
    Alert.alert('删除奖品', '确定删除？', [
      { text: '取消', style: 'cancel' },
      { text: '删除', style: 'destructive', onPress: () => setPrizes((prev) => prev.filter((p) => p.id !== id)) },
    ]);
  };

  // ====== 保存全局配置 ======
  const handleSaveGlobal = async () => {
    const probSum = getProbSum(prizes);
    if (probSum > 1.0001) {
      Alert.alert('概率校验失败', `奖品总概率为 ${(probSum * 100).toFixed(1)}%，已超过100%，请调整。`);
      return;
    }
    setSaving(true);
    const newConfig: LotteryConfig = {
      id: config?.id || 'default',
      status: isActive ? 'active' : 'inactive',
      maxDrawsPerDay: parseInt(maxDraws) || 3,
      prizes: prizes.map((p) => ({
        id: p.id, name: p.name, imageUri: null,
        type: p.type,
        totalCount: p.totalCount,
        remainingCount: p.remainingCount,
        probability: parseFloat(p.probStr) || 0,
      })),
      startAt: parseDateTime(startDate) || new Date().toISOString(),
      endAt: parseDateTime(endDate) || new Date(Date.now() + 86400000 * 30).toISOString(),
    };
    await updateLotteryConfig(newConfig);
    setSaving(false);
    Alert.alert('保存成功', '全局抽奖配置已更新并实时生效');
    loadAll();
  };

  // ====== 申请审核 ======
  const handleProcess = (app: any, approved: boolean) => {
    Alert.alert(approved ? '确认中奖' : '未中奖', `处理 ${app.username} 的申请？`, [
      { text: '取消', style: 'cancel' },
      { text: '确定', onPress: async () => { await processLotteryApplication(app.id, approved); loadAll(); } },
    ]);
  };

  // ====== 用户搜索 ======
  const handleSearchUser = async (q: string) => {
    if (!q.trim()) { setUserSearchResults([]); return; }
    const all = await getAllUsersBrief();
    setUserSearchResults(all.filter((u) => u.username.includes(q) || u.phone.includes(q)).slice(0, 5));
  };

  // ====== 用户专属规则CRUD ======
  const handleAddUserRule = () => {
    setEditingRule(null);
    setRuleForm({ userId: '', username: '', phone: '', prizeProbStr: '0.5', prizeName: '专属大奖', maxDraws: '3', isActive: true });
    setUserSearchResults([]);
    setShowUserRuleModal(true);
  };
  const handleEditUserRule = (r: UserRule) => {
    setEditingRule(r);
    setRuleForm({ userId: r.userId, username: r.username, phone: r.phone, prizeProbStr: String(r.prizes[0]?.probability || 0.5), prizeName: r.prizes[0]?.name || '专属大奖', maxDraws: String(r.maxDrawsPerDay), isActive: r.isActive });
    setShowUserRuleModal(true);
  };
  const handleSaveUserRule = async () => {
    if (!ruleForm.userId) { Alert.alert('提示', '请先搜索并选择用户'); return; }
    const prob = parseFloat(ruleForm.prizeProbStr);
    if (isNaN(prob) || prob < 0 || prob > 1) { Alert.alert('提示', '概率需在0~1之间'); return; }
    const prizeEntry: PrizeEdit = editingRule?.prizes?.[0]
      ? { ...editingRule.prizes[0], name: ruleForm.prizeName.trim(), probability: prob, probStr: ruleForm.prizeProbStr }
      : { id: 'upz_' + Date.now(), name: ruleForm.prizeName.trim(), type: 'virtual' as const, totalCount: 1, remainingCount: 1, probability: prob, probStr: ruleForm.prizeProbStr };
    const newRule: UserRule = editingRule
      ? { ...editingRule, prizes: [prizeEntry], maxDrawsPerDay: parseInt(ruleForm.maxDraws) || 3, isActive: ruleForm.isActive }
      : { id: 'ur_' + Date.now(), userId: ruleForm.userId, username: ruleForm.username, phone: ruleForm.phone, prizes: [prizeEntry], maxDrawsPerDay: parseInt(ruleForm.maxDraws) || 3, isActive: true };
    const updated = editingRule ? userRules.map((r) => r.id === newRule.id ? newRule : r) : [...userRules, newRule];
    await saveUserLotteryRules(updated);
    setUserRules(updated);
    setShowUserRuleModal(false);
    Alert.alert('保存成功', '用户专属抽奖规则已更新');
  };
  const handleDeleteUserRule = (id: string) => {
    Alert.alert('删除规则', '确定删除该用户的专属抽奖规则？', [
      { text: '取消', style: 'cancel' },
      { text: '删除', style: 'destructive', onPress: async () => {
        const updated = userRules.filter((r) => r.id !== id);
        await saveUserLotteryRules(updated);
        setUserRules(updated);
      }},
    ]);
  };

  const totalPages = Math.max(1, Math.ceil(recordsTotal / 20));

  // ====== 渲染 ======
  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}><Ionicons name="arrow-back" size={24} color={Colors.textPrimary} /></TouchableOpacity>
        <Text style={styles.headerTitle}>抽奖管理</Text>
        <View style={{ width: 24 }} />
      </View>

      {/* Tab切换 */}
      <View style={styles.tabRow}>
        {[
          { key: 'global' as const, label: '全局配置' },
          { key: 'users' as const, label: `用户专属 (${userRules.length})` },
          { key: 'records' as const, label: `中奖记录 (${recordsTotal})` },
          { key: 'applications' as const, label: `申请 (${applications.length})` },
        ].map((t) => (
          <TouchableOpacity key={t.key} style={[styles.tab, tab === t.key && styles.tabActive]} onPress={() => setTab(t.key)}>
            <Text style={[styles.tabText, tab === t.key && styles.tabActiveText]}>{t.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView contentContainerStyle={styles.container}>
        {/* ====== 全局配置 ====== */}
        {tab === 'global' && (
          <>
            <Card style={styles.section}>
              <Text style={styles.sectionTitle}>活动开关</Text>
              <View style={styles.switchRow}>
                <Text style={styles.switchLabel}>{isActive ? '活动进行中' : '活动已关闭'}</Text>
                <Switch value={isActive} onValueChange={setIsActive} trackColor={{ false: Colors.divider, true: Colors.family + '60' }} thumbColor={isActive ? Colors.family : '#f4f3f4'} />
              </View>
              <View style={styles.inputRow}>
                <Text style={styles.inputLabel}>每日抽奖次数</Text>
                <TextInput style={styles.numInput} keyboardType="number-pad" value={maxDraws} onChangeText={setMaxDraws} placeholderTextColor={Colors.textHint} />
              </View>
            </Card>

            <Card style={styles.section}>
              <Text style={styles.sectionTitle}>活动时间</Text>
              <View style={styles.inputRow}>
                <Text style={styles.inputLabel}>开始时间</Text>
                <TouchableOpacity style={[styles.numInput, { width: 160, justifyContent: 'center' }]} onPress={() => setShowStartDatePicker(true)} activeOpacity={0.6}>
                  <Text style={startDate ? styles.inputText : styles.placeholderText}>
                    {startDate ? startDate.replace('T', ' ').slice(0, 16) : '2025-01-01 00:00'}
                  </Text>
                </TouchableOpacity>
              </View>
              <View style={styles.inputRow}>
                <Text style={styles.inputLabel}>结束时间</Text>
                <TouchableOpacity style={[styles.numInput, { width: 160, justifyContent: 'center' }]} onPress={() => setShowEndDatePicker(true)} activeOpacity={0.6}>
                  <Text style={endDate ? styles.inputText : styles.placeholderText}>
                    {endDate ? endDate.replace('T', ' ').slice(0, 16) : '2025-12-31 23:59'}
                  </Text>
                </TouchableOpacity>
              </View>
            </Card>

            <Card style={styles.section}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>奖品列表</Text>
                <TouchableOpacity onPress={handleAddPrize}>
                  <Ionicons name="add-circle" size={28} color={Colors.primary} />
                </TouchableOpacity>
              </View>
              <Text style={styles.probSum}>
                总概率:{' '}
                <Text style={{ color: getProbSum(prizes) > 1 ? Colors.lover : Colors.family, fontWeight: '700' }}>
                  {(getProbSum(prizes) * 100).toFixed(1)}%
                </Text>
                {' '}(不能超过100%)
              </Text>
              {prizes.map((p) => (
                <View key={p.id} style={styles.prizeItem}>
                  <View style={{ flex: 1 }}>
                    <View style={styles.prizeHeader}>
                      <Text style={styles.prizeName}>{p.name}</Text>
                      <View style={[styles.typeTag, { backgroundColor: p.type === 'physical' ? Colors.friend + '20' : Colors.primary + '20' }]}>
                        <Text style={[styles.typeTagText, { color: p.type === 'physical' ? Colors.friend : Colors.primary }]}>{p.type === 'physical' ? '实物' : '虚拟'}</Text>
                      </View>
                    </View>
                    <Text style={styles.prizeMeta}>库存: {p.remainingCount}/{p.totalCount} | 概率: {(parseFloat(p.probStr) * 100).toFixed(1)}%</Text>
                  </View>
                  <TouchableOpacity onPress={() => handleEditPrize(p)} style={styles.iconBtn}>
                    <Ionicons name="create-outline" size={18} color={Colors.primary} />
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => handleDeletePrize(p.id)} style={styles.iconBtn}>
                    <Ionicons name="trash-outline" size={18} color={Colors.lover} />
                  </TouchableOpacity>
                </View>
              ))}
            </Card>

            <Button title="保存全局配置" onPress={handleSaveGlobal} loading={saving} style={styles.saveBtn} />
          </>
        )}

        {/* ====== 用户专属 ====== */}
        {tab === 'users' && (
          <>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>用户专属抽奖配置</Text>
              <TouchableOpacity onPress={handleAddUserRule}>
                <Ionicons name="person-add" size={24} color={Colors.admin} />
              </TouchableOpacity>
            </View>
            <Text style={styles.hint}>用户专属规则优先级高于全局配置，命中专属用户时使用专属奖品与概率。</Text>
            {userRules.length === 0 ? (
              <Text style={styles.empty}>暂无用户专属配置</Text>
            ) : (
              userRules.map((r) => (
                <Card key={r.id} style={styles.ruleCard}>
                  <View style={styles.ruleHeader}>
                    <View>
                      <Text style={styles.ruleUser}>{r.username}</Text>
                      <Text style={styles.rulePhone}>{r.phone}</Text>
                    </View>
                    <View style={[styles.statusTag, { backgroundColor: r.isActive ? Colors.family + '20' : Colors.textHint + '20' }]}>
                      <Text style={[styles.statusTagText, { color: r.isActive ? Colors.family : Colors.textHint }]}>{r.isActive ? '启用' : '禁用'}</Text>
                    </View>
                  </View>
                  {r.prizes.map((p) => (
                    <Text key={p.id} style={styles.rulePrize}>🎁 {p.name}（概率: {(p.probability * 100).toFixed(1)}%）</Text>
                  ))}
                  <Text style={styles.ruleMeta}>每日 {r.maxDrawsPerDay} 次</Text>
                  <View style={styles.ruleActions}>
                    <TouchableOpacity onPress={() => handleEditUserRule(r)}><Text style={{ color: Colors.primary, fontSize: Typography.caption }}>编辑</Text></TouchableOpacity>
                    <TouchableOpacity onPress={() => handleDeleteUserRule(r.id)}><Text style={{ color: Colors.lover, fontSize: Typography.caption }}>删除</Text></TouchableOpacity>
                  </View>
                </Card>
              ))
            )}
          </>
        )}

        {/* ====== 中奖记录 ====== */}
        {tab === 'records' && (
          <>
            <Text style={styles.sectionTitle}>所有用户中奖记录</Text>
            <Text style={styles.hint}>共 {recordsTotal} 条记录</Text>
            {lotteryRecords.length === 0 ? (
              <Text style={styles.empty}>暂无中奖记录</Text>
            ) : (
              <>
                {lotteryRecords.map((r) => (
                  <Card key={r.id} style={styles.recordCard}>
                    <View style={styles.recordRow}>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.recordPrize}>{r.prizeName}</Text>
                        <Text style={styles.recordMeta}>{r.username} · {new Date(r.wonAt).toLocaleString('zh-CN')}</Text>
                      </View>
                      <Ionicons
                        name={r.prizeName?.includes('谢谢') ? 'close-circle' : 'trophy'}
                        size={22}
                        color={r.prizeName?.includes('谢谢') ? Colors.textHint : Colors.friend}
                      />
                    </View>
                  </Card>
                ))}
                {/* 分页器 */}
                {totalPages > 1 && (
                  <View style={styles.pagination}>
                    <TouchableOpacity
                      style={[styles.pageBtn, recordsPage <= 1 && styles.pageBtnDisabled]}
                      disabled={recordsPage <= 1}
                      onPress={() => loadRecords(recordsPage - 1)}
                    >
                      <Text style={[styles.pageBtnText, recordsPage <= 1 && styles.pageBtnTextDisabled]}>上一页</Text>
                    </TouchableOpacity>
                    <Text style={styles.pageInfo}>{recordsPage}/{totalPages}</Text>
                    <TouchableOpacity
                      style={[styles.pageBtn, recordsPage >= totalPages && styles.pageBtnDisabled]}
                      disabled={recordsPage >= totalPages}
                      onPress={() => loadRecords(recordsPage + 1)}
                    >
                      <Text style={[styles.pageBtnText, recordsPage >= totalPages && styles.pageBtnTextDisabled]}>下一页</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </>
            )}
          </>
        )}

        {/* ====== 申请处理 ====== */}
        {tab === 'applications' && (
          applications.length === 0 ? (
            <Text style={styles.empty}>暂无抽奖申请</Text>
          ) : (
            applications.map((app) => (
              <Card key={app.id} style={styles.appCard}>
                <View style={styles.appHeader}>
                  <Text style={styles.appUser}>{app.username}</Text>
                  <View style={[styles.appStatus, { backgroundColor: app.result === 'pending' ? Colors.friend + '20' : app.result === 'won' ? Colors.family + '20' : Colors.textHint + '20' }]}>
                    <Text style={[styles.appStatusText, { color: app.result === 'pending' ? Colors.friend : app.result === 'won' ? Colors.family : Colors.textHint }]}>
                      {app.result === 'pending' ? '待处理' : app.result === 'won' ? '已中奖' : '未中奖'}
                    </Text>
                  </View>
                </View>
                <Text style={styles.appTime}>{new Date(app.appliedAt).toLocaleString('zh-CN')}</Text>
                {app.result === 'pending' && (
                  <View style={styles.appActions}>
                    <Button title="中奖" onPress={() => handleProcess(app, true)} style={{ flex: 1 }} />
                    <Button title="未中奖" onPress={() => handleProcess(app, false)} variant="outline" style={{ flex: 1 }} />
                  </View>
                )}
              </Card>
            ))
          )
        )}
      </ScrollView>

      {/* ====== 奖品编辑弹窗 ====== */}
      <Modal visible={showPrizeModal} title={editingPrize ? '编辑奖品' : '新增奖品'} onClose={() => setShowPrizeModal(false)} confirmText="保存" onConfirm={handleSavePrize}>
        <Text style={styles.formLabel}>奖品名称</Text>
        <TextInput style={styles.formInput} placeholder="如：手机一部" placeholderTextColor={Colors.textHint} value={prizeForm.name} onChangeText={(t) => setPrizeForm({ ...prizeForm, name: t })} />
        <Text style={styles.formLabel}>类型</Text>
        <View style={styles.typeRow}>
          <TouchableOpacity style={[styles.typeBtn, prizeForm.type === 'virtual' && { backgroundColor: Colors.primary, borderColor: Colors.primary }]} onPress={() => setPrizeForm({ ...prizeForm, type: 'virtual' })}>
            <Text style={[styles.typeBtnText, prizeForm.type === 'virtual' && { color: '#FFF' }]}>虚拟</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.typeBtn, prizeForm.type === 'physical' && { backgroundColor: Colors.friend, borderColor: Colors.friend }]} onPress={() => setPrizeForm({ ...prizeForm, type: 'physical' })}>
            <Text style={[styles.typeBtnText, prizeForm.type === 'physical' && { color: '#FFF' }]}>实物</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.formLabel}>奖品数量</Text>
        <TextInput style={styles.formInput} keyboardType="number-pad" value={prizeForm.totalCount} onChangeText={(t) => setPrizeForm({ ...prizeForm, totalCount: t })} />
        <Text style={styles.formLabel}>中奖概率</Text>
        <ProbSlider
          value={parseFloat(prizeForm.probStr) || 0}
          onValueChange={(prob) => setPrizeForm({ ...prizeForm, probStr: String(prob) })}
        />
        <TextInput
          style={[styles.formInput, { marginTop: Spacing.xs }]}
          keyboardType="decimal-pad"
          placeholder="微调输入概率值，如 0.15"
          placeholderTextColor={Colors.textHint}
          value={prizeForm.probStr}
          onChangeText={(t) => setPrizeForm({ ...prizeForm, probStr: t })}
        />
      </Modal>

      {/* ====== 用户专属规则弹窗 ====== */}
      <Modal visible={showUserRuleModal} title={editingRule ? '编辑专属规则' : '新增用户专属规则'} onClose={() => setShowUserRuleModal(false)} confirmText="保存" onConfirm={handleSaveUserRule}>
        <Text style={styles.formLabel}>搜索用户</Text>
        <SearchBar placeholder="输入用户名或手机号搜索" onSearch={handleSearchUser} onClear={() => setUserSearchResults([])} />
        {userSearchResults.map((u) => (
          <TouchableOpacity key={u.userId} style={[styles.userItem, ruleForm.userId === u.userId && styles.userItemActive]} onPress={() => setRuleForm({ ...ruleForm, userId: u.userId, username: u.username, phone: u.phone })}>
            <Text style={styles.userItemName}>{u.username}</Text>
            <Text style={styles.userItemPhone}>{u.phone}</Text>
            {ruleForm.userId === u.userId && <Ionicons name="checkmark-circle" size={18} color={Colors.family} />}
          </TouchableOpacity>
        ))}
        {ruleForm.userId ? <Text style={styles.selectedUser}>已选: {ruleForm.username} ({ruleForm.phone})</Text> : null}
        <Text style={styles.formLabel}>专属奖品名称</Text>
        <TextInput style={styles.formInput} placeholder="如：VIP专属大奖" placeholderTextColor={Colors.textHint} value={ruleForm.prizeName} onChangeText={(t) => setRuleForm({ ...ruleForm, prizeName: t })} />
        <Text style={styles.formLabel}>中奖概率</Text>
        <ProbSlider
          value={parseFloat(ruleForm.prizeProbStr) || 0}
          onValueChange={(prob) => setRuleForm({ ...ruleForm, prizeProbStr: String(prob) })}
        />
        <TextInput
          style={[styles.formInput, { marginTop: Spacing.xs }]}
          keyboardType="decimal-pad"
          placeholder="微调输入概率值，如 0.8"
          placeholderTextColor={Colors.textHint}
          value={ruleForm.prizeProbStr}
          onChangeText={(t) => setRuleForm({ ...ruleForm, prizeProbStr: t })}
        />
        <Text style={styles.formLabel}>每日次数</Text>
        <TextInput style={styles.formInput} keyboardType="number-pad" value={ruleForm.maxDraws} onChangeText={(t) => setRuleForm({ ...ruleForm, maxDraws: t })} />
        <View style={styles.switchRow}>
          <Text style={styles.switchLabel}>启用规则</Text>
          <Switch value={ruleForm.isActive} onValueChange={(v) => setRuleForm({ ...ruleForm, isActive: v })} trackColor={{ false: Colors.divider, true: Colors.family + '60' }} thumbColor={ruleForm.isActive ? Colors.family : '#f4f3f4'} />
        </View>
      </Modal>
      <DateTimePicker visible={showStartDatePicker} value={startDate} onConfirm={(v) => { setStartDate(v); setShowStartDatePicker(false); }} onClose={() => setShowStartDatePicker(false)} title="选择开始时间" />
      <DateTimePicker visible={showEndDatePicker} value={endDate} onConfirm={(v) => { setEndDate(v); setShowEndDatePicker(false); }} onClose={() => setShowEndDatePicker(false)} title="选择结束时间" />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.bgWhite, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  tabRow: { flexDirection: 'row', backgroundColor: Colors.bgWhite, paddingHorizontal: Spacing.lg, paddingBottom: Spacing.sm, gap: Spacing.xs, flexWrap: 'wrap' },
  tab: { paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, borderRadius: BorderRadius.input, backgroundColor: Colors.bgPrimary },
  tabActive: { backgroundColor: Colors.admin },
  tabText: { fontSize: Typography.caption, color: Colors.textSecondary },
  tabActiveText: { color: Colors.white, fontWeight: '500' },
  container: { padding: Spacing.lg },
  // 全局
  section: { marginBottom: Spacing.md },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.md },
  sectionTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.sm },
  switchRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: Spacing.sm },
  switchLabel: { fontSize: Typography.body, color: Colors.textPrimary },
  inputRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: Spacing.sm },
  inputLabel: { fontSize: Typography.body, color: Colors.textPrimary },
  numInput: { borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input, paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, fontSize: Typography.body, color: Colors.textPrimary, width: 60, textAlign: 'center' },
  inputText: { fontSize: Typography.caption, color: Colors.textPrimary },
  placeholderText: { fontSize: Typography.caption, color: Colors.textHint },
  probSum: { fontSize: Typography.caption, color: Colors.textSecondary, marginBottom: Spacing.md },
  prizeItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: Spacing.md, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider },
  prizeHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, marginBottom: 2 },
  prizeName: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary },
  typeTag: { paddingHorizontal: 6, paddingVertical: 1, borderRadius: 3 },
  typeTagText: { fontSize: 10, fontWeight: '500' },
  prizeMeta: { fontSize: Typography.caption, color: Colors.textHint },
  iconBtn: { padding: Spacing.xs },
  saveBtn: { marginTop: Spacing.lg },
  // 用户专属
  hint: { fontSize: Typography.caption, color: Colors.textHint, marginBottom: Spacing.lg, lineHeight: 18 },
  empty: { textAlign: 'center', fontSize: Typography.body, color: Colors.textHint, paddingVertical: Spacing.xl * 2 },
  ruleCard: { marginBottom: Spacing.sm },
  ruleHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: Spacing.xs },
  ruleUser: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary },
  rulePhone: { fontSize: Typography.caption, color: Colors.textHint },
  statusTag: { paddingHorizontal: 8, paddingVertical: 1, borderRadius: 4 },
  statusTagText: { fontSize: 10, fontWeight: '500' },
  rulePrize: { fontSize: Typography.body, color: Colors.textSecondary, marginTop: 4 },
  ruleMeta: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 4 },
  ruleActions: { flexDirection: 'row', gap: Spacing.lg, marginTop: Spacing.sm, paddingTop: Spacing.sm, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider },
  // 中奖记录
  recordCard: { marginBottom: Spacing.sm },
  recordRow: { flexDirection: 'row', alignItems: 'center' },
  recordPrize: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary },
  recordMeta: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  pagination: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: Spacing.lg, gap: Spacing.lg },
  pageBtn: { paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm, borderRadius: BorderRadius.card, backgroundColor: Colors.primary },
  pageBtnDisabled: { backgroundColor: Colors.divider },
  pageBtnText: { fontSize: Typography.caption, color: '#FFF', fontWeight: '500' },
  pageBtnTextDisabled: { color: Colors.textHint },
  pageInfo: { fontSize: Typography.body, color: Colors.textSecondary },
  // 申请
  appCard: { marginBottom: Spacing.sm },
  appHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  appUser: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  appStatus: { paddingHorizontal: 8, paddingVertical: 1, borderRadius: 3 },
  appStatusText: { fontSize: Typography.caption, fontWeight: '500' },
  appTime: { fontSize: Typography.caption, color: Colors.textHint },
  appActions: { flexDirection: 'row', gap: Spacing.sm, marginTop: Spacing.md },
  // 弹窗
  formLabel: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary, marginBottom: 4, marginTop: Spacing.sm },
  formInput: { borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input, padding: Spacing.md, fontSize: Typography.body, color: Colors.textPrimary },
  typeRow: { flexDirection: 'row', gap: Spacing.sm, marginBottom: Spacing.sm },
  typeBtn: { flex: 1, paddingVertical: Spacing.sm, borderRadius: BorderRadius.card, borderWidth: 1, borderColor: Colors.divider, alignItems: 'center' },
  typeBtnText: { fontSize: Typography.caption, fontWeight: '500' },
  userItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: Spacing.sm, paddingHorizontal: Spacing.md, borderRadius: BorderRadius.input, backgroundColor: Colors.bgPrimary, marginBottom: 4 },
  userItemActive: { backgroundColor: Colors.admin + '15', borderWidth: 1, borderColor: Colors.admin },
  userItemName: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  userItemPhone: { fontSize: Typography.caption, color: Colors.textHint },
  selectedUser: { fontSize: Typography.caption, color: Colors.family, fontWeight: '500', marginTop: Spacing.xs, marginBottom: Spacing.md },
});

export default AdminLotteryScreen;
