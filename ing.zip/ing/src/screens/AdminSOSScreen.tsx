/**
 * 管理员SOS管理面板（增强版）
 * 全站SOS记录 / 状态标记 / 异常预警 / 搜索筛选 / 时间范围 / 详情弹窗 / 分页
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Alert, RefreshControl,
  Modal as RNModal, ScrollView, TextInput,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card, SearchBar, Button, DatePicker } from '../components';
import { useAuth } from '../context/AuthContext';
import { getAllSOSRecords, getAbnormalSOSRecords, resolveSOSAlert, getSOSTrajectory } from '../services/sos';
import type { SOSRecord, SOSStatusType } from '../services/sos';
import type { LocationData } from '../services/gps';

// ====== 分页配置 ======
const PAGE_SIZE = 20;

interface AdminSOSScreenProps {
  onBack: () => void;
}

const STATUS_OPTIONS: { key: SOSStatusType | 'all'; label: string; color: string }[] = [
  { key: 'all', label: '全部', color: Colors.primary },
  { key: 'pending', label: '待处理', color: Colors.lover },
  { key: 'processing', label: '处理中', color: Colors.friend },
  { key: 'resolved', label: '已处理', color: Colors.family },
  { key: 'false_alarm', label: '误触', color: Colors.textHint },
  { key: 'cancelled', label: '已取消', color: Colors.textHint },
];

const AdminSOSScreen: React.FC<AdminSOSScreenProps> = ({ onBack }) => {
  const { state } = useAuth();
  const adminName = state.user?.username || '管理员';

  const [allRecords, setAllRecords] = useState<SOSRecord[]>([]);
  const [abnormalRecords, setAbnormalRecords] = useState<SOSRecord[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [filterStatus, setFilterStatus] = useState<SOSStatusType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  // 日期筛选（统一DatePicker）
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [showFromDatePicker, setShowFromDatePicker] = useState(false);
  const [showToDatePicker, setShowToDatePicker] = useState(false);
  const [showAbnormal, setShowAbnormal] = useState(true);
  const [page, setPage] = useState(0);

  // 详情弹窗
  const [detailRecord, setDetailRecord] = useState<SOSRecord | null>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [detailTrajectory, setDetailTrajectory] = useState<LocationData[]>([]);
  const [loadingTrajectory, setLoadingTrajectory] = useState(false);

  const loadData = useCallback(async () => {
    const all = await getAllSOSRecords();
    setAllRecords(all);
    const abnormal = await getAbnormalSOSRecords();
    setAbnormalRecords(abnormal);
    setPage(0);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleRefresh = async () => { setRefreshing(true); await loadData(); setRefreshing(false); };

  // 多维度筛选
  const filteredRecords = useMemo(() => {
    let result = allRecords;

    // 状态筛选
    if (filterStatus !== 'all') {
      result = result.filter((r) => r.sosStatus === filterStatus);
    }

    // 搜索（用户名/手机号）
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      result = result.filter(
        (r) => r.senderName.toLowerCase().includes(q) || r.senderPhone.includes(q),
      );
    }

    // 时间范围
    if (dateFrom.trim()) {
      const from = new Date(dateFrom).getTime();
      result = result.filter((r) => new Date(r.triggeredAt).getTime() >= from);
    }
    if (dateTo.trim()) {
      const to = new Date(dateTo).getTime() + 86400000; // +1天
      result = result.filter((r) => new Date(r.triggeredAt).getTime() <= to);
    }

    return result;
  }, [allRecords, filterStatus, searchQuery, dateFrom, dateTo]);

  // 分页
  const pagedRecords = useMemo(() => {
    return filteredRecords.slice(0, (page + 1) * PAGE_SIZE);
  }, [filteredRecords, page]);

  const hasMore = pagedRecords.length < filteredRecords.length;

  const loadMore = () => {
    if (hasMore) setPage((p) => p + 1);
  };

  // 标记SOS状态
  const handleMarkStatus = (record: SOSRecord) => {
    const options: Array<{ text: string; onPress?: () => void; style?: 'cancel' | 'destructive' | 'default' }> = STATUS_OPTIONS
      .filter((s) => s.key !== 'all')
      .map((s) => ({
        text: s.label,
        onPress: async () => {
          await resolveSOSAlert(record.id, adminName, s.key as SOSStatusType);
          Alert.alert('已更新', `SOS → ${s.label}`);
          loadData();
        },
      }));
    options.push({ text: '取消', style: 'cancel' });

    Alert.alert(
      '标记SOS状态',
      `${record.senderName} · ${new Date(record.triggeredAt).toLocaleString('zh-CN')}`,
      options,
    );
  };

  // 查看详情（含GPS轨迹加载）
  const handleViewDetail = async (record: SOSRecord) => {
    setDetailRecord(record);
    setDetailTrajectory([]);
    setShowDetail(true);
    setLoadingTrajectory(true);
    try {
      const traj = await getSOSTrajectory(record.id);
      setDetailTrajectory(traj);
    } catch {
      setDetailTrajectory([]);
    } finally {
      setLoadingTrajectory(false);
    }
  };

  const statusColor = (s: SOSStatusType) =>
    STATUS_OPTIONS.find((o) => o.key === s)?.color || Colors.textHint;
  const statusLabel = (s: SOSStatusType) =>
    STATUS_OPTIONS.find((o) => o.key === s)?.label || s;

  const renderItem = ({ item }: { item: SOSRecord }) => {
    const isAbnormal = abnormalRecords.some((a) => a.id === item.id);
    const sc = statusColor(item.sosStatus);

    return (
      <TouchableOpacity
        style={[styles.sosCard, isAbnormal && styles.sosAbnormal]}
        onPress={() => handleViewDetail(item)}
        onLongPress={() => handleMarkStatus(item)}
        activeOpacity={0.7}
      >
        <View style={styles.sosHeader}>
          <View style={styles.sosInfo}>
            <View style={styles.sosTitleRow}>
              <Text style={styles.sosSender}>{item.senderName}</Text>
              {item.isSilent && (
                <View style={styles.silentTag}>
                  <Ionicons name="volume-mute" size={12} color={Colors.textHint} />
                </View>
              )}
              {isAbnormal && (
                <View style={styles.abnormalTag}>
                  <Text style={styles.abnormalText}>⚠ 异常</Text>
                </View>
              )}
            </View>
            <Text style={styles.sosPhone}>{item.senderPhone}</Text>
            <Text style={styles.sosAddr} numberOfLines={1}>
              {item.address || `(${item.location.latitude.toFixed(4)}, ${item.location.longitude.toFixed(4)})`}
            </Text>
            <Text style={styles.sosTime}>{new Date(item.triggeredAt).toLocaleString('zh-CN')}</Text>
          </View>
          <View style={[styles.statusBadge, { backgroundColor: sc + '20' }]}>
            <Text style={[styles.statusText, { color: sc }]}>{statusLabel(item.sosStatus)}</Text>
          </View>
        </View>
        {item.resolvedAt && (
          <View style={styles.sosFooter}>
            <Text style={styles.footerText}>
              已解决 · {new Date(item.resolvedAt).toLocaleString('zh-CN')}
              {item.resolvedBy ? ` · ${item.resolvedBy}` : ''}
            </Text>
          </View>
        )}
        <View style={styles.viewDetailRow}>
          <Text style={styles.viewDetailText}>点击查看详情 · 长按标记状态</Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={styles.headerTitle}>SOS管理</Text>
          {abnormalRecords.length > 0 && (
            <View style={styles.alertBadge}>
              <Text style={styles.alertBadgeText}>{abnormalRecords.length}</Text>
            </View>
          )}
        </View>
        <Text style={styles.headerCount}>{filteredRecords.length}条</Text>
      </View>

      {/* 搜索 + 时间筛选 */}
      <View style={styles.filterSection}>
        <SearchBar placeholder="搜索用户名/手机号" onSearch={setSearchQuery} onClear={() => setSearchQuery('')} />
        {/* 日期筛选（统一DatePicker） */}
        <View style={styles.dateRow}>
          <Text style={styles.dateLabel}>从</Text>
          <TouchableOpacity style={styles.datePickerBtn} onPress={() => setShowFromDatePicker(true)}>
            <Ionicons name="calendar-outline" size={14} color={Colors.primary} />
            <Text style={[styles.selectText, !dateFrom && styles.selectPlaceholder]}>{dateFrom || '开始日期'}</Text>
          </TouchableOpacity>
          <Text style={styles.dateSep}>—</Text>
          <TouchableOpacity style={styles.datePickerBtn} onPress={() => setShowToDatePicker(true)}>
            <Ionicons name="calendar-outline" size={14} color={Colors.primary} />
            <Text style={[styles.selectText, !dateTo && styles.selectPlaceholder]}>{dateTo || '结束日期'}</Text>
          </TouchableOpacity>
          {(dateFrom || dateTo) && (
            <TouchableOpacity onPress={() => { setDateFrom(''); setDateTo(''); }}>
              <Ionicons name="close-circle" size={18} color={Colors.lover} />
            </TouchableOpacity>
          )}
        </View>
        {/* 状态筛选 */}
        <View style={styles.filterRow}>
          {STATUS_OPTIONS.map((f) => (
            <TouchableOpacity
              key={f.key}
              style={[styles.filterBtn, filterStatus === f.key && { backgroundColor: f.color, borderColor: f.color }]}
              onPress={() => { setFilterStatus(f.key); setPage(0); }}
            >
              <Text style={[styles.filterText, filterStatus === f.key && { color: '#FFF' }]}>
                {f.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* 异常预警 */}
      {showAbnormal && abnormalRecords.length > 0 && (
        <TouchableOpacity style={styles.abnormalBanner} onPress={() => setShowAbnormal(false)}>
          <Ionicons name="warning" size={16} color="#FFF" />
          <Text style={styles.abnormalBannerText}>
            检测到 {abnormalRecords.length} 条异常SOS（24h高频触发）
          </Text>
          <Ionicons name="close" size={14} color="#FFF" style={{ opacity: 0.6 }} />
        </TouchableOpacity>
      )}

      <FlatList
        data={pagedRecords}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
        removeClippedSubviews
        windowSize={6}
        maxToRenderPerBatch={8}
        onEndReached={loadMore}
        onEndReachedThreshold={0.3}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={[Colors.primary]} />}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="shield-checkmark-outline" size={48} color={Colors.textHint} />
            <Text style={styles.emptyText}>暂无匹配的SOS记录</Text>
          </View>
        }
        ListFooterComponent={
          hasMore ? (
            <TouchableOpacity style={styles.loadMore} onPress={loadMore}>
              <Text style={styles.loadMoreText}>加载更多 ({filteredRecords.length - pagedRecords.length}条剩余)</Text>
            </TouchableOpacity>
          ) : filteredRecords.length > 0 ? (
            <Text style={styles.footerHint}>共 {filteredRecords.length} 条记录 · 点击查看详情 · 长按标记状态</Text>
          ) : null
        }
      />

      {/* ====== SOS详情弹窗 ====== */}
      <RNModal visible={showDetail} transparent animationType="slide" onRequestClose={() => setShowDetail(false)}>
        <View style={styles.detailOverlay}>
          <View style={styles.detailContainer}>
            <View style={styles.detailHeader}>
              <Text style={styles.detailTitle}>SOS 详情</Text>
              <TouchableOpacity onPress={() => setShowDetail(false)}>
                <Ionicons name="close" size={24} color={Colors.textPrimary} />
              </TouchableOpacity>
            </View>
            <ScrollView style={styles.detailScroll}>
              {detailRecord && (
                <>
                  <View style={styles.detailCard}>
                    <Text style={styles.detailLabel}>求助人</Text>
                    <Text style={styles.detailValue}>{detailRecord.senderName}</Text>
                  </View>
                  <View style={styles.detailCard}>
                    <Text style={styles.detailLabel}>手机号</Text>
                    <Text style={styles.detailValue}>{detailRecord.senderPhone}</Text>
                  </View>
                  <View style={styles.detailCard}>
                    <Text style={styles.detailLabel}>求助时间</Text>
                    <Text style={styles.detailValue}>{new Date(detailRecord.triggeredAt).toLocaleString('zh-CN')}</Text>
                  </View>
                  <View style={styles.detailCard}>
                    <Text style={styles.detailLabel}>定位坐标</Text>
                    <Text style={styles.detailValue}>
                      {detailRecord.location.latitude.toFixed(6)}, {detailRecord.location.longitude.toFixed(6)}
                    </Text>
                  </View>
                  {detailRecord.address && (
                    <View style={styles.detailCard}>
                      <Text style={styles.detailLabel}>地址</Text>
                      <Text style={styles.detailValue}>{detailRecord.address}</Text>
                    </View>
                  )}
                  <View style={styles.detailCard}>
                    <Text style={styles.detailLabel}>SOS模式</Text>
                    <Text style={styles.detailValue}>{detailRecord.isSilent ? '静音模式' : '标准模式'}</Text>
                  </View>
                  <View style={styles.detailCard}>
                    <Text style={styles.detailLabel}>当前状态</Text>
                    <View style={[styles.statusBadge, { backgroundColor: statusColor(detailRecord.sosStatus) + '20', alignSelf: 'flex-start' }]}>
                      <Text style={[styles.statusText, { color: statusColor(detailRecord.sosStatus) }]}>
                        {statusLabel(detailRecord.sosStatus)}
                      </Text>
                    </View>
                  </View>
                  {detailRecord.resolvedAt && (
                    <>
                      <View style={styles.detailCard}>
                        <Text style={styles.detailLabel}>解决时间</Text>
                        <Text style={styles.detailValue}>{new Date(detailRecord.resolvedAt).toLocaleString('zh-CN')}</Text>
                      </View>
                      {detailRecord.resolvedBy && (
                        <View style={styles.detailCard}>
                          <Text style={styles.detailLabel}>处理人</Text>
                          <Text style={styles.detailValue}>{detailRecord.resolvedBy}</Text>
                        </View>
                      )}
                    </>
                  )}
                  <View style={styles.detailCard}>
                    <Text style={styles.detailLabel}>记录ID</Text>
                    <Text style={[styles.detailValue, { fontFamily: 'monospace', fontSize: 11 }]}>{detailRecord.id}</Text>
                  </View>

                  {/* GPS轨迹信息（C6修复） */}
                  <View style={styles.detailCard}>
                    <Text style={styles.detailLabel}>GPS轨迹</Text>
                    {loadingTrajectory ? (
                      <Text style={[styles.detailValue, { color: Colors.textHint }]}>加载中...</Text>
                    ) : detailTrajectory.length > 0 ? (
                      <>
                        <Text style={styles.detailValue}>
                          共 {detailTrajectory.length} 个定位点
                        </Text>
                        <Text style={[styles.detailValue, { fontSize: 11, color: Colors.textSecondary, marginTop: 4 }]}>
                          起点: {detailTrajectory[0].latitude.toFixed(5)}, {detailTrajectory[0].longitude.toFixed(5)}
                        </Text>
                        <Text style={[styles.detailValue, { fontSize: 11, color: Colors.textSecondary }]}>
                          终点: {detailTrajectory[detailTrajectory.length - 1].latitude.toFixed(5)}, {detailTrajectory[detailTrajectory.length - 1].longitude.toFixed(5)}
                        </Text>
                        <Text style={[styles.detailValue, { fontSize: 11, color: Colors.textHint, marginTop: 2 }]}>
                          时间跨度: {new Date(detailTrajectory[0].timestamp).toLocaleTimeString('zh-CN')} — {new Date(detailTrajectory[detailTrajectory.length - 1].timestamp).toLocaleTimeString('zh-CN')}
                        </Text>
                      </>
                    ) : (
                      <Text style={[styles.detailValue, { color: Colors.textHint }]}>无轨迹数据（SOS期间未开启持续定位或数据已清理）</Text>
                    )}
                  </View>
                </>
              )}
            </ScrollView>
            <View style={styles.detailActions}>
              <Button
                title="标记为已处理"
                variant="primary"
                onPress={async () => {
                  if (detailRecord) {
                    await resolveSOSAlert(detailRecord.id, adminName, 'resolved');
                    setShowDetail(false);
                    Alert.alert('已处理', 'SOS记录已标记为已处理');
                    loadData();
                  }
                }}
                style={styles.detailBtn}
              />
              <Button
                title="标记为误触"
                variant="outline"
                onPress={async () => {
                  if (detailRecord) {
                    await resolveSOSAlert(detailRecord.id, adminName, 'false_alarm');
                    setShowDetail(false);
                    Alert.alert('已标记', 'SOS记录已标记为误触');
                    loadData();
                  }
                }}
                style={styles.detailBtn}
              />
            </View>
          </View>
        </View>
      </RNModal>

      {/* 日期选择器 */}
      <DatePicker visible={showFromDatePicker} value={dateFrom} onConfirm={(v) => { setDateFrom(v); setShowFromDatePicker(false); }} onClose={() => setShowFromDatePicker(false)} title="选择开始日期" />
      <DatePicker visible={showToDatePicker} value={dateTo} onConfirm={(v) => { setDateTo(v); setShowToDatePicker(false); }} onClose={() => setShowToDatePicker(false)} title="选择结束日期" />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerCenter: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  headerCount: { fontSize: Typography.caption, color: Colors.textHint },
  alertBadge: { backgroundColor: Colors.lover, paddingHorizontal: 6, paddingVertical: 1, borderRadius: 8 },
  alertBadgeText: { fontSize: 10, color: '#FFF', fontWeight: '700' },
  // 筛选区
  filterSection: { paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.bgWhite },
  dateRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: Spacing.sm, flexWrap: 'wrap' },
  dateLabel: { fontSize: Typography.caption, color: Colors.textHint, marginRight: 2 },
  dateSep: { fontSize: Typography.caption, color: Colors.textHint, marginHorizontal: 2 },
  selectText: { fontSize: 11, color: Colors.textPrimary },
  selectPlaceholder: { color: Colors.textHint },
  datePickerBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input,
    paddingHorizontal: Spacing.sm, paddingVertical: Spacing.xs, backgroundColor: Colors.bgWhite,
  },
  filterRow: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xs, marginTop: Spacing.sm },
  filterBtn: {
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.input, borderWidth: 1, borderColor: Colors.divider,
    backgroundColor: Colors.bgWhite, marginBottom: 4,
  },
  filterText: { fontSize: Typography.caption, color: Colors.textSecondary },
  abnormalBanner: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: Colors.lover, padding: Spacing.md, marginHorizontal: Spacing.lg,
    marginTop: Spacing.md, borderRadius: BorderRadius.card,
  },
  abnormalBannerText: { flex: 1, fontSize: Typography.caption, color: '#FFF', fontWeight: '500' },
  // 列表
  list: { padding: Spacing.lg },
  sosCard: {
    backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    marginBottom: Spacing.sm, overflow: 'hidden',
    borderLeftWidth: 3, borderLeftColor: Colors.divider,
  },
  sosAbnormal: { borderLeftColor: Colors.lover, backgroundColor: '#FFF5F5' },
  sosHeader: { flexDirection: 'row', alignItems: 'flex-start', padding: Spacing.md },
  sosInfo: { flex: 1 },
  sosTitleRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
  sosSender: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary },
  silentTag: { backgroundColor: Colors.bgPrimary, paddingHorizontal: 4, borderRadius: 3 },
  abnormalTag: { backgroundColor: Colors.lover + '20', paddingHorizontal: 4, borderRadius: 3 },
  abnormalText: { fontSize: 10, color: Colors.lover, fontWeight: '600' },
  sosPhone: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  sosAddr: { fontSize: Typography.caption, color: Colors.textSecondary, marginTop: 2 },
  sosTime: { fontSize: 10, color: Colors.textHint, marginTop: 4 },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 4, marginTop: Spacing.xs },
  statusText: { fontSize: 10, fontWeight: '600' },
  sosFooter: {
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    backgroundColor: Colors.bgPrimary, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider,
  },
  footerText: { fontSize: 10, color: Colors.textHint },
  viewDetailRow: {
    paddingHorizontal: Spacing.md, paddingBottom: Spacing.sm,
  },
  viewDetailText: { fontSize: 10, color: Colors.textHint, textAlign: 'right' },
  loadMore: {
    paddingVertical: Spacing.lg, alignItems: 'center',
  },
  loadMoreText: { fontSize: Typography.body, color: Colors.primary, fontWeight: '500' },
  footerHint: { fontSize: Typography.caption, color: Colors.textHint, textAlign: 'center', paddingVertical: Spacing.lg },
  empty: { alignItems: 'center', paddingVertical: Spacing.xl * 3 },
  emptyText: { fontSize: Typography.body, color: Colors.textHint, marginTop: Spacing.md },
  // 详情弹窗
  detailOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'flex-end',
  },
  detailContainer: {
    backgroundColor: Colors.bgWhite,
    borderTopLeftRadius: BorderRadius.card, borderTopRightRadius: BorderRadius.card,
    maxHeight: '85%', paddingBottom: Spacing.xl,
  },
  detailHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  detailTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  detailScroll: { paddingHorizontal: Spacing.lg },
  detailCard: {
    paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  detailLabel: { fontSize: Typography.caption, color: Colors.textHint, marginBottom: 2 },
  detailValue: { fontSize: Typography.body, color: Colors.textPrimary, fontWeight: '500' },
  detailActions: { flexDirection: 'row', gap: Spacing.md, paddingHorizontal: Spacing.lg, paddingTop: Spacing.md },
  detailBtn: { flex: 1 },
});

export default AdminSOSScreen;
