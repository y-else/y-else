/**
 * 绑定页面（支持Tab内嵌+Stack独立两种模式）
 *
 * 功能：
 * - 手机号搜索用户并发起绑定请求
 * - 待处理请求列表（收到+发出）
 * - 已绑定关系列表（从通讯录实时加载）
 * - 单方发起解绑（对方确认后生效）
 * - 恋人唯一绑定校验（发送+接受双重校验）
 * - 家人/朋友无人数上限
 * - 解绑需对方确认（不再自己发起自己确认）
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, RefreshControl,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Input, Button, Card } from '../components';
import {
  searchByPhone, sendBindRequest,
  getPendingBindRequests, getSentBindRequests,
  respondBindRequest, cancelBindRequest,
  requestUnbind, confirmUnbind,
  getContacts, maskPhone,
} from '../services/contacts';
import type { BindRequest, Contact, ContactGroup } from '../types';

interface BindScreenProps {
  onBack?: () => void;
  defaultType?: ContactGroup;
  /** 当前登录用户的ID（必传，用于绑定/解绑操作） */
  currentUserId: string;
  currentUsername?: string;
  currentPhone?: string;
}

const RELATION_TYPES: { key: ContactGroup; label: string; color: string; icon: string }[] = [
  { key: 'family', label: '家人', color: '#5CB85C', icon: 'home' },
  { key: 'friend', label: '朋友', color: '#F0AD4E', icon: 'people' },
  { key: 'lover', label: '恋人', color: '#E74C3C', icon: 'heart' },
];

interface BoundRelation {
  userId: string;
  username: string;
  phone: string;
  type: ContactGroup;
  remark: string | null;
}

const BindScreen: React.FC<BindScreenProps> = ({
  onBack,
  defaultType,
  currentUserId,
  currentUsername = '我',
  currentPhone = '****',
}) => {
  const mountedRef = useRef(true);

  // 搜索绑定
  const [searchPhone, setSearchPhone] = useState('');
  const [searchResult, setSearchResult] = useState<{
    found: boolean; username?: string; userId?: string; alreadyBound?: boolean;
  } | null>(null);
  const [searching, setSearching] = useState(false);
  const [selectedType, setSelectedType] = useState<ContactGroup>(defaultType || 'friend');
  const [bindMessage, setBindMessage] = useState('');

  // 待处理请求
  const [incomingRequests, setIncomingRequests] = useState<BindRequest[]>([]);
  const [outgoingRequests, setOutgoingRequests] = useState<BindRequest[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  // 已绑定关系（从通讯录加载）
  const [boundRelations, setBoundRelations] = useState<BoundRelation[]>([]);
  const [loadingBounds, setLoadingBounds] = useState(true);

  // 解绑中状态
  const [unbindingId, setUnbindingId] = useState<string | null>(null);

  // ====== 生命周期 ======

  useEffect(() => {
    mountedRef.current = true;
    loadAll();
    return () => { mountedRef.current = false; };
  }, []);

  const loadAll = useCallback(async () => {
    try {
      const [contacts, incoming, outgoing] = await Promise.all([
        getContacts(),
        getPendingBindRequests(currentUserId),
        getSentBindRequests(currentUserId),
      ]);
      if (!mountedRef.current) return;
      setBoundRelations(
        contacts
          .filter((c) => !c.isBlocked && c.group !== 'blocked')
          .map((c) => ({
            userId: c.userId,
            username: c.remark || c.username,
            phone: c.phone,
            type: c.group as ContactGroup,
            remark: c.remark,
          })),
      );
      setIncomingRequests(incoming);
      setOutgoingRequests(outgoing);
    } catch {
      // 加载失败静默
    } finally {
      if (mountedRef.current) setLoadingBounds(false);
    }
  }, [currentUserId]);

  // ====== 搜索用户 ======

  const handleSearch = useCallback(async () => {
    const phone = searchPhone.trim();
    if (!/^1[3-9]\d{9}$/.test(phone)) {
      Alert.alert('提示', '请输入正确的11位手机号');
      return;
    }
    setSearching(true);
    try {
      const result = await searchByPhone(phone, currentUserId);
      if (!mountedRef.current) return;
      setSearchResult(result);
    } catch {
      if (mountedRef.current) Alert.alert('错误', '搜索失败，请重试');
    } finally {
      if (mountedRef.current) setSearching(false);
    }
  }, [searchPhone, currentUserId]);

  // ====== 发送绑定请求 ======

  const handleSendBindRequest = useCallback(async () => {
    if (!searchResult?.found || !searchResult.userId) return;

    // 已绑定提示
    if (searchResult.alreadyBound) {
      Alert.alert('提示', '该用户已在您的通讯录中');
      return;
    }

    try {
      await sendBindRequest(
        currentUserId, currentUsername, currentPhone, null,
        searchResult.userId, selectedType, bindMessage || '请求添加为联系人',
      );
      if (!mountedRef.current) return;

      const typeLabel = RELATION_TYPES.find((t) => t.key === selectedType)?.label;
      Alert.alert('请求已发送', `已向 ${searchResult.username} 发送${typeLabel}绑定请求`);
      setSearchResult(null);
      setSearchPhone('');
      setBindMessage('');
      // 刷新发出列表
      const outgoing = await getSentBindRequests(currentUserId);
      if (mountedRef.current) setOutgoingRequests(outgoing);
    } catch (e: any) {
      Alert.alert('发送失败', e?.message || '未知错误');
    }
  }, [searchResult, selectedType, bindMessage, currentUserId, currentUsername, currentPhone]);

  // ====== 处理绑定请求（接受/拒绝） ======

  const handleRespondRequest = useCallback(
    (request: BindRequest, accept: boolean) => {
      Alert.alert(
        accept ? '同意绑定' : '拒绝绑定',
        `${accept ? '同意' : '拒绝'} ${request.fromUsername} 的${RELATION_TYPES.find((t) => t.key === request.type)?.label}绑定请求？`,
        [
          { text: '取消', style: 'cancel' },
          {
            text: '确定',
            onPress: async () => {
              try {
                await respondBindRequest(request.id, accept);
                if (!mountedRef.current) return;

                // 从待处理列表移除
                setIncomingRequests((prev) => prev.filter((r) => r.id !== request.id));

                if (accept) {
                  // 重新加载通讯录以更新已绑定列表
                  const contacts = await getContacts();
                  if (mountedRef.current) {
                    setBoundRelations(
                      contacts
                        .filter((c) => !c.isBlocked && c.group !== 'blocked')
                        .map((c) => ({
                          userId: c.userId,
                          username: c.remark || c.username,
                          phone: c.phone,
                          type: c.group as ContactGroup,
                          remark: c.remark,
                        })),
                    );
                  }
                }
                Alert.alert('完成', accept ? '已接受绑定请求' : '已拒绝绑定请求');
              } catch (e: any) {
                Alert.alert('操作失败', e?.message || '未知错误');
              }
            },
          },
        ],
      );
    },
    [],
  );

  // ====== 取消发出的绑定请求 ======

  const handleCancelRequest = useCallback((request: BindRequest) => {
    Alert.alert('取消请求', `确定取消对 ${request.toUsername} 的绑定请求？`, [
      { text: '返回', style: 'cancel' },
      {
        text: '取消请求',
        style: 'destructive',
        onPress: async () => {
          await cancelBindRequest(request.id);
          if (!mountedRef.current) return;
          setOutgoingRequests((prev) => prev.filter((r) => r.id !== request.id));
        },
      },
    ]);
  }, []);

  // ====== 刷新 ======

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadAll();
    if (mountedRef.current) setRefreshing(false);
  }, [loadAll]);

  // ====== 解绑 ======

  const handleUnbind = useCallback(
    (relation: BoundRelation) => {
      const typeCfg = RELATION_TYPES.find((t) => t.key === relation.type);
      Alert.alert(
        '确认解绑',
        `确定要解除与 ${relation.username} 的${typeCfg?.label}关系吗？\n\n解绑申请将发送给对方确认，确认后关系正式解除。`,
        [
          { text: '取消', style: 'cancel' },
          {
            text: '发起解绑',
            style: 'destructive',
            onPress: async () => {
              setUnbindingId(relation.userId);
              try {
                await requestUnbind(
                  currentUserId, currentUsername,
                  relation.userId, relation.username,
                  relation.type,
                );
                if (!mountedRef.current) return;
                Alert.alert(
                  '解绑申请已发送',
                  `已向 ${relation.username} 发送解绑申请，等待对方确认。\n\n在对方确认前，关系保持不变。`,
                );
                // 刷新列表
                await loadAll();
              } catch (e: any) {
                if (mountedRef.current) Alert.alert('解绑失败', e?.message || '未知错误');
              } finally {
                if (mountedRef.current) setUnbindingId(null);
              }
            },
          },
        ],
      );
    },
    [currentUserId, currentUsername, loadAll],
  );

  // ====== 确认解绑（对方发来的解绑请求） ======

  const handleConfirmUnbind = useCallback(
    (request: any) => {
      Alert.alert(
        '确认解绑',
        `${request.fromUsername} 请求解除与您的${RELATION_TYPES.find((t: any) => t.key === request.relationType)?.label}关系，确认后关系将正式解除。`,
        [
          { text: '取消', style: 'cancel' },
          {
            text: '确认解绑',
            style: 'destructive',
            onPress: async () => {
              try {
                const result = await confirmUnbind(request.id);
                if (!mountedRef.current) return;
                if (result.success) {
                  Alert.alert('解绑成功', result.message);
                  await loadAll();
                } else {
                  Alert.alert('解绑失败', result.message);
                }
              } catch (e: any) {
                if (mountedRef.current) Alert.alert('错误', e?.message || '未知错误');
              }
            },
          },
        ],
      );
    },
    [loadAll],
  );

  // ====== 渲染 ======

  const pendingCount = incomingRequests.length + outgoingRequests.length;

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView
        contentContainerStyle={styles.container}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={[Colors.primary]} />
        }
      >
        {/* Stack模式显示返回按钮 */}
        {onBack && (
          <TouchableOpacity onPress={onBack} style={{ marginBottom: Spacing.md }}>
            <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
          </TouchableOpacity>
        )}
        <Text style={styles.pageTitle}>绑定</Text>

        {/* ====== 搜索绑定 ====== */}
        <Card>
          <Text style={styles.sectionTitle}>搜索绑定</Text>
          <Text style={styles.hint}>通过手机号搜索并发送绑定请求</Text>

          <Input
            label="手机号"
            placeholder="请输入对方手机号"
            keyboardType="phone-pad"
            maxLength={11}
            value={searchPhone}
            onChangeText={(t) => { setSearchPhone(t); setSearchResult(null); }}
          />

          {/* 关系类型选择 */}
          <Text style={styles.typeLabel}>选择关系类型</Text>
          <View style={styles.typeRow}>
            {RELATION_TYPES.map((t) => (
              <TouchableOpacity
                key={t.key}
                style={[
                  styles.typeBtn,
                  selectedType === t.key && { backgroundColor: t.color, borderColor: t.color },
                ]}
                onPress={() => setSelectedType(t.key)}
                activeOpacity={0.7}
              >
                <Ionicons
                  name={t.icon as React.ComponentProps<typeof Ionicons>['name']}
                  size={16}
                  color={selectedType === t.key ? '#FFF' : t.color}
                />
                <Text style={[styles.typeBtnText, selectedType === t.key && { color: '#FFF' }]}>
                  {t.label}
                </Text>
                {t.key === 'family' || t.key === 'friend' ? (
                  <Text style={[styles.noLimitHint, selectedType === t.key && { color: 'rgba(255,255,255,0.7)' }]}>
                    无上限
                  </Text>
                ) : null}
              </TouchableOpacity>
            ))}
          </View>

          <Input
            label="验证消息"
            placeholder="发送给对方的验证消息（选填）"
            value={bindMessage}
            onChangeText={setBindMessage}
          />

          <Button
            title={searching ? '搜索中...' : '搜索'}
            onPress={handleSearch}
            loading={searching}
          />

          {/* 搜索结果 */}
          {searchResult && (
            <View style={styles.searchResult}>
              {searchResult.found ? (
                <View>
                  <View style={styles.foundUser}>
                    <Ionicons name="person-circle" size={40} color={Colors.primary} />
                    <View style={styles.foundInfo}>
                      <Text style={styles.foundName}>{searchResult.username}</Text>
                      <Text style={styles.foundPhone}>{searchPhone}</Text>
                    </View>
                    {!searchResult.alreadyBound && (
                      <Button title="发送请求" onPress={handleSendBindRequest} variant="outline" />
                    )}
                  </View>
                  {searchResult.alreadyBound && (
                    <Text style={styles.alreadyBoundHint}>该用户已在您的通讯录中</Text>
                  )}
                </View>
              ) : (
                <View style={styles.notFound}>
                  <Ionicons name="search-outline" size={24} color={Colors.textHint} />
                  <Text style={styles.notFoundText}>未找到该用户</Text>
                </View>
              )}
            </View>
          )}
        </Card>

        {/* ====== 待处理请求 ====== */}
        {pendingCount > 0 && (
          <Card>
            <Text style={styles.sectionTitle}>
              待处理请求
              {pendingCount > 0 && (
                <Text style={styles.pendingCountBadge}> {pendingCount}</Text>
              )}
            </Text>

            {/* 收到的请求 */}
            {incomingRequests.map((req) => (
              <View key={req.id} style={styles.pendingItem}>
                <View style={styles.pendingInfo}>
                  <Text style={styles.pendingName}>{req.fromUsername}</Text>
                  <Text style={styles.pendingMsg}>
                    请求添加为{RELATION_TYPES.find((t) => t.key === req.type)?.label}：{req.message}
                  </Text>
                  <Text style={styles.pendingTime}>{formatTime(req.createdAt)}</Text>
                </View>
                <View style={styles.pendingActions}>
                  <TouchableOpacity
                    style={[styles.respondBtn, { backgroundColor: Colors.family }]}
                    onPress={() => handleRespondRequest(req, true)}
                  >
                    <Text style={styles.respondText}>同意</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.respondBtn, { backgroundColor: Colors.textHint }]}
                    onPress={() => handleRespondRequest(req, false)}
                  >
                    <Text style={styles.respondText}>拒绝</Text>
                  </TouchableOpacity>
                </View>
              </View>
            ))}

            {/* 发出的请求 */}
            {outgoingRequests.map((req) => (
              <View key={req.id} style={[styles.pendingItem, styles.outgoingItem]}>
                <View style={styles.pendingInfo}>
                  <Text style={styles.pendingName}>
                    {req.toUsername}
                    <Text style={styles.outgoingLabel}> (等待回复)</Text>
                  </Text>
                  <Text style={styles.pendingMsg}>
                    {RELATION_TYPES.find((t) => t.key === req.type)?.label}绑定请求已发送
                  </Text>
                </View>
                <TouchableOpacity
                  style={[styles.respondBtn, { backgroundColor: Colors.textHint }]}
                  onPress={() => handleCancelRequest(req)}
                >
                  <Text style={styles.respondText}>取消</Text>
                </TouchableOpacity>
              </View>
            ))}
          </Card>
        )}

        {/* ====== 已绑定关系 ====== */}
        <Card>
          <Text style={styles.sectionTitle}>已绑定关系</Text>
          {loadingBounds ? (
            <View style={styles.emptyBound}>
              <Text style={styles.emptyText}>加载中...</Text>
            </View>
          ) : boundRelations.length === 0 ? (
            <View style={styles.emptyBound}>
              <Ionicons name="link-outline" size={24} color={Colors.textHint} />
              <Text style={styles.emptyText}>暂无绑定关系</Text>
              <Text style={styles.emptySubText}>通过上方搜索绑定功能添加联系人</Text>
            </View>
          ) : (
            boundRelations.map((r) => {
              const typeCfg = RELATION_TYPES.find((t) => t.key === r.type);
              return (
                <View key={r.userId} style={styles.boundItem}>
                  <View style={[styles.boundDot, { backgroundColor: typeCfg?.color || '#999' }]} />
                  <View style={styles.boundInfo}>
                    <Text style={styles.boundName}>
                      {r.username}
                      {r.remark && <Text style={styles.boundRemark}> ({r.remark})</Text>}
                    </Text>
                    <View style={styles.boundMeta}>
                      <Text style={[styles.boundType, { color: typeCfg?.color }]}>
                        {typeCfg?.label}
                      </Text>
                      <Text style={styles.boundPhone}>{r.phone}</Text>
                    </View>
                  </View>
                  <TouchableOpacity
                    style={styles.unbindBtn}
                    onPress={() => handleUnbind(r)}
                    disabled={unbindingId === r.userId}
                  >
                    <Text style={[styles.unbindText, unbindingId === r.userId && { color: Colors.textHint }]}>
                      {unbindingId === r.userId ? '处理中...' : '解绑'}
                    </Text>
                  </TouchableOpacity>
                </View>
              );
            })
          )}
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
};

/** 格式化时间显示 */
function formatTime(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return '刚刚';
  if (diffMin < 60) return `${diffMin}分钟前`;
  const diffHour = Math.floor(diffMin / 60);
  if (diffHour < 24) return `${diffHour}小时前`;
  const diffDay = Math.floor(diffHour / 24);
  if (diffDay < 7) return `${diffDay}天前`;
  return `${d.getMonth() + 1}/${d.getDate()}`;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  container: { padding: Spacing.lg },
  pageTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.lg },
  sectionTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.xs },
  hint: { fontSize: Typography.caption, color: Colors.textHint, marginBottom: Spacing.lg },
  // 类型选择
  typeLabel: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary, marginBottom: Spacing.sm, marginTop: Spacing.sm },
  typeRow: { flexDirection: 'row', gap: Spacing.sm, marginBottom: Spacing.lg },
  typeBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4,
    paddingVertical: Spacing.sm, borderRadius: BorderRadius.card, borderWidth: 1.5,
    borderColor: Colors.divider, backgroundColor: Colors.bgWhite,
  },
  typeBtnText: { fontSize: Typography.caption, fontWeight: '500' },
  noLimitHint: { fontSize: 9, color: Colors.textHint, marginLeft: 2 },
  // 搜索结果
  searchResult: { marginTop: Spacing.lg, paddingTop: Spacing.lg, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider },
  foundUser: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  foundInfo: { flex: 1 },
  foundName: { fontSize: Typography.subtitle, fontWeight: '500', color: Colors.textPrimary },
  foundPhone: { fontSize: Typography.caption, color: Colors.textHint },
  alreadyBoundHint: { fontSize: Typography.caption, color: Colors.primary, marginTop: Spacing.sm, textAlign: 'right' },
  notFound: { alignItems: 'center', paddingVertical: Spacing.lg, gap: Spacing.sm },
  notFoundText: { fontSize: Typography.body, color: Colors.textHint },
  // 待处理请求
  pendingCountBadge: { fontSize: Typography.caption, color: Colors.lover },
  pendingItem: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingVertical: Spacing.md, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  outgoingItem: { backgroundColor: '#FAFAFA' },
  pendingInfo: { flex: 1 },
  pendingName: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  pendingMsg: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  pendingTime: { fontSize: 10, color: Colors.textHint, marginTop: 2 },
  outgoingLabel: { color: Colors.textHint, fontWeight: '400' },
  pendingActions: { flexDirection: 'row', gap: Spacing.sm },
  respondBtn: { paddingHorizontal: Spacing.lg, paddingVertical: Spacing.xs, borderRadius: 4 },
  respondText: { fontSize: Typography.caption, color: '#FFF', fontWeight: '600' },
  // 已绑定
  emptyBound: { alignItems: 'center', paddingVertical: Spacing.xl, gap: Spacing.sm },
  emptyText: { fontSize: Typography.body, color: Colors.textHint },
  emptySubText: { fontSize: Typography.caption, color: Colors.textHint },
  boundItem: {
    flexDirection: 'row', alignItems: 'center',
    paddingVertical: Spacing.md, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  boundDot: { width: 10, height: 10, borderRadius: 5, marginRight: Spacing.md },
  boundInfo: { flex: 1 },
  boundName: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  boundRemark: { fontSize: Typography.caption, color: Colors.textHint, fontWeight: '400' },
  boundMeta: { flexDirection: 'row', gap: Spacing.sm, marginTop: 2 },
  boundType: { fontSize: Typography.caption, fontWeight: '500' },
  boundPhone: { fontSize: Typography.caption, color: Colors.textHint },
  unbindBtn: { borderWidth: 1, borderColor: Colors.lover, borderRadius: 4, paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs },
  unbindText: { fontSize: Typography.caption, color: Colors.lover },
});

export default BindScreen;
