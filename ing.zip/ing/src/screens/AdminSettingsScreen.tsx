/**
 * 管理员设置页面
 * 专属密令展示/复制 + 密令校验修改密码
 * 规则：修改密码前必须输入密令 → 校验通过方可修改 → 修改成功后自动生成新密令
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert,
  TextInput,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card, Button, Modal } from '../components';
import { useAuth } from '../context/AuthContext';
import {
  getOrCreateToken, verifyToken, regenerateToken, copyTokenToClipboard,
} from '../services/adminToken';

interface AdminSettingsScreenProps {
  onBack: () => void;
}

const AdminSettingsScreen: React.FC<AdminSettingsScreenProps> = ({ onBack }) => {
  const { state } = useAuth();
  const adminName = state.user?.username || '管理员';

  // 密令状态
  const [token, setToken] = useState<string>('');
  const [tokenLoading, setTokenLoading] = useState(true);
  const [copySuccess, setCopySuccess] = useState(false);

  // 修改密码状态
  const [showPwdModal, setShowPwdModal] = useState(false);
  const [step, setStep] = useState<'verify' | 'change' | 'done'>('verify');
  const [inputToken, setInputToken] = useState('');
  const [verifyError, setVerifyError] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [pwdError, setPwdError] = useState('');
  const [changing, setChanging] = useState(false);

  // 显示/隐藏密令
  const [showToken, setShowToken] = useState(false);

  // 加载密令
  useEffect(() => {
    (async () => {
      const t = await getOrCreateToken();
      setToken(t);
      setTokenLoading(false);
    })();
  }, []);

  // 复制密令
  const handleCopyToken = async () => {
    const copied = await copyTokenToClipboard();
    if (copied) {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } else {
      // 降级方案：使用 Alert 展示密令
      Alert.alert('密令复制', '请手动复制以下密令：\n\n' + token, [
        { text: '知道了' },
      ]);
    }
  };

  // 打开修改密码流程
  const handleOpenChangePwd = () => {
    setStep('verify');
    setInputToken('');
    setVerifyError('');
    setNewPassword('');
    setConfirmPassword('');
    setPwdError('');
    setShowPwdModal(true);
  };

  // 校验密令
  const handleVerifyToken = async () => {
    if (!inputToken.trim()) {
      setVerifyError('请输入管理员密令');
      return;
    }
    const valid = await verifyToken(inputToken.trim());
    if (!valid) {
      setVerifyError('密令错误，禁止修改账号密码');
      return;
    }
    // 密令正确 → 进入密码修改步骤
    setVerifyError('');
    setStep('change');
  };

  // 提交新密码
  const handleChangePassword = async () => {
    setPwdError('');
    if (newPassword.length < 6) {
      setPwdError('新密码至少6位');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPwdError('两次密码不一致');
      return;
    }
    if (inputToken.trim() === newPassword) {
      setPwdError('新密码不能与密令相同');
      return;
    }

    setChanging(true);

    // 更新管理员的登录密码（使用auth服务）
    try {
      const { changePassword } = await import('../services/auth');
      const resp = await changePassword({
        phone: state.user?.phone || '00000001',
        smsCode: '123456', // 管理员修改密码免短信码
        newPassword,
      });

      if (resp.code === 200) {
        // 密码修改成功 → 自动生成全新密令 + 联动解绑所有绑定关系
        const { token: newToken, invalidatedCount: invalidated } = await regenerateToken(
          state.user?.id,
          state.user?.username,
        );
        setToken(newToken);
        setStep('done');
        setShowPwdModal(false);
        Alert.alert(
          '密码修改成功',
          `您的账号密码已更新。\n\n系统已自动生成全新密令，旧密令已失效。\n${invalidated > 0 ? `已自动解除 ${invalidated} 个普通用户的管理员绑定。` : ''}\n请妥善保管新密令。`,
          [{ text: '我知道了' }],
        );
      } else {
        Alert.alert('修改失败', resp.message);
      }
    } catch {
      Alert.alert('修改失败', '网络异常，请稍后重试');
    }
    setChanging(false);
  };

  // 重置弹窗状态
  const handleCloseModal = () => {
    setShowPwdModal(false);
    setStep('verify');
    setInputToken('');
    setVerifyError('');
    setNewPassword('');
    setConfirmPassword('');
    setPwdError('');
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      {/* 头部 */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>系统设置</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView contentContainerStyle={styles.container}>
        {/* ====== 密令展示卡片 ====== */}
        <Card style={styles.tokenCard}>
          <View style={styles.tokenHeader}>
            <Ionicons name="key" size={22} color={Colors.admin} />
            <Text style={styles.tokenTitle}>管理员专属密令</Text>
          </View>
          <Text style={styles.tokenDesc}>
            密令是管理员身份的象征，修改账号密码的唯一强制凭证。请妥善保管。
          </Text>

          {/* 密令展示区 */}
          <View style={styles.tokenDisplay}>
            <Text style={styles.tokenValue}>
              {tokenLoading ? '加载中...' : showToken ? token : '••••••••••••••••'}
            </Text>
            <View style={styles.tokenActions}>
              <TouchableOpacity
                style={styles.tokenActionBtn}
                onPress={() => setShowToken(!showToken)}
                activeOpacity={0.7}
              >
                <Ionicons
                  name={showToken ? 'eye-off' : 'eye'}
                  size={20}
                  color={Colors.textSecondary}
                />
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.tokenActionBtn, copySuccess && styles.copySuccessBtn]}
                onPress={handleCopyToken}
                activeOpacity={0.7}
              >
                <Ionicons
                  name={copySuccess ? 'checkmark-circle' : 'copy-outline'}
                  size={20}
                  color={copySuccess ? Colors.family : Colors.primary}
                />
                <Text style={[styles.copyText, copySuccess && { color: Colors.family }]}>
                  {copySuccess ? '已复制' : '复制'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.tokenInfo}>
            <Ionicons name="information-circle-outline" size={14} color={Colors.textHint} />
            <Text style={styles.tokenInfoText}>
              密令永久有效，修改密码后自动更新为新密令
            </Text>
          </View>
        </Card>

        {/* ====== 修改密码入口 ====== */}
        <Card style={styles.pwdCard}>
          <TouchableOpacity
            style={styles.pwdEntry}
            onPress={handleOpenChangePwd}
            activeOpacity={0.7}
          >
            <View style={[styles.pwdIcon, { backgroundColor: Colors.admin + '15' }]}>
              <Ionicons name="lock-closed" size={22} color={Colors.admin} />
            </View>
            <View style={styles.pwdInfo}>
              <Text style={styles.pwdTitle}>修改账号密码</Text>
              <Text style={styles.pwdDesc}>需要验证管理员专属密令</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={Colors.textHint} />
          </TouchableOpacity>
        </Card>

        {/* ====== 管理员信息 ====== */}
        <Card style={styles.infoCard}>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>管理员账号</Text>
            <Text style={styles.infoValue}>{state.user?.phone || '00000001'}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>用户名</Text>
            <Text style={styles.infoValue}>{adminName}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>角色</Text>
            <View style={styles.roleBadge}>
              <Ionicons name="shield" size={14} color={Colors.admin} />
              <Text style={styles.roleText}>系统管理员</Text>
            </View>
          </View>
        </Card>
      </ScrollView>

      {/* ====== 修改密码弹窗 ====== */}
      <Modal
        visible={showPwdModal}
        title="修改管理员密码"
        onClose={handleCloseModal}
        confirmText={step === 'verify' ? '验证密令' : '确认修改'}
        onConfirm={step === 'verify' ? handleVerifyToken : handleChangePassword}
      >
        {/* 步骤1：密令校验 */}
        {step === 'verify' && (
          <>
            <Text style={styles.modalHint}>
              请输入当前有效的管理员专属密令以验证身份：
            </Text>
            <TextInput
              style={styles.modalInput}
              placeholder="请输入管理员密令"
              placeholderTextColor={Colors.textHint}
              value={inputToken}
              onChangeText={(t) => { setInputToken(t); setVerifyError(''); }}
              secureTextEntry
              autoFocus
            />
            {verifyError ? (
              <Text style={styles.errorText}>{verifyError}</Text>
            ) : null}
          </>
        )}

        {/* 步骤2：输入新密码 */}
        {step === 'change' && (
          <>
            <View style={styles.verifyOkRow}>
              <Ionicons name="checkmark-circle" size={18} color={Colors.family} />
              <Text style={styles.verifyOkText}>密令验证通过</Text>
            </View>
            <Text style={styles.modalHint}>请输入新密码：</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="新密码（至少6位）"
              placeholderTextColor={Colors.textHint}
              value={newPassword}
              onChangeText={(t) => { setNewPassword(t); setPwdError(''); }}
              secureTextEntry
            />
            <TextInput
              style={[styles.modalInput, { marginTop: Spacing.md }]}
              placeholder="确认新密码"
              placeholderTextColor={Colors.textHint}
              value={confirmPassword}
              onChangeText={(t) => { setConfirmPassword(t); setPwdError(''); }}
              secureTextEntry
            />
            {pwdError ? (
              <Text style={styles.errorText}>{pwdError}</Text>
            ) : null}
          </>
        )}
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  container: { padding: Spacing.lg },

  // ====== 密令卡片 ======
  tokenCard: { marginBottom: Spacing.lg },
  tokenHeader: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  tokenTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  tokenDesc: {
    fontSize: Typography.body, color: Colors.textSecondary,
    lineHeight: 20, marginBottom: Spacing.lg,
  },
  tokenDisplay: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: Colors.bgPrimary, borderRadius: BorderRadius.card,
    padding: Spacing.lg, marginBottom: Spacing.md,
    borderWidth: 1, borderColor: Colors.divider,
  },
  tokenValue: {
    fontSize: Typography.subtitle, fontWeight: '700', color: Colors.admin,
    fontFamily: 'monospace',
    flex: 1, marginRight: Spacing.md,
  },
  tokenActions: { flexDirection: 'row', gap: Spacing.md },
  tokenActionBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    padding: Spacing.xs,
  },
  copySuccessBtn: {},
  copyText: { fontSize: Typography.caption, color: Colors.primary, fontWeight: '500' },
  tokenInfo: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.xs,
  },
  tokenInfoText: { fontSize: Typography.caption, color: Colors.textHint, flex: 1 },

  // ====== 修改密码入口 ======
  pwdCard: { marginBottom: Spacing.lg },
  pwdEntry: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
  },
  pwdIcon: {
    width: 44, height: 44, borderRadius: 22,
    alignItems: 'center', justifyContent: 'center',
  },
  pwdInfo: { flex: 1 },
  pwdTitle: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  pwdDesc: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },

  // ====== 管理员信息 ======
  infoCard: { marginBottom: Spacing.lg },
  infoRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: Spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  infoLabel: { fontSize: Typography.body, color: Colors.textSecondary },
  infoValue: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  roleBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: Colors.admin + '15', paddingHorizontal: Spacing.sm,
    paddingVertical: 2, borderRadius: 4,
  },
  roleText: { fontSize: Typography.caption, color: Colors.admin, fontWeight: '500' },

  // ====== 弹窗 ======
  modalHint: {
    fontSize: Typography.body, color: Colors.textSecondary,
    lineHeight: 20, marginBottom: Spacing.lg,
  },
  modalInput: {
    borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input,
    padding: Spacing.md, fontSize: Typography.body, color: Colors.textPrimary,
  },
  errorText: {
    fontSize: Typography.caption, color: Colors.lover,
    marginTop: Spacing.sm,
  },
  verifyOkRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: Colors.family + '15', padding: Spacing.md,
    borderRadius: BorderRadius.input, marginBottom: Spacing.lg,
  },
  verifyOkText: { fontSize: Typography.body, fontWeight: '600', color: Colors.family },
});

export default AdminSettingsScreen;
