/**
 * 专属日记页面（持久化版）
 *
 * 绑定双方图文视频发布、仅双方可见。
 * - 发布/编辑/删除均持久化到 AsyncStorage
 * - 绑定关系校验（需双方互为联系人且非拉黑）
 * - 图片/视频选取 + 编辑器内预览
 * - 媒体卡片点击全屏预览
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  TouchableOpacity,
  Alert,
  Image,
  ActivityIndicator,
  Modal as RNModal,
  Pressable,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Button, DiaryPostCard } from '../components';
import {
  getDiaries, createDiary, deleteDiary, updateDiary, getDiaryCount,
} from '../services/diary';
import { getContactById } from '../services/contacts';
import type { Contact, DiaryPost, DiaryMedia } from '../types';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

interface DiaryScreenProps {
  contact: Contact;
  currentUserId: string;
  currentUsername: string;
  onBack: () => void;
}

const DiaryScreen: React.FC<DiaryScreenProps> = ({
  contact,
  currentUserId,
  currentUsername,
  onBack,
}) => {
  const mountedRef = useRef(true);

  // 列表
  const [posts, setPosts] = useState<DiaryPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [diaryCount, setDiaryCount] = useState(0);

  // 发布/编辑
  const [newContent, setNewContent] = useState('');
  const [newMedia, setNewMedia] = useState<DiaryMedia[]>([]);
  const [publishing, setPublishing] = useState(false);
  const [showEditor, setShowEditor] = useState(false);
  const [editingPost, setEditingPost] = useState<DiaryPost | null>(null);

  // 媒体全屏预览
  const [previewMedia, setPreviewMedia] = useState<DiaryMedia | null>(null);
  const [previewIndex, setPreviewIndex] = useState(0);

  // 拉黑状态
  const [isBlocked, setIsBlocked] = useState(false);

  // ====== 生命周期 ======

  useEffect(() => {
    mountedRef.current = true;
    initScreen();
    return () => { mountedRef.current = false; };
  }, []);

  const initScreen = async () => {
    try {
      // 检查拉黑状态（双向）
      const [selfContact, targetContact] = await Promise.all([
        getContactById(currentUserId),
        getContactById(contact.userId),
      ]);
      if (!mountedRef.current) return;
      setIsBlocked(
        contact.isBlocked ||
        (targetContact?.isBlocked ?? false) ||
        (selfContact?.isBlocked ?? false),
      );
    } catch { /* 静默 */ }

    await loadPosts();
    if (mountedRef.current) setLoading(false);
  };

  const loadPosts = useCallback(async () => {
    try {
      const { posts: data, total } = await getDiaries(currentUserId, contact.userId);
      if (mountedRef.current) {
        setPosts(data);
        setDiaryCount(total);
      }
    } catch {
      if (mountedRef.current) setPosts([]);
    }
  }, [currentUserId, contact.userId]);

  // ====== 媒体选取 ======

  const handlePickMedia = async (mediaType: 'image' | 'video') => {
    // 检查数量限制
    if (newMedia.length >= 9) {
      Alert.alert('提示', '最多添加9个图片/视频');
      return;
    }

    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('权限提示', '需要相册权限才能选取图片/视频');
      return;
    }

    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: mediaType === 'video'
          ? ImagePicker.MediaTypeOptions.Videos
          : ImagePicker.MediaTypeOptions.Images,
        allowsEditing: false,
        quality: 0.85,
        videoMaxDuration: 60,
      });

      if (!result.canceled && result.assets.length > 0) {
        const asset = result.assets[0];
        setNewMedia((prev) => [
          ...prev,
          {
            uri: asset.uri,
            type: mediaType,
            // 视频用首帧作为缩略图（expo-image-picker 不提供 thumbnail，后续可用 expo-video-thumbnails）
            thumbnailUri: asset.uri,
          },
        ]);
      }
    } catch {
      Alert.alert('错误', '选取媒体失败，请重试');
    }
  };

  // ====== 移除媒体 ======

  const handleRemoveMedia = (index: number) => {
    setNewMedia((prev) => prev.filter((_, i) => i !== index));
  };

  // ====== 发布/保存日记 ======

  const handlePublish = async () => {
    if (!newContent.trim() && newMedia.length === 0) {
      Alert.alert('提示', '请输入内容或添加图片/视频');
      return;
    }

    if (isBlocked) {
      Alert.alert('提示', '该用户已被拉黑，无法发布日记');
      return;
    }

    setPublishing(true);
    try {
      if (editingPost) {
        const updated = await updateDiary(
          editingPost.id, currentUserId, newContent.trim(), newMedia,
        );
        if (!mountedRef.current) return;
        if (updated) {
          setPosts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
        }
      } else {
        const post = await createDiary(
          currentUserId, currentUsername, null,
          contact.userId, contact.username,
          newContent.trim(), newMedia,
        );
        if (!mountedRef.current) return;
        setPosts((prev) => [post, ...prev]);
        setDiaryCount((c) => c + 1);
      }

      resetEditor();
    } catch (e: any) {
      if (mountedRef.current) {
        Alert.alert('发布失败', e?.message || '未知错误');
      }
    } finally {
      if (mountedRef.current) setPublishing(false);
    }
  };

  const resetEditor = () => {
    setNewContent('');
    setNewMedia([]);
    setShowEditor(false);
    setEditingPost(null);
  };

  // ====== 删除日记 ======

  const handleDelete = useCallback((post: DiaryPost) => {
    Alert.alert('删除日记', '确定删除这篇日记吗？删除后不可恢复。', [
      { text: '取消', style: 'cancel' },
      {
        text: '删除',
        style: 'destructive',
        onPress: async () => {
          try {
            const result = await deleteDiary(post.id, currentUserId);
            if (!mountedRef.current) return;
            if (result.success) {
              setPosts((prev) => prev.filter((p) => p.id !== post.id));
              setDiaryCount((c) => Math.max(0, c - 1));
            } else {
              Alert.alert('删除失败', result.message);
            }
          } catch {
            if (mountedRef.current) Alert.alert('错误', '删除失败，请重试');
          }
        },
      },
    ]);
  }, [currentUserId]);

  // ====== 编辑日记 ======

  const handleEdit = useCallback((post: DiaryPost) => {
    setEditingPost(post);
    setNewContent(post.content);
    setNewMedia(post.media);
    setShowEditor(true);
  }, []);

  // ====== 媒体预览 ======

  const handleMediaPress = useCallback((media: DiaryMedia, index: number) => {
    setPreviewMedia(media);
    setPreviewIndex(index);
  }, []);

  const closePreview = () => setPreviewMedia(null);

  // ====== 刷新 ======

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadPosts();
    if (mountedRef.current) setRefreshing(false);
  };

  // ====== 渲染 ======

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      {/* 头部 */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <View>
          <View style={styles.headerTitleRow}>
            <Text style={styles.headerTitle}>专属日记</Text>
            {diaryCount > 0 && (
              <Text style={styles.diaryCount}>{diaryCount}篇</Text>
            )}
          </View>
          <View style={styles.headerSub}>
            <Ionicons name="lock-closed" size={14} color={Colors.family} />
            <Text style={styles.headerSubText}>
              仅 {currentUsername} 和 {contact.username} 可见
            </Text>
          </View>
        </View>
      </View>

      {/* 拉黑提示 */}
      {isBlocked && (
        <View style={styles.blockedBanner}>
          <Ionicons name="ban" size={16} color="#FFF" />
          <Text style={styles.blockedText}>
            该用户已被拉黑，日记功能受限
          </Text>
        </View>
      )}

      {/* 日记列表 */}
      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={Colors.primary} />
        </View>
      ) : (
        <FlatList
          data={posts}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.postWrapper}>
              <DiaryPostCard
                post={item}
                isOwner={item.authorId === currentUserId}
                onDelete={handleDelete}
                onEdit={handleEdit}
                onMediaPress={handleMediaPress}
              />
            </View>
          )}
          contentContainerStyle={styles.listContent}
          refreshing={refreshing}
          onRefresh={handleRefresh}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="book-outline" size={64} color={Colors.divider} />
              <Text style={styles.emptyTitle}>还没有日记</Text>
              <Text style={styles.emptyHint}>记录只属于你们的珍贵时光</Text>
            </View>
          }
        />
      )}

      {/* FAB 发布按钮 */}
      {!showEditor && !isBlocked && (
        <TouchableOpacity
          style={styles.fab}
          onPress={() => setShowEditor(true)}
          activeOpacity={0.8}
        >
          <Ionicons name="add" size={28} color="#FFF" />
        </TouchableOpacity>
      )}

      {/* 编辑器 */}
      {showEditor && (
        <View style={styles.editor}>
          {/* 媒体预览 */}
          {newMedia.length > 0 && (
            <View style={styles.mediaPreviewRow}>
              {newMedia.map((m, idx) => (
                <View key={`${m.uri.slice(-20)}_${idx}`} style={styles.mediaPreview}>
                  <Image
                    source={{ uri: m.thumbnailUri || m.uri }}
                    style={styles.mediaPreviewImg}
                    resizeMode="cover"
                  />
                  {m.type === 'video' && (
                    <View style={styles.videoTag}>
                      <Ionicons name="play" size={10} color="#FFF" />
                    </View>
                  )}
                  <TouchableOpacity
                    style={styles.removeMedia}
                    onPress={() => handleRemoveMedia(idx)}
                    hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
                  >
                    <Ionicons name="close-circle" size={20} color={Colors.lover} />
                  </TouchableOpacity>
                </View>
              ))}
            </View>
          )}

          <View style={styles.editorInputRow}>
            <TextInput
              style={styles.editorInput}
              placeholder={editingPost ? '编辑日记...' : '记录你们的瞬间...'}
              placeholderTextColor={Colors.textHint}
              multiline
              value={newContent}
              onChangeText={setNewContent}
              maxLength={2000}
              textAlignVertical="top"
            />
            <View style={styles.editorMediaActions}>
              <TouchableOpacity onPress={() => handlePickMedia('image')}>
                <Ionicons name="image-outline" size={22} color={Colors.textSecondary} />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handlePickMedia('video')}>
                <Ionicons name="videocam-outline" size={22} color={Colors.textSecondary} />
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.editorActions}>
            <TouchableOpacity onPress={resetEditor}>
              <Text style={styles.editorCancel}>取消</Text>
            </TouchableOpacity>
            <Button
              title={editingPost ? '保存修改' : '发布'}
              onPress={handlePublish}
              loading={publishing}
              style={styles.publishBtn}
            />
          </View>
        </View>
      )}

      {/* 媒体全屏预览 Modal */}
      <RNModal
        visible={previewMedia !== null}
        transparent
        animationType="fade"
        onRequestClose={closePreview}
      >
        <View style={styles.previewOverlay}>
          <TouchableOpacity style={styles.previewCloseBtn} onPress={closePreview}>
            <Ionicons name="close" size={28} color="#FFF" />
          </TouchableOpacity>

          {previewMedia && (
            <View style={styles.previewContainer}>
              <Image
                source={{ uri: previewMedia.uri }}
                style={styles.previewImage}
                resizeMode="contain"
              />
              {previewMedia.type === 'video' && (
                <View style={styles.previewVideoTag}>
                  <Ionicons name="play-circle" size={64} color="rgba(255,255,255,0.9)" />
                  <Text style={styles.previewVideoHint}>视频预览（点击播放需服务端视频流支持）</Text>
                </View>
              )}
            </View>
          )}

          <Text style={styles.previewHint}>点击右上角关闭</Text>
        </View>
      </RNModal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  // 头部
  header: {
    paddingHorizontal: Spacing.lg, paddingTop: Spacing.lg, paddingBottom: Spacing.md,
    backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  backBtn: { marginBottom: Spacing.sm },
  headerTitleRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  diaryCount: { fontSize: Typography.caption, color: Colors.textHint },
  headerSub: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, marginTop: 4 },
  headerSubText: { fontSize: Typography.caption, color: Colors.textHint },
  // 拉黑横幅
  blockedBanner: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm,
    backgroundColor: '#999', paddingVertical: Spacing.sm, paddingHorizontal: Spacing.lg,
  },
  blockedText: { fontSize: Typography.caption, color: '#FFF' },
  // 列表
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  listContent: { padding: Spacing.lg },
  postWrapper: { marginBottom: Spacing.sm },
  empty: { alignItems: 'center', paddingVertical: Spacing.xl * 4 },
  emptyTitle: { fontSize: Typography.subtitle, color: Colors.textHint, marginTop: Spacing.lg },
  emptyHint: { fontSize: Typography.caption, color: Colors.textHint, marginTop: Spacing.xs },
  // FAB
  fab: {
    position: 'absolute', right: Spacing.lg, bottom: Spacing.xl,
    width: 56, height: 56, borderRadius: 28,
    backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center',
    elevation: 6, shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.3, shadowRadius: 6,
  },
  // 编辑器
  editor: {
    backgroundColor: Colors.bgWhite,
    borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider,
    padding: Spacing.lg, paddingBottom: Spacing.xl,
  },
  mediaPreviewRow: {
    flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm, marginBottom: Spacing.md,
  },
  mediaPreview: { position: 'relative' },
  mediaPreviewImg: {
    width: 72, height: 72, borderRadius: 4, backgroundColor: Colors.bgPrimary,
  },
  videoTag: {
    position: 'absolute', top: 4, left: 4,
    backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 3, padding: 2,
  },
  removeMedia: {
    position: 'absolute', top: -8, right: -8,
    backgroundColor: Colors.bgWhite, borderRadius: 10,
  },
  editorInputRow: { flexDirection: 'row', alignItems: 'flex-end', gap: Spacing.sm },
  editorInput: {
    flex: 1, minHeight: 44, maxHeight: 120,
    fontSize: Typography.body, color: Colors.textPrimary,
    borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.card,
    paddingHorizontal: Spacing.md, paddingTop: Spacing.sm, paddingBottom: Spacing.sm,
  },
  editorMediaActions: {
    flexDirection: 'row', gap: Spacing.md, paddingBottom: Spacing.sm,
  },
  editorActions: {
    flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center',
    marginTop: Spacing.md, gap: Spacing.lg,
  },
  editorCancel: { fontSize: Typography.body, color: Colors.textHint },
  publishBtn: { paddingHorizontal: Spacing.xl },
  // 全屏预览
  previewOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.95)',
    justifyContent: 'center', alignItems: 'center',
  },
  previewCloseBtn: {
    position: 'absolute', top: 48, right: Spacing.lg, zIndex: 10,
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center',
  },
  previewContainer: {
    width: SCREEN_WIDTH, height: SCREEN_HEIGHT * 0.6,
    alignItems: 'center', justifyContent: 'center',
  },
  previewImage: {
    width: SCREEN_WIDTH - Spacing.lg * 2,
    height: SCREEN_HEIGHT * 0.55,
    borderRadius: BorderRadius.card,
  },
  previewVideoTag: {
    position: 'absolute',
    alignItems: 'center', justifyContent: 'center',
  },
  previewVideoHint: {
    fontSize: Typography.caption, color: 'rgba(255,255,255,0.5)', marginTop: Spacing.sm,
  },
  previewHint: {
    fontSize: Typography.caption, color: 'rgba(255,255,255,0.3)',
    marginTop: Spacing.lg,
  },
});

export default DiaryScreen;
