/**
 * 实名认证页
 * 强制实名认证，未实名禁用 APP 所有功能
 * 注册后必须完成实名认证，不可手动跳过
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Alert,
  Image,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Input, Button } from '../components';
import { useAuth } from '../context/AuthContext';

interface RealNameScreenProps {
  isMandatory?: boolean; // 强制认证模式：不可跳过
  onComplete: () => void;
}

/** 身份证号校验：18位 + 校验位验证 */
function isValidIdCard(id: string): boolean {
  if (!/^\d{17}[\dXx]$/.test(id)) return false;

  // 加权因子
  const weights = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
  // 校验码映射
  const checkCodes = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'];

  let sum = 0;
  for (let i = 0; i < 17; i++) {
    sum += parseInt(id[i], 10) * weights[i];
  }
  const mod = sum % 11;
  return checkCodes[mod] === id[17].toUpperCase();
}

const RealNameScreen: React.FC<RealNameScreenProps> = ({
  isMandatory = false,
  onComplete,
}) => {
  const { state, submitRealName, checkRealNameStatus } = useAuth();

  const [realName, setRealName] = useState('');
  const [idCardNumber, setIdCardNumber] = useState('');
  const [frontImageUri, setFrontImageUri] = useState<string | null>(null);
  const [backImageUri, setBackImageUri] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // 检查是否已完成实名认证
  useEffect(() => {
    if (state.isRealNameVerified) {
      onComplete();
    }
  }, [state.isRealNameVerified, onComplete]);

  const pickImage = async (side: 'front' | 'back') => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('权限提示', '需要相册权限才能上传身份证照片');
      return;
    }

    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        quality: 0.9,
      });
      if (!result.canceled && result.assets.length > 0) {
        if (side === 'front') {
          setFrontImageUri(result.assets[0].uri);
        } else {
          setBackImageUri(result.assets[0].uri);
        }
      }
    } catch {
      Alert.alert('错误', '选取图片失败');
    }
  };

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!realName.trim()) {
      errs.realName = '请输入真实姓名';
    } else if (realName.trim().length < 2) {
      errs.realName = '姓名至少2个字符';
    } else if (realName.trim().length > 30) {
      errs.realName = '姓名最多30个字符';
    }
    if (!idCardNumber) {
      errs.idCardNumber = '请输入身份证号码';
    } else if (!isValidIdCard(idCardNumber)) {
      errs.idCardNumber = '请输入正确的18位身份证号码';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  // 脱敏显示身份证号（仅前端显示用）
  const maskedIdCard = (id: string): string => {
    if (id.length < 8) return id;
    return id.slice(0, 3) + '***********' + id.slice(-4);
  };

  const handleSubmit = async () => {
    if (!validate()) return;

    setLoading(true);
    const result = await submitRealName({
      realName: realName.trim(),
      idCardNumber: idCardNumber.toUpperCase(),
      frontImageUri: frontImageUri || undefined,
      backImageUri: backImageUri || undefined,
    });
    setLoading(false);

    if (result.success) {
      if (isMandatory) {
        // 强制模式下：若审核通过则自动放行
        Alert.alert(
          '提交成功',
          '实名认证已提交，审核通过后即可正常使用。',
          [{ text: '我知道了', onPress: onComplete }],
        );
      } else {
        Alert.alert(
          '提交成功',
          '实名认证已提交，审核通过后即可正常使用。',
          [{ text: '我知道了', onPress: onComplete }],
        );
      }
    } else {
      Alert.alert('提交失败', result.message);
    }
  };

  // 如果已经认证，直接通过
  if (state.isRealNameVerified) {
    return null;
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior="height"
      >
        <ScrollView
          style={styles.flex}
          contentContainerStyle={styles.container}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.iconArea}>
            <Ionicons name="shield-checkmark" size={48} color={Colors.primary} />
          </View>
          <Text style={styles.title}>实名认证</Text>
          <Text style={styles.desc}>
            根据相关法律法规，使用本应用需要完成实名认证。{'\n'}
            您的信息将严格保密，仅用于身份核实。
          </Text>

          {/* 实名状态提示 */}
          {state.realNameInfo && (
            <View style={styles.statusBanner}>
              <Ionicons
                name={
                  state.realNameInfo.status === 'verified'
                    ? 'checkmark-circle'
                    : state.realNameInfo.status === 'rejected'
                      ? 'close-circle'
                      : 'time'
                }
                size={20}
                color={
                  state.realNameInfo.status === 'verified'
                    ? Colors.family
                    : state.realNameInfo.status === 'rejected'
                      ? Colors.lover
                      : Colors.friend
                }
              />
              <Text style={styles.statusText}>
                {state.realNameInfo.status === 'verified'
                  ? '已通过实名认证'
                  : state.realNameInfo.status === 'rejected'
                    ? '实名认证未通过，请重新提交'
                    : state.realNameInfo.status === 'pending'
                      ? '实名认证审核中...'
                      : '未完成实名认证'}
              </Text>
            </View>
          )}

          <Input
            label="真实姓名"
            placeholder="请输入身份证上的姓名"
            value={realName}
            onChangeText={(t) => { setRealName(t); setErrors((e) => ({ ...e, realName: '' })); }}
            error={errors.realName}
            autoCapitalize="words"
            maxLength={30}
          />
          <Input
            label="身份证号码"
            placeholder="请输入18位身份证号码"
            keyboardType="default"
            maxLength={18}
            value={idCardNumber}
            onChangeText={(t) => { setIdCardNumber(t); setErrors((e) => ({ ...e, idCardNumber: '' })); }}
            error={errors.idCardNumber}
            autoCapitalize="characters"
          />

          {/* 身份证照片上传 */}
          <Text style={styles.sectionTitle}>身份证照片（选填，推荐上传加速审核）</Text>
          <View style={styles.imageRow}>
            <TouchableOpacity
              style={styles.imageBox}
              onPress={() => pickImage('front')}
              activeOpacity={0.7}
            >
              {frontImageUri ? (
                <Image source={{ uri: frontImageUri }} style={styles.idImage} />
              ) : (
                <View style={styles.imagePlaceholder}>
                  <Ionicons name="camera-outline" size={24} color={Colors.textHint} />
                  <Text style={styles.imageLabel}>人像面</Text>
                </View>
              )}
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.imageBox}
              onPress={() => pickImage('back')}
              activeOpacity={0.7}
            >
              {backImageUri ? (
                <Image source={{ uri: backImageUri }} style={styles.idImage} />
              ) : (
                <View style={styles.imagePlaceholder}>
                  <Ionicons name="camera-outline" size={24} color={Colors.textHint} />
                  <Text style={styles.imageLabel}>国徽面</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>

          <Button
            title="提交认证"
            onPress={handleSubmit}
            loading={loading}
            style={styles.submitBtn}
          />

          {!isMandatory && (
            <TouchableOpacity onPress={() => {
              Alert.alert(
                '跳过实名认证',
                '未实名用户将无法使用 APP 的大部分功能（通讯录、绑定、定位等）。确定要跳过吗？',
                [
                  { text: '去认证', style: 'cancel' },
                  { text: '跳过', style: 'destructive', onPress: onComplete },
                ],
              );
            }} style={styles.skipBtn}>
              <Text style={styles.skipText}>跳过，稍后认证</Text>
            </TouchableOpacity>
          )}

          {isMandatory && (
            <Text style={styles.mandatoryNote}>
              完成实名认证后方可继续使用本应用
            </Text>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: Colors.bgWhite,
  },
  flex: {
    flex: 1,
  },
  container: {
    flexGrow: 1,
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.xl,
    paddingBottom: Spacing.xl * 2,
  },
  iconArea: {
    alignItems: 'center',
    marginBottom: Spacing.lg,
  },
  title: {
    fontSize: Typography.title,
    fontWeight: '600',
    color: Colors.textPrimary,
    textAlign: 'center',
    marginBottom: Spacing.sm,
  },
  desc: {
    fontSize: Typography.body,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: Spacing.xl,
  },
  statusBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.bgPrimary,
    padding: Spacing.md,
    borderRadius: BorderRadius.card,
    marginBottom: Spacing.xl,
    gap: Spacing.sm,
  },
  statusText: {
    fontSize: Typography.body,
    color: Colors.textPrimary,
  },
  sectionTitle: {
    fontSize: Typography.body,
    fontWeight: '500',
    color: Colors.textPrimary,
    marginBottom: Spacing.md,
    marginTop: Spacing.sm,
  },
  imageRow: {
    flexDirection: 'row',
    gap: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  imageBox: {
    flex: 1,
    height: 130,
    borderRadius: BorderRadius.input,
    borderWidth: 1,
    borderColor: Colors.divider,
    borderStyle: 'dashed',
    overflow: 'hidden',
    backgroundColor: Colors.bgPrimary,
  },
  imagePlaceholder: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  imageLabel: {
    fontSize: Typography.caption,
    color: Colors.textHint,
    marginTop: 4,
  },
  idImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  submitBtn: {
    marginTop: Spacing.sm,
  },
  skipBtn: {
    alignItems: 'center',
    marginTop: Spacing.lg,
  },
  skipText: {
    fontSize: Typography.body,
    color: Colors.textHint,
  },
  mandatoryNote: {
    fontSize: Typography.caption,
    color: Colors.lover,
    textAlign: 'center',
    marginTop: Spacing.lg,
    fontWeight: '500',
  },
});

export default RealNameScreen;
