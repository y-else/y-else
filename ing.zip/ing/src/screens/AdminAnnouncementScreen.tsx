/**
 * 管理员公告发布/编辑
 * 编辑标题内容，全体用户启动自动弹窗
 */

import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, FlatList,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Input, Button, Card } from '../components';
import { useAuth } from '../context/AuthContext';
import { publishAdminAnnouncement } from '../services/admin';
import { getAllAnnouncements } from '../services/announcement';
import type { Announcement, AnnouncementForm } from '../types';

interface AdminAnnouncementScreenProps {
  onBack: () => void;
}

const LEVEL_OPTIONS: { key: 'normal' | 'important' | 'urgent'; label: string; color: string }[] = [
  { key: 'normal', label: '通知', color: Colors.primary },
  { key: 'important', label: '重要', color: Colors.friend },
  { key: 'urgent', label: '紧急', color: Colors.lover },
];

const AdminAnnouncementScreen: React.FC<AdminAnnouncementScreenProps> = ({ onBack }) => {
  const { state } = useAuth();
  const adminId = state.user?.id || 'admin';
  const adminName = state.user?.username || '管理员';

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [level, setLevel] = useState<'normal' | 'important' | 'urgent'>('normal');
  const [publishing, setPublishing] = useState(false);
  const [allAnnouncements, setAllAnnouncements] = useState<Announcement[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    let cancelled = false;
    getAllAnnouncements().then((list) => {
      if (!cancelled) setAllAnnouncements(list);
    });
    return () => { cancelled = true; };
  }, []);

  const handlePublish = async () => {
    if (!title.trim()) { Alert.alert('提示', '请输入公告标题'); return; }
    if (!content.trim()) { Alert.alert('提示', '请输入公告内容'); return; }

    setPublishing(true);
    const ann = await publishAdminAnnouncement(adminId, adminName, { title: title.trim(), content: content.trim(), level });
    setPublishing(false);
    setAllAnnouncements((prev) => [ann, ...prev]);
    setTitle(''); setContent(''); setLevel('normal');
    Alert.alert('发布成功', '公告已发布，全体用户将在下次启动时自动弹窗查看');
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.container}>
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.title}>发布公告</Text>

        {/* 编辑表单 */}
        <Card>
          <Input label="公告标题" placeholder="请输入公告标题" value={title} onChangeText={setTitle} />
          <Input
            label="公告内容" placeholder="请输入公告内容" value={content} onChangeText={setContent}
            multiline numberOfLines={4} style={styles.contentInput}
          />
          <Text style={styles.levelLabel}>公告级别</Text>
          <View style={styles.levelRow}>
            {LEVEL_OPTIONS.map((o) => (
              <TouchableOpacity
                key={o.key} style={[styles.levelBtn, level === o.key && { backgroundColor: o.color, borderColor: o.color }]}
                onPress={() => setLevel(o.key)}
              >
                <Text style={[styles.levelText, level === o.key && { color: '#FFF' }]}>{o.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <Button title="发布公告" onPress={handlePublish} loading={publishing} style={styles.publishBtn} />
        </Card>

        {/* 历史公告 */}
        <TouchableOpacity style={styles.historyToggle} onPress={() => setShowHistory(!showHistory)}>
          <Text style={styles.historyToggleText}>已发布公告 ({allAnnouncements.length})</Text>
          <Ionicons name={showHistory ? 'chevron-up' : 'chevron-down'} size={16} color={Colors.primary} />
        </TouchableOpacity>

        {showHistory && allAnnouncements.map((ann) => (
          <Card key={ann.id} style={styles.historyCard}>
            <View style={[styles.levelBadge, { backgroundColor: ann.level === 'urgent' ? Colors.lover : ann.level === 'important' ? Colors.friend : Colors.primary }]}>
              <Text style={styles.levelBadgeText}>{ann.level === 'urgent' ? '紧急' : ann.level === 'important' ? '重要' : '通知'}</Text>
            </View>
            <Text style={styles.historyTitle}>{ann.title}</Text>
            <Text style={styles.historyContent} numberOfLines={3}>{ann.content}</Text>
            <Text style={styles.historyMeta}>{ann.publishedBy} · {new Date(ann.publishedAt).toLocaleDateString('zh-CN')}</Text>
          </Card>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  container: { padding: Spacing.lg },
  backBtn: { marginBottom: Spacing.lg },
  title: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.lg },
  contentInput: { height: 100, textAlignVertical: 'top' },
  levelLabel: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary, marginBottom: Spacing.sm },
  levelRow: { flexDirection: 'row', gap: Spacing.sm, marginBottom: Spacing.lg },
  levelBtn: {
    flex: 1, alignItems: 'center', paddingVertical: Spacing.sm, borderRadius: 4,
    borderWidth: 1.5, borderColor: Colors.divider,
  },
  levelText: { fontSize: Typography.body, color: Colors.textSecondary, fontWeight: '500' },
  publishBtn: { marginTop: Spacing.md },
  historyToggle: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: Spacing.lg,
  },
  historyToggleText: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.primary },
  historyCard: { marginBottom: Spacing.sm },
  levelBadge: { alignSelf: 'flex-start', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 3, marginBottom: Spacing.xs },
  levelBadgeText: { fontSize: Typography.caption, color: '#FFF', fontWeight: '600' },
  historyTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.xs },
  historyContent: { fontSize: Typography.body, color: Colors.textSecondary, lineHeight: 22, marginBottom: Spacing.sm },
  historyMeta: { fontSize: Typography.caption, color: Colors.textHint },
});

export default AdminAnnouncementScreen;
