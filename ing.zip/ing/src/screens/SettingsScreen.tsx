/**
 * 独立设置页面
 * 收纳：互动权限 / 兑换码 / 实名认证 / 存储空间 / 数据导出 / 切换账号 / 注销账号 / 退出登录
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, TextInput,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card, SwitchSetting, Modal, Button } from '../components';
import { useAuth } from '../context/AuthContext';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { MainStackParamList } from '../navigation/AppNavigator';
import {
  getInteractionSettings, updateInteractionSetting, resetInteractionSettings,
} from '../services/settings';
import { bindToAdmin, unbindFromAdmin, getUserBinding, isBindingValid } from '../services/bindingService';
import { redeemCode, getUserAddress, saveUserAddress } from '../services/redemptionCode';
import { getStorageStats, clearAppCache, exportUserData, formatBytes } from '../services/cacheManager';
import { submitRealName, getRealNameStatus, reviewRealNameApplication } from '../services/auth';
import { requestDeactivation, confirmDeactivation, adminPurgeAllDeactivatedUsers, getDeactivationStorageStats } from '../services/deactivationService';
import type { InteractionSettings, AdminBinding, ShippingAddress, RealNameInfo } from '../types';

type SettingRowProps = {
  icon: string; color: string; label: string; desc?: string;
  onPress: () => void; rightText?: string; danger?: boolean;
};

const SettingRow: React.FC<SettingRowProps> = ({ icon, color, label, desc, onPress, rightText, danger }) => (
  <TouchableOpacity style={styles.row} onPress={onPress} activeOpacity={0.6}>
    <View style={[styles.rowIcon, { backgroundColor: color + '12' }]}>
      <Ionicons name={icon as any} size={20} color={color} />
    </View>
    <View style={styles.rowInfo}>
      <Text style={[styles.rowLabel, danger && { color: Colors.lover }]}>{label}</Text>
      {desc ? <Text style={styles.rowDesc}>{desc}</Text> : null}
    </View>
    {rightText ? <Text style={styles.rowRight}>{rightText}</Text> : null}
    <Ionicons name="chevron-forward" size={16} color={Colors.textHint} />
  </TouchableOpacity>
);

const SettingsScreen: React.FC = () => {
  const { state, logout } = useAuth();
  const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>();
  const user = state.user;
  const isAdmin = user?.role === 'admin';
  const mountedRef = useRef(true);

  // 互动权限
  const [settings, setSettings] = useState<InteractionSettings | null>(null);
  const [showInteraction, setShowInteraction] = useState(false);
  // 兑换码
  const [showRedeem, setShowRedeem] = useState(false);
  const [redeemInput, setRedeemInput] = useState('');
  const [redeemLoading, setRedeemLoading] = useState(false);
  const [showAddressForm, setShowAddressForm] = useState(false);
  const [address, setAddress] = useState<ShippingAddress>({ name: '', phone: '', province: '', city: '', district: '', detail: '' });
  const [pendingRedeemCode, setPendingRedeemCode] = useState('');
  // 管理员绑定
  const [binding, setBinding] = useState<AdminBinding | null>(null);
  const [showBindModal, setShowBindModal] = useState(false);
  const [bindToken, setBindToken] = useState('');
  // 实名认证
  const [realName, setRealName] = useState<RealNameInfo | null>(null);
  const [showRealName, setShowRealName] = useState(false);
  const [rnName, setRnName] = useState('');
  const [rnIdCard, setRnIdCard] = useState('');
  // 存储
  const [storage, setStorage] = useState({ totalBytes: 0, totalKeys: 0 });
  // 数据导出格式
  const [exportFormat, setExportFormat] = useState<'json' | 'csv'>('json');
  const [showExportPicker, setShowExportPicker] = useState(false);
  // 注销
  const [showDeact, setShowDeact] = useState(false);
  const [deactStep, setDeactStep] = useState<'confirm' | 'apply' | 'verify'>('confirm');
  const [deactCode, setDeactCode] = useState('');
  const [deactInput, setDeactInput] = useState('');
  const [deactLoading, setDeactLoading] = useState(false);
  // 清理面板（管理员）
  const [cleanupStats, setCleanupStats] = useState({ pendingUsers: 0, scheduledPurge: 0, totalDeactivatedCodes: 0 });

  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  const loadAll = useCallback(async () => {
    try {
      const s = await getInteractionSettings();
      if (mountedRef.current) setSettings(s);
    } catch {}
    if (user && !isAdmin) {
      try {
        const v = await isBindingValid(user.id);
        if (v) { const b = await getUserBinding(user.id); if (mountedRef.current) setBinding(b); }
        else { if (mountedRef.current) setBinding(null); }
      } catch {}
      try {
        const a = await getUserAddress(user.id);
        if (a && mountedRef.current) setAddress(a);
      } catch {}
    }
    // 实名状态
    if (user && !isAdmin) {
      try {
        const rnResp = await getRealNameStatus(user.id);
        if (rnResp.data && mountedRef.current) setRealName(rnResp.data);
      } catch {}
    }
    // 存储
    try {
      const st = await getStorageStats();
      if (mountedRef.current) setStorage({ totalBytes: st.totalBytes, totalKeys: st.totalKeys });
    } catch {}
    // 管理员清理统计
    if (isAdmin) {
      try {
        const cs = await getDeactivationStorageStats();
        if (mountedRef.current) setCleanupStats(cs);
      } catch {}
    }
  }, [user, isAdmin]);

  useEffect(() => { loadAll(); }, [loadAll]);

  const handleToggle = useCallback(async (key: keyof InteractionSettings, value: boolean) => {
    const r = await updateInteractionSetting(key, value); setSettings(r);
  }, []);

  // 存储清理
  const handleStorage = async () => {
    const st = await getStorageStats();
    const info = st.categories.map((c) => `${c.name}: ${formatBytes(c.bytes)} (${c.keys}项)`).join('\n');
    Alert.alert('存储空间', `总占用: ${formatBytes(st.totalBytes)} / ${st.totalKeys}个存储项\n\n${info}`, [
      { text: '取消', style: 'cancel' },
      { text: '清理缓存', onPress: async () => {
        const r = await clearAppCache();
        Alert.alert('清理完成', `已清理${r.removedKeys}个缓存，释放${formatBytes(r.freedBytes)}`);
        loadAll();
      }},
    ]);
  };

  // 数据导出
  const handleExport = async () => {
    if (!user) return;
    try {
      const data = await exportUserData(user.id);
      Alert.alert(
        '导出完成',
        `格式: ${exportFormat.toUpperCase()}\n${data.totalEntries}条数据 · ${formatBytes(data.totalBytes)}\n\n导出时间: ${new Date(data.exportedAt).toLocaleString('zh-CN')}`,
        [{ text: '知道了' }],
      );
    } catch { Alert.alert('导出失败', '请检查存储权限'); }
  };

  // 切换账号
  const handleSwitchAccount = () => { navigation.navigate('AccountSwitch' as any); };

  // 注销流程
  const handleDeactConfirm = () => { setDeactStep('apply'); };
  const handleApplyDeact = async () => {
    if (!user) return;
    setDeactLoading(true);
    const result = await requestDeactivation(user.id, user.username, user.phone);
    setDeactLoading(false);
    if (result.success) {
      setDeactCode(result.code || '');
      setDeactStep('verify');
    }
  };
  const handleVerifyDeact = async () => {
    if (!user) return;
    if (!deactInput.trim()) { Alert.alert('提示', '请输入6位注销验证码'); return; }
    setDeactLoading(true);
    const result = await confirmDeactivation(user.id, deactInput.trim());
    setDeactLoading(false);
    if (result.success) {
      setShowDeact(false); setDeactStep('confirm'); setDeactInput('');
      Alert.alert('注销成功', result.message, [{ text: '确定', onPress: logout }]);
    } else { Alert.alert('注销失败', result.message); }
  };

  // 退出登录
  const handleLogout = () => {
    Alert.alert('退出登录', '确定退出当前账号？', [
      { text: '取消', style: 'cancel' },
      { text: '退出', style: 'destructive', onPress: logout },
    ]);
  };

  // 实名提交
  const handleSubmitRealName = async () => {
    if (!rnName.trim() || rnName.length < 2) { Alert.alert('提示', '姓名至少2个字符'); return; }
    if (!/^\d{17}[\dXx]$/.test(rnIdCard.trim())) { Alert.alert('提示', '身份证号格式不正确'); return; }
    if (!user) return;
    await submitRealName(user.id, { realName: rnName.trim(), idCardNumber: rnIdCard.trim() });
    setShowRealName(false);
    const rnResp = await getRealNameStatus(user.id);
    if (rnResp.data && mountedRef.current) setRealName(rnResp.data);
    Alert.alert('已提交', '实名认证已提交，请等待管理员审核');
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>设置</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
        {/* ====== 实名认证状态 ====== */}
        {!isAdmin && (
          <Card style={styles.section}>
            <SettingRow
              icon="finger-print" color={realName?.status === 'verified' ? Colors.family : Colors.warning}
              label={realName ? (realName.status === 'verified' ? '已实名认证' : realName.status === 'pending' ? '实名审核中' : '实名被驳回') : '实名认证'}
              desc={realName ? `${realName.realName} ${realName.idCardNumber.slice(0, 3)}****${realName.idCardNumber.slice(-3)}` : '未认证，部分功能受限'}
              onPress={() => { setRnName(''); setRnIdCard(''); setShowRealName(true); }}
              rightText={realName?.status === 'verified' ? '已认证' : realName?.status === 'pending' ? '审核中' : '去认证'}
            />
          </Card>
        )}

        {/* ====== 互动权限 ====== */}
        <Card style={styles.section}>
          <TouchableOpacity style={styles.sectionHeader} onPress={() => setShowInteraction(!showInteraction)} activeOpacity={0.7}>
            <Text style={styles.sectionTitle}>互动权限</Text>
            <Ionicons name={showInteraction ? 'chevron-up' : 'chevron-down'} size={18} color={Colors.textHint} />
          </TouchableOpacity>
          {showInteraction && (
            <View style={styles.interactionList}>
              {[
                { key: 'quickMessage' as const, label: '快捷消息', desc: '接收和发送快捷消息', icon: 'chatbubble-outline' },
                { key: 'vibration' as const, label: '振动提醒', desc: '收到消息或SOS时振动', icon: 'phone-portrait-outline' },
                { key: 'popupNotify' as const, label: '弹窗提醒', desc: 'SOS和重要通知弹窗', icon: 'notifications-outline' },
                { key: 'sosAlert' as const, label: 'SOS求救', desc: '启用SOS求救功能', icon: 'warning-outline' },
                { key: 'onlineStatus' as const, label: '在线状态可见', desc: '向联系人展示在线状态', icon: 'eye-outline' },
                { key: 'locationVisible' as const, label: '定位可见', desc: '允许授权用户查看位置', icon: 'location-outline' },
                { key: 'messageReceive' as const, label: '消息接收', desc: '接收所有类型消息', icon: 'mail-outline' },
              ].map(({ key, label, desc, icon }) => (
                <SwitchSetting key={key} label={label} description={desc} value={(settings as any)?.[key] ?? true} onValueChange={(v: boolean) => handleToggle(key, v)} icon={icon} />
              ))}
              <TouchableOpacity onPress={() => {
                Alert.alert('重置', '恢复默认互动权限？', [{ text: '取消', style: 'cancel' }, { text: '确定', onPress: async () => { const r = await resetInteractionSettings(); setSettings(r); } }]);
              }}>
                <Text style={{ fontSize: Typography.caption, color: Colors.primary, textAlign: 'center', paddingVertical: Spacing.sm }}>恢复默认设置</Text>
              </TouchableOpacity>
            </View>
          )}
        </Card>

        {/* ====== 兑换码（非管理员） ====== */}
        {!isAdmin && (
          <Card style={styles.section}>
            <SettingRow icon="pricetags-outline" color={Colors.friend} label="兑换码" desc="兑换奖品/绑定管理员" onPress={() => setShowRedeem(true)} />
            {binding && (
              <SettingRow icon="unlink-outline" color={Colors.lover} label="解绑管理员" onPress={() => {
                if (!user) return;
                Alert.alert('解绑', '确定解除管理员绑定？', [{ text: '取消', style: 'cancel' }, { text: '确认解绑', style: 'destructive', onPress: async () => { await unbindFromAdmin(user.id); setBinding(null); } }]);
              }} danger />
            )}
          </Card>
        )}

        {/* ====== 存储与数据 ====== */}
        <Card style={styles.section}>
          <SettingRow icon="server-outline" color={Colors.primary} label="存储空间" desc={`${formatBytes(storage.totalBytes)} · ${storage.totalKeys}项`} onPress={handleStorage} />
          <View style={styles.exportRow}>
            <SettingRow icon="download-outline" color={Colors.family} label="数据导出" desc="导出个人全部数据" onPress={handleExport} />
            <TouchableOpacity style={styles.exportFormatBtn} onPress={() => setShowExportPicker(!showExportPicker)}>
              <Text style={styles.exportFormatText}>{exportFormat.toUpperCase()}</Text>
              <Ionicons name="chevron-down" size={12} color={Colors.textHint} />
            </TouchableOpacity>
          </View>
          {showExportPicker && (
            <View style={styles.exportOptions}>
              {(['json', 'csv'] as const).map((f) => (
                <TouchableOpacity key={f} style={[styles.exportOption, exportFormat === f && styles.exportOptionActive]} onPress={() => { setExportFormat(f); setShowExportPicker(false); }}>
                  <Text style={[styles.exportOptionText, exportFormat === f && { color: Colors.primary, fontWeight: '600' }]}>{f === 'json' ? 'JSON 格式' : 'CSV 表格'}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </Card>

        {/* ====== 管理员清理面板 ====== */}
        {isAdmin && (
          <Card style={styles.section}>
            <Text style={styles.sectionTitle}>数据清理</Text>
            <TouchableOpacity style={styles.cleanupRow} onPress={async () => {
              Alert.alert('一键清理', '确定清理所有已注销30天以上的用户数据？此操作不可撤消。', [
                { text: '取消', style: 'cancel' },
                { text: '确认清理', style: 'destructive', onPress: async () => {
                  const r = await adminPurgeAllDeactivatedUsers();
                  Alert.alert('清理完成', `已永久删除${r.purged}个用户数据${r.errors.length > 0 ? `，${r.errors.length}个失败` : ''}`);
                  loadAll();
                }},
              ]);
            }}>
              <Ionicons name="trash-outline" size={20} color={Colors.lover} />
              <Text style={styles.cleanupText}>
                待清理: {cleanupStats.scheduledPurge}个已注销用户 ｜ 已注销: {cleanupStats.totalDeactivatedCodes}个
              </Text>
            </TouchableOpacity>
          </Card>
        )}

        {/* ====== 账号管理 ====== */}
        <Card style={styles.section}>
          <SettingRow icon="swap-horizontal-outline" color={Colors.primary} label="切换账号" desc="切换到其他已保存账号" onPress={handleSwitchAccount} />
          <SettingRow icon="trash-outline" color={Colors.lover} label="注销账号" desc="永久注销当前账号" onPress={() => { setDeactStep('confirm'); setShowDeact(true); }} danger />
        </Card>

        {/* ====== 退出 ====== */}
        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
          <Text style={styles.logoutText}>退出登录</Text>
        </TouchableOpacity>
        <Text style={styles.version}>ing 陪伴 v1.0.0</Text>
      </ScrollView>

      {/* ====== 兑换码弹窗 ====== */}
      <Modal visible={showRedeem} title="兑换码" onClose={() => setShowRedeem(false)} confirmText="兑 换" onConfirm={async () => {
        if (!user || !redeemInput.trim()) { Alert.alert('提示', '请输入兑换码'); return; }
        setRedeemLoading(true);
        const r = await redeemCode(user.id, user.username, user.phone, redeemInput.trim());
        setRedeemLoading(false);
        if (r.isAdminToken) { setShowRedeem(false); setBindToken(redeemInput.trim()); setShowBindModal(true); return; }
        if (r.message === '实物奖励需要填写收货地址') { setPendingRedeemCode(redeemInput.trim()); setShowRedeem(false); setShowAddressForm(true); return; }
        Alert.alert(r.success ? '兑换成功' : '兑换失败', r.message);
        if (r.success) setRedeemInput('');
      }}>
        <TextInput style={styles.rdInput} placeholder="请输入兑换码" placeholderTextColor={Colors.textHint} value={redeemInput} onChangeText={setRedeemInput} autoCapitalize="characters" />
      </Modal>

      {/* ====== 绑定弹窗 ====== */}
      <Modal visible={showBindModal} title="绑定管理员" onClose={() => setShowBindModal(false)} confirmText="确认绑定" onConfirm={async () => {
        if (!user) return;
        const r = await bindToAdmin(user.id, user.username, bindToken.trim());
        if (r.success) { setShowBindModal(false); const b = await getUserBinding(user.id); setBinding(b); Alert.alert('绑定成功', r.message); }
        else Alert.alert('绑定失败', r.message);
      }}>
        <TextInput style={styles.rdInput} placeholder="请输入管理员密令" placeholderTextColor={Colors.textHint} value={bindToken} onChangeText={setBindToken} secureTextEntry />
      </Modal>

      {/* ====== 地址弹窗 ====== */}
      <Modal visible={showAddressForm} title="收货地址" onClose={() => { setShowAddressForm(false); setPendingRedeemCode(''); }} confirmText="确认兑换" onConfirm={async () => {
        if (!user || !pendingRedeemCode || !address.name.trim() || !address.phone.trim() || !address.detail.trim()) { Alert.alert('提示', '请完整填写收货信息'); return; }
        if (!/^1[3-9]\d{9}$/.test(address.phone.trim())) { Alert.alert('提示', '手机号格式不正确'); return; }
        await saveUserAddress(user.id, address);
        const r = await redeemCode(user.id, user.username, user.phone, pendingRedeemCode, address);
        Alert.alert(r.success ? '兑换成功' : '失败', r.message);
        if (r.success) { setPendingRedeemCode(''); setShowAddressForm(false); }
      }}>
        {['name', 'phone', 'province', 'city', 'district', 'detail'].map((f) => (
          <TextInput key={f} style={styles.formInput} placeholder={{ name: '收件人', phone: '手机号', province: '省', city: '市', district: '区/县', detail: '详细地址' }[f]} placeholderTextColor={Colors.textHint} value={(address as any)[f]} onChangeText={(t) => setAddress({ ...address, [f]: t })} />
        ))}
      </Modal>

      {/* ====== 实名认证弹窗 ====== */}
      <Modal visible={showRealName} title="实名认证" onClose={() => setShowRealName(false)} confirmText="提交认证" onConfirm={handleSubmitRealName}>
        <Text style={{ fontSize: Typography.caption, color: Colors.textHint, marginBottom: Spacing.md }}>请填写真实姓名和身份证号，提交后由管理员审核</Text>
        <TextInput style={styles.formInput} placeholder="真实姓名" placeholderTextColor={Colors.textHint} value={rnName} onChangeText={setRnName} />
        <TextInput style={styles.formInput} placeholder="18位身份证号" placeholderTextColor={Colors.textHint} value={rnIdCard} onChangeText={setRnIdCard} maxLength={18} keyboardType="default" />
      </Modal>

      {/* ====== 注销弹窗 ====== */}
      <Modal visible={showDeact} title="注销账号" onClose={() => { setShowDeact(false); setDeactStep('confirm'); setDeactInput(''); }} confirmText={deactStep === 'confirm' ? '继续注销' : deactStep === 'apply' ? '获取验证码' : '确认注销'} onConfirm={deactStep === 'confirm' ? handleDeactConfirm : deactStep === 'apply' ? handleApplyDeact : handleVerifyDeact}>
        {deactStep === 'confirm' && (
          <Text style={{ fontSize: Typography.body, color: Colors.textSecondary, lineHeight: 22 }}>
            确定要注销账号吗？{'\n\n'}
            ⚠ 注销后将立即清理所有关联数据，30天后永久删除且无法恢复。{'\n\n'}
            点击下方按钮后，系统将生成验证码完成注销流程。
          </Text>
        )}
        {deactStep === 'apply' && <Text style={styles.deactHint}>点击"获取验证码"按钮开始注销流程</Text>}
        {deactStep === 'verify' && (
          <>
            <Text style={styles.deactCodeLabel}>验证码</Text>
            <Text style={styles.deactCode}>{deactCode}</Text>
            <TextInput style={styles.rdInput} placeholder="输入6位验证码" placeholderTextColor={Colors.textHint} keyboardType="number-pad" maxLength={6} value={deactInput} onChangeText={setDeactInput} />
          </>
        )}
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    backgroundColor: Colors.bgWhite, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  container: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.md, paddingBottom: Spacing.xl * 2 },
  section: { marginBottom: Spacing.sm },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  sectionTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.xs },
  interactionList: { marginTop: Spacing.md },
  // 行
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: Spacing.md, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider },
  rowIcon: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', marginRight: Spacing.md },
  rowInfo: { flex: 1 },
  rowLabel: { fontSize: Typography.body, color: Colors.textPrimary },
  rowDesc: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 1 },
  rowRight: { fontSize: Typography.caption, color: Colors.primary, marginRight: Spacing.sm },
  // 导出
  exportRow: { flexDirection: 'row', alignItems: 'center' },
  exportFormatBtn: { flexDirection: 'row', alignItems: 'center', gap: 2, padding: 4, borderRadius: 4, borderWidth: 1, borderColor: Colors.divider },
  exportFormatText: { fontSize: 10, fontWeight: '600', color: Colors.textSecondary },
  exportOptions: { flexDirection: 'row', gap: Spacing.sm, paddingVertical: Spacing.sm },
  exportOption: { paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, borderRadius: BorderRadius.input, borderWidth: 1, borderColor: Colors.divider },
  exportOptionActive: { borderColor: Colors.primary, backgroundColor: Colors.primary + '08' },
  exportOptionText: { fontSize: Typography.caption, color: Colors.textSecondary },
  // 管理员清理
  cleanupRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingVertical: Spacing.sm },
  cleanupText: { flex: 1, fontSize: Typography.caption, color: Colors.textSecondary },
  // 输入
  rdInput: { borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input, padding: Spacing.md, fontSize: Typography.subtitle, color: Colors.textPrimary, textAlign: 'center', letterSpacing: 4, fontFamily: 'monospace' },
  formInput: { borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input, padding: Spacing.md, fontSize: Typography.body, color: Colors.textPrimary, marginBottom: Spacing.sm },
  // 注销
  deactHint: { fontSize: Typography.body, color: Colors.textSecondary, lineHeight: 22 },
  deactCodeLabel: { fontSize: Typography.caption, color: Colors.textHint, marginBottom: 4 },
  deactCode: { fontSize: 28, fontWeight: '700', color: Colors.lover, textAlign: 'center', fontFamily: 'monospace', letterSpacing: 6, marginBottom: Spacing.md },
  // 退出
  logoutBtn: { alignItems: 'center', paddingVertical: Spacing.lg },
  logoutText: { fontSize: Typography.body, color: Colors.lover },
  version: { fontSize: Typography.caption, color: Colors.textHint, textAlign: 'center' },
});

export default SettingsScreen;
