/**
 * 管理员全局定位监控页面
 *
 * - 所有用户实时定位标记（从 GPS 持久化数据加载）
 * - 选中用户历史轨迹折线绘制
 * - 定位统计数据面板
 * - 用户搜索筛选
 *
 * 修复:
 * - 使用 getAllUsersBrief (GlobalStore) 获取用户列表，不依赖联系人
 * - 确保所有注册用户（不仅仅是联系人）都出现在地图上
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import MapViewBase, { Marker, Polyline, PROVIDER_GOOGLE } from 'react-native-maps';
const MapView = MapViewBase as React.ComponentType<any>;
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Input, Card } from '../components';
import { getAllUsersBrief } from '../services/admin';
import {
  getAllUsersLatestLocations,
  getTrajectory,
  getLocationStats,
} from '../services/gps';
import type { LocationData } from '../services/gps';

const { height: SCREEN_HEIGHT } = Dimensions.get('window');
const MAP_HEIGHT = SCREEN_HEIGHT * 0.4;

interface DisplayUser {
  userId: string;
  username: string;
  role: string;
  isOnline: boolean;
  location: LocationData | null;
  updatedAt: string;
}

const AdminLocationScreen: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const mountedRef = useRef(true);

  const [users, setUsers] = useState<DisplayUser[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [trajectory, setTrajectory] = useState<LocationData[]>([]);
  const [showingTrajectory, setShowingTrajectory] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [stats, setStats] = useState({ totalUsers: 0, activeTrackingUsers: 0, totalPoints: 0, last24hPoints: 0 });
  const mapRef = useRef<any>(null);

  // ====== 生命周期 ======

  useEffect(() => {
    mountedRef.current = true;
    loadAll();
    return () => { mountedRef.current = false; };
  }, []);

  const loadAll = async () => {
    try {
      const [allUsers, latestLocs, st] = await Promise.all([
        getAllUsersBrief(),          // 使用GlobalStore获取所有用户，不依赖联系人
        getAllUsersLatestLocations(),
        getLocationStats(),
      ]);

      if (!mountedRef.current) return;

      // 合并用户信息和定位数据
      const displayUsers: DisplayUser[] = allUsers.map((u) => {
        const loc = latestLocs.get(u.userId);
        return {
          userId: u.userId,
          username: u.username,
          role: u.role,
          isOnline: u.isOnline,
          location: loc ? {
            latitude: loc.latitude,
            longitude: loc.longitude,
            timestamp: loc.timestamp,
            address: loc.address,
            accuracy: loc.accuracy,
            speed: loc.speed,
          } : null,
          updatedAt: loc
            ? new Date(loc.timestamp).toISOString()
            : u.lastActive || new Date().toISOString(),
        };
      });

      setUsers(displayUsers);
      setStats(st);
    } catch (e) {
      console.warn('[管理员定位] 加载失败:', e);
    }
  };

  // ====== 查看历史轨迹 ======

  const handleSelectUser = useCallback(async (user: DisplayUser) => {
    setSelectedUserId(user.userId);
    setShowingTrajectory(false);

    if (!user.location) return;

    // 加载最近24小时轨迹
    const now = Date.now();
    const dayAgo = now - 24 * 60 * 60 * 1000;
    const points = await getTrajectory(user.userId, dayAgo, now, 10);

    if (!mountedRef.current) return;

    setTrajectory(points);
    setShowingTrajectory(true);

    // 缩放到轨迹范围
    if (mapRef.current && points.length > 0) {
      const lats = points.map((p) => p.latitude);
      const lngs = points.map((p) => p.longitude);
      const minLat = Math.min(...lats);
      const maxLat = Math.max(...lats);
      const minLng = Math.min(...lngs);
      const maxLng = Math.max(...lngs);

      mapRef.current.animateToRegion({
        latitude: (minLat + maxLat) / 2,
        longitude: (minLng + maxLng) / 2,
        latitudeDelta: Math.max(0.01, (maxLat - minLat) * 1.4),
        longitudeDelta: Math.max(0.01, (maxLng - minLng) * 1.4),
      }, 500);
    }
  }, []);

  // ====== 筛选 ======

  const filteredUsers = searchQuery.trim()
    ? users.filter(
        (u) =>
          u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
          u.userId.includes(searchQuery),
      )
    : users;

  const selectedUser = users.find((u) => u.userId === selectedUserId);

  // 默认地图中心
  const defaultCenter = users.find((u) => u.location)?.location || {
    latitude: 39.9042,
    longitude: 116.4074,
  };

  // ====== 角色色 ======

  const getRoleColor = (role: string) => {
    const colors: Record<string, string> = {
      family: '#5CB85C', friend: '#F0AD4E', lover: '#E74C3C', admin: '#7B68EE',
    };
    return colors[role] || Colors.primary;
  };

  // ====== 渲染 ======

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      {/* 头部 */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>全局定位监控</Text>
        <TouchableOpacity onPress={loadAll}>
          <Ionicons name="refresh" size={22} color={Colors.primary} />
        </TouchableOpacity>
      </View>

      {/* 地图 */}
      <View style={styles.mapContainer}>
        <MapView
          ref={mapRef}
          style={styles.map}
          initialRegion={{
            latitude: defaultCenter.latitude,
            longitude: defaultCenter.longitude,
            latitudeDelta: 0.05,
            longitudeDelta: 0.05,
          }}
        >
          {/* 所有用户位置标记 */}
          {users
            .filter((u) => u.location)
            .map((u) => (
              <Marker
                key={u.userId}
                coordinate={{
                  latitude: u.location!.latitude,
                  longitude: u.location!.longitude,
                }}
                title={u.username}
                description={u.location!.address || '未知地址'}
                pinColor={getRoleColor(u.role)}
                opacity={u.userId === selectedUserId ? 1 : u.isOnline ? 0.8 : 0.4}
              />
            ))}

          {/* 历史轨迹折线 */}
          {showingTrajectory && trajectory.length > 1 && (
            <Polyline
              coordinates={trajectory.map((p) => ({
                latitude: p.latitude,
                longitude: p.longitude,
              }))}
              strokeColor={Colors.primary}
              strokeWidth={3}
            />
          )}

          {/* 轨迹起止标记 */}
          {showingTrajectory && trajectory.length > 0 && (
            <>
              <Marker
                coordinate={{
                  latitude: trajectory[0].latitude,
                  longitude: trajectory[0].longitude,
                }}
                title="起点"
                pinColor={Colors.family}
              />
              {trajectory.length > 1 && (
                <Marker
                  coordinate={{
                    latitude: trajectory[trajectory.length - 1].latitude,
                    longitude: trajectory[trajectory.length - 1].longitude,
                  }}
                  title="最新"
                  pinColor={Colors.primary}
                />
              )}
            </>
          )}
        </MapView>
      </View>

      {/* 统计面板 */}
      <View style={styles.statsBar}>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{stats.totalUsers}</Text>
          <Text style={styles.statLabel}>有定位用户</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={[styles.statValue, { color: Colors.family }]}>
            {stats.activeTrackingUsers}
          </Text>
          <Text style={styles.statLabel}>活跃追踪</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>{stats.totalPoints}</Text>
          <Text style={styles.statLabel}>总定位点</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={[styles.statValue, { color: Colors.primary }]}>
            {stats.last24hPoints}
          </Text>
          <Text style={styles.statLabel}>24h上报</Text>
        </View>
      </View>

      {/* 用户列表 */}
      <ScrollView style={styles.listContainer}>
        <View style={styles.searchBox}>
          <Input
            placeholder="搜索用户名或ID"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        {filteredUsers.map((u) => (
          <TouchableOpacity
            key={u.userId}
            style={[styles.userRow, selectedUserId === u.userId && styles.userRowActive]}
            onPress={() => handleSelectUser(u)}
            activeOpacity={0.7}
          >
            <View
              style={[
                styles.statusDot,
                { backgroundColor: u.location ? getRoleColor(u.role) : Colors.textHint },
              ]}
            />
            <View style={styles.userInfo}>
              <Text style={styles.userName}>{u.username}</Text>
              <Text style={styles.userMeta}>
                {u.role} · {u.location ? '有定位' : '无数据'}
                {u.location?.address ? ` · ${u.location.address}` : ''}
              </Text>
            </View>
            <View style={styles.userLocInfo}>
              <Text style={styles.locTime}>
                {u.location
                  ? formatTime(u.location.timestamp)
                  : '暂无'}
              </Text>
              <Ionicons name="chevron-forward" size={14} color={Colors.textHint} />
            </View>
          </TouchableOpacity>
        ))}

        {filteredUsers.length === 0 && (
          <View style={styles.empty}>
            <Ionicons name="location-outline" size={32} color={Colors.textHint} />
            <Text style={styles.emptyText}>暂无用户定位数据</Text>
          </View>
        )}
      </ScrollView>

      {/* 轨迹详情面板 */}
      {showingTrajectory && selectedUser && trajectory.length > 0 && (
        <View style={styles.trajectoryPanel}>
          <View style={styles.trajectoryHeader}>
            <Text style={styles.trajectoryTitle}>
              {selectedUser.username} · 24小时轨迹
              <Text style={styles.trajectoryCount}> ({trajectory.length}点)</Text>
            </Text>
            <TouchableOpacity
              onPress={() => { setShowingTrajectory(false); setTrajectory([]); }}
            >
              <Ionicons name="close" size={20} color={Colors.textHint} />
            </TouchableOpacity>
          </View>
          <ScrollView style={styles.trajectoryList} horizontal showsHorizontalScrollIndicator={false}>
            {trajectory.slice(0, 20).map((p, i) => (
              <View key={`${p.timestamp}_${i}`} style={styles.trajectoryPoint}>
                <Text style={styles.pointIndex}>#{i + 1}</Text>
                <Text style={styles.pointTime}>
                  {new Date(p.timestamp).toLocaleTimeString('zh-CN')}
                </Text>
                <Text style={styles.pointCoord}>
                  {p.latitude.toFixed(4)}, {p.longitude.toFixed(4)}
                </Text>
                {p.address && (
                  <Text style={styles.pointAddr} numberOfLines={1}>
                    {p.address}
                  </Text>
                )}
              </View>
            ))}
          </ScrollView>
        </View>
      )}
    </SafeAreaView>
  );
};

function formatTime(ts: number): string {
  const diff = Date.now() - ts;
  if (diff < 60000) return '刚刚';
  if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}小时前`;
  return new Date(ts).toLocaleDateString('zh-CN');
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  mapContainer: { height: MAP_HEIGHT },
  map: { flex: 1 },
  statsBar: {
    flexDirection: 'row', backgroundColor: Colors.bgWhite,
    paddingVertical: Spacing.sm, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  statItem: { flex: 1, alignItems: 'center' },
  statValue: { fontSize: 18, fontWeight: '700', color: Colors.textPrimary },
  statLabel: { fontSize: 10, color: Colors.textHint, marginTop: 1 },
  listContainer: { flex: 1 },
  searchBox: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.sm, backgroundColor: Colors.bgWhite },
  userRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    backgroundColor: Colors.bgWhite, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  userRowActive: { backgroundColor: '#F0F4FF' },
  statusDot: { width: 10, height: 10, borderRadius: 5 },
  userInfo: { flex: 1 },
  userName: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  userMeta: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  userLocInfo: { alignItems: 'flex-end' },
  locTime: { fontSize: Typography.caption, color: Colors.textHint },
  empty: { alignItems: 'center', paddingVertical: Spacing.xl * 2, gap: Spacing.sm },
  emptyText: { fontSize: Typography.body, color: Colors.textHint },
  trajectoryPanel: {
    backgroundColor: Colors.bgWhite, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider,
    padding: Spacing.lg, maxHeight: 150,
  },
  trajectoryHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.sm,
  },
  trajectoryTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  trajectoryCount: { fontSize: Typography.caption, color: Colors.textHint, fontWeight: '400' },
  trajectoryList: { flexDirection: 'row' },
  trajectoryPoint: {
    backgroundColor: Colors.bgPrimary, borderRadius: BorderRadius.card,
    padding: Spacing.sm, marginRight: Spacing.sm, minWidth: 110,
  },
  pointIndex: { fontSize: Typography.caption, fontWeight: '600', color: Colors.primary },
  pointTime: { fontSize: Typography.caption, color: Colors.textSecondary, marginTop: 2 },
  pointCoord: { fontSize: 10, color: Colors.textHint, marginTop: 1 },
  pointAddr: { fontSize: 10, color: Colors.textHint, marginTop: 1, maxWidth: 100 },
});

export default AdminLocationScreen;
