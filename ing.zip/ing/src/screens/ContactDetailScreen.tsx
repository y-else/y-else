/**
 * 联系人详情
 * 主页/空间/发消息/一键拨号/查看定位/设置备注/拉黑/在线状态/信息脱敏
 */

import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Linking,
  TextInput,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Button, Card, StatusBadge, QuickMessageSheet } from '../components';
import {
  setRemark,
  blockUser,
  unblockUser,
  togglePin as togglePinApi,
} from '../services/contacts';
import { getCurrentLocation } from '../services/gps';
import type { Contact, QuickMessage } from '../types';

interface ContactDetailScreenProps {
  contact: Contact;
  onBack: () => void;
  onNavigateDiary: (contact: Contact) => void;
}

const ContactDetailScreen: React.FC<ContactDetailScreenProps> = ({
  contact: initialContact,
  onBack,
  onNavigateDiary,
}) => {
  const [contact, setContact] = useState<Contact>(initialContact);
  const [showQuickMessages, setShowQuickMessages] = useState(false);
  const [showRemarkInput, setShowRemarkInput] = useState(false);
  const [remarkText, setRemarkText] = useState(contact.remark || '');
  const [sentMsg, setSentMsg] = useState('');

  // 脱敏显示规则
  const maskPhone = (raw: string) => {
    if (raw.length === 11) return raw.slice(0, 3) + '****' + raw.slice(7);
    return raw;
  };

  // 一键拨号
  const handleCall = useCallback(() => {
    if (contact.isBlocked) {
      Alert.alert('提示', '已拉黑该联系人，无法拨号');
      return;
    }
    Linking.openURL(`tel:${contact.rawPhone}`);
  }, [contact]);

  // 查看定位
  const handleViewLocation = useCallback(async () => {
    if (contact.isBlocked && contact.lastKnownLocation) {
      // 拉黑后显示冻结位置
      Alert.alert(
        '定位信息（已冻结）',
        `拉黑前最后位置：\n${contact.lastKnownLocation.address || '未知地址'}\n\n坐标：${contact.lastKnownLocation.latitude}, ${contact.lastKnownLocation.longitude}`,
      );
      return;
    }
    const loc = await getCurrentLocation();
    if (loc) {
      Alert.alert(
        '对方当前位置',
        `${loc.address || '未知地址'}\n\n坐标：${loc.latitude.toFixed(6)}, ${loc.longitude.toFixed(6)}\n更新时间：${new Date(loc.timestamp).toLocaleString('zh-CN')}`,
      );
    }
  }, [contact]);

  // 设置备注
  const handleSaveRemark = async () => {
    await setRemark(contact.userId, remarkText);
    setContact({ ...contact, remark: remarkText || null });
    setShowRemarkInput(false);
  };

  // 拉黑/取消拉黑
  const handleToggleBlock = () => {
    if (contact.isBlocked) {
      Alert.alert('取消拉黑', `确定取消拉黑 ${contact.username}？`, [
        { text: '取消', style: 'cancel' },
        {
          text: '确定',
          onPress: async () => {
            await unblockUser('current_user', contact.userId);
            setContact({ ...contact, isBlocked: false, blockedAt: null, lastKnownLocation: null });
            Alert.alert('已取消拉黑');
          },
        },
      ]);
    } else {
      Alert.alert(
        '拉黑联系人',
        `拉黑后：\n- 对方无法查看你的主页/空间/动态\n- 对方定位将冻结在当前位置\n- 可随时取消拉黑\n\n确定拉黑 ${contact.username}？`,
        [
          { text: '取消', style: 'cancel' },
          {
            text: '拉黑',
            style: 'destructive',
            onPress: async () => {
              const loc = await getCurrentLocation();
              const record = await blockUser('current_user', contact.userId, '用户主动拉黑');
              setContact({
                ...contact,
                isBlocked: true,
                blockedAt: new Date().toISOString(),
                lastKnownLocation: record.frozenLocation
                  ? { ...record.frozenLocation, updatedAt: new Date().toISOString() }
                  : null,
              });
              Alert.alert('已拉黑', '该联系人已被移入黑名单');
            },
          },
        ],
      );
    }
  };

  // 置顶切换
  const handleTogglePin = async () => {
    await togglePinApi(contact.userId);
    setContact({ ...contact, isPinned: !contact.isPinned });
  };

  // 快捷消息已发送
  const handleQuickMessageSent = (msg: QuickMessage) => {
    setShowQuickMessages(false);
    setSentMsg(msg.text);
    setTimeout(() => setSentMsg(''), 2000);
  };

  // 跳转专属日记
  const handleDiary = () => {
    if (contact.isBlocked) {
      Alert.alert('提示', '已拉黑该联系人，无法查看日记');
      return;
    }
    onNavigateDiary(contact);
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.container}>
        {/* 返回按钮 */}
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>

        {/* 头像区 */}
        <View style={styles.profileHeader}>
          <View style={styles.avatarLarge}>
            <Ionicons name="person" size={48} color={contact.isBlocked ? Colors.textHint : Colors.primary} />
          </View>
          <View style={styles.nameRow}>
            <Text style={[styles.name, contact.isBlocked && styles.blockedName]}>
              {contact.remark || contact.username}
            </Text>
            <StatusBadge status={contact.isBlocked ? 'offline' : contact.status} size={12} />
          </View>
          {contact.remark && (
            <Text style={styles.username}>原名：{contact.username}</Text>
          )}
          <Text style={styles.phone}>{contact.phone}</Text>
          {contact.isBlocked && (
            <View style={styles.blockedBanner}>
              <Ionicons name="ban" size={14} color="#999" />
              <Text style={styles.blockedText}>已拉黑 — 限制查看主页/空间/动态</Text>
            </View>
          )}
          {sentMsg ? (
            <View style={styles.sentToast}>
              <Ionicons name="checkmark-circle" size={16} color={Colors.family} />
              <Text style={styles.sentText}>已发送：{sentMsg}</Text>
            </View>
          ) : null}
        </View>

        {/* 操作按钮 */}
        <View style={styles.actionRow}>
          {[
            { icon: 'chatbubble-outline', label: '发消息', onPress: () => setShowQuickMessages(true), disabled: contact.isBlocked },
            { icon: 'call-outline', label: '拨号', onPress: handleCall, disabled: contact.isBlocked },
            { icon: 'location-outline', label: '定位', onPress: handleViewLocation, disabled: false },
            { icon: 'book-outline', label: '日记', onPress: handleDiary, disabled: contact.isBlocked },
          ].map((action) => (
            <TouchableOpacity
              key={action.label}
              style={[styles.actionItem, action.disabled && styles.actionDisabled]}
              onPress={action.onPress}
              disabled={action.disabled}
              activeOpacity={0.7}
            >
              <View style={styles.actionIcon}>
                <Ionicons
                  name={action.icon as React.ComponentProps<typeof Ionicons>['name']}
                  size={22}
                  color={action.disabled ? Colors.textHint : Colors.primary}
                />
              </View>
              <Text style={[styles.actionLabel, action.disabled && styles.disabledText]}>
                {action.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* 信息卡片 */}
        <Card style={styles.infoCard}>
          <Text style={styles.cardTitle}>联系人信息</Text>

          {/* 备注 */}
          <TouchableOpacity
            style={styles.infoRow}
            onPress={() => { setRemarkText(contact.remark || ''); setShowRemarkInput(!showRemarkInput); }}
          >
            <Text style={styles.infoLabel}>备注</Text>
            <Text style={styles.infoValue}>{contact.remark || '未设置'}</Text>
            <Ionicons name="chevron-forward" size={14} color={Colors.textHint} />
          </TouchableOpacity>

          {showRemarkInput && (
            <View style={styles.remarkInput}>
              <TextInput
                style={styles.remarkField}
                value={remarkText}
                onChangeText={setRemarkText}
                placeholder="输入备注（仅自己可见）"
                placeholderTextColor={Colors.textHint}
              />
              <View style={styles.remarkActions}>
                <TouchableOpacity onPress={() => setShowRemarkInput(false)}>
                  <Text style={styles.remarkCancel}>取消</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={handleSaveRemark}>
                  <Text style={styles.remarkSave}>保存</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>手机号</Text>
            <Text style={styles.infoValue}>{contact.phone}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>在线状态</Text>
            <View style={styles.statusRow}>
              <StatusBadge status={contact.isBlocked ? 'offline' : contact.status} size={8} />
              <Text style={styles.infoValue}>
                {contact.isBlocked ? '离线' : contact.status === 'online' ? '在线' : contact.status === 'busy' ? '忙碌' : '离线'}
              </Text>
            </View>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>最后在线</Text>
            <Text style={styles.infoValue}>
              {new Date(contact.lastOnlineAt).toLocaleString('zh-CN')}
            </Text>
          </View>
        </Card>

        {/* 设置 */}
        <Card style={styles.infoCard}>
          <Text style={styles.cardTitle}>设置</Text>
          <TouchableOpacity style={styles.infoRow} onPress={handleTogglePin}>
            <Text style={styles.infoLabel}>置顶</Text>
            <Text style={styles.infoValue}>{contact.isPinned ? '已置顶' : '未置顶'}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.infoRow, styles.dangerRow]} onPress={handleToggleBlock}>
            <Text style={[styles.infoLabel, { color: Colors.lover }]}>
              {contact.isBlocked ? '取消拉黑' : '拉黑'}
            </Text>
            <Text style={styles.infoValue}>
              {contact.isBlocked ? '点击取消拉黑' : '禁止查看主页/空间/动态'}
            </Text>
          </TouchableOpacity>
        </Card>
      </ScrollView>

      {/* 快捷消息面板 */}
      <QuickMessageSheet
        visible={showQuickMessages}
        targetUserId={contact.userId}
        targetUsername={contact.username}
        onClose={() => setShowQuickMessages(false)}
        onSent={handleQuickMessageSent}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  container: { paddingBottom: Spacing.xl * 2 },
  backBtn: { padding: Spacing.lg },
  // 头像区
  profileHeader: { alignItems: 'center', paddingBottom: Spacing.xl },
  avatarLarge: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: Colors.bgPrimary, alignItems: 'center', justifyContent: 'center',
    marginBottom: Spacing.lg,
  },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, marginBottom: Spacing.xs },
  name: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  blockedName: { color: Colors.textHint },
  username: { fontSize: Typography.caption, color: Colors.textHint, marginBottom: Spacing.xs },
  phone: { fontSize: Typography.body, color: Colors.textSecondary },
  blockedBanner: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.xs,
    marginTop: Spacing.md, backgroundColor: '#F5F5F5',
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, borderRadius: 4,
  },
  blockedText: { fontSize: Typography.caption, color: '#999' },
  sentToast: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.xs,
    marginTop: Spacing.md, backgroundColor: '#E8F5E9',
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, borderRadius: 4,
  },
  sentText: { fontSize: Typography.caption, color: Colors.family },
  // 操作按钮
  actionRow: { flexDirection: 'row', justifyContent: 'space-around', paddingHorizontal: Spacing.lg, marginBottom: Spacing.lg },
  actionItem: { alignItems: 'center', gap: Spacing.xs },
  actionDisabled: { opacity: 0.4 },
  actionIcon: {
    width: 48, height: 48, borderRadius: 24,
    backgroundColor: '#E8F4FD', alignItems: 'center', justifyContent: 'center',
  },
  actionLabel: { fontSize: Typography.caption, color: Colors.textSecondary },
  disabledText: { color: Colors.textHint },
  // 信息卡片
  infoCard: { marginHorizontal: Spacing.lg, marginBottom: Spacing.md },
  cardTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.md },
  infoRow: {
    flexDirection: 'row', alignItems: 'center',
    paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  infoLabel: { width: 80, fontSize: Typography.body, color: Colors.textSecondary },
  infoValue: { flex: 1, fontSize: Typography.body, color: Colors.textPrimary },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, flex: 1 },
  dangerRow: { borderBottomWidth: 0 },
  // 备注输入
  remarkInput: {
    paddingVertical: Spacing.sm, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  remarkField: {
    borderWidth: 1, borderColor: Colors.primary, borderRadius: BorderRadius.input,
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, fontSize: Typography.body, color: Colors.textPrimary,
    marginBottom: Spacing.sm,
  },
  remarkActions: { flexDirection: 'row', justifyContent: 'flex-end', gap: Spacing.lg },
  remarkCancel: { fontSize: Typography.body, color: Colors.textHint },
  remarkSave: { fontSize: Typography.body, color: Colors.primary, fontWeight: '600' },
});

export default ContactDetailScreen;
