/**
 * 通讯录页面（完整版）
 *
 * 功能：
 * - 家人/朋友/恋人/已拉黑 四分组
 * - 分组折叠/展开（本地缓存记忆）
 * - 组内排序：置顶优先 > 最近联系时间降序 > 姓名首字母A-Z
 * - 顶部全局模糊搜索（300ms防抖 + 竞态保护）
 * - 搜索匹配：备注/用户名/手机号
 * - 右侧A-Z+#字母索引栏，点击精确跳转
 * - 批量管理：长按进入多选，批量置顶/删除
 * - 批量模式自动隐藏字母索引
 * - 快捷发消息（QuickMessageSheet）
 * - 一键拨号（Linking）
 * - 编辑备注（Modal）
 * - 拉黑/取消拉黑
 * - 拉黑拦截导航
 * - 空白无联系人空状态页
 * - 手机号脱敏保障
 * - SectionList 性能优化（windowSize/maxToRenderPerBatch/getItemLayout）
 */

import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  View, Text, StyleSheet, SectionList, TouchableOpacity, Alert,
  RefreshControl, TextInput, Modal as RNModal, Pressable,
  Linking, ActivityIndicator, Platform,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { SearchBar, ContactListItem, QuickMessageSheet, StatusBadge } from '../components';
import {
  getContacts, searchContacts, togglePin as togglePinApi,
  deleteContacts, setRemark, blockUser, unblockUser, sortContacts,
} from '../services/contacts';
import type { Contact, ContactGroup, QuickMessage } from '../types';
import type { SectionListData } from 'react-native';

// ====== 常量 ======

interface ContactSection {
  title: string;
  icon: string;
  color: string;
  key: ContactGroup;
  data: Contact[];
  totalCount: number;
  isCollapsed: boolean;
}

const COLLAPSED_GROUPS_KEY = '@ing_collapsed_groups';
const ITEM_HEIGHT = 64; // ContactListItem 近似高度

const GROUP_CONFIG: { key: ContactGroup; title: string; icon: string; color: string }[] = [
  { key: 'family', title: '家人', icon: 'home', color: Colors.family },
  { key: 'friend', title: '朋友', icon: 'people', color: Colors.friend },
  { key: 'lover', title: '恋人', icon: 'heart', color: Colors.lover },
  { key: 'blocked', title: '已拉黑', icon: 'ban', color: '#999999' },
];

const LETTERS = '#ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

/** 获取名称首字母分组 */
function getFirstLetter(name: string): string {
  if (!name) return '#';
  const first = name.charAt(0).toUpperCase();
  if (/[A-Z]/.test(first)) return first;
  return '#';
}

// ====== Props ======

interface ContactsScreenProps {
  onNavigateDetail: (contact: Contact) => void;
  onNavigateSpace?: (contact: Contact) => void;
  onNavigateLocation?: (contact: Contact) => void;
}

// ====== 组件 ======

const ContactsScreen: React.FC<ContactsScreenProps> = ({
  onNavigateDetail,
  onNavigateSpace,
  onNavigateLocation,
}) => {
  const [allContacts, setAllContacts] = useState<Contact[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<Contact[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [collapsedGroups, setCollapsedGroups] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);

  // 批量管理
  const [selectMode, setSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [batchLoading, setBatchLoading] = useState(false);

  // 快捷消息
  const [quickMsgVisible, setQuickMsgVisible] = useState(false);
  const [quickMsgTarget, setQuickMsgTarget] = useState<Contact | null>(null);

  // 编辑备注
  const [remarkVisible, setRemarkVisible] = useState(false);
  const [remarkTarget, setRemarkTarget] = useState<Contact | null>(null);
  const [remarkText, setRemarkText] = useState('');
  const [remarkSaving, setRemarkSaving] = useState(false);

  const sectionListRef = useRef<SectionList<Contact, ContactSection>>(null);
  const searchIdRef = useRef(0);        // 竞态保护
  const mountedRef = useRef(true);      // 内存泄漏保护

  // ====== 生命周期 ======

  useEffect(() => {
    mountedRef.current = true;
    loadAll();
    return () => { mountedRef.current = false; };
  }, []);

  const loadAll = useCallback(async () => {
    try {
      const [contacts, cached] = await Promise.all([
        getContacts(),
        AsyncStorage.getItem(COLLAPSED_GROUPS_KEY).catch(() => null),
      ]);
      if (!mountedRef.current) return;
      setAllContacts(contacts);
      if (cached) setCollapsedGroups(new Set(JSON.parse(cached)));
    } catch (e) {
      console.warn('[通讯录] 加载失败:', e);
    } finally {
      if (mountedRef.current) setLoading(false);
    }
  }, []);

  const saveCollapsed = useCallback(async (set: Set<string>) => {
    try {
      await AsyncStorage.setItem(COLLAPSED_GROUPS_KEY, JSON.stringify([...set]));
    } catch (e) { /* 静默 */ }
  }, []);

  // ====== 分组折叠 ======

  const toggleGroupCollapse = useCallback(async (key: string) => {
    setCollapsedGroups((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      saveCollapsed(next);
      return next;
    });
  }, [saveCollapsed]);

  // ====== 构建sections（排序：置顶 > 最近联系时间 > 首字母） ======

  const sections = useMemo((): ContactSection[] => {
    const source = searching ? searchResults : allContacts;

    return GROUP_CONFIG.map((g) => {
      const groupData = source.filter((c) => c.group === g.key);
      const sorted = searching ? groupData : sortContacts(groupData);
      const isCollapsed = collapsedGroups.has(g.key);

      return {
        title: g.title,
        icon: g.icon,
        color: g.color,
        key: g.key,
        data: isCollapsed ? [] : sorted,
        totalCount: sorted.length,
        isCollapsed,
      };
    });
  }, [allContacts, searchResults, searching, collapsedGroups]);

  // ====== 字母索引映射表（精确跳转） ======

  const letterIndexMap = useMemo(() => {
    // letter → { sectionIndex, itemIndex }
    const map: Record<string, { sectionIndex: number; itemIndex: number } | null> = {};

    for (const letter of LETTERS) {
      map[letter] = null;
      for (let si = 0; si < sections.length; si++) {
        const section = sections[si];
        if (section.data.length === 0) continue;
        for (let ii = 0; ii < section.data.length; ii++) {
          const contact = section.data[ii];
          const fl = getFirstLetter(contact.remark || contact.username);
          if (fl === letter || (letter === '#' && fl === '#')) {
            map[letter] = { sectionIndex: si, itemIndex: ii };
            break;
          }
        }
        if (map[letter]) break;
      }
    }
    return map;
  }, [sections]);

  // ====== 搜索（300ms防抖在SearchBar内，此处加竞态保护） ======

  const handleSearch = useCallback(async (query: string) => {
    const id = ++searchIdRef.current;
    setSearching(true);
    try {
      const results = await searchContacts(query);
      if (!mountedRef.current || id !== searchIdRef.current) return; // 竞态丢弃
      setSearchResults(results);
    } catch {
      if (mountedRef.current && id === searchIdRef.current) {
        setSearchResults([]);
      }
    }
  }, []);

  const handleClearSearch = useCallback(() => {
    searchIdRef.current++;
    setSearching(false);
    setSearchResults([]);
  }, []);

  // ====== 刷新 ======

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadAll();
    setRefreshing(false);
  }, [loadAll]);

  // ====== 联系人交互 ======

  const handlePress = useCallback(
    (contact: Contact) => {
      if (selectMode) {
        // 批量模式：切换选中
        setSelectedIds((prev) => {
          const next = new Set(prev);
          if (next.has(contact.userId)) {
            next.delete(contact.userId);
            if (next.size === 0) setSelectMode(false);
          } else {
            next.add(contact.userId);
          }
          return next;
        });
      } else {
        // 拉黑拦截
        if (contact.isBlocked) {
          Alert.alert('提示', '该用户已被您拉黑，无法查看详情', [{ text: '确定' }]);
          return;
        }
        onNavigateDetail(contact);
      }
    },
    [selectMode, onNavigateDetail],
  );

  const handleLongPress = useCallback(
    (contact: Contact) => {
      if (!selectMode) {
        setSelectMode(true);
        setSelectedIds(new Set([contact.userId]));
      }
    },
    [selectMode],
  );

  // ====== 批量操作 ======

  const handleBatchDelete = useCallback(() => {
    if (selectedIds.size === 0) return;
    Alert.alert('批量删除', `确定删除 ${selectedIds.size} 个联系人？`, [
      { text: '取消', style: 'cancel' },
      {
        text: '删除', style: 'destructive',
        onPress: async () => {
          setBatchLoading(true);
          try {
            const { deleted } = await deleteContacts([...selectedIds]);
            if (!mountedRef.current) return;
            Alert.alert('完成', `已删除 ${deleted} 个联系人`);
            setSelectMode(false);
            setSelectedIds(new Set());
            await loadAll();
          } catch {
            Alert.alert('错误', '删除失败，请重试');
          } finally {
            if (mountedRef.current) setBatchLoading(false);
          }
        },
      },
    ]);
  }, [selectedIds, loadAll]);

  const handleBatchPin = useCallback(async () => {
    if (selectedIds.size === 0) return;
    setBatchLoading(true);
    try {
      for (const id of selectedIds) {
        await togglePinApi(id);
      }
      if (!mountedRef.current) return;
      setSelectMode(false);
      setSelectedIds(new Set());
      await loadAll();
    } catch {
      Alert.alert('错误', '操作失败，请重试');
    } finally {
      if (mountedRef.current) setBatchLoading(false);
    }
  }, [selectedIds, loadAll]);

  const handleExitSelectMode = useCallback(() => {
    setSelectMode(false);
    setSelectedIds(new Set());
  }, []);

  // ====== 字母索引点击 ======

  const handleLetterPress = useCallback(
    (letter: string) => {
      const target = letterIndexMap[letter];
      if (!target || !sectionListRef.current) return;

      // 安全跳转：try-catch 防止无效 index 导致原生崩溃
      try {
        sectionListRef.current.scrollToLocation({
          sectionIndex: target.sectionIndex,
          itemIndex: target.itemIndex,
          animated: true,
          viewPosition: 0,
        });
      } catch {
        // 降级：直接滚动到对应section顶部
        try {
          sectionListRef.current.scrollToLocation({
            sectionIndex: target.sectionIndex,
            itemIndex: 0,
            animated: true,
            viewPosition: 0,
          });
        } catch { /* 静默 */ }
      }
    },
    [letterIndexMap],
  );

  // ====== 拨号 ======

  const handleDial = useCallback((contact: Contact) => {
    const phone = contact.rawPhone || contact.phone.replace(/\*/g, '');
    if (!phone || phone.length < 5) {
      Alert.alert('提示', '无法获取该联系人的手机号');
      return;
    }
    Linking.openURL(`tel:${phone}`).catch(() => {
      Alert.alert('提示', '拨号失败，请检查设备是否支持通话功能');
    });
  }, []);

  // ====== 快捷消息 ======

  const handleOpenQuickMsg = useCallback((contact: Contact) => {
    if (contact.isBlocked) {
      Alert.alert('提示', '该用户已被您拉黑，无法发送消息');
      return;
    }
    setQuickMsgTarget(contact);
    setQuickMsgVisible(true);
  }, []);

  const handleQuickMsgSent = useCallback((msg: QuickMessage) => {
    setQuickMsgVisible(false);
    setQuickMsgTarget(null);
    // 刷新列表以更新最近联系时间
    loadAll();
  }, [loadAll]);

  // ====== 编辑备注 ======

  const handleOpenRemark = useCallback((contact: Contact) => {
    setRemarkTarget(contact);
    setRemarkText(contact.remark || '');
    setRemarkVisible(true);
  }, []);

  const handleSaveRemark = useCallback(async () => {
    if (!remarkTarget) return;
    setRemarkSaving(true);
    try {
      await setRemark(remarkTarget.userId, remarkText);
      if (!mountedRef.current) return;
      setRemarkVisible(false);
      setRemarkTarget(null);
      await loadAll();
    } catch {
      Alert.alert('错误', '保存备注失败');
    } finally {
      if (mountedRef.current) setRemarkSaving(false);
    }
  }, [remarkTarget, remarkText, loadAll]);

  // ====== 拉黑/取消拉黑 ======

  const handleBlock = useCallback((contact: Contact) => {
    Alert.alert(
      contact.isBlocked ? '取消拉黑' : '拉黑联系人',
      contact.isBlocked
        ? `确定将「${contact.remark || contact.username}」移出黑名单？`
        : `拉黑后您将无法查看对方主页/空间/动态，对方GPS将冻结在当前位置。\n\n确定拉黑「${contact.remark || contact.username}」？`,
      [
        { text: '取消', style: 'cancel' },
        {
          text: contact.isBlocked ? '取消拉黑' : '拉黑',
          style: 'destructive',
          onPress: async () => {
            try {
              if (contact.isBlocked) {
                await unblockUser('self', contact.userId);
              } else {
                await blockUser('self', contact.userId);
              }
              if (!mountedRef.current) return;
              await loadAll();
            } catch {
              Alert.alert('错误', '操作失败，请重试');
            }
          },
        },
      ],
    );
  }, [loadAll]);

  // ====== 渲染分组头 ======

  const renderSectionHeader = useCallback(
    ({ section }: { section: ContactSection }) => (
      <TouchableOpacity
        style={styles.sectionHeader}
        activeOpacity={0.7}
        onPress={() => toggleGroupCollapse(section.key)}
      >
        <Ionicons
          name={section.isCollapsed ? 'chevron-forward' : 'chevron-down'}
          size={14}
          color={Colors.textHint}
          style={{ marginRight: Spacing.xs }}
        />
        <Ionicons name={section.icon as any} size={16} color={section.color} />
        <Text style={[styles.sectionTitle, { color: section.color }]}>{section.title}</Text>
        <Text style={styles.sectionCount}>
          {section.isCollapsed ? `${section.totalCount}` : `${section.data.length}`}
        </Text>
      </TouchableOpacity>
    ),
    [toggleGroupCollapse],
  );

  // ====== 渲染列表项 ======

  const renderItem = useCallback(
    ({ item }: { item: Contact }) => (
      <ContactListItem
        contact={item}
        onPress={handlePress}
        onLongPress={handleLongPress}
        isSelectMode={selectMode}
        isSelected={selectedIds.has(item.userId)}
        showGroupTag
      />
    ),
    [handlePress, handleLongPress, selectMode, selectedIds],
  );

  const keyExtractor = useCallback((item: Contact) => item.userId, []);

  // ====== getItemLayout 性能优化 ======

  const getItemLayout = useCallback(
    (_data: SectionListData<Contact, ContactSection>[] | null, index: number) => ({
      length: ITEM_HEIGHT,
      offset: ITEM_HEIGHT * index,
      index,
    }),
    [],
  );

  // ====== 加载状态 ======

  if (loading) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.primary} />
          <Text style={styles.loadingText}>加载通讯录...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const totalContacts = allContacts.filter((c) => !c.isBlocked).length;

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.container}>
        {/* 顶部栏 */}
        <View style={styles.header}>
          {selectMode ? (
            <View style={styles.selectHeader}>
              <TouchableOpacity onPress={handleExitSelectMode}>
                <Text style={styles.cancelText}>取消</Text>
              </TouchableOpacity>
              <Text style={styles.selectCount}>已选 {selectedIds.size} 项</Text>
              <View style={styles.selectActions}>
                {batchLoading ? (
                  <ActivityIndicator size="small" color={Colors.primary} />
                ) : (
                  <>
                    <TouchableOpacity onPress={handleBatchPin} style={styles.batchBtn}>
                      <Ionicons name="push" size={18} color={Colors.primary} />
                    </TouchableOpacity>
                    <TouchableOpacity onPress={handleBatchDelete} style={styles.batchBtn}>
                      <Ionicons name="trash-outline" size={18} color={Colors.lover} />
                    </TouchableOpacity>
                  </>
                )}
              </View>
            </View>
          ) : (
            <>
              <Text style={styles.headerTitle}>通讯录</Text>
              {totalContacts > 0 && (
                <TouchableOpacity onPress={() => setSelectMode(true)}>
                  <Text style={styles.manageText}>管理</Text>
                </TouchableOpacity>
              )}
            </>
          )}
        </View>

        {/* 搜索栏 */}
        <View style={styles.searchContainer}>
          <SearchBar
            placeholder="搜索备注/用户名/手机号"
            onSearch={handleSearch}
            onClear={handleClearSearch}
          />
        </View>

        {/* 主体内容 */}
        <View style={styles.bodyContainer}>
          <SectionList<Contact, ContactSection>
            ref={sectionListRef}
            sections={sections}
            keyExtractor={keyExtractor}
            renderItem={renderItem}
            renderSectionHeader={renderSectionHeader}
            getItemLayout={getItemLayout}
            windowSize={10}
            maxToRenderPerBatch={15}
            initialNumToRender={20}
            removeClippedSubviews={true}
            refreshControl={
              <RefreshControl
                refreshing={refreshing}
                onRefresh={handleRefresh}
                colors={[Colors.primary]}
              />
            }
            stickySectionHeadersEnabled
            onScrollToIndexFailed={(info) => {
              // 降级：延迟重试
              setTimeout(() => {
                if (sectionListRef.current) {
                  sectionListRef.current.scrollToLocation({
                    sectionIndex: info.index,
                    itemIndex: 0,
                    animated: true,
                    viewPosition: 0,
                  });
                }
              }, 200);
            }}
            ListEmptyComponent={
              <View style={styles.empty}>
                <Ionicons name="people-outline" size={48} color={Colors.textHint} />
                <Text style={styles.emptyText}>
                  {searching ? '未找到匹配联系人' : '暂无联系人\n通过绑定功能添加家人、朋友或恋人'}
                </Text>
              </View>
            }
          />

          {/* 右侧字母索引栏 — selectMode时隐藏 */}
          {!selectMode && sections.some((s) => s.data.length > 0) && (
            <View style={styles.letterIndexBar}>
              {LETTERS.map((letter) => {
                const hasMatch = letterIndexMap[letter] !== null;
                return (
                  <TouchableOpacity
                    key={letter}
                    style={styles.letterItem}
                    onPress={() => handleLetterPress(letter)}
                    activeOpacity={0.5}
                    hitSlop={{ top: 2, bottom: 2, left: 8, right: 4 }}
                  >
                    <Text
                      style={[
                        styles.letterText,
                        hasMatch && styles.letterTextActive,
                      ]}
                    >
                      {letter}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          )}
        </View>
      </View>

      {/* 快捷消息底部弹窗 */}
      <QuickMessageSheet
        visible={quickMsgVisible}
        targetUserId={quickMsgTarget?.userId || ''}
        targetUsername={quickMsgTarget?.remark || quickMsgTarget?.username || ''}
        onClose={() => { setQuickMsgVisible(false); setQuickMsgTarget(null); }}
        onSent={handleQuickMsgSent}
      />

      {/* 编辑备注Modal */}
      <RNModal
        visible={remarkVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setRemarkVisible(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setRemarkVisible(false)}>
          <Pressable style={styles.modalContent} onPress={() => {}}>
            <Text style={styles.modalTitle}>编辑备注</Text>
            <Text style={styles.modalSubtitle}>
              {remarkTarget?.username}（仅自己可见）
            </Text>
            <TextInput
              style={styles.remarkInput}
              value={remarkText}
              onChangeText={setRemarkText}
              placeholder="输入备注名（最长20字）"
              placeholderTextColor={Colors.textHint}
              maxLength={20}
              autoFocus
              returnKeyType="done"
              onSubmitEditing={handleSaveRemark}
            />
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalCancelBtn}
                onPress={() => setRemarkVisible(false)}
              >
                <Text style={styles.modalCancelText}>取消</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalConfirmBtn, remarkSaving && styles.btnDisabled]}
                onPress={handleSaveRemark}
                disabled={remarkSaving}
              >
                {remarkSaving ? (
                  <ActivityIndicator size="small" color="#FFF" />
                ) : (
                  <Text style={styles.modalConfirmText}>保存</Text>
                )}
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </RNModal>
    </SafeAreaView>
  );
};

// ====== 样式 ======

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  container: { flex: 1 },
  loadingContainer: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  loadingText: { fontSize: Typography.body, color: Colors.textHint, marginTop: Spacing.md },

  // 头部
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  manageText: { fontSize: Typography.body, color: Colors.primary },
  selectHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', flex: 1,
  },
  cancelText: { fontSize: Typography.body, color: Colors.primary },
  selectCount: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary },
  selectActions: { flexDirection: 'row', gap: Spacing.lg, alignItems: 'center' },
  batchBtn: { padding: Spacing.xs },

  // 搜索
  searchContainer: {
    paddingHorizontal: Spacing.lg, paddingTop: Spacing.md,
    backgroundColor: Colors.bgWhite,
  },

  // 主体
  bodyContainer: { flex: 1, flexDirection: 'row' },

  // 分组头
  sectionHeader: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm,
    backgroundColor: Colors.bgPrimary, gap: Spacing.sm,
  },
  sectionTitle: { fontSize: Typography.caption, fontWeight: '600', flex: 1 },
  sectionCount: { fontSize: Typography.caption, color: Colors.textHint },

  // 字母索引栏
  letterIndexBar: {
    position: 'absolute', right: 0, top: 0, bottom: 0,
    justifyContent: 'center', alignItems: 'center',
    paddingRight: 2, paddingVertical: Spacing.lg,
    zIndex: 10,
  },
  letterItem: { paddingHorizontal: 4, paddingVertical: 1 },
  letterText: { fontSize: 10, fontWeight: '600', color: Colors.textHint },
  letterTextActive: { color: Colors.primary, fontWeight: '700' },

  // 空状态
  empty: {
    alignItems: 'center', justifyContent: 'center',
    paddingVertical: Spacing.xl * 3, paddingHorizontal: Spacing.lg,
  },
  emptyText: {
    fontSize: Typography.body, color: Colors.textHint, marginTop: Spacing.md,
    textAlign: 'center', lineHeight: 22,
  },

  // Modal
  modalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.4)',
    alignItems: 'center', justifyContent: 'center',
  },
  modalContent: {
    width: '85%', backgroundColor: Colors.bgWhite,
    borderRadius: BorderRadius.card * 2, padding: Spacing.xl,
  },
  modalTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, textAlign: 'center' },
  modalSubtitle: { fontSize: Typography.caption, color: Colors.textHint, textAlign: 'center', marginTop: Spacing.xs },
  remarkInput: {
    marginTop: Spacing.lg, borderWidth: 1, borderColor: Colors.divider,
    borderRadius: BorderRadius.card, paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm, fontSize: Typography.body, color: Colors.textPrimary,
  },
  modalActions: {
    flexDirection: 'row', marginTop: Spacing.lg, gap: Spacing.md,
  },
  modalCancelBtn: {
    flex: 1, paddingVertical: Spacing.md,
    borderRadius: BorderRadius.card, borderWidth: 1, borderColor: Colors.divider,
    alignItems: 'center',
  },
  modalCancelText: { fontSize: Typography.body, color: Colors.textPrimary },
  modalConfirmBtn: {
    flex: 1, paddingVertical: Spacing.md,
    borderRadius: BorderRadius.card, backgroundColor: Colors.primary,
    alignItems: 'center',
  },
  modalConfirmText: { fontSize: Typography.body, color: '#FFF', fontWeight: '600' },
  btnDisabled: { opacity: 0.6 },
});

export default ContactsScreen;
