/**
 * 管理员手机使用情况页面
 * 查看全站所有用户的手机使用数据，支持搜索、筛选、排序、时间区间查询
 *
 * 修复:
 * - 添加时间区间筛选UI（日期选择器）
 * - 支持按开始-结束日期范围过滤手机使用数据
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, RefreshControl, ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card, SearchBar, Button, DatePicker } from '../components';
import {
  getAllUsersPhoneUsage,
  getPhoneUsageByTimeRange,
} from '../services/admin';
import type { AllUsersPhoneUsage, PhoneData } from '../types';

interface AdminPhoneUsageScreenProps {
  onBack: () => void;
}

const AdminPhoneUsageScreen: React.FC<AdminPhoneUsageScreenProps> = ({ onBack }) => {
  const [data, setData] = useState<AllUsersPhoneUsage | null>(null);
  const [filteredUsers, setFilteredUsers] = useState<PhoneData[]>([]);
  const [selectedUser, setSelectedUser] = useState<PhoneData | null>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<'screenTime' | 'appUsage' | 'chargeCount'>('screenTime');
  const mountedRef = useRef(true);

  // 时间区间筛选（统一DatePicker）
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [showFromDatePicker, setShowFromDatePicker] = useState(false);
  const [showToDatePicker, setShowToDatePicker] = useState(false);

  useEffect(() => {
    mountedRef.current = true;
    loadData();
    return () => { mountedRef.current = false; };
  }, []);

  const loadData = async () => {
    try {
      const d = await getAllUsersPhoneUsage();
      if (!mountedRef.current) return;
      setData(d);
      setFilteredUsers(d?.users ?? []);
    } catch {
      if (mountedRef.current) {
        setData(null);
        setFilteredUsers([]);
      }
    } finally {
      if (mountedRef.current) setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadData();
    if (mountedRef.current) setRefreshing(false);
  };

  const handleSearch = async (query: string) => {
    if (!data) return;
    setFilteredUsers(
      data.users.filter((u) =>
        u.username.includes(query) || u.phone.includes(query) || u.userId.includes(query),
      ),
    );
  };

  const handleClearSearch = () => {
    if (data) setFilteredUsers(data.users);
  };

  const handleSort = (by: typeof sortBy) => {
    setSortBy(by);
    const sorted = [...filteredUsers].sort((a, b) => {
      if (by === 'screenTime') return b.screenTimePerDay - a.screenTimePerDay;
      if (by === 'appUsage') return b.appUsageMinutes - a.appUsageMinutes;
      return b.chargeCount - a.chargeCount;
    });
    setFilteredUsers(sorted);
  };

  const handleViewDetail = async (user: PhoneData) => {
    try {
      const detail = await getPhoneUsageByTimeRange(user.userId, dateFrom, dateTo);
      if (!mountedRef.current) return;
      if (detail) {
        setSelectedUser(detail);
        setShowDetail(true);
      }
    } catch {
      if (mountedRef.current) Alert.alert('查询失败', '无法获取该用户的手机使用数据');
    }
  };

  // 时间筛选确认
  const handleApplyDateFilter = () => {
    if (dateFrom && dateTo && new Date(dateFrom).getTime() > new Date(dateTo).getTime()) {
      Alert.alert('提示', '开始日期不能晚于结束日期');
      return;
    }
    setShowDetail(false);
    setSelectedUser(null);
    // 触发重新排序刷新
    if (data) {
      handleSort(sortBy);
    }
  };

  const handleClearDateFilter = () => {
    setDateFrom('');
    setDateTo('');
  };

  const formatMinutes = (min: number) => {
    if (min >= 60) return `${Math.floor(min / 60)}小时${min % 60}分钟`;
    return `${min}分钟`;
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      {/* 头部 */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>全站手机使用情况</Text>
        <View style={{ width: 24 }} />
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.primary} />
          <Text style={styles.loadingText}>加载手机使用数据...</Text>
        </View>
      ) : (
      <ScrollView
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={[Colors.primary]} />
        }
      >
        {/* 汇总统计 */}
        {data && data.totalUsers > 0 && (
          <View style={styles.summaryRow}>
            <View style={styles.summaryCard}>
              <Text style={styles.summaryNum}>{data.totalUsers}</Text>
              <Text style={styles.summaryLabel}>监测用户</Text>
            </View>
            <View style={[styles.summaryCard, { borderLeftColor: Colors.primary }]}>
              <Text style={[styles.summaryNum, { color: Colors.primary }]}>
                {formatMinutes(data.avgScreenTimePerDay)}
              </Text>
              <Text style={styles.summaryLabel}>日均屏幕时间</Text>
            </View>
            <View style={[styles.summaryCard, { borderLeftColor: Colors.friend }]}>
              <Text style={[styles.summaryNum, { color: Colors.friend }]}>
                {formatMinutes(data.avgAppUsageMinutes)}
              </Text>
              <Text style={styles.summaryLabel}>日均APP使用</Text>
            </View>
          </View>
        )}

        {/* 搜索 + 排序 + 时间筛选 */}
        <View style={styles.toolbar}>
          <SearchBar placeholder="搜索用户/手机号" onSearch={handleSearch} onClear={handleClearSearch} />

          {/* 时间区间筛选UI */}
          <View style={styles.dateFilterRow}>
            <Text style={styles.dateFilterLabel}>时间区间：</Text>
            <TouchableOpacity style={styles.dateBtn} onPress={() => setShowFromDatePicker(true)}>
              <Ionicons name="calendar-outline" size={14} color={Colors.primary} />
              <Text style={[styles.dateBtnText, !dateFrom && { color: Colors.textHint }]}>
                {dateFrom || '开始日期'}
              </Text>
            </TouchableOpacity>
            <Text style={styles.dateSep}>—</Text>
            <TouchableOpacity style={styles.dateBtn} onPress={() => setShowToDatePicker(true)}>
              <Ionicons name="calendar-outline" size={14} color={Colors.primary} />
              <Text style={[styles.dateBtnText, !dateTo && { color: Colors.textHint }]}>
                {dateTo || '结束日期'}
              </Text>
            </TouchableOpacity>
            {(dateFrom || dateTo) && (
              <TouchableOpacity onPress={handleClearDateFilter}>
                <Ionicons name="close-circle" size={18} color={Colors.lover} />
              </TouchableOpacity>
            )}
          </View>

          <View style={styles.sortRow}>
            <Text style={styles.sortLabel}>排序：</Text>
            {[
              { key: 'screenTime' as const, label: '屏幕时间' },
              { key: 'appUsage' as const, label: 'APP使用' },
              { key: 'chargeCount' as const, label: '充电次数' },
            ].map((s) => (
              <TouchableOpacity
                key={s.key}
                style={[styles.sortBtn, sortBy === s.key && styles.sortBtnActive]}
                onPress={() => handleSort(s.key)}
              >
                <Text style={[styles.sortBtnText, sortBy === s.key && styles.sortBtnTextActive]}>
                  {s.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* 用户列表 */}
        <View style={styles.listSection}>
          <Text style={styles.sectionTitle}>
            用户手机使用数据
            {(dateFrom || dateTo) ? (
              <Text style={styles.filterHint}> (已筛选)</Text>
            ) : null}
          </Text>
          {filteredUsers.map((u) => (
            <TouchableOpacity
              key={u.userId}
              style={styles.userCard}
              onPress={() => handleViewDetail(u)}
              activeOpacity={0.7}
            >
              <View style={styles.userHeader}>
                <View style={styles.avatarCircle}>
                  <Ionicons name="phone-portrait-outline" size={20} color={Colors.admin} />
                </View>
                <View style={styles.userInfo}>
                  <Text style={styles.userName}>{u.username}</Text>
                  <Text style={styles.userPhone}>{u.phone}</Text>
                </View>
                <Ionicons name="chevron-forward" size={16} color={Colors.textHint} />
              </View>
              <View style={styles.userStats}>
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>{formatMinutes(u.screenTimePerDay)}</Text>
                  <Text style={styles.statLabel}>日均屏幕</Text>
                </View>
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>{formatMinutes(u.appUsageMinutes)}</Text>
                  <Text style={styles.statLabel}>APP使用</Text>
                </View>
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>{u.chargeCount}次</Text>
                  <Text style={styles.statLabel}>充电</Text>
                </View>
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>{u.appStartCount}</Text>
                  <Text style={styles.statLabel}>启停</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        {/* 用户详情弹窗 */}
        {showDetail && selectedUser && (
          <Card style={styles.detailCard}>
            <View style={styles.detailHeader}>
              <Text style={styles.detailTitle}>
                {selectedUser.username} · 详细数据
                {(dateFrom || dateTo) ? <Text style={styles.filterHint}> (时间筛选)</Text> : null}
              </Text>
              <TouchableOpacity onPress={() => setShowDetail(false)}>
                <Ionicons name="close" size={20} color={Colors.textHint} />
              </TouchableOpacity>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>屏幕时间</Text>
              <Text style={styles.detailValue}>{formatMinutes(selectedUser.screenTimePerDay)}</Text>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>APP使用时长</Text>
              <Text style={styles.detailValue}>{formatMinutes(selectedUser.appUsageMinutes)}</Text>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>APP启动次数</Text>
              <Text style={styles.detailValue}>{selectedUser.appStartCount} 次</Text>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>APP停止次数</Text>
              <Text style={styles.detailValue}>{selectedUser.appStopCount} 次</Text>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>充电次数</Text>
              <Text style={styles.detailValue}>{selectedUser.chargeCount} 次</Text>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>电池健康</Text>
              <Text style={styles.detailValue}>{selectedUser.batteryHealth}</Text>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>最后充电</Text>
              <Text style={styles.detailValue}>{new Date(selectedUser.lastChargeAt).toLocaleString('zh-CN')}</Text>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>数据更新时间</Text>
              <Text style={styles.detailValue}>{new Date(selectedUser.dataUpdatedAt).toLocaleString('zh-CN')}</Text>
            </View>
            {selectedUser.foregroundRecords.length > 0 && (
              <>
                <Text style={styles.subTitle}>前台驻留记录</Text>
                {selectedUser.foregroundRecords.map((r, i) => (
                  <View key={i} style={styles.recordItem}>
                    <Text style={styles.recordApp}>{r.appName}</Text>
                    <Text style={styles.recordTime}>
                      {new Date(r.startTime).toLocaleTimeString('zh-CN')} - {new Date(r.endTime).toLocaleTimeString('zh-CN')} ({r.durationMinutes}分钟)
                    </Text>
                  </View>
                ))}
              </>
            )}
            {selectedUser.backgroundRecords.length > 0 && (
              <>
                <Text style={styles.subTitle}>后台驻留记录</Text>
                {selectedUser.backgroundRecords.map((r, i) => (
                  <View key={i} style={styles.recordItem}>
                    <Text style={styles.recordApp}>{r.appName}</Text>
                    <Text style={styles.recordTime}>
                      {new Date(r.startTime).toLocaleTimeString('zh-CN')} - {new Date(r.endTime).toLocaleTimeString('zh-CN')} ({r.durationMinutes}分钟)
                    </Text>
                  </View>
                ))}
              </>
            )}
          </Card>
        )}

        {/* 空状态 */}
        {(!data || data.totalUsers === 0) && (
          <View style={styles.emptyContainer}>
            <Ionicons name="phone-portrait-outline" size={48} color={Colors.textHint} />
            <Text style={styles.emptyText}>暂无用户手机使用数据</Text>
            <Text style={styles.emptyHint}>用户上报手机使用数据后将在此展示</Text>
          </View>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>
      )}

      {/* 日期选择器 */}
      <DatePicker visible={showFromDatePicker} value={dateFrom} onConfirm={(v) => { setDateFrom(v); setShowFromDatePicker(false); }} onClose={() => setShowFromDatePicker(false)} title="选择开始日期" />
      <DatePicker visible={showToDatePicker} value={dateTo} onConfirm={(v) => { setDateTo(v); setShowToDatePicker(false); }} onClose={() => setShowToDatePicker(false)} title="选择结束日期" />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  loadingContainer: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  loadingText: { fontSize: Typography.body, color: Colors.textHint, marginTop: Spacing.md },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  summaryRow: { flexDirection: 'row', padding: Spacing.lg, gap: Spacing.sm },
  summaryCard: {
    flex: 1, backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    borderLeftWidth: 3, borderLeftColor: Colors.admin,
    padding: Spacing.md, alignItems: 'center',
  },
  summaryNum: { fontSize: Typography.subtitle, fontWeight: '700', color: Colors.textPrimary },
  summaryLabel: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  toolbar: { paddingHorizontal: Spacing.lg, marginBottom: Spacing.md },
  // 时间筛选
  dateFilterRow: { flexDirection: 'row', alignItems: 'center', marginTop: Spacing.sm, gap: Spacing.xs },
  dateFilterLabel: { fontSize: Typography.caption, color: Colors.textSecondary },
  dateBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input,
    paddingHorizontal: 8, paddingVertical: 4,
  },
  dateBtnText: { fontSize: Typography.caption, color: Colors.textPrimary },
  dateSep: { fontSize: Typography.caption, color: Colors.textHint },
  sortRow: { flexDirection: 'row', alignItems: 'center', marginTop: Spacing.sm, gap: Spacing.xs },
  sortLabel: { fontSize: Typography.caption, color: Colors.textSecondary },
  sortBtn: {
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.input, backgroundColor: Colors.bgWhite,
    borderWidth: 1, borderColor: Colors.divider,
  },
  sortBtnActive: { backgroundColor: Colors.admin, borderColor: Colors.admin },
  sortBtnText: { fontSize: Typography.caption, color: Colors.textSecondary },
  sortBtnTextActive: { color: Colors.white },
  listSection: { paddingHorizontal: Spacing.lg },
  sectionTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.md },
  filterHint: { fontSize: Typography.caption, color: Colors.textHint, fontWeight: '400' },
  userCard: {
    backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    padding: Spacing.lg, marginBottom: Spacing.sm,
  },
  userHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: Spacing.md },
  avatarCircle: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: Colors.admin + '15', alignItems: 'center', justifyContent: 'center',
    marginRight: Spacing.md,
  },
  userInfo: { flex: 1 },
  userName: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  userPhone: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  userStats: { flexDirection: 'row', justifyContent: 'space-around', paddingTop: Spacing.md, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider },
  statItem: { alignItems: 'center' },
  statValue: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary },
  statLabel: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  detailCard: { marginHorizontal: Spacing.lg, marginTop: Spacing.lg },
  detailHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    marginBottom: Spacing.lg,
  },
  detailTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  detailRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    paddingVertical: Spacing.sm, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  detailLabel: { fontSize: Typography.body, color: Colors.textSecondary },
  detailValue: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  subTitle: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary, marginTop: Spacing.lg, marginBottom: Spacing.sm },
  recordItem: {
    backgroundColor: Colors.bgPrimary, borderRadius: BorderRadius.input,
    padding: Spacing.sm, marginBottom: Spacing.xs,
  },
  recordApp: { fontSize: Typography.caption, fontWeight: '500', color: Colors.primary },
  recordTime: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  emptyContainer: { alignItems: 'center', paddingVertical: Spacing.xl * 2, paddingHorizontal: Spacing.lg },
  emptyText: { fontSize: Typography.body, color: Colors.textHint, marginTop: Spacing.sm },
  emptyHint: { fontSize: Typography.caption, color: Colors.textHint, marginTop: Spacing.xs },
});

export default AdminPhoneUsageScreen;
