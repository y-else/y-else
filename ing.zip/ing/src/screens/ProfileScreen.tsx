/**
 * 我的页面（精简重构版）
 * 头像卡片 → 6项核心菜单 → 存储显示 → 底部操作
 * 编辑资料/互动权限/兑换码等功能已迁移至独立设置页
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert,
  TextInput, Image, Modal as RNModal,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card, Modal } from '../components';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useAuth } from '../context/AuthContext';
import type { MainStackParamList } from '../navigation/AppNavigator';
import {
  submitFeedback, getMyFeedbacks, sendContactAdminMessage,
} from '../services/settings';
import { getUserBinding, isBindingValid } from '../services/bindingService';
import { getMyReports } from '../services/contentReport';
import { getPublicProfile, getDisplayId, getOnlineStatus } from '../services/profile';
import { getNextLevelProgress, getLevelConfig } from '../services/level';
import { getStorageStats, formatBytes } from '../services/cacheManager';
import type { Feedback, AdminBinding, PublicProfile } from '../types';
import type { ContentReport } from '../services/contentReport';

// 存储大小
interface StorageSnapshot {
  totalBytes: number;
  totalKeys: number;
}

const ProfileScreen: React.FC = () => {
  const { state, logout } = useAuth();
  const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>();
  const user = state.user;
  const isAdmin = user?.role === 'admin';
  const mountedRef = useRef(true);

  // 公开资料/等级
  const [publicProfile, setPublicProfile] = useState<PublicProfile | null>(null);
  const [displayId, setDisplayId] = useState('');
  const [isOnline, setIsOnline] = useState(false);
  const [levelProgress, setLevelProgress] = useState({ currentLevel: 0, currentMinutes: 0, nextLevelMinutes: 0, progress: 0 });
  // 存储用量
  const [storage, setStorage] = useState<StorageSnapshot>({ totalBytes: 0, totalKeys: 0 });
  // 反馈引用
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [myReports, setMyReports] = useState<ContentReport[]>([]);
  // 管理员绑定
  const [binding, setBinding] = useState<AdminBinding | null>(null);

  // 弹窗
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [feedbackText, setFeedbackText] = useState('');
  const [feedbackContact, setFeedbackContact] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [showContact, setShowContact] = useState(false);
  const [contactMsg, setContactMsg] = useState('');

  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  const loadAll = useCallback(async () => {
    if (!user) return;
    try {
      const p = await getPublicProfile(user.id);
      if (p && mountedRef.current) {
        setPublicProfile(p);
        const did = await getDisplayId(user.id);
        if (mountedRef.current) setDisplayId(did);
      }
    } catch {}
    try {
      const online = await getOnlineStatus(user.id);
      if (mountedRef.current) setIsOnline(online);
    } catch {}
    try {
      const lp = await getNextLevelProgress();
      if (mountedRef.current) setLevelProgress(lp);
    } catch {}
    try {
      const fbs = await getMyFeedbacks(user.id);
      if (mountedRef.current) setFeedbacks(fbs);
    } catch {}
    try {
      const rpts = await getMyReports(user.id);
      if (mountedRef.current) setMyReports(rpts);
    } catch {}
    try {
      const stats = await getStorageStats();
      if (mountedRef.current) setStorage({ totalBytes: stats.totalBytes, totalKeys: stats.totalKeys });
    } catch {}
    if (!isAdmin) {
      try {
        const v = await isBindingValid(user.id);
        if (v) {
          const b = await getUserBinding(user.id);
          if (mountedRef.current) setBinding(b);
        } else { if (mountedRef.current) setBinding(null); }
      } catch {}
    }
  }, [user, isAdmin]);

  useEffect(() => { loadAll(); }, [loadAll]);

  // 跳转个人空间
  const handleGoSpace = () => {
    if (!user) return;
    navigation.navigate('PersonalSpace', { ownerId: user.id, ownerName: user.username });
  };

  // 提交反馈
  const handleSubmitFeedback = async () => {
    if (!feedbackText.trim()) { Alert.alert('提示', '请输入反馈内容'); return; }
    setSubmitting(true);
    try {
      await submitFeedback(user?.id || '', user?.username || '', feedbackText.trim(), feedbackContact.trim());
      if (!mountedRef.current) return;
      setFeedbackText(''); setFeedbackContact(''); setShowFeedbackModal(false);
      Alert.alert('已提交', '感谢反馈，管理员会尽快处理');
      const fbs = await getMyFeedbacks(user?.id || '');
      if (mountedRef.current) setFeedbacks(fbs);
    } catch { if (mountedRef.current) Alert.alert('提交失败', '请检查网络后重试'); }
    finally { if (mountedRef.current) setSubmitting(false); }
  };

  const handleContactAdmin = async () => {
    if (!contactMsg.trim()) { Alert.alert('提示', '请输入消息'); return; }
    setSubmitting(true);
    try {
      await sendContactAdminMessage(user?.id || '', user?.username || '', user?.phone || '', contactMsg.trim());
      if (!mountedRef.current) return;
      setContactMsg(''); setShowContact(false);
      Alert.alert('已发送', '管理员会尽快回复您');
    } catch { if (mountedRef.current) Alert.alert('发送失败', '请检查网络后重试'); }
    finally { if (mountedRef.current) setSubmitting(false); }
  };

  const handleLogout = () => {
    Alert.alert('退出登录', '确定退出当前账号？', [
      { text: '取消', style: 'cancel' },
      { text: '退出', style: 'destructive', onPress: logout },
    ]);
  };

  // 菜单项配置
  const mainMenu = [
    { key: 'space', icon: 'home-outline', color: '#7B68EE', label: '我的个人空间', desc: '动态 · 访客 · 相册', onPress: handleGoSpace },
    { key: 'privacy', icon: 'shield-checkmark-outline', color: Colors.family, label: '隐私政策', desc: '查看隐私条款', onPress: () => setShowPrivacy(true) },
    { key: 'contact', icon: 'person-outline', color: Colors.admin, label: '联系管理员', desc: '问题咨询与反馈', onPress: () => setShowContact(true) },
    { key: 'feedback', icon: 'chatbubble-ellipses-outline', color: Colors.friend, label: '意见反馈', desc: '提交功能建议', onPress: () => setShowFeedbackModal(true) },
    { key: 'myFeedback', icon: 'list-outline', color: Colors.primary, label: '我的反馈', desc: feedbacks.length > 0 ? `${feedbacks.length}条记录` : '查看反馈历史', onPress: () => navigation.navigate('MyFeedback' as any) },
    { key: 'settings', icon: 'settings-outline', color: Colors.textSecondary, label: '设置', desc: '权限 · 管理 · 系统工具', onPress: () => navigation.navigate('Settings' as any) },
  ];

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
        {/* ====== 头像区 ====== */}
        <TouchableOpacity style={styles.profileCard} onPress={handleGoSpace} activeOpacity={0.9}>
          <View style={styles.profileBg} />
          <View style={styles.avatarWrap}>
            <View style={styles.avatarOuter}>
              <View style={styles.avatarInner}>
                {user?.avatar ? (
                  <Image source={{ uri: user.avatar }} style={styles.avatarImg} />
                ) : (
                  <Ionicons name="person" size={38} color={Colors.textHint} />
                )}
              </View>
              {isOnline && <View style={styles.onlineDot} />}
            </View>
          </View>
          <Text style={styles.profileName}>{user?.username || '未登录'}</Text>
          <Text style={styles.profileId}>ID: {displayId || (user?.id || '').slice(-7)}</Text>
          {publicProfile && publicProfile.level > 0 && (
            <View style={styles.levelRow}>
              <View style={styles.levelBadge}>
                <Ionicons name="star" size={12} color={Colors.friend} />
                <Text style={styles.levelBadgeText}>LV.{publicProfile.level}</Text>
              </View>
              <Text style={styles.levelTitle}>{getLevelConfig(publicProfile.level).title}</Text>
            </View>
          )}
          {levelProgress.currentLevel > 0 && levelProgress.currentLevel < 100 && (
            <View style={styles.progressWrap}>
              <View style={styles.progressBar}>
                <View style={[styles.progressFill, { width: `${Math.min(Math.round(levelProgress.progress * 100), 100)}%` }]} />
              </View>
              <Text style={styles.progressText}>
                {levelProgress.currentMinutes}分钟 · 距下级{levelProgress.nextLevelMinutes - levelProgress.currentMinutes}分钟
              </Text>
            </View>
          )}
          {isAdmin && (
            <TouchableOpacity style={styles.adminChip} onPress={() => navigation.navigate('AdminDashboard')}>
              <Ionicons name="shield" size={14} color={Colors.admin} />
              <Text style={[styles.adminChipText, { color: Colors.admin }]}>管理员后台</Text>
            </TouchableOpacity>
          )}
          {!isAdmin && binding && (
            <TouchableOpacity style={[styles.adminChip, { backgroundColor: Colors.family + '15' }]} onPress={() => navigation.navigate('AdminDashboard')}>
              <Ionicons name="shield-checkmark" size={14} color={Colors.family} />
              <Text style={[styles.adminChipText, { color: Colors.family }]}>管理员入口</Text>
            </TouchableOpacity>
          )}
        </TouchableOpacity>

        {/* ====== 6项核心菜单 ====== */}
        <View style={styles.menuSection}>
          {mainMenu.map((item) => (
            <TouchableOpacity key={item.key} style={styles.menuRow} onPress={item.onPress} activeOpacity={0.6}>
              <View style={[styles.menuIcon, { backgroundColor: item.color + '12' }]}>
                <Ionicons name={item.icon as any} size={22} color={item.color} />
              </View>
              <View style={styles.menuInfo}>
                <Text style={styles.menuLabel}>{item.label}</Text>
                <Text style={styles.menuDesc}>{item.desc}</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={Colors.textHint} />
            </TouchableOpacity>
          ))}
        </View>

        {/* ====== 存储用量 ====== */}
        <Card style={styles.storageCard}>
          <View style={styles.storageHeader}>
            <View style={styles.storageTitleRow}>
              <Ionicons name="server-outline" size={16} color={Colors.textHint} />
              <Text style={styles.storageLabel}>存储空间</Text>
            </View>
            <Text style={styles.storageValue}>{formatBytes(storage.totalBytes)}</Text>
          </View>
          <View style={styles.storageBar}>
            <View style={[styles.storageFill, { width: `${Math.min((storage.totalBytes / (50 * 1024 * 1024)) * 100, 100)}%` }]} />
          </View>
          <Text style={styles.storageHint}>{storage.totalKeys}个存储项 · 上限约50MB</Text>
        </Card>

        {/* ====== 反馈历史速览 ====== */}
        {feedbacks.length > 0 && (
          <Card style={styles.miniListCard}>
            <Text style={styles.miniListTitle}>反馈历史</Text>
            {feedbacks.slice(0, 3).map((fb) => (
              <View key={fb.id} style={styles.miniItem}>
                <View style={[styles.miniDot, { backgroundColor: fb.status === 'pending' ? Colors.warning : Colors.family }]} />
                <Text style={styles.miniText} numberOfLines={1}>{fb.content}</Text>
                <Text style={styles.miniMeta}>{fb.status === 'pending' ? '处理中' : '已解决'}</Text>
              </View>
            ))}
          </Card>
        )}

        {/* ====== 举报速览 ====== */}
        {myReports.length > 0 && (
          <Card style={styles.miniListCard}>
            <Text style={styles.miniListTitle}>我的举报</Text>
            {myReports.slice(0, 3).map((rpt) => (
              <View key={rpt.id} style={styles.miniItem}>
                <Text style={styles.miniText} numberOfLines={1}>{rpt.targetPreview}</Text>
                <Text style={[styles.miniMeta, { color: rpt.status === 'reviewed' ? Colors.family : rpt.status === 'dismissed' ? Colors.textHint : Colors.warning }]}>
                  {rpt.status === 'pending' ? '处理中' : rpt.status === 'reviewed' ? '已处理' : '已驳回'}
                </Text>
              </View>
            ))}
          </Card>
        )}

        {/* ====== 退出 ====== */}
        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout} activeOpacity={0.6}>
          <Text style={styles.logoutText}>退出登录</Text>
        </TouchableOpacity>
        <Text style={styles.version}>ing 陪伴 v1.0.0</Text>
      </ScrollView>

      {/* ====== 弹窗 ====== */}
      <RNModal visible={showPrivacy} transparent animationType="fade" onRequestClose={() => setShowPrivacy(false)}>
        <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={() => setShowPrivacy(false)}>
          <TouchableOpacity activeOpacity={1} style={styles.alertBox}>
            <Text style={styles.alertTitle}>隐私政策</Text>
            <ScrollView style={{ maxHeight: 260 }}>
              <Text style={styles.privacyText}>ing 陪伴尊重并保护您的个人隐私。本应用会使用您的手机号码进行注册和登录验证，使用 GPS 定位用于 SOS 求救和位置共享功能。所有个人信息加密存储，不会出售给第三方。如有疑问，请联系 y-else 工作室。</Text>
            </ScrollView>
            <TouchableOpacity style={styles.alertBtn} onPress={() => setShowPrivacy(false)}>
              <Text style={styles.alertBtnText}>我知道了</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        </TouchableOpacity>
      </RNModal>

      <Modal visible={showFeedbackModal} title="意见反馈" onClose={() => setShowFeedbackModal(false)} confirmText="提交" onConfirm={handleSubmitFeedback}>
        <TextInput style={styles.modalInput} placeholder="请描述您的建议或问题" placeholderTextColor={Colors.textHint} multiline numberOfLines={4} value={feedbackText} onChangeText={setFeedbackText} />
        <TextInput style={styles.modalInputSmall} placeholder="联系方式（选填）" placeholderTextColor={Colors.textHint} value={feedbackContact} onChangeText={setFeedbackContact} />
      </Modal>

      <Modal visible={showContact} title="联系管理员" onClose={() => setShowContact(false)} confirmText="发送" onConfirm={handleContactAdmin}>
        <Text style={styles.modalHint}>请描述您遇到的问题，管理员会尽快回复。</Text>
        <TextInput style={styles.modalInput} placeholder="您的问题或建议" placeholderTextColor={Colors.textHint} multiline numberOfLines={4} value={contactMsg} onChangeText={setContactMsg} />
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  container: { paddingBottom: Spacing.xl * 2 },
  // 头像
  profileCard: {
    alignItems: 'center', paddingVertical: Spacing.xl, backgroundColor: Colors.bgWhite,
    marginBottom: Spacing.sm,
  },
  profileBg: { position: 'absolute', top: 0, left: 0, right: 0, height: 100, backgroundColor: '#7B68EE', opacity: 0.06 },
  avatarWrap: { marginBottom: Spacing.sm },
  avatarOuter: { position: 'relative' },
  avatarInner: {
    width: 72, height: 72, borderRadius: 36, backgroundColor: Colors.bgPrimary,
    alignItems: 'center', justifyContent: 'center', overflow: 'hidden',
    borderWidth: 3, borderColor: Colors.primary + '25',
  },
  avatarImg: { width: 72, height: 72, borderRadius: 36 },
  onlineDot: {
    width: 14, height: 14, borderRadius: 7, backgroundColor: Colors.family,
    borderWidth: 2.5, borderColor: Colors.bgWhite, position: 'absolute', bottom: 1, right: 1,
  },
  profileName: { fontSize: 20, fontWeight: '700', color: Colors.textPrimary, marginTop: Spacing.sm },
  profileId: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2, fontFamily: 'monospace' },
  levelRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, marginTop: Spacing.xs },
  levelBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: Colors.friend + '15', paddingHorizontal: Spacing.sm, paddingVertical: 2, borderRadius: 10 },
  levelBadgeText: { fontSize: Typography.caption, color: Colors.friend, fontWeight: '600' },
  levelTitle: { fontSize: Typography.caption, color: Colors.textSecondary },
  progressWrap: { width: '70%', marginTop: Spacing.xs },
  progressBar: { height: 4, borderRadius: 2, backgroundColor: Colors.divider, overflow: 'hidden' },
  progressFill: { height: 4, borderRadius: 2, backgroundColor: Colors.friend },
  progressText: { fontSize: 10, color: Colors.textHint, marginTop: 2, textAlign: 'center' },
  adminChip: {
    flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: Spacing.sm,
    backgroundColor: Colors.admin + '10', paddingHorizontal: Spacing.md, paddingVertical: 3, borderRadius: 12,
  },
  adminChipText: { fontSize: Typography.caption, fontWeight: '500' },
  // 菜单
  menuSection: {
    backgroundColor: Colors.bgWhite, marginHorizontal: Spacing.lg,
    borderRadius: BorderRadius.card, marginBottom: Spacing.sm,
    overflow: 'hidden',
  },
  menuRow: {
    flexDirection: 'row', alignItems: 'center', paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg, borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: Colors.divider,
  },
  menuIcon: {
    width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center',
    marginRight: Spacing.md,
  },
  menuInfo: { flex: 1 },
  menuLabel: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  menuDesc: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 1 },
  // 存储
  storageCard: { marginHorizontal: Spacing.lg, marginBottom: Spacing.sm },
  storageHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.sm },
  storageTitleRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
  storageLabel: { fontSize: Typography.caption, color: Colors.textSecondary },
  storageValue: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary },
  storageBar: { height: 6, borderRadius: 3, backgroundColor: Colors.divider, overflow: 'hidden', marginBottom: Spacing.xs },
  storageFill: { height: 6, borderRadius: 3, backgroundColor: Colors.primary },
  storageHint: { fontSize: 10, color: Colors.textHint },
  // 反馈/举报速览
  miniListCard: { marginHorizontal: Spacing.lg, marginBottom: Spacing.sm },
  miniListTitle: { fontSize: Typography.caption, fontWeight: '600', color: Colors.textSecondary, marginBottom: Spacing.sm },
  miniItem: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingVertical: Spacing.xs },
  miniDot: { width: 6, height: 6, borderRadius: 3 },
  miniText: { flex: 1, fontSize: Typography.caption, color: Colors.textPrimary },
  miniMeta: { fontSize: 10, color: Colors.textHint },
  // 退出
  logoutBtn: { alignItems: 'center', paddingVertical: Spacing.lg },
  logoutText: { fontSize: Typography.body, color: Colors.lover },
  version: { fontSize: Typography.caption, color: Colors.textHint, textAlign: 'center', marginTop: Spacing.sm },
  // 弹窗
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', padding: Spacing.xl },
  alertBox: { backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card, padding: Spacing.lg },
  alertTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.md },
  alertBtn: { alignItems: 'center', paddingVertical: Spacing.md, marginTop: Spacing.sm },
  alertBtnText: { fontSize: Typography.body, fontWeight: '600', color: Colors.primary },
  privacyText: { fontSize: Typography.body, color: Colors.textSecondary, lineHeight: 22 },
  modalHint: { fontSize: Typography.body, color: Colors.textSecondary, marginBottom: Spacing.md, lineHeight: 20 },
  modalInput: { borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input, padding: Spacing.md, fontSize: Typography.body, color: Colors.textPrimary, minHeight: 100, textAlignVertical: 'top', marginBottom: Spacing.md },
  modalInputSmall: { borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input, padding: Spacing.md, fontSize: Typography.body, color: Colors.textPrimary, marginBottom: Spacing.md },
});

export default ProfileScreen;
