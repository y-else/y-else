/**
 * 管理员反馈/联系消息查看页面
 * 查看用户提交的意见反馈和联系管理员消息
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Alert,
  RefreshControl,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card, SearchBar, Button } from '../components';
import {
  getAllFeedbacks, updateFeedbackStatus,
  getAllContactAdminMessages, markContactMessageRead,
} from '../services/settings';
import type { Feedback } from '../types';
import type { ContactAdminMessage } from '../services/settings';

type TabType = 'feedbacks' | 'contacts';

interface AdminFeedbackScreenProps {
  onBack: () => void;
}

const AdminFeedbackScreen: React.FC<AdminFeedbackScreenProps> = ({ onBack }) => {
  const [tab, setTab] = useState<TabType>('feedbacks');
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [contacts, setContacts] = useState<ContactAdminMessage[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  const loadData = useCallback(async () => {
    const fb = await getAllFeedbacks();
    const ct = await getAllContactAdminMessages();
    if (!mountedRef.current) return;
    setFeedbacks(fb);
    setContacts(ct);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const handleResolve = async (id: string) => {
    await updateFeedbackStatus(id, 'resolved');
    Alert.alert('已处理', '反馈已标记为已解决');
    loadData();
  };

  const handleMarkContactRead = async (id: string) => {
    await markContactMessageRead(id);
    loadData();
  };

  const filteredFeedbacks = searchQuery.trim()
    ? feedbacks.filter((f) =>
        f.username.includes(searchQuery) ||
        f.content.includes(searchQuery) ||
        (f.contact && f.contact.includes(searchQuery)))
    : feedbacks;

  const filteredContacts = searchQuery.trim()
    ? contacts.filter((c) =>
        c.username.includes(searchQuery) ||
        c.message.includes(searchQuery))
    : contacts;

  const renderFeedback = ({ item }: { item: Feedback }) => (
    <Card style={[styles.itemCard, item.status === 'pending' && styles.pendingCard]}>
      <View style={styles.itemHeader}>
        <View style={styles.userInfo}>
          <View style={styles.avatarCircle}>
            <Ionicons name="person" size={18} color={Colors.primary} />
          </View>
          <View>
            <Text style={styles.userName}>{item.username}</Text>
            <Text style={styles.dateText}>
              {new Date(item.createdAt).toLocaleString('zh-CN')}
            </Text>
          </View>
        </View>
        <View style={[
          styles.statusBadge,
          { backgroundColor: item.status === 'pending' ? Colors.lover + '18' : Colors.family + '18' },
        ]}>
          <View style={[styles.statusDot, { backgroundColor: item.status === 'pending' ? Colors.lover : Colors.family }]} />
          <Text style={[styles.statusText, { color: item.status === 'pending' ? Colors.lover : Colors.family }]}>
            {item.status === 'pending' ? '待处理' : '已解决'}
          </Text>
        </View>
      </View>
      <Text style={styles.content}>{item.content}</Text>
      {item.contact ? (
        <Text style={styles.contact}>联系方式: {item.contact}</Text>
      ) : null}
      {item.status === 'pending' && (
        <TouchableOpacity
          style={styles.resolveBtn}
          onPress={() => handleResolve(item.id)}
          activeOpacity={0.7}
        >
          <Ionicons name="checkmark-circle-outline" size={16} color={Colors.family} />
          <Text style={styles.resolveText}>标记为已解决</Text>
        </TouchableOpacity>
      )}
    </Card>
  );

  const renderContact = ({ item }: { item: ContactAdminMessage }) => (
    <Card style={[styles.itemCard, item.status === 'unread' && styles.pendingCard] as any}>
      <View style={styles.itemHeader}>
        <View style={styles.userInfo}>
          <View style={styles.avatarCircle}>
            <Ionicons name="chatbubble-ellipses" size={18} color={Colors.admin} />
          </View>
          <View>
            <Text style={styles.userName}>{item.username}</Text>
            <Text style={styles.dateText}>
              {new Date(item.createdAt).toLocaleString('zh-CN')}
            </Text>
          </View>
        </View>
        <View style={[
          styles.statusBadge,
          { backgroundColor: item.status === 'unread' ? Colors.lover + '18' : Colors.textHint + '18' },
        ]}>
          <View style={[styles.statusDot, { backgroundColor: item.status === 'unread' ? Colors.lover : Colors.textHint }]} />
          <Text style={[styles.statusText, { color: item.status === 'unread' ? Colors.lover : Colors.textHint }]}>
            {item.status === 'unread' ? '未读' : item.status === 'read' ? '已读' : '已回复'}
          </Text>
        </View>
      </View>
      <Text style={styles.content}>{item.message}</Text>
      {item.status === 'unread' && (
        <TouchableOpacity
          style={styles.resolveBtn}
          onPress={() => handleMarkContactRead(item.id)}
          activeOpacity={0.7}
        >
          <Ionicons name="checkmark-circle-outline" size={16} color={Colors.primary} />
          <Text style={[styles.resolveText, { color: Colors.primary }]}>标记为已读</Text>
        </TouchableOpacity>
      )}
    </Card>
  );

  const unreadContacts = contacts.filter((c) => c.status === 'unread').length;
  const pendingFeedbacks = feedbacks.filter((f) => f.status === 'pending').length;

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>用户反馈</Text>
        <View style={{ width: 24 }} />
      </View>

      {/* 统计卡片 */}
      <View style={styles.statsRow}>
        <View style={[styles.statCard, { borderLeftColor: Colors.lover }]}>
          <Text style={[styles.statNum, { color: Colors.lover }]}>{pendingFeedbacks}</Text>
          <Text style={styles.statLabel}>待处理反馈</Text>
        </View>
        <View style={[styles.statCard, { borderLeftColor: Colors.admin }]}>
          <Text style={[styles.statNum, { color: Colors.admin }]}>{unreadContacts}</Text>
          <Text style={styles.statLabel}>未读消息</Text>
        </View>
      </View>

      {/* 标签切换 */}
      <View style={styles.tabRow}>
        <TouchableOpacity
          style={[styles.tab, tab === 'feedbacks' && styles.tabActive]}
          onPress={() => setTab('feedbacks')}
        >
          <Text style={[styles.tabText, tab === 'feedbacks' && styles.tabTextActive]}>
            意见反馈
          </Text>
          {pendingFeedbacks > 0 && (
            <View style={styles.tabBadge}>
              <Text style={styles.tabBadgeText}>{pendingFeedbacks}</Text>
            </View>
          )}
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, tab === 'contacts' && styles.tabActive]}
          onPress={() => setTab('contacts')}
        >
          <Text style={[styles.tabText, tab === 'contacts' && styles.tabTextActive]}>
            联系管理员
          </Text>
          {unreadContacts > 0 && (
            <View style={styles.tabBadge}>
              <Text style={styles.tabBadgeText}>{unreadContacts}</Text>
            </View>
          )}
        </TouchableOpacity>
      </View>

      <SearchBar
        placeholder="搜索用户名/内容"
        onSearch={setSearchQuery}
        onClear={() => setSearchQuery('')}
      />

      {tab === 'feedbacks' ? (
        <FlatList
          data={filteredFeedbacks}
          keyExtractor={(item) => item.id}
          renderItem={renderFeedback}
          contentContainerStyle={styles.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={[Colors.primary]} />}
          ListEmptyComponent={<View style={styles.empty}><Ionicons name="chatbubble-outline" size={48} color={Colors.textHint} /><Text style={styles.emptyText}>暂无反馈内容</Text></View>}
        />
      ) : (
        <FlatList
          data={filteredContacts as any[]}
          keyExtractor={(item: any) => item.id}
          renderItem={renderContact as any}
          contentContainerStyle={styles.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={[Colors.primary]} />}
          ListEmptyComponent={<View style={styles.empty}><Ionicons name="chatbubble-outline" size={48} color={Colors.textHint} /><Text style={styles.emptyText}>暂无联系消息</Text></View>}
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  statsRow: {
    flexDirection: 'row', padding: Spacing.md, gap: Spacing.sm,
    backgroundColor: Colors.bgWhite,
  },
  statCard: {
    flex: 1, backgroundColor: Colors.bgPrimary, borderRadius: BorderRadius.card,
    borderLeftWidth: 3, padding: Spacing.md, alignItems: 'center',
  },
  statNum: { fontSize: 22, fontWeight: '700' },
  statLabel: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  tabRow: {
    flexDirection: 'row', paddingHorizontal: Spacing.lg, paddingTop: Spacing.md,
    backgroundColor: Colors.bgWhite, gap: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  tab: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingVertical: Spacing.sm, paddingHorizontal: Spacing.xs,
    borderBottomWidth: 2, borderBottomColor: 'transparent',
    marginBottom: -StyleSheet.hairlineWidth,
  },
  tabActive: { borderBottomColor: Colors.primary },
  tabText: { fontSize: Typography.body, color: Colors.textHint },
  tabTextActive: { color: Colors.primary, fontWeight: '600' },
  tabBadge: {
    backgroundColor: Colors.lover, borderRadius: 10,
    minWidth: 20, height: 20, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 6,
  },
  tabBadgeText: { fontSize: 10, color: '#FFF', fontWeight: '700' },
  list: { padding: Spacing.lg },
  itemCard: { marginBottom: Spacing.sm },
  pendingCard: { borderLeftWidth: 3, borderLeftColor: Colors.lover },
  itemHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start',
    marginBottom: Spacing.sm,
  },
  userInfo: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  avatarCircle: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: Colors.primary + '12', alignItems: 'center', justifyContent: 'center',
  },
  userName: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary },
  dateText: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  statusBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10,
  },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  statusText: { fontSize: 11, fontWeight: '600' },
  content: {
    fontSize: Typography.body, color: Colors.textSecondary,
    lineHeight: 22, marginBottom: Spacing.sm,
  },
  contact: {
    fontSize: Typography.caption, color: Colors.primary,
    marginBottom: Spacing.sm,
  },
  resolveBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingVertical: Spacing.xs, alignSelf: 'flex-end',
  },
  resolveText: { fontSize: Typography.caption, color: Colors.family, fontWeight: '500' },
  empty: { alignItems: 'center', paddingVertical: Spacing.xl * 3 },
  emptyText: { fontSize: Typography.body, color: Colors.textHint, marginTop: Spacing.md },
});

export default AdminFeedbackScreen;
