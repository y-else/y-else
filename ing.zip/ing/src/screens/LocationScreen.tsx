/**
 * 用户定位页面
 *
 * 地图区域占 70%，展示自身定位（蓝色标记）与授权用户定位（角色色标记）。
 * 支持实时追踪、后台保活、标记弹窗信息展示。
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import MapViewBase, { Marker, Callout } from 'react-native-maps';
const MapView = MapViewBase as React.ComponentType<any>; // ref类型兼容
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { PermissionGuard } from '../components';
import {
  getCurrentLocation,
  startRealtimeTracking,
  stopRealtimeTracking,
  startBackgroundTracking,
  stopBackgroundTracking,
  getAllUsersLatestLocations,
  destroyGPSResources,
  simplifyTrajectory,
} from '../services/gps';
import { getContacts } from '../services/contacts';
import { emitLocation } from '../services/websocketClient';
import type { LocationData, LocationRecord } from '../services/gps';
import type { Contact } from '../types';

const { height: SCREEN_HEIGHT } = Dimensions.get('window');
const MAP_HEIGHT = SCREEN_HEIGHT * 0.7;

interface LocationScreenProps {
  currentUserId?: string;
}

interface DisplayUser {
  userId: string;
  username: string;
  role: string;
  isOnline: boolean;
  location: LocationData | null;
  updatedAt: string;
}

const LocationScreen: React.FC<LocationScreenProps> = ({
  currentUserId = 'self',
}) => {
  const mountedRef = useRef(true);
  const mapRef = useRef<any>(null); // MapView ref类型兼容

  const [myLocation, setMyLocation] = useState<LocationData | null>(null);
  const [userLocations, setUserLocations] = useState<DisplayUser[]>([]);
  const [tracking, setTracking] = useState(false);
  const [selectedUser, setSelectedUser] = useState<DisplayUser | null>(null);
  const [address, setAddress] = useState<string | null>(null);

  // ====== 生命周期 ======

  useEffect(() => {
    mountedRef.current = true;
    initLocation();
    return () => {
      mountedRef.current = false;
      destroyGPSResources();
    };
  }, []);

  const initLocation = async () => {
    // 获取自身位置
    const myLoc = await getCurrentLocation();
    if (!mountedRef.current) return;

    if (myLoc) {
      setMyLocation(myLoc);
      setAddress(myLoc.address || null);
    }

    // 加载授权用户位置
    await loadUserLocations();
  };

  const loadUserLocations = async () => {
    try {
      const [contacts, latestLocs] = await Promise.all([
        getContacts(),
        getAllUsersLatestLocations(),
      ]);

      if (!mountedRef.current) return;

      const displayUsers: DisplayUser[] = contacts
        .filter((c: Contact) => !c.isBlocked && c.group !== 'blocked' && c.userId !== currentUserId)
        .slice(0, 20) // 只显示前20个，避免过多标记
        .map((c: Contact) => {
          const loc = latestLocs.get(c.userId);
          return {
            userId: c.userId,
            username: c.remark || c.username,
            role: c.role,
            isOnline: c.status === 'online',
            location: loc ? {
              latitude: loc.latitude,
              longitude: loc.longitude,
              timestamp: loc.timestamp,
              address: loc.address,
              accuracy: loc.accuracy,
              speed: loc.speed,
            } : null,
            updatedAt: loc
              ? new Date(loc.timestamp).toISOString()
              : c.lastOnlineAt || new Date().toISOString(),
          };
        });

      setUserLocations(displayUsers);
    } catch (e) {
      console.warn('[定位页] 加载用户位置失败:', e);
    }
  };

  // ====== 实时追踪 ======

  const handleToggleTracking = async () => {
    if (tracking) {
      stopRealtimeTracking();
      stopBackgroundTracking();
      if (mountedRef.current) setTracking(false);
    } else {
      // 启动前台追踪
      const ok = await startRealtimeTracking(currentUserId, (loc: LocationData) => {
        if (!mountedRef.current) return;
        setMyLocation(loc);
        setAddress(loc.address || null);
        // WS实时推送位置同步
        try {
          emitLocation({
            latitude: loc.latitude,
            longitude: loc.longitude,
            address: loc.address || null,
            speed: loc.speed,
            timestamp: loc.timestamp,
          });
        } catch {}
        // 地图跟随
        mapRef.current?.animateToRegion({
          latitude: loc.latitude,
          longitude: loc.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        }, 300);
      });
      if (!ok || !mountedRef.current) return;

      setTracking(true);

      // 同时启动后台定位保活
      startBackgroundTracking(currentUserId).catch(() => {});
    }
  };

  // ====== 缩放到用户 ======

  const handleZoomToUser = useCallback((user: DisplayUser) => {
    setSelectedUser(user);
    if (user.location && mapRef.current) {
      mapRef.current.animateToRegion({
        latitude: user.location.latitude,
        longitude: user.location.longitude,
        latitudeDelta: 0.005,
        longitudeDelta: 0.005,
      }, 400);
    }
  }, []);

  // ====== 角色色 ======

  const getRoleColor = (role: string) => {
    const colors: Record<string, string> = {
      family: '#5CB85C', friend: '#F0AD4E', lover: '#E74C3C', admin: '#7B68EE',
    };
    return colors[role] || Colors.primary;
  };

  // ====== 初始地图区域 ======

  const initialRegion = {
    latitude: myLocation?.latitude || 39.9042,
    longitude: myLocation?.longitude || 116.4074,
    latitudeDelta: 0.02,
    longitudeDelta: 0.02,
  };

  return (
    <View style={styles.container}>
      {/* ====== 地图区域 70% ====== */}
      <View style={styles.mapContainer}>
        <MapView
          ref={mapRef}
          style={styles.map}
          initialRegion={initialRegion}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
        >
          {/* 自身位置标记（蓝色） */}
          {myLocation && (
            <Marker
              coordinate={{
                latitude: myLocation.latitude,
                longitude: myLocation.longitude,
              }}
              title="我的位置"
              pinColor={Colors.primary}
            >
              <Callout>
                <View style={styles.callout}>
                  <Text style={styles.calloutTitle}>我的位置</Text>
                  <Text style={styles.calloutText}>
                    {address || '定位中...'}
                  </Text>
                  <Text style={styles.calloutTime}>
                    {new Date(myLocation.timestamp).toLocaleTimeString('zh-CN')}
                  </Text>
                </View>
              </Callout>
            </Marker>
          )}

          {/* 授权用户位置标记（角色色） */}
          {userLocations
            .filter((u) => u.location)
            .map((u) => (
              <Marker
                key={u.userId}
                coordinate={{
                  latitude: u.location!.latitude,
                  longitude: u.location!.longitude,
                }}
                title={u.username}
                description={u.location!.address || ''}
                pinColor={getRoleColor(u.role)}
                opacity={u.isOnline ? 1 : 0.5}
              >
                <Callout onPress={() => handleZoomToUser(u)}>
                  <View style={styles.callout}>
                    <Text style={styles.calloutTitle}>{u.username}</Text>
                    <Text style={[styles.calloutRole, { color: getRoleColor(u.role) }]}>
                      {u.role === 'family' ? '家人' : u.role === 'friend' ? '朋友' : u.role === 'lover' ? '恋人' : u.role}
                    </Text>
                    <Text style={styles.calloutText}>
                      {u.isOnline ? '在线' : '离线'} · {u.location!.address || '未知地址'}
                    </Text>
                    <Text style={styles.calloutTime}>
                      更新于 {formatTime(u.location!.timestamp)}
                    </Text>
                  </View>
                </Callout>
              </Marker>
            ))}
        </MapView>

        {/* 地图控件 */}
        <View style={styles.mapControls}>
          {/* 追踪按钮 */}
          <TouchableOpacity
            style={[styles.trackingBtn, tracking && styles.trackingActive]}
            onPress={handleToggleTracking}
            activeOpacity={0.8}
          >
            <Ionicons
              name={tracking ? 'radio' : 'radio-outline'}
              size={18}
              color={tracking ? '#FFF' : Colors.primary}
            />
            <Text style={[styles.trackingText, tracking && { color: '#FFF' }]}>
              {tracking ? '追踪中' : '实时追踪'}
            </Text>
          </TouchableOpacity>

          {/* 重新定位 */}
          <TouchableOpacity
            style={styles.locateBtn}
            onPress={async () => {
              const loc = await getCurrentLocation();
              if (loc && mountedRef.current) {
                setMyLocation(loc);
                setAddress(loc.address || null);
                mapRef.current?.animateToRegion({
                  latitude: loc.latitude,
                  longitude: loc.longitude,
                  latitudeDelta: 0.01,
                  longitudeDelta: 0.01,
                }, 400);
              }
            }}
            activeOpacity={0.7}
          >
            <Ionicons name="locate" size={20} color={Colors.primary} />
          </TouchableOpacity>
        </View>
      </View>

      {/* ====== 用户列表区域 30% ====== */}
      <View style={styles.userListContainer}>
        <SafeAreaView edges={['bottom']} style={styles.userListInner}>
          <View style={styles.listHeader}>
            <Text style={styles.listTitle}>授权用户定位</Text>
            <TouchableOpacity onPress={loadUserLocations}>
              <Text style={styles.listCount}>
                {userLocations.filter((u) => u.location).length} 有定位 · 刷新
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.userList}>
            {userLocations.map((u) => (
              <TouchableOpacity
                key={u.userId}
                style={[
                  styles.userItem,
                  selectedUser?.userId === u.userId && styles.userItemSelected,
                ]}
                onPress={() => handleZoomToUser(u)}
                activeOpacity={0.7}
              >
                <View
                  style={[
                    styles.userDot,
                    { backgroundColor: u.location ? getRoleColor(u.role) : Colors.textHint },
                  ]}
                />
                <View style={styles.userInfo}>
                  <Text style={styles.userName}>{u.username}</Text>
                  <Text style={styles.userStatus}>
                    {u.isOnline ? '在线' : '离线'}
                    {u.location?.address ? ` · ${u.location.address}` : ''}
                  </Text>
                </View>
                <Ionicons
                  name="location"
                  size={16}
                  color={u.location ? getRoleColor(u.role) : Colors.textHint}
                />
              </TouchableOpacity>
            ))}

            {userLocations.length === 0 && (
              <View style={styles.empty}>
                <Ionicons name="people-outline" size={32} color={Colors.textHint} />
                <Text style={styles.emptyText}>暂无授权用户</Text>
                <Text style={styles.emptyHint}>绑定联系人后即可查看对方位置</Text>
              </View>
            )}
          </View>
        </SafeAreaView>
      </View>
    </View>
  );
};

function formatTime(ts: number): string {
  const diff = Date.now() - ts;
  if (diff < 60000) return '刚刚';
  if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
  return new Date(ts).toLocaleTimeString('zh-CN');
}

// 包装权限守卫
const LocationScreenWithGuard: React.FC<LocationScreenProps> = (props) => (
  <PermissionGuard requiredPermissions={['location']}>
    <LocationScreen {...props} />
  </PermissionGuard>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bgPrimary },
  mapContainer: { height: MAP_HEIGHT, position: 'relative' },
  map: { flex: 1 },
  callout: { minWidth: 130, padding: Spacing.xs },
  calloutTitle: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary },
  calloutRole: { fontSize: Typography.caption, fontWeight: '500' },
  calloutText: { fontSize: Typography.caption, color: Colors.textSecondary, marginTop: 2 },
  calloutTime: { fontSize: 10, color: Colors.textHint, marginTop: 2 },
  mapControls: { position: 'absolute', top: Spacing.lg, right: Spacing.lg, gap: Spacing.sm },
  trackingBtn: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.xs,
    backgroundColor: Colors.bgWhite, paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.card, elevation: 3, shadowOpacity: 0.1, shadowRadius: 4,
  },
  trackingActive: { backgroundColor: Colors.primary },
  trackingText: { fontSize: Typography.caption, fontWeight: '600', color: Colors.primary },
  locateBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: Colors.bgWhite, alignItems: 'center', justifyContent: 'center',
    elevation: 3, shadowOpacity: 0.1, shadowRadius: 4,
  },
  userListContainer: { flex: 1, backgroundColor: Colors.bgWhite },
  userListInner: { flex: 1 },
  listHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  listTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  listCount: { fontSize: Typography.caption, color: Colors.primary },
  userList: { paddingHorizontal: Spacing.lg },
  userItem: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
    paddingVertical: Spacing.md, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  userItemSelected: { backgroundColor: '#F0F8FF' },
  userDot: { width: 10, height: 10, borderRadius: 5 },
  userInfo: { flex: 1 },
  userName: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  userStatus: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  empty: { alignItems: 'center', paddingVertical: Spacing.xl * 2, gap: Spacing.xs },
  emptyText: { fontSize: Typography.body, color: Colors.textHint },
  emptyHint: { fontSize: Typography.caption, color: Colors.textHint },
});

export default LocationScreenWithGuard;
