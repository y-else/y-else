/**
 * 消息页面（增强版）
 * 聚合绑定关系私聊、快捷消息、系统公告、SOS求救消息
 * 未读角标、已读标记、清空未读
 *
 * 修复:
 * - 添加 quick(快捷消息) Tab
 * - 每个Tab显示分类未读角标
 * - 清空已读消息（仅清已读，保留未读）
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Alert, RefreshControl,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { useAuth } from '../context/AuthContext';
import {
  getMessages, getUnreadCount, markAsRead, markAllRead, clearMessages, clearReadMessages,
} from '../services/message';
import type { Message, MessageType, UnreadCount } from '../types';

interface MessageScreenProps {
  onBack: () => void;
}

const TYPE_TABS: { key: MessageType | 'all'; label: string; unreadKey?: keyof UnreadCount }[] = [
  { key: 'all', label: '全部' },
  { key: 'private', label: '私聊', unreadKey: 'private' },
  { key: 'quick', label: '快捷', unreadKey: 'quick' },
  { key: 'announcement', label: '公告', unreadKey: 'announcement' },
  { key: 'sos', label: 'SOS', unreadKey: 'sos' },
];

const TYPE_ICONS: Record<string, { name: string; color: string }> = {
  private: { name: 'chatbubble-outline', color: Colors.primary },
  quick: { name: 'flash-outline', color: Colors.friend },
  announcement: { name: 'megaphone-outline', color: '#F0AD4E' },
  sos: { name: 'warning-outline', color: Colors.lover },
};

const MessageScreen: React.FC<MessageScreenProps> = ({ onBack }) => {
  const { state } = useAuth();
  const user = state.user;

  const [messages, setMessages] = useState<Message[]>([]);
  const [unread, setUnread] = useState<UnreadCount>({ total: 0, private: 0, quick: 0, announcement: 0, sos: 0 });
  const [activeTab, setActiveTab] = useState<MessageType | 'all'>('all');
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    if (!user) return;
    const type = activeTab === 'all' ? undefined : activeTab;
    const msgs = await getMessages(user.id, type);
    // 排序：未读优先 → 再按时间倒序
    msgs.sort((a, b) => {
      if (a.isRead !== b.isRead) return a.isRead ? 1 : -1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
    setMessages(msgs);
    const count = await getUnreadCount(user.id);
    setUnread(count);
  }, [user, activeTab]);

  useEffect(() => { loadData(); }, [loadData]);

  const handleRefresh = async () => { setRefreshing(true); await loadData(); setRefreshing(false); };

  const handleMarkRead = async (msgId: string) => {
    await markAsRead(msgId);
    await loadData();
  };

  const handleMarkAllRead = () => {
    if (!user) return;
    Alert.alert('全部已读', '确定将所有消息标记为已读？', [
      { text: '取消', style: 'cancel' },
      { text: '确定', onPress: async () => { await markAllRead(user.id); await loadData(); } },
    ]);
  };

  const handleClearRead = () => {
    if (!user) return;
    Alert.alert('清空已读', '确定清空所有已读消息？未读消息将保留。', [
      { text: '取消', style: 'cancel' },
      { text: '清空', style: 'destructive', onPress: async () => {
        const count = await clearReadMessages(user.id);
        await loadData();
        Alert.alert('已清空', `已清除 ${count} 条已读消息`);
      }},
    ]);
  };

  const handleClearAll = () => {
    if (!user) return;
    Alert.alert('清空消息', '确定清空所有消息？此操作不可恢复。', [
      { text: '取消', style: 'cancel' },
      { text: '清空', style: 'destructive', onPress: async () => { await clearMessages(user.id); await loadData(); } },
    ]);
  };

  const formatTime = (iso: string) => {
    const d = new Date(iso);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
    if (diff < 86400000) return d.toTimeString().slice(0, 5);
    return `${d.getMonth() + 1}/${d.getDate()}`;
  };

  const renderMessage = ({ item }: { item: Message }) => {
    const icon = TYPE_ICONS[item.type] || TYPE_ICONS.private;
    return (
      <TouchableOpacity
        style={[styles.msgCard, !item.isRead && styles.unreadCard]}
        onPress={() => !item.isRead && handleMarkRead(item.id)}
        onLongPress={() => {
          Alert.alert('消息详情', `${item.fromUsername}: ${item.content}`, [
            { text: item.isRead ? '标为未读' : '标为已读', onPress: async () => { await markAsRead(item.id); await loadData(); } },
            { text: '关闭', style: 'cancel' },
          ]);
        }}
        activeOpacity={0.7}
      >
        <View style={[styles.avatarCircle, { backgroundColor: icon.color + '20' }]}>
          <Ionicons name={icon.name as any} size={20} color={icon.color} />
        </View>
        {!item.isRead && <View style={styles.unreadDot} />}
        <View style={styles.msgContent}>
          <View style={styles.msgHeader}>
            <Text style={styles.msgFrom} numberOfLines={1}>{item.fromUsername}</Text>
            <Text style={styles.msgTime}>{formatTime(item.createdAt)}</Text>
          </View>
          <Text style={styles.msgText} numberOfLines={2}>{item.content}</Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={styles.headerTitle}>消息</Text>
          {unread.total > 0 && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{unread.total > 99 ? '99+' : unread.total}</Text>
            </View>
          )}
        </View>
        <View style={styles.headerRight}>
          <TouchableOpacity onPress={handleMarkAllRead} style={styles.headerBtn}>
            <Ionicons name="checkmark-done-outline" size={20} color={Colors.primary} />
          </TouchableOpacity>
          <TouchableOpacity onPress={handleClearRead} style={styles.headerBtn}>
            <Ionicons name="archive-outline" size={20} color={Colors.textHint} />
          </TouchableOpacity>
          <TouchableOpacity onPress={handleClearAll} style={styles.headerBtn}>
            <Ionicons name="trash-outline" size={20} color={Colors.textHint} />
          </TouchableOpacity>
        </View>
      </View>

      {/* 分类标签（带未读角标） */}
      <View style={styles.tabRow}>
        {TYPE_TABS.map((tab) => {
          const tabUnread = tab.unreadKey ? unread[tab.unreadKey] : 0;
          return (
            <TouchableOpacity
              key={tab.key}
              style={[styles.tab, activeTab === tab.key && styles.tabActive]}
              onPress={() => setActiveTab(tab.key)}
            >
              <Text style={[styles.tabText, activeTab === tab.key && styles.tabTextActive]}>
                {tab.label}
              </Text>
              {tab.key !== 'all' && tabUnread > 0 && (
                <View style={styles.tabBadge}>
                  <Text style={styles.tabBadgeText}>{tabUnread > 99 ? '99+' : tabUnread}</Text>
                </View>
              )}
            </TouchableOpacity>
          );
        })}
      </View>

      <FlatList
        data={messages}
        keyExtractor={(item) => item.id}
        renderItem={renderMessage}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="chatbubbles-outline" size={48} color={Colors.textHint} />
            <Text style={styles.emptyText}>暂无消息</Text>
          </View>
        }
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={[Colors.primary]} />
        }
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerCenter: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  headerRight: { flexDirection: 'row', gap: Spacing.md },
  headerBtn: { padding: 4 },
  badge: {
    backgroundColor: Colors.lover, borderRadius: 10,
    minWidth: 20, height: 20, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 6,
  },
  badgeText: { fontSize: 11, color: Colors.white, fontWeight: '700' },
  tabRow: {
    flexDirection: 'row', backgroundColor: Colors.bgWhite,
    paddingHorizontal: Spacing.lg, paddingBottom: Spacing.md, gap: Spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  tab: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.input, backgroundColor: Colors.bgPrimary,
  },
  tabActive: { backgroundColor: Colors.primary },
  tabText: { fontSize: Typography.caption, color: Colors.textSecondary },
  tabTextActive: { color: Colors.white, fontWeight: '500' },
  tabBadge: {
    backgroundColor: Colors.lover, borderRadius: 8,
    minWidth: 16, height: 16, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 4,
  },
  tabBadgeText: { fontSize: 9, color: Colors.white, fontWeight: '700' },
  list: { padding: Spacing.lg },
  msgCard: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    padding: Spacing.lg, marginBottom: Spacing.sm,
  },
  unreadCard: { borderLeftWidth: 3, borderLeftColor: Colors.primary },
  avatarCircle: {
    width: 44, height: 44, borderRadius: 22,
    alignItems: 'center', justifyContent: 'center', marginRight: Spacing.md,
  },
  unreadDot: {
    position: 'absolute', top: Spacing.lg, left: Spacing.md,
    width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.lover,
  },
  msgContent: { flex: 1 },
  msgHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  msgFrom: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary, maxWidth: '70%' },
  msgTime: { fontSize: Typography.caption, color: Colors.textHint },
  msgText: { fontSize: Typography.caption, color: Colors.textSecondary, lineHeight: 18 },
  empty: { alignItems: 'center', paddingVertical: Spacing.xl * 3, gap: Spacing.lg },
  emptyText: { fontSize: Typography.body, color: Colors.textHint },
});

export default MessageScreen;
