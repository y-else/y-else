/**
 * 首页（容错加固版）
 * 关系卡片（层叠堆叠式）：家人/朋友/恋人分组展示所有已绑定成员
 * 排序：置顶优先 > 等级由高到低
 * 色彩：最顶层纯白，下层逐级淡化浅灰
 * 手势：左右滑动缓慢翻页动画
 * 管理员隐藏入口、悬浮SOS求救、悬浮抽奖入口
 * 4个快捷功能按键：日程/消息/健康/出行
 */

import React, { useState, useCallback, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Image,
  RefreshControl,
  FlatList,
  AppState,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card } from '../components';
import SOSCountdownModal from '../components/SOSCountdownModal';
import SOSAlertModal from '../components/SOSAlertModal';
import BirthdayBlessingModal from '../components/BirthdayBlessingModal';
import { useAuth } from '../context/AuthContext';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { MainStackParamList } from '../navigation/AppNavigator';
import * as Crypto from 'expo-crypto';
import { triggerSOS, resolveAlert, destroySOSResources, cacheOfflineSOS, stopSOSTracking, stopAllVibration } from '../services/sos';
import { getContacts } from '../services/contacts';
import { getCheckInStatus } from '../services/checkin';
import { onSOSAlert } from '../services/websocketClient';
import { getNetworkStatus } from '../services/network';
import { startSession, endSession } from '../services/level';
import { checkTodayBirthday, getFriendBirthdays, heartbeatOnline } from '../services/profile';
import type { SOSAlert as SOSAlertType, BirthdayInfo, BirthdayReminder } from '../types';


// ====== 分组配置 ======

type CardGroupKey = 'family' | 'friend' | 'lover';

const GROUP_CONFIG: { key: CardGroupKey; label: string; color: string; icon: string }[] = [
  { key: 'family', label: '家人', color: Colors.family, icon: 'home' },
  { key: 'friend', label: '朋友', color: Colors.friend, icon: 'people' },
  { key: 'lover', label: '恋人', color: Colors.lover, icon: 'heart' },
];

// ====== 层叠成员卡片组件 ======

interface MemberCardData {
  userId: string;
  username: string;
  avatar: string | null;
  phone: string;
  level: number;
  isPinned: boolean;
}

// ====== 首页组件 ======

const HomeScreen: React.FC = () => {
  const { state } = useAuth();
  const user = state.user;
  const isAdmin = user?.role === 'admin';
  const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>();
  const mountedRef = useRef(true);

  // SOS 状态
  const [sosPhase, setSosPhase] = useState<'idle' | 'countdown' | 'triggered'>('idle');
  const [sosAlert, setSosAlert] = useState<SOSAlertType | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  // 生日祝福弹窗
  const [birthdayInfo, setBirthdayInfo] = useState<BirthdayInfo | null>(null);
  const [friendBirthdays, setFriendBirthdays] = useState<BirthdayReminder[]>([]);
  const [showBirthdayBlessing, setShowBirthdayBlessing] = useState(false);

  // 抽奖入口
  const [lotteryVisible, setLotteryVisible] = useState(true);

  // 签到状态（初始化安全兜底）
  const [checkinStatus, setCheckinStatus] = useState({ checkedIn: false, streak: 0, chances: 0 });

  // 分组数据（仅家人/朋友/恋人，不含已拉黑）
  const [groupMembers, setGroupMembers] = useState<Record<CardGroupKey, MemberCardData[]>>({
    family: [],
    friend: [],
    lover: [],
  });

  // 加载绑定关系并构建分组
  const loadRelations = useCallback(async () => {
    if (!user) return;
    try {
      const contacts = await getContacts();
      // 安全兜底：contacts 为 undefined/null 时使用空数组
      const safeContacts = contacts ?? [];

      const groups: Record<CardGroupKey, MemberCardData[]> = {
        family: [],
        friend: [],
        lover: [],
      };

      for (const c of safeContacts) {
        if (!c) continue;
        if (c.isBlocked || !c.group || c.group === 'blocked') continue;
        const g = c.group as CardGroupKey;
        if (g in groups) {
          groups[g].push({
            userId: c.userId ?? '',
            username: c.username ?? '未知',
            avatar: c.avatar ?? null,
            phone: c.phone ?? '',
            level: 0,
            isPinned: c.isPinned ?? false,
          });
        }
      }

      if (!mountedRef.current) return;
      setGroupMembers(groups);
    } catch {
      // 加载失败保持原状，不清空已有数据
    }
  }, [user]);

  useEffect(() => {
    loadRelations();
  }, [loadRelations]);

  // 加载签到状态
  useEffect(() => {
    if (!user) return;
    (async () => {
      try {
        const result = await getCheckInStatus();
        if (!result || !mountedRef.current) return;
        setCheckinStatus({
          checkedIn: result.checkedInToday ?? false,
          streak: result.streak ?? 0,
          chances: result.totalChances ?? 0,
        });
      } catch { /* 静默 */ }
    })();
  }, [user?.id]);

  // ====== F6修复：使用时长追踪 + 生日检查 + 在线心跳 ======

  useEffect(() => {
    if (!user) return;

    // 启动会话计时
    startSession().catch(() => {});

    // 生日检查
    (async () => {
      try {
        const bday = await checkTodayBirthday(user.id);
        if (bday?.isToday && mountedRef.current) {
          setBirthdayInfo(bday);
          setShowBirthdayBlessing(true);
          const friends = await getFriendBirthdays(user.id);
          if (mountedRef.current) setFriendBirthdays(friends);
        }
      } catch { /* 静默 */ }
    })();

    // 在线心跳（每30秒更新一次）
    heartbeatOnline(user.id).catch(() => {});
    const heartbeatTimer = setInterval(() => {
      heartbeatOnline(user.id).catch(() => {});
    }, 30000);

    // AppState 监听：前台/后台切换
    const sub = AppState.addEventListener('change', (nextState) => {
      if (nextState === 'active') {
        startSession().catch(() => {});
        heartbeatOnline(user.id).catch(() => {});
      } else if (nextState === 'background' || nextState === 'inactive') {
        endSession().catch(() => {});
      }
    });

    return () => {
      endSession().catch(() => {});
      clearInterval(heartbeatTimer);
      sub.remove();
    };
  }, [user?.id]);

  // ====== SOS 流程 ======

  const handleSOSActivate = useCallback(() => {
    setSosPhase('countdown');
  }, []);

  // 页面卸载时清理SOS相关资源（WS生命周期由AppNavigator管理）
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      destroySOSResources();
      stopAllVibration();
    };
  }, []);

  // WebSocket SOS实时监听（接收端：监听远程SOS推送）
  useEffect(() => {
    if (!user) return;
    const unsub = onSOSAlert((data: any) => {
      if (!data || !mountedRef.current) return;
      // 排除自己发出的SOS
      if (data.senderId === user.id) return;
      const remoteAlert: SOSAlertType = {
        id: data.alertId || Crypto.randomUUID(),
        senderId: data.senderId ?? '',
        senderName: data.senderName ?? '未知用户',
        senderPhone: data.senderPhone ?? '',
        location: {
          latitude: data.latitude || 0,
          longitude: data.longitude || 0,
        },
        address: data.address || null,
        triggeredAt: data.triggeredAt || new Date().toISOString(),
        status: 'active',
      };
      setSosAlert(remoteAlert);
      setSosPhase('triggered');
    });
    return () => {
      if (typeof unsub === 'function') unsub();
    };
  }, [user]);

  const handleSOSCancel = useCallback(() => {
    setSosPhase('idle');
    // 取消倒计时时清理残留的定位监听和振动
    stopSOSTracking();
    stopAllVibration();
  }, []);

  const handleSOSTrigger = useCallback(async () => {
    if (!user) return;
    setSosPhase('triggered');
    const result = await triggerSOS(user.id, user.username, user.phone);
    if (!mountedRef.current) return;

    if (result?.alert) {
      setSosAlert(result.alert);
    } else {
      setSosPhase('idle');
      const reason = result?.reason;
      if (reason === 'network_error') {
        await cacheOfflineSOS(user.id, user.username, user.phone, false).catch(() => {});
        Alert.alert('求救发送中', '当前网络不可用，求救信息已缓存，联网后将自动发送');
      } else if (reason === 'rate_limited') {
        Alert.alert('操作过快', '请稍后再试，10秒内已触发过求救信号');
      } else if (reason === 'permission_denied') {
        Alert.alert('权限受限', 'SOS求救功能已被管理员禁用');
      } else {
        Alert.alert('发送失败', '求救信号发送失败，请检查网络后重试');
      }
    }
  }, [user]);

  const handleSOSResolve = useCallback(() => {
    resolveAlert();
    setSosAlert(null);
    setSosPhase('idle');
    // 释放SOS定位跟踪资源
    destroySOSResources();
  }, []);

  // ====== 管理员入口 ======

  const handleAdminEntry = () => {
    navigation.navigate('AdminDashboard');
  };

  // ====== 抽奖入口 ======

  const handleLotteryPress = () => {
    navigation.navigate('Lottery');
  };

  // ====== 签到入口 ======

  const handleCheckinPress = () => {
    navigation.navigate('Lottery');
  };

  // ====== 下拉刷新 ======

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadRelations();
    // 同时刷新签到状态
    try {
      const result = await getCheckInStatus();
      if (result && mountedRef.current) {
        setCheckinStatus({
          checkedIn: result.checkedInToday ?? false,
          streak: result.streak ?? 0,
          chances: result.totalChances ?? 0,
        });
      }
    } catch { /* 静默 */ }
    if (mountedRef.current) setRefreshing(false);
  }, [loadRelations]);

  // ====== 已绑定 → 切换底部标签到通讯录 Tab ======

  const handleGroupPress = (_groupKey: string) => {
    navigation.navigate('Contacts' as any);
  };

  // ====== 未绑定 → 跳转绑定页 ======

  const handleUnboundPress = (groupKey?: string) => {
    navigation.navigate('Bind', { defaultType: groupKey } as any);
  };

  // ====== 4个快捷功能 ======

  const quickActions = [
    { label: 'SOS', icon: 'warning-outline' as const, color: Colors.lover, bg: '#FDECEA', route: 'SOS' as const, onPress: handleSOSActivate },
    { label: '日程', icon: 'calendar-outline' as const, color: Colors.primary, bg: '#E8F4FD', route: 'Schedule' as const },
    { label: '消息', icon: 'chatbubbles-outline' as const, color: Colors.friend, bg: '#FFF3E0', route: 'Message' as const },
    { label: '健康', icon: 'heart-outline' as const, color: Colors.family, bg: '#E8F5E9', route: 'Health' as const },
    { label: '抽奖', icon: 'gift-outline' as const, color: '#FF6B35', bg: '#FFF0E8', route: 'Lottery' as const },
  ];

  // ====== 安全获取分组成员（兜底空数组） ======

  const getGroupMembers = (key: CardGroupKey): MemberCardData[] => {
    return groupMembers?.[key] ?? [];
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.container}>
        {/* ====== 顶部标题栏 ====== */}
        <View style={styles.header}>
          <View style={styles.headerGradient} />
          <View style={styles.headerContent}>
            <Text style={styles.headerTitle}>ing</Text>
            <View style={styles.headerRight}>
              {isAdmin && (
                <TouchableOpacity style={styles.adminBtn} onPress={handleAdminEntry} activeOpacity={0.7}>
                  <Ionicons name="settings-outline" size={22} color={Colors.admin} />
                </TouchableOpacity>
              )}
            </View>
          </View>
        </View>

        {/* ====== 欢迎区（卡片式 + 签到入口） ====== */}
        <View style={styles.welcomeCard}>
          <View style={styles.welcomeInner}>
            <View style={styles.welcomeAv}>
              <Ionicons name="person-circle" size={36} color={Colors.primary} />
            </View>
            <View style={styles.welcomeTextGroup}>
              <Text style={styles.welcomeText}>
                {user?.username ? `你好，${user.username}` : '欢迎使用 ing'}
              </Text>
              <Text style={styles.welcomeHint}>
                {user ? '您的陪伴伙伴都在这里' : '请先登录以使用全部功能'}
              </Text>
            </View>
            {user && (
              <TouchableOpacity
                style={[styles.checkinEntry, checkinStatus.checkedIn && styles.checkinEntryDone]}
                onPress={handleCheckinPress}
                activeOpacity={0.7}
              >
                <Ionicons
                  name={checkinStatus.checkedIn ? 'checkmark-circle' : 'calendar-outline'}
                  size={18}
                  color={checkinStatus.checkedIn ? Colors.family : Colors.primary}
                />
                <Text style={[styles.checkinEntryText, checkinStatus.checkedIn && styles.checkinEntryTextDone]}>
                  {checkinStatus.checkedIn ? `连签${checkinStatus.streak}天` : '签到'}
                </Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* ====== 关系板块（紧凑横向列表） ====== */}
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={[Colors.primary]} tintColor={Colors.primary} />
          }
        >
          <View style={styles.sectionHeaderRow}>
            <Text style={styles.sectionTitle}>我的关系</Text>
            <TouchableOpacity onPress={() => handleGroupPress('all')} activeOpacity={0.6}>
              <Text style={styles.sectionMore}>查看全部</Text>
            </TouchableOpacity>
          </View>

          {GROUP_CONFIG.map((group) => {
            const members = getGroupMembers(group.key);
            if (members.length === 0) {
              return (
                <TouchableOpacity key={group.key} style={styles.emptyRelationGroup} onPress={() => handleUnboundPress(group.key)} activeOpacity={0.6}>
                  <Ionicons name={group.icon as any} size={16} color={group.color} />
                  <Text style={styles.emptyRelationText}>{group.label}: 暂无绑定</Text>
                  <Ionicons name="add-circle" size={18} color={group.color} />
                </TouchableOpacity>
              );
            }
            return (
              <View key={group.key} style={styles.relationGroup}>
                <TouchableOpacity style={styles.groupHeader} onPress={() => handleGroupPress(group.key)} activeOpacity={0.6}>
                  <View style={[styles.groupDot, { backgroundColor: group.color }]} />
                  <Text style={styles.groupLabel}>{group.label}</Text>
                  <Text style={styles.groupCount}>{members.length}人</Text>
                </TouchableOpacity>
                <FlatList
                  horizontal
                  data={members}
                  keyExtractor={(m) => m.userId}
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.horizontalMemberList}
                  renderItem={({ item }) => (
                    <TouchableOpacity
                      style={styles.memberChip}
                      activeOpacity={0.7}
                      onPress={() => handleGroupPress(group.key)}
                    >
                      <View style={styles.memberAvatarSm}>
                        {item.avatar ? (
                          <Image source={{ uri: item.avatar }} style={styles.memberAvatarImgSm} />
                        ) : (
                          <Ionicons name="person" size={16} color={group.color} />
                        )}
                      </View>
                      <Text style={styles.memberNameSm} numberOfLines={1}>{item.username}</Text>
                    </TouchableOpacity>
                  )}
                />
              </View>
            );
          })}

          {/* 快捷功能区 */}
          <View style={styles.quickActions}>
            {quickActions.map((action) => (
              <TouchableOpacity
                key={action.route}
                style={styles.quickActionItem}
                activeOpacity={0.7}
                onPress={() => {
                  if ((action as any).onPress) {
                    (action as any).onPress();
                  } else {
                    navigation.navigate(action.route as any);
                  }
                }}
              >
                <View style={[styles.quickActionIcon, { backgroundColor: action.bg }]}>
                  <Ionicons name={action.icon} size={22} color={action.color} />
                </View>
                <Text style={styles.quickActionLabel}>{action.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <View style={styles.bottomSpacer} />
        </ScrollView>
      </View>

      {/* ====== SOS 弹窗 ====== */}
      <SOSCountdownModal
        visible={sosPhase === 'countdown'}
        countdownSeconds={5}
        onCancel={handleSOSCancel}
        onTrigger={handleSOSTrigger}
      />
      <SOSAlertModal
        visible={sosPhase === 'triggered' && sosAlert !== null}
        alert={sosAlert}
        onResolve={handleSOSResolve}
        isReceiver={false}
      />

      {/* ====== 生日祝福弹窗（F4修复） ====== */}
      <BirthdayBlessingModal
        visible={showBirthdayBlessing}
        birthday={birthdayInfo}
        friendBirthdays={friendBirthdays}
        onClose={() => setShowBirthdayBlessing(false)}
      />
    </SafeAreaView>
  );
};

// ====== 样式 ======

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  container: { flex: 1 },
  // 顶部
  header: {
    backgroundColor: Colors.bgWhite, overflow: 'hidden',
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 3, elevation: 2,
  },
  headerGradient: {
    position: 'absolute', top: 0, left: 0, right: 0, height: 3,
    backgroundColor: Colors.primary,
  },
  headerContent: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingTop: Spacing.md, paddingBottom: Spacing.sm,
  },
  headerTitle: { fontSize: 26, fontWeight: '800', color: Colors.primary, letterSpacing: 2 },
  headerRight: { flexDirection: 'row' },
  adminBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: Colors.bgPrimary, alignItems: 'center', justifyContent: 'center',
  },
  // 欢迎区（卡片式）
  welcomeCard: {
    marginHorizontal: Spacing.lg, marginTop: Spacing.lg, marginBottom: Spacing.sm,
    backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 2,
  },
  welcomeInner: {
    flexDirection: 'row', alignItems: 'center', padding: Spacing.lg, gap: Spacing.md,
  },
  welcomeAv: {
    width: 48, height: 48, borderRadius: 24, backgroundColor: Colors.primary + '12',
    alignItems: 'center', justifyContent: 'center',
  },
  welcomeTextGroup: { flex: 1 },
  welcomeText: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  welcomeHint: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  // 签到入口
  checkinEntry: {
    alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: Spacing.sm, paddingVertical: Spacing.xs,
    borderRadius: 8, backgroundColor: Colors.primary + '10',
    minWidth: 52,
  },
  checkinEntryDone: { backgroundColor: Colors.family + '12' },
  checkinEntryText: { fontSize: 10, fontWeight: '600', color: Colors.primary, marginTop: 2 },
  checkinEntryTextDone: { color: Colors.family },
  // 滚动区
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: Spacing.lg, paddingTop: Spacing.lg, paddingBottom: Spacing.xl },
  sectionTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  sectionHeaderRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.sm },
  sectionMore: { fontSize: Typography.caption, color: Colors.primary },
  // 紧凑横向关系列表
  relationGroup: {
    backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    marginBottom: Spacing.sm, paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    borderWidth: StyleSheet.hairlineWidth, borderColor: Colors.divider,
  },
  groupHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: Spacing.xs },
  groupDot: { width: 8, height: 8, borderRadius: 4, marginRight: Spacing.xs },
  groupLabel: { fontSize: Typography.caption, fontWeight: '600', color: Colors.textSecondary, flex: 1 },
  groupCount: { fontSize: 10, color: Colors.textHint },
  horizontalMemberList: { paddingRight: Spacing.md },
  memberChip: {
    alignItems: 'center', marginRight: Spacing.md, width: 56,
  },
  memberAvatarSm: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: Colors.bgPrimary, alignItems: 'center', justifyContent: 'center',
    overflow: 'hidden', marginBottom: 4,
  },
  memberAvatarImgSm: { width: 44, height: 44, borderRadius: 22 },
  memberNameSm: {
    fontSize: 11, color: Colors.textSecondary, textAlign: 'center', maxWidth: 56,
  },
  // 未绑定关系
  emptyRelationGroup: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    paddingVertical: Spacing.sm, paddingHorizontal: Spacing.md,
    backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    marginBottom: Spacing.sm, borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.divider, borderStyle: 'dashed',
  },
  emptyRelationText: { flex: 1, fontSize: Typography.caption, color: Colors.textHint },
  // 快捷功能
  quickActions: {
    flexDirection: 'row', justifyContent: 'space-between',
    marginTop: Spacing.lg, marginBottom: Spacing.lg,
  },
  quickActionItem: { alignItems: 'center', gap: Spacing.xs },
  quickActionIcon: {
    width: 48, height: 48, borderRadius: 24,
    alignItems: 'center', justifyContent: 'center',
  },
  quickActionLabel: { fontSize: Typography.caption, color: Colors.textSecondary },
  bottomSpacer: { height: 24 },
});

export default HomeScreen;
