/**
 * 找回密码页
 * 方案一：管理员验证码改密（向管理员申请验证码→校验→修改密码）
 * 方案二：申请管理员改密（管理员审核后短信通知）
 * 含验证码倒计时 + 改密操作日志
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, KeyboardAvoidingView,
  TouchableOpacity, Alert,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Input, Button } from '../components';
import { changePassword, applyAdminReset } from '../services/auth';
import { requestVerificationCode, verifyCode } from '../services/verificationCode';
import { appendAuthLog } from '../services/storage';
import type { AuthLog } from '../types';

interface ForgotPasswordScreenProps {
  onNavigateLogin: () => void;
}

const SMS_COUNTDOWN_SECONDS = 60;

const ForgotPasswordScreen: React.FC<ForgotPasswordScreenProps> = ({
  onNavigateLogin,
}) => {
  // 方案一：管理员验证码改密
  const [phone, setPhone] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [loading1, setLoading1] = useState(false);
  const [requestingCode, setRequestingCode] = useState(false);
  const [codeRequested, setCodeRequested] = useState(false);

  // 验证码倒计时
  const [countdown, setCountdown] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // 方案二：申请管理员改密
  const [adminPhone, setAdminPhone] = useState('');
  const [reason, setReason] = useState('');
  const [loading2, setLoading2] = useState(false);

  const [activeTab, setActiveTab] = useState<'sms' | 'admin'>('sms');

  // 清理倒计时定时器
  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  // 倒计时管理
  useEffect(() => {
    if (countdown <= 0) {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  }, [countdown]);

  // 记录改密日志
  const recordPasswordChangeLog = async (phoneNumber: string, detail: string, success: boolean) => {
    const log: AuthLog = {
      id: 'log_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
      userId: '',
      phone: phoneNumber,
      action: 'password_change',
      ip: '0.0.0.0',
      deviceInfo: 'React Native',
      timestamp: new Date().toISOString(),
      success,
      detail,
    };
    await appendAuthLog(log);
  };

  // 向管理员申请验证码（含60秒倒计时）
  const handleRequestCode = async () => {
    if (!/^1[3-9]\d{9}$/.test(phone)) {
      Alert.alert('提示', '请先输入正确的手机号');
      return;
    }
    setRequestingCode(true);
    const result = await requestVerificationCode(phone, 'reset_password');
    setRequestingCode(false);
    if (result.success) {
      setCodeRequested(true);
      // 启动60秒倒计时
      setCountdown(SMS_COUNTDOWN_SECONDS);
      timerRef.current = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) return 0;
          return prev - 1;
        });
      }, 1000);
      Alert.alert('验证码已生成', result.message);
    } else {
      Alert.alert('申请失败', result.message);
    }
  };

  // 方案一：验证码改密
  const handleSmsReset = async () => {
    if (!/^1[3-9]\d{9}$/.test(phone)) {
      Alert.alert('提示', '请输入正确的手机号');
      return;
    }
    if (verificationCode.length !== 6) {
      Alert.alert('提示', '请输入6位验证码');
      return;
    }
    if (newPassword.length < 6) {
      Alert.alert('提示', '新密码至少6位');
      return;
    }

    // 先校验验证码
    const verifyResult = await verifyCode(phone, verificationCode, 'reset_password');
    if (!verifyResult.valid) {
      Alert.alert('验证失败', verifyResult.message);
      return;
    }

    setLoading1(true);
    const resp = await changePassword({ phone, smsCode: verificationCode, newPassword });
    setLoading1(false);

    if (resp.code === 200) {
      await recordPasswordChangeLog(phone, '通过验证码修改密码成功', true);
      Alert.alert('成功', '密码修改成功，请重新登录', [
        { text: '去登录', onPress: onNavigateLogin },
      ]);
    } else {
      await recordPasswordChangeLog(phone, `改密失败: ${resp.message}`, false);
      Alert.alert('失败', resp.message);
    }
  };

  // 方案二：申请管理员改密
  const handleAdminReset = async () => {
    if (!/^1[3-9]\d{9}$/.test(adminPhone)) {
      Alert.alert('提示', '请输入正确的手机号');
      return;
    }
    if (!reason.trim()) {
      Alert.alert('提示', '请填写申请原因');
      return;
    }
    setLoading2(true);
    const resp = await applyAdminReset({ phone: adminPhone, reason: reason.trim() });
    setLoading2(false);
    if (resp.code === 200) {
      await recordPasswordChangeLog(adminPhone, '申请管理员协助改密', true);
      Alert.alert('已提交', resp.message, [{ text: '返回登录', onPress: onNavigateLogin }]);
    } else {
      Alert.alert('失败', resp.message);
    }
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior="height"
      >
        <ScrollView
          style={styles.flex}
          contentContainerStyle={styles.container}
          keyboardShouldPersistTaps="handled"
        >
          <TouchableOpacity onPress={onNavigateLogin} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
          </TouchableOpacity>

          <Text style={styles.title}>找回密码</Text>

          {/* 方案切换 Tab */}
          <View style={styles.tabRow}>
            <TouchableOpacity
              style={[styles.tab, activeTab === 'sms' && styles.tabActive]}
              onPress={() => setActiveTab('sms')}
            >
              <Text style={[styles.tabText, activeTab === 'sms' && styles.tabTextActive]}>
                验证码改密
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.tab, activeTab === 'admin' && styles.tabActive]}
              onPress={() => setActiveTab('admin')}
            >
              <Text style={[styles.tabText, activeTab === 'admin' && styles.tabTextActive]}>
                申请管理员改密
              </Text>
            </TouchableOpacity>
          </View>

          {/* 方案一：管理员验证码改密 */}
          {activeTab === 'sms' && (
            <View style={styles.form}>
              <Text style={styles.schemeTitle}>通过管理员验证码修改密码</Text>
              <Text style={styles.hint}>
                点击下方按钮向管理员申请验证码，输入收到的6位数字验证码后即可修改密码。
              </Text>
              <Input
                label="手机号"
                placeholder="请输入注册手机号"
                keyboardType="phone-pad"
                maxLength={11}
                value={phone}
                onChangeText={setPhone}
              />

              {/* 验证码输入 + 申请按钮（含倒计时） */}
              <View style={styles.codeSection}>
                <Text style={styles.codeLabel}>验证码</Text>
                <View style={styles.codeRow}>
                  <View style={styles.codeInputWrap}>
                    <Input
                      label=""
                      placeholder="请输入6位验证码"
                      keyboardType="number-pad"
                      maxLength={6}
                      value={verificationCode}
                      onChangeText={setVerificationCode}
                    />
                  </View>
                  <TouchableOpacity
                    style={[
                      styles.requestCodeBtn,
                      (requestingCode || countdown > 0) && styles.requestCodeBtnDisabled,
                    ]}
                    onPress={handleRequestCode}
                    disabled={requestingCode || countdown > 0}
                    activeOpacity={0.7}
                  >
                    <Text style={styles.requestCodeBtnText}>
                      {requestingCode
                        ? '生成中...'
                        : countdown > 0
                          ? `${countdown}秒`
                          : codeRequested
                            ? '重新申请'
                            : '申请验证码'}
                    </Text>
                  </TouchableOpacity>
                </View>
                {codeRequested && (
                  <Text style={styles.codeHint}>验证码已生成，请输入收到的6位数字</Text>
                )}
              </View>

              <Input
                label="新密码"
                placeholder="请输入新密码（至少6位）"
                secureTextEntry
                value={newPassword}
                onChangeText={setNewPassword}
              />
              <Button title="确认修改" onPress={handleSmsReset} loading={loading1} />
            </View>
          )}

          {/* 方案二：申请管理员改密 */}
          {activeTab === 'admin' && (
            <View style={styles.form}>
              <Text style={styles.schemeTitle}>申请管理员协助修改密码</Text>
              <Text style={styles.hint}>
                提交申请后，管理员将在24小时内审核处理，新密码将以短信方式发送至您的手机。
              </Text>
              <Input
                label="手机号"
                placeholder="请输入注册手机号"
                keyboardType="phone-pad"
                maxLength={11}
                value={adminPhone}
                onChangeText={setAdminPhone}
              />
              <Input
                label="申请原因"
                placeholder="请说明申请改密的原因"
                multiline
                numberOfLines={3}
                value={reason}
                onChangeText={setReason}
                style={styles.textArea}
              />
              <Button title="提交申请" onPress={handleAdminReset} loading={loading2} variant="outline" />
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgWhite },
  flex: { flex: 1 },
  container: {
    flexGrow: 1, paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.lg, paddingBottom: Spacing.xl,
  },
  backBtn: { marginBottom: Spacing.lg },
  title: {
    fontSize: Typography.title, fontWeight: '600',
    color: Colors.textPrimary, textAlign: 'center', marginBottom: Spacing.xl,
  },
  tabRow: {
    flexDirection: 'row', backgroundColor: Colors.bgPrimary,
    borderRadius: 8, padding: 4, marginBottom: Spacing.xl,
  },
  tab: { flex: 1, paddingVertical: Spacing.sm, borderRadius: 6, alignItems: 'center' },
  tabActive: { backgroundColor: Colors.bgWhite },
  tabText: { fontSize: Typography.body, color: Colors.textSecondary },
  tabTextActive: { color: Colors.primary, fontWeight: '600' },
  form: { gap: Spacing.xs },
  schemeTitle: {
    fontSize: Typography.subtitle, fontWeight: '500',
    color: Colors.textPrimary, marginBottom: Spacing.md,
  },
  hint: {
    fontSize: Typography.caption, color: Colors.textHint,
    lineHeight: 18, marginBottom: Spacing.lg,
  },
  // 验证码
  codeSection: { marginBottom: Spacing.sm },
  codeLabel: {
    fontSize: Typography.body, color: Colors.textPrimary,
    marginBottom: Spacing.xs, fontWeight: '500',
  },
  codeRow: { flexDirection: 'row', gap: Spacing.sm, alignItems: 'flex-start' },
  codeInputWrap: { flex: 1 },
  requestCodeBtn: {
    height: 48, paddingHorizontal: Spacing.md,
    backgroundColor: Colors.admin, borderRadius: BorderRadius.input,
    alignItems: 'center', justifyContent: 'center',
    minWidth: 90, marginTop: 0,
  },
  requestCodeBtnDisabled: { backgroundColor: Colors.textHint },
  requestCodeBtnText: {
    fontSize: 12, color: Colors.white, fontWeight: '500',
    textAlign: 'center', lineHeight: 16,
  },
  codeHint: {
    fontSize: Typography.caption, color: Colors.family,
    marginTop: Spacing.xs, fontWeight: '500',
  },
  textArea: { height: 80, textAlignVertical: 'top' },
});

export default ForgotPasswordScreen;
