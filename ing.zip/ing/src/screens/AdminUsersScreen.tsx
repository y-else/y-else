/**
 * 管理员用户管理页面（增强版）
 * 卡片化用户列表 / 搜索筛选 / 注册审核 / 验证码列表 / 长按管理操作
 * 支持：在线筛选、备注标签、分页虚拟列表
 *
 * 修复:
 * - 使用 GlobalStore 真实在线状态（不再Math.random模拟）
 * - 长按菜单增加编辑信息入口
 * - 注销使用 admin.ts 的 deleteUser
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Alert, RefreshControl,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card, SearchBar } from '../components';
import { useAuth } from '../context/AuthContext';
import { getAllRegisteredUsers, getPendingApplications, reviewApplication } from '../services/auth';
import { adminResetPassword, forceUnbind, deleteUser, getAllUsersBrief } from '../services/admin';
import { getAllVerificationCodes, clearUsedCodes } from '../services/verificationCode';
import type { VerificationCodeEntry } from '../services/verificationCode';
import type { RegisterApplication } from '../types';

interface UserBrief {
  userId: string;
  username: string;
  phone: string;
  role: string;
  status: string;
  createdAt: string;
  isOnline?: boolean;
  lastActive?: string;
}

interface AdminUsersScreenProps {
  onBack: () => void;
  onViewUser: (userId: string, username: string) => void;
  onViewUserProfile: (userId: string, username: string) => void;
}

const AdminUsersScreen: React.FC<AdminUsersScreenProps> = ({ onBack, onViewUser, onViewUserProfile }) => {
  const { state } = useAuth();
  const adminId = state.user?.id || 'admin_001';
  const adminName = state.user?.username || '管理员';

  const [users, setUsers] = useState<UserBrief[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<UserBrief[]>([]);
  const [applications, setApplications] = useState<RegisterApplication[]>([]);
  const [verificationCodes, setVerificationCodes] = useState<VerificationCodeEntry[]>([]);
  const [showCodes, setShowCodes] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'disabled' | 'pending' | 'online' | 'offline'>('all');
  const [adminNotes, setAdminNotes] = useState<Record<string, string>>({});

  const loadData = useCallback(async () => {
    // 同时从注册表和GlobalStore获取用户数据
    const [regUsers, gdsUsers] = await Promise.all([
      getAllRegisteredUsers(),
      getAllUsersBrief().catch(() => []),
    ]);

    // 创建gds用户的快速查找Map
    const gdsMap = new Map(gdsUsers.map((u: any) => [u.userId, u]));

    const normalUsers: UserBrief[] = regUsers
      .filter((u) => u.role !== 'admin')
      .map((u) => ({
        userId: u.userId,
        username: u.username,
        phone: u.phone,
        role: u.role,
        status: u.status,
        createdAt: u.createdAt,
        isOnline: gdsMap.get(u.userId)?.isOnline || false,
        lastActive: gdsMap.get(u.userId)?.lastActive || u.updatedAt || new Date().toISOString(),
      }));

    setUsers(normalUsers);
    applyFilter(normalUsers, filterStatus, '');

    const apps = await getPendingApplications();
    setApplications(apps);
    const codes = await getAllVerificationCodes();
    setVerificationCodes(codes);
  }, [filterStatus]);

  useEffect(() => { loadData(); }, [loadData]);

  const handleRefresh = async () => { setRefreshing(true); await loadData(); setRefreshing(false); };

  const applyFilter = (userList: UserBrief[], status: string, query: string) => {
    let result = userList;
    if (query) {
      result = result.filter((u) =>
        u.username.includes(query) || u.phone.includes(query) || u.userId.includes(query),
      );
    }
    if (status === 'online') result = result.filter((u) => u.isOnline);
    else if (status === 'offline') result = result.filter((u) => !u.isOnline);
    else if (status !== 'all') result = result.filter((u) => u.status === status);
    setFilteredUsers(result);
  };

  const handleSearch = (query: string) => applyFilter(users, filterStatus, query);
  const handleClearSearch = () => applyFilter(users, filterStatus, '');

  const handleFilterStatus = (status: typeof filterStatus) => {
    setFilterStatus(status);
    applyFilter(users, status, '');
  };

  // 添加备注
  const handleAddNote = (user: UserBrief) => {
    Alert.alert(
      '添加备注',
      `为 ${user.username} 添加管理备注（当前备注: ${adminNotes[user.userId] || '无'}）`,
      [
        { text: '取消', style: 'cancel' },
        {
          text: '清空备注',
          onPress: () => setAdminNotes((prev) => {
            const n = { ...prev };
            delete n[user.userId];
            return n;
          }),
        },
        {
          text: '输入备注',
          onPress: () => {
            // 用prompt式降级方案
            Alert.alert('输入备注', `请在下方为 ${user.username} 输入备注：`, [
              { text: '取消', style: 'cancel' },
              {
                text: '无备注',
                onPress: () => setAdminNotes((prev) => ({ ...prev, [user.userId]: '无' })),
              },
              {
                text: '重点关注',
                onPress: () => setAdminNotes((prev) => ({ ...prev, [user.userId]: '重点关注' })),
              },
              {
                text: '新用户',
                onPress: () => setAdminNotes((prev) => ({ ...prev, [user.userId]: '新用户' })),
              },
              {
                text: '异常用户',
                onPress: () => setAdminNotes((prev) => ({ ...prev, [user.userId]: '异常用户' })),
              },
            ]);
          },
        },
      ],
    );
  };

  // 注册审核
  const handleReviewApp = (userId: string, approved: boolean) => {
    const action = approved ? '通过' : '驳回';
    Alert.alert(`审核${action}`, `确定${action}该注册申请？`, [
      { text: '取消', style: 'cancel' },
      { text: `确认${action}`, style: approved ? 'default' : 'destructive',
        onPress: async () => { await reviewApplication(userId, approved, adminName); Alert.alert('操作完成'); loadData(); } },
    ]);
  };

  const handleToggleUserStatus = (user: UserBrief) => {
    const targetStatus = user.status === 'active' ? 'disabled' : 'active';
    Alert.alert(`${user.status === 'active' ? '禁用' : '启用'}账号`, `确定${user.status === 'active' ? '禁用' : '启用'}「${user.username}」？`, [
      { text: '取消', style: 'cancel' },
      { text: '确认', style: 'destructive', onPress: async () => {
        await reviewApplication(user.userId, targetStatus === 'active', adminName);
        Alert.alert('操作完成'); loadData();
      }},
    ]);
  };

  const handleResetPassword = (user: UserBrief) => {
    Alert.alert('重置密码', `确定重置「${user.username}」的密码？`, [
      { text: '取消', style: 'cancel' },
      { text: '确认重置', style: 'destructive', onPress: async () => {
        const r = await adminResetPassword(adminId, adminName, user.userId, user.username);
        if (r.success) Alert.alert('密码已重置', `新密码: ${r.newPassword}\n请通知用户及时修改`);
      }},
    ]);
  };

  const handleForceUnbind = (user: UserBrief) => {
    Alert.alert('强制解绑', `确定解除「${user.username}」的所有绑定关系？不可撤销。`, [
      { text: '取消', style: 'cancel' },
      { text: '确认解绑', style: 'destructive', onPress: async () => {
        await forceUnbind(adminId, adminName, user.userId, user.username, '管理员强制解绑');
        Alert.alert('已解绑'); loadData();
      }},
    ]);
  };

  // 注销用户账号（使用admin.ts真实deleteUser）
  const handleDeleteUser = (user: UserBrief) => {
    Alert.alert(
      '注销账号',
      `确定注销「${user.username}」的账号？\n\n注销后该用户将无法登录，所有数据将被清除。此操作不可撤销。`,
      [
        { text: '取消', style: 'cancel' },
        {
          text: '确认注销',
          style: 'destructive',
          onPress: async () => {
            await deleteUser(adminId, adminName, user.userId, user.username);
            Alert.alert('已注销', `用户「${user.username}」的账号已被注销`);
            loadData();
          },
        },
      ],
    );
  };

  const statusColor = (s: string) => ({ active: Colors.family, disabled: Colors.lover, pending: Colors.friend } as any)[s] || Colors.textHint;
  const statusLabel = (s: string) => ({ active: '正常', disabled: '已禁用', pending: '待审核', deleted: '已注销' } as any)[s] || s;

  const formatLastActive = (iso?: string) => {
    if (!iso) return '';
    const diff = Date.now() - new Date(iso).getTime();
    if (diff < 60000) return '1分钟内';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}小时前`;
    return `${Math.floor(diff / 86400000)}天前`;
  };

  const renderUserItem = ({ item }: { item: UserBrief }) => (
    <TouchableOpacity
      style={styles.userCard}
      onPress={() => onViewUserProfile(item.userId, item.username)}
      onLongPress={() => {
        Alert.alert(`管理: ${item.username}`, '', [
          { text: '查看完整资料', onPress: () => onViewUserProfile(item.userId, item.username) },
          { text: '权限管理', onPress: () => onViewUser(item.userId, item.username) },
          { text: '添加备注', onPress: () => handleAddNote(item) },
          { text: '编辑基础信息', onPress: () => onViewUser(item.userId, item.username) },
          { text: item.status === 'active' ? '禁用账号' : '启用账号', onPress: () => handleToggleUserStatus(item) },
          { text: '重置密码', onPress: () => handleResetPassword(item) },
          { text: '强制解绑', onPress: () => handleForceUnbind(item) },
          { text: '注销账号', style: 'destructive', onPress: () => handleDeleteUser(item) },
          { text: '取消', style: 'cancel' },
        ]);
      }}
      activeOpacity={0.7}
    >
      <View style={[styles.statusBar, { backgroundColor: statusColor(item.status) }]} />

      <View style={styles.userContent}>
        <View style={styles.userHeader}>
          <View style={styles.avatarSmall}>
            <Ionicons name="person" size={20} color={Colors.textHint} />
          </View>
          <View style={styles.userInfo}>
            <View style={styles.nameRow}>
              <Text style={styles.userName}>{item.username}</Text>
              <View style={[styles.onlineDot, { backgroundColor: item.isOnline ? Colors.family : Colors.textHint }]} />
              <Text style={styles.onlineText}>{item.isOnline ? '在线' : formatLastActive(item.lastActive)}</Text>
            </View>
            <Text style={styles.userPhone}>{item.phone}</Text>
          </View>
          <View style={styles.userTags}>
            <View style={[styles.statusTag, { backgroundColor: statusColor(item.status) + '20' }]}>
              <Text style={[styles.statusTagText, { color: statusColor(item.status) }]}>
                {statusLabel(item.status)}
              </Text>
            </View>
          </View>
        </View>

        {/* 备注标签 */}
        {adminNotes[item.userId] && (
          <View style={styles.noteRow}>
            <Ionicons name="bookmark" size={12} color={Colors.friend} />
            <Text style={styles.noteText}>{adminNotes[item.userId]}</Text>
          </View>
        )}

        <View style={styles.userFooter}>
          <Text style={styles.footerMeta}>注册: {new Date(item.createdAt).toLocaleDateString('zh-CN')}</Text>
          <Ionicons name="chevron-forward" size={14} color={Colors.textHint} />
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>用户管理</Text>
        <Text style={styles.headerCount}>{users.length}人</Text>
      </View>

      <View style={styles.toolbar}>
        <SearchBar placeholder="搜索昵称/手机号" onSearch={handleSearch} onClear={handleClearSearch} />
        <View style={styles.filterRow}>
          {[
            { key: 'all', label: '全部' },
            { key: 'active', label: '正常' },
            { key: 'pending', label: '待审核' },
            { key: 'disabled', label: '禁用' },
            { key: 'online', label: '在线' },
            { key: 'offline', label: '离线' },
          ].map((f) => (
            <TouchableOpacity
              key={f.key}
              style={[styles.filterBtn, filterStatus === f.key && styles.filterBtnActive]}
              onPress={() => handleFilterStatus(f.key as typeof filterStatus)}
            >
              <Text style={[styles.filterText, filterStatus === f.key && styles.filterTextActive]}>{f.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <FlatList
        data={filteredUsers}
        keyExtractor={(item) => item.userId}
        renderItem={renderUserItem}
        contentContainerStyle={styles.list}
        removeClippedSubviews
        windowSize={8}
        maxToRenderPerBatch={8}
        initialNumToRender={12}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={[Colors.primary]} />}
        ListHeaderComponent={
          <>
            {/* 注册审核 */}
            {applications.length > 0 && (
              <View style={styles.reviewSection}>
                <Text style={styles.sectionTitle}>注册审核 · {applications.length} 待处理</Text>
                {applications.map((app) => (
                  <View key={app.userId} style={styles.appCard}>
                    <View style={styles.appInfo}>
                      <Text style={styles.appName}>{app.username}</Text>
                      <Text style={styles.appPhone}>{app.phone}</Text>
                      <Text style={styles.appTime}>{new Date(app.appliedAt).toLocaleString('zh-CN')}</Text>
                    </View>
                    <View style={styles.appActions}>
                      <TouchableOpacity style={[styles.appBtn, { backgroundColor: Colors.family }]} onPress={() => handleReviewApp(app.userId, true)}>
                        <Text style={styles.appBtnText}>通过</Text>
                      </TouchableOpacity>
                      <TouchableOpacity style={[styles.appBtn, { backgroundColor: Colors.lover }]} onPress={() => handleReviewApp(app.userId, false)}>
                        <Text style={styles.appBtnText}>驳回</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                ))}
              </View>
            )}
            {/* 验证码列表 */}
            {verificationCodes.length > 0 && (
              <View style={styles.reviewSection}>
                <TouchableOpacity style={styles.sectionHeaderRow} onPress={() => setShowCodes(!showCodes)} activeOpacity={0.7}>
                  <Text style={styles.sectionTitle}>验证码 · {verificationCodes.filter((c) => !c.isUsed).length} 待用</Text>
                  <Ionicons name={showCodes ? 'chevron-up' : 'chevron-down'} size={16} color={Colors.textHint} />
                </TouchableOpacity>
                {showCodes && verificationCodes.map((vc) => (
                  <View key={vc.id} style={[styles.codeCard, vc.isUsed && { opacity: 0.5 }]}>
                    <Text style={styles.codePhone}>{vc.phone}</Text>
                    <Text style={styles.codeValue}>{vc.code}</Text>
                    <Text style={styles.codeTime}>{vc.type === 'register' ? '注册' : '改密'} · {new Date(vc.createdAt).toLocaleString('zh-CN')}</Text>
                  </View>
                ))}
              </View>
            )}
          </>
        }
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="people-outline" size={48} color={Colors.textHint} />
            <Text style={styles.emptyText}>暂无匹配用户</Text>
          </View>
        }
        ListFooterComponent={filteredUsers.length > 0 ? (
          <Text style={styles.footerHint}>点击查看完整资料 · 长按快捷管理</Text>
        ) : null}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  headerCount: { fontSize: Typography.caption, color: Colors.textHint },
  toolbar: { padding: Spacing.lg, backgroundColor: Colors.bgWhite },
  filterRow: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xs, marginTop: Spacing.md },
  filterBtn: {
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.input, borderWidth: 1, borderColor: Colors.divider,
    backgroundColor: Colors.bgWhite, marginBottom: 4,
  },
  filterBtnActive: { backgroundColor: Colors.admin, borderColor: Colors.admin },
  filterText: { fontSize: Typography.caption, color: Colors.textSecondary },
  filterTextActive: { color: Colors.white, fontWeight: '500' },
  list: { padding: Spacing.lg },
  sectionTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.md },
  // 用户卡片
  userCard: {
    flexDirection: 'row', backgroundColor: Colors.bgWhite,
    borderRadius: BorderRadius.card, marginBottom: Spacing.sm,
    overflow: 'hidden', elevation: 1, shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 2,
  },
  statusBar: { width: 3 },
  userContent: { flex: 1, padding: Spacing.md },
  userHeader: { flexDirection: 'row', alignItems: 'center' },
  avatarSmall: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.bgPrimary,
    alignItems: 'center', justifyContent: 'center', marginRight: Spacing.md,
  },
  userInfo: { flex: 1 },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
  userName: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary },
  onlineDot: { width: 6, height: 6, borderRadius: 3 },
  onlineText: { fontSize: 10, color: Colors.textHint },
  userPhone: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  userTags: {},
  statusTag: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 4 },
  statusTagText: { fontSize: 10, fontWeight: '600' },
  noteRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: Spacing.sm, backgroundColor: Colors.friend + '12', padding: 6, borderRadius: 4 },
  noteText: { fontSize: Typography.caption, color: Colors.textSecondary, flex: 1 },
  userFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: Spacing.sm, paddingTop: Spacing.sm, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider },
  footerMeta: { fontSize: 10, color: Colors.textHint },
  // 审核
  reviewSection: { marginBottom: Spacing.lg },
  appCard: {
    backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    padding: Spacing.lg, marginBottom: Spacing.sm,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    borderLeftWidth: 3, borderLeftColor: Colors.friend,
  },
  appInfo: { flex: 1 },
  appName: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  appPhone: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  appTime: { fontSize: 10, color: Colors.textHint, marginTop: 4 },
  appActions: { flexDirection: 'row', gap: Spacing.sm },
  appBtn: { paddingHorizontal: Spacing.lg, paddingVertical: Spacing.xs, borderRadius: 4 },
  appBtnText: { fontSize: Typography.caption, color: Colors.white, fontWeight: '600' },
  // 验证码
  sectionHeaderRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.md },
  codeCard: {
    backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    padding: Spacing.md, marginBottom: Spacing.sm,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    borderLeftWidth: 3, borderLeftColor: Colors.admin,
  },
  codePhone: { fontSize: Typography.caption, color: Colors.textSecondary },
  codeValue: { fontSize: Typography.body, fontWeight: '700', color: Colors.admin, fontFamily: 'monospace' },
  codeTime: { fontSize: 10, color: Colors.textHint },
  // 底部
  footerHint: { fontSize: Typography.caption, color: Colors.textHint, textAlign: 'center', paddingVertical: Spacing.lg },
  empty: { alignItems: 'center', paddingVertical: Spacing.xl * 3 },
  emptyText: { fontSize: Typography.body, color: Colors.textHint, marginTop: Spacing.md },
});

export default AdminUsersScreen;
