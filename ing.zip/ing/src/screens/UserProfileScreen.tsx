/**
 * 用户主页（公开可查看）
 * 等级/点赞/留言墙/生日提醒
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, TextInput, Image,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card, Button, LevelBadge } from '../components';
import { useAuth } from '../context/AuthContext';
import {
  getPublicProfile, toggleProfileLike, getProfileLikes,
  getWallMessages, addWallMessage, deleteWallMessage,
  checkTodayBirthday, getFriendBirthdays,
} from '../services/profile';
import { getNextLevelProgress } from '../services/level';
import type { PublicProfile, LikeRecord, WallMessage, BirthdayInfo, BirthdayReminder } from '../types';

interface UserProfileScreenProps {
  userId: string;
  onBack: () => void;
  onEditProfile: () => void;
}

const UserProfileScreen: React.FC<UserProfileScreenProps> = ({ userId, onBack, onEditProfile }) => {
  const { state } = useAuth();
  const currentUser = state.user;
  const isOwner = currentUser?.id === userId;

  const [profile, setProfile] = useState<PublicProfile | null>(null);
  const [likeRecord, setLikeRecord] = useState<LikeRecord | null>(null);
  const [messages, setMessages] = useState<WallMessage[]>([]);
  const [levelProgress, setLevelProgress] = useState({ currentLevel: 0, progress: 0 });
  const [birthday, setBirthday] = useState<BirthdayInfo | null>(null);
  const [friendBirthdays, setFriendBirthdays] = useState<BirthdayReminder[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [showBirthdayModal, setShowBirthdayModal] = useState(false);

  useEffect(() => {
    loadProfile();
  }, [userId]);

  const loadProfile = async () => {
    const p = await getPublicProfile(userId);
    setProfile(p);
    const likes = await getProfileLikes(userId, currentUser?.id || '');
    setLikeRecord(likes);
    const msgs = await getWallMessages(userId);
    setMessages(msgs);
    const lp = await getNextLevelProgress();
    setLevelProgress(lp);
    const bday = await checkTodayBirthday(userId);
    if (bday?.isToday) {
      setBirthday(bday);
      setShowBirthdayModal(true);
      const friends = await getFriendBirthdays(userId);
      setFriendBirthdays(friends);
    }
  };

  // 点赞
  const handleLike = async () => {
    if (!currentUser) return;
    const result = await toggleProfileLike(userId, currentUser.id, currentUser.username, currentUser.avatar);
    setLikeRecord((prev) => prev ? { ...prev, totalLikes: result.totalLikes } : null);
    Alert.alert(result.message);
  };

  // 留言
  const handleAddMessage = async () => {
    if (!newMessage.trim() || !currentUser) return;
    const msg = await addWallMessage(userId, currentUser.id, currentUser.username, currentUser.avatar, newMessage.trim());
    setMessages((prev) => [msg, ...prev]);
    setNewMessage('');
  };

  const handleDeleteMessage = (msgId: string) => {
    Alert.alert('删除留言', '确定删除此留言？', [
      { text: '取消', style: 'cancel' },
      {
        text: '删除', style: 'destructive',
        onPress: async () => {
          await deleteWallMessage(msgId, userId);
          setMessages((prev) => prev.filter((m) => m.id !== msgId));
        },
      },
    ]);
  };

  if (!profile) return null;

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.container}>
        {/* 返回 */}
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>

        {/* 头像区 */}
        <View style={styles.profileHeader}>
          <View style={styles.avatarLarge}>
            <Ionicons name="person" size={52} color={Colors.textHint} />
          </View>
          <Text style={styles.username}>{profile.username}</Text>
          <LevelBadge level={profile.level} progress={levelProgress.progress} />
          <Text style={styles.bio}>{profile.bio || '这个人很懒，什么都没写'}</Text>
          <View style={styles.meta}>
            <Ionicons name="location-outline" size={12} color={Colors.textHint} />
            <Text style={styles.metaText}>{profile.location}</Text>
            <Text style={styles.metaText}>·</Text>
            <Text style={styles.metaText}>累计 {profile.totalMinutes} 分钟</Text>
          </View>
        </View>

        {/* 生日祝福弹窗 */}
        {showBirthdayModal && birthday && (
          <Card style={styles.birthdayCard}>
            <Ionicons name="gift" size={32} color="#FF6B6B" />
            <Text style={styles.birthdayTitle}>生日快乐！</Text>
            <Text style={styles.birthdayText}>
              今天是你 {birthday.age} 岁生日，ing 陪伴祝你生日快乐！
            </Text>
            {friendBirthdays.map((f) => (
              <Text key={f.friendUserId} style={styles.birthdayRemind}>
                今天是 {f.friendUsername} 的生日，记得送祝福哦
              </Text>
            ))}
            <Button title="谢谢！" onPress={() => setShowBirthdayModal(false)} style={styles.birthdayBtn} />
          </Card>
        )}

        {/* 点赞区 */}
        <Card>
          <View style={styles.likeRow}>
            <TouchableOpacity style={styles.likeBtn} onPress={handleLike}>
              <Ionicons name="heart" size={28} color={Colors.lover} />
            </TouchableOpacity>
            <View style={styles.likeInfo}>
              <Text style={styles.likeCount}>{likeRecord?.totalLikes || 0} 人赞过</Text>
              {isOwner && likeRecord && likeRecord.likeList.length > 0 && (
                <Text style={styles.likeList}>
                  {likeRecord.likeList.map((l) => l.username).join('、')}
                </Text>
              )}
              {!isOwner && (
                <Text style={styles.likeHint}>名单仅主人可见</Text>
              )}
            </View>
          </View>
        </Card>

        {/* 留言墙 */}
        <Card>
          <Text style={styles.sectionTitle}>
            留言墙 ({messages.length})
          </Text>
          {/* 留言输入 */}
          <View style={styles.msgInputRow}>
            <TextInput
              style={styles.msgInput}
              placeholder="留下你的足迹..."
              placeholderTextColor={Colors.textHint}
              value={newMessage}
              onChangeText={setNewMessage}
              onSubmitEditing={handleAddMessage}
            />
            <TouchableOpacity onPress={handleAddMessage}>
              <Ionicons name="send" size={20} color={Colors.primary} />
            </TouchableOpacity>
          </View>
          {/* 留言列表 */}
          {messages.map((m) => (
            <View key={m.id} style={styles.msgItem}>
              <View style={styles.msgAvatar}>
                <Ionicons name="person" size={16} color={Colors.textHint} />
              </View>
              <View style={styles.msgContent}>
                <Text style={styles.msgAuthor}>{m.authorName}</Text>
                <Text style={styles.msgText}>{m.content}</Text>
                <Text style={styles.msgTime}>
                  {new Date(m.createdAt).toLocaleDateString('zh-CN')}
                </Text>
              </View>
              {isOwner && (
                <TouchableOpacity onPress={() => handleDeleteMessage(m.id)}>
                  <Ionicons name="trash-outline" size={14} color={Colors.textHint} />
                </TouchableOpacity>
              )}
            </View>
          ))}
        </Card>

        {/* 编辑入口（仅主人） */}
        {isOwner && (
          <Button title="编辑资料" variant="outline" onPress={onEditProfile} style={styles.editBtn} />
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  container: { paddingBottom: Spacing.xl * 2 },
  backBtn: { padding: Spacing.lg },
  profileHeader: { alignItems: 'center', paddingVertical: Spacing.lg },
  avatarLarge: {
    width: 100, height: 100, borderRadius: 50, backgroundColor: Colors.bgWhite,
    alignItems: 'center', justifyContent: 'center', marginBottom: Spacing.lg,
  },
  username: { fontSize: Typography.title, fontWeight: '700', color: Colors.textPrimary, marginBottom: Spacing.sm },
  bio: { fontSize: Typography.body, color: Colors.textSecondary, marginTop: Spacing.sm, textAlign: 'center', paddingHorizontal: Spacing.xl },
  meta: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, marginTop: Spacing.sm },
  metaText: { fontSize: Typography.caption, color: Colors.textHint },
  // 生日
  birthdayCard: { marginHorizontal: Spacing.lg, marginBottom: Spacing.md, alignItems: 'center' },
  birthdayTitle: { fontSize: Typography.title, fontWeight: '700', color: '#FF6B6B', marginTop: Spacing.sm },
  birthdayText: { fontSize: Typography.body, color: Colors.textSecondary, marginTop: Spacing.sm, textAlign: 'center' },
  birthdayRemind: { fontSize: Typography.caption, color: Colors.friend, marginTop: 4 },
  birthdayBtn: { marginTop: Spacing.lg, width: '100%' },
  // 点赞
  likeRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.lg },
  likeBtn: {
    width: 56, height: 56, borderRadius: 28, backgroundColor: '#FFF0F0',
    alignItems: 'center', justifyContent: 'center',
  },
  likeInfo: { flex: 1 },
  likeCount: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  likeList: { fontSize: Typography.caption, color: Colors.textSecondary, marginTop: 2 },
  likeHint: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  // 留言
  sectionTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.md },
  msgInputRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    marginBottom: Spacing.lg, backgroundColor: Colors.bgPrimary,
    borderRadius: BorderRadius.card, paddingHorizontal: Spacing.md,
  },
  msgInput: { flex: 1, height: 40, fontSize: Typography.body, color: Colors.textPrimary },
  msgItem: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm, paddingVertical: Spacing.sm, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider },
  msgAvatar: {
    width: 32, height: 32, borderRadius: 16, backgroundColor: Colors.bgPrimary,
    alignItems: 'center', justifyContent: 'center',
  },
  msgContent: { flex: 1 },
  msgAuthor: { fontSize: Typography.caption, fontWeight: '600', color: Colors.textPrimary },
  msgText: { fontSize: Typography.body, color: Colors.textSecondary, marginTop: 2 },
  msgTime: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  editBtn: { marginHorizontal: Spacing.lg, marginTop: Spacing.lg },
});

export default UserProfileScreen;
