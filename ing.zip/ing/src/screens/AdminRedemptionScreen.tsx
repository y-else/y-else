/**
 * 管理员兑换码管理系统
 * 生成兑换码/设置奖励/指定用户/查看记录/作废兑换
 *
 * 修复:
 * - 添加统计面板（总码数/有效/已兑完/过期/兑换次数）
 * - 添加搜索框（码列表 + 记录列表双搜索）
 * - 添加类型/状态筛选
 * - 修复 filter(Boolean) as any TS 问题
 * - 添加批量作废模式
 * - validFrom 可配日期
 * - 指定用户ID支持
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert,
  TextInput, RefreshControl,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card, Modal } from '../components';
import { useAuth } from '../context/AuthContext';
import {
  getAllRedemptionCodes, getAllRedemptionRecords,
  createRedemptionCode, deactivateCode, cancelRedemption,
  batchDeactivateCodes, searchCodes, searchRecords, getRedemptionStats,
} from '../services/redemptionCode';
import type {
  RedemptionCode, RedemptionRecord, RedemptionStats,
  RedemptionCodeFilterType, RedemptionCodeFilterStatus,
} from '../types';

interface Props { onBack: () => void; }

const AdminRedemptionScreen: React.FC<Props> = ({ onBack }) => {
  const { state } = useAuth();
  const adminId = state.user?.id || '';
  const adminName = state.user?.username || '管理员';

  const [codes, setCodes] = useState<RedemptionCode[]>([]);
  const [records, setRecords] = useState<RedemptionRecord[]>([]);
  const [stats, setStats] = useState<RedemptionStats>({
    totalCodes: 0, activeCodes: 0, exhaustedCodes: 0, expiredCodes: 0, inactiveCodes: 0,
    totalRedemptions: 0, totalCancelled: 0,
  });
  const [refreshing, setRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState<'codes' | 'records'>('codes');

  // 筛选
  const [typeFilter, setTypeFilter] = useState<RedemptionCodeFilterType>('all');
  const [statusFilter, setStatusFilter] = useState<RedemptionCodeFilterStatus>('all');
  const [codeSearch, setCodeSearch] = useState('');
  const [recordSearch, setRecordSearch] = useState('');

  // 批量作废
  const [batchMode, setBatchMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // 新建弹窗
  const [showCreate, setShowCreate] = useState(false);
  const [formRewardName, setFormRewardName] = useState('');
  const [formRewardDesc, setFormRewardDesc] = useState('');
  const [formRewardType, setFormRewardType] = useState<'virtual' | 'physical'>('virtual');
  const [formTargetPhone, setFormTargetPhone] = useState('');
  const [formTargetUser, setFormTargetUser] = useState('');
  const [formMaxUse, setFormMaxUse] = useState('1');
  const [formPerUser, setFormPerUser] = useState('1');
  const [formValidFromDays, setFormValidFromDays] = useState('0'); // 0=立即生效
  const [formValidDays, setFormValidDays] = useState('30');
  const [creating, setCreating] = useState(false);

  // 记录搜索
  const [recordsQuery, setRecordsQuery] = useState('');

  const loadData = useCallback(async () => {
    try {
      const [c, r, s] = await Promise.all([
        getAllRedemptionCodes(),
        getAllRedemptionRecords(),
        getRedemptionStats(),
      ]);
      setCodes(c);
      setRecords(r);
      setStats(s);
    } catch {}
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleRefresh = async () => { setRefreshing(true); await loadData(); setRefreshing(false); };

  // 应用筛选
  const filteredCodes = (() => {
    let result = codes;
    if (typeFilter !== 'all') result = result.filter((c) => c.rewardType === typeFilter);
    if (statusFilter !== 'all') {
      const now = new Date();
      result = result.filter((c) => {
        switch (statusFilter) {
          case 'active': return c.isActive && new Date(c.validUntil) >= now && c.redeemedCount < c.maxRedemptions;
          case 'inactive': return !c.isActive;
          case 'expired': return c.isActive && new Date(c.validUntil) < now;
          case 'exhausted': return c.isActive && c.redeemedCount >= c.maxRedemptions;
          default: return true;
        }
      });
    }
    if (codeSearch.trim()) {
      const q = codeSearch.trim().toUpperCase();
      result = result.filter(
        (c) => c.code.includes(q) || c.rewardName.toUpperCase().includes(q),
      );
    }
    return result;
  })();

  const filteredRecords = (() => {
    let result = records;
    if (recordsQuery.trim()) {
      const q = recordsQuery.trim();
      result = result.filter(
        (r) =>
          r.code.includes(q) || r.username.includes(q) || r.phone.includes(q) || r.rewardName.includes(q),
      );
    }
    return result;
  })();

  // 创建兑换码
  const handleCreate = async () => {
    if (!formRewardName.trim()) { Alert.alert('提示', '请输入奖励名称'); return; }
    setCreating(true);
    const validFrom = new Date(Date.now() + parseInt(formValidFromDays || '0') * 86400000).toISOString();
    const validUntil = new Date(Date.now() + parseInt(formValidDays) * 86400000).toISOString();
    await createRedemptionCode({
      rewardType: formRewardType,
      rewardName: formRewardName.trim(),
      rewardDescription: formRewardDesc.trim(),
      targetPhone: formTargetPhone.trim() || null,
      targetUserId: formTargetUser.trim() || null,
      maxRedemptions: parseInt(formMaxUse) || 1,
      perUserLimit: parseInt(formPerUser) || 1,
      validFrom,
      validUntil,
      createdBy: adminName,
      adminId,
      adminName,
    });
    setCreating(false);
    setShowCreate(false);
    resetForm();
    Alert.alert('已生成', '兑换码已创建成功');
    loadData();
  };

  const resetForm = () => {
    setFormRewardName(''); setFormRewardDesc(''); setFormRewardType('virtual');
    setFormTargetPhone(''); setFormTargetUser(''); setFormMaxUse('1');
    setFormPerUser('1'); setFormValidFromDays('0'); setFormValidDays('30');
  };

  // 作废兑换码
  const handleDeactivate = (code: RedemptionCode) => {
    Alert.alert('作废兑换码', `确定作废 ${code.code}（${code.rewardName}）？\n此操作不可撤销。`, [
      { text: '取消', style: 'cancel' },
      { text: '作废', style: 'destructive', onPress: async () => {
        await deactivateCode(code.id, adminId, adminName);
        Alert.alert('已作废', '兑换码已失效');
        loadData();
      }},
    ]);
  };

  // 批量作废
  const handleBatchDeactivate = () => {
    if (selectedIds.size === 0) { Alert.alert('提示', '请先选择需要作废的兑换码'); return; }
    Alert.alert(
      '批量作废',
      `确定作废选中的 ${selectedIds.size} 个兑换码？`,
      [
        { text: '取消', style: 'cancel' },
        { text: '确认作废', style: 'destructive', onPress: async () => {
          const count = await batchDeactivateCodes([...selectedIds], adminId, adminName);
          setSelectedIds(new Set());
          setBatchMode(false);
          Alert.alert('已完成', `已作废 ${count} 个兑换码`);
          loadData();
        }},
      ],
    );
  };

  const toggleSelect = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id); else next.add(id);
    setSelectedIds(next);
  };

  // 取消兑换记录
  const handleCancelRecord = (rec: RedemptionRecord) => {
    if (rec.status === 'cancelled') return;
    Alert.alert('取消兑换', `确定取消 ${rec.username} 的兑换？`, [
      { text: '关闭', style: 'cancel' },
      { text: '取消兑换', style: 'destructive', onPress: async () => {
        await cancelRedemption(rec.id, adminId, adminName);
        Alert.alert('已取消', '该兑换已被取消，兑换码次数已回退');
        loadData();
      }},
    ]);
  };

  // 复制兑换码
  const handleCopy = (code: string) => {
    try {
      const Clipboard = require('expo-clipboard');
      Clipboard.setStringAsync(code);
      Alert.alert('已复制', `兑换码 ${code} 已复制到剪贴板`);
    } catch {
      Alert.alert('提示', code);
    }
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      {/* 头部 */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>兑换码管理</Text>
        <View style={styles.headerRight}>
          {activeTab === 'codes' && (
            <TouchableOpacity
              style={styles.headerBtn}
              onPress={() => {
                if (batchMode) { setBatchMode(false); setSelectedIds(new Set()); }
                else setBatchMode(true);
              }}
            >
              <Ionicons name={batchMode ? 'close-circle' : 'checkbox-outline'} size={22} color={batchMode ? Colors.lover : Colors.textSecondary} />
            </TouchableOpacity>
          )}
          <TouchableOpacity onPress={() => { resetForm(); setShowCreate(true); }}>
            <Ionicons name="add-circle" size={28} color={Colors.admin} />
          </TouchableOpacity>
        </View>
      </View>

      {/* 统计面板 */}
      <View style={styles.statsBar}>
        <View style={styles.statItem}><Text style={styles.statValue}>{stats.totalCodes}</Text><Text style={styles.statLabel}>总码</Text></View>
        <View style={styles.statItem}><Text style={[styles.statValue, { color: Colors.family }]}>{stats.activeCodes}</Text><Text style={styles.statLabel}>有效</Text></View>
        <View style={styles.statItem}><Text style={[styles.statValue, { color: Colors.friend }]}>{stats.exhaustedCodes}</Text><Text style={styles.statLabel}>已兑完</Text></View>
        <View style={styles.statItem}><Text style={[styles.statValue, { color: Colors.textHint }]}>{stats.expiredCodes}</Text><Text style={styles.statLabel}>过期</Text></View>
        <View style={styles.statItem}><Text style={[styles.statValue, { color: Colors.lover }]}>{stats.inactiveCodes}</Text><Text style={styles.statLabel}>已作废</Text></View>
        <View style={styles.statItem}><Text style={styles.statValue}>{stats.totalRedemptions}</Text><Text style={styles.statLabel}>兑换次数</Text></View>
      </View>

      {/* Tab切换 */}
      <View style={styles.tabRow}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'codes' && styles.tabActive]}
          onPress={() => { setActiveTab('codes'); setBatchMode(false); setSelectedIds(new Set()); }}
        >
          <Text style={[styles.tabText, activeTab === 'codes' && styles.tabTextActive]}>
            兑换码 ({codes.length})
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'records' && styles.tabActive]}
          onPress={() => setActiveTab('records')}
        >
          <Text style={[styles.tabText, activeTab === 'records' && styles.tabTextActive]}>
            兑换记录 ({records.length})
          </Text>
        </TouchableOpacity>
      </View>

      {/* 筛选栏（仅码列表） */}
      {activeTab === 'codes' && (
        <>
          <View style={styles.searchRow}>
            <TextInput
              style={styles.searchInput}
              placeholder="搜索兑换码/奖励名称"
              placeholderTextColor={Colors.textHint}
              value={codeSearch}
              onChangeText={setCodeSearch}
              autoCapitalize="characters"
            />
            {codeSearch.length > 0 && (
              <TouchableOpacity onPress={() => setCodeSearch('')}>
                <Ionicons name="close-circle" size={18} color={Colors.textHint} />
              </TouchableOpacity>
            )}
          </View>
          <View style={styles.filterRow}>
            {(['all', 'virtual', 'physical'] as RedemptionCodeFilterType[]).map((f) => (
              <TouchableOpacity
                key={f}
                style={[styles.fBtn, typeFilter === f && styles.fBtnActive]}
                onPress={() => setTypeFilter(f)}
              >
                <Text style={[styles.fText, typeFilter === f && styles.fTextActive]}>
                  {{ all: '全部', virtual: '虚拟', physical: '实物' }[f]}
                </Text>
              </TouchableOpacity>
            ))}
            <View style={styles.fSep} />
            {(['all', 'active', 'exhausted', 'expired', 'inactive'] as RedemptionCodeFilterStatus[]).map((f) => (
              <TouchableOpacity
                key={f}
                style={[styles.fBtn, statusFilter === f && styles.fBtnActive]}
                onPress={() => setStatusFilter(f)}
              >
                <Text style={[styles.fText, statusFilter === f && styles.fTextActive]}>
                  {{ all: '全部状态', active: '有效', exhausted: '已兑完', expired: '已过期', inactive: '已作废' }[f]}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          {batchMode && (
            <View style={styles.batchBar}>
              <Text style={styles.batchText}>已选 {selectedIds.size} 项</Text>
              <TouchableOpacity style={styles.batchBtn} onPress={handleBatchDeactivate}>
                <Text style={styles.batchBtnText}>批量作废</Text>
              </TouchableOpacity>
            </View>
          )}
        </>
      )}

      {/* 记录搜索 */}
      {activeTab === 'records' && (
        <View style={styles.searchRow}>
          <TextInput
            style={styles.searchInput}
            placeholder="搜索用户名/手机号/兑换码"
            placeholderTextColor={Colors.textHint}
            value={recordsQuery}
            onChangeText={setRecordsQuery}
          />
          {recordsQuery.length > 0 && (
            <TouchableOpacity onPress={() => setRecordsQuery('')}>
              <Ionicons name="close-circle" size={18} color={Colors.textHint} />
            </TouchableOpacity>
          )}
        </View>
      )}

      {/* 内容区 */}
      <ScrollView
        contentContainerStyle={styles.container}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
      >
        {/* 兑换码列表 */}
        {activeTab === 'codes' && (
          filteredCodes.length === 0 ? (
            <View style={styles.empty}>
              <Ionicons name="pricetags-outline" size={48} color={Colors.textHint} />
              <Text style={styles.emptyText}>{codes.length === 0 ? '暂无兑换码' : '无匹配结果'}</Text>
            </View>
          ) : (
            filteredCodes.map((c) => {
              const isExpired = new Date(c.validUntil) < new Date();
              const isExhausted = c.redeemedCount >= c.maxRedemptions;
              const isSelected = selectedIds.has(c.id);

              return (
                <TouchableOpacity
                  key={c.id}
                  activeOpacity={batchMode ? 0.6 : 1}
                  onPress={batchMode ? () => toggleSelect(c.id) : undefined}
                  onLongPress={() => handleCopy(c.code)}
                >
                  <Card style={{
                    ...styles.codeCard,
                    ...(!c.isActive ? styles.codeInactive : {}),
                    ...(isSelected ? styles.codeSelected : {}),
                  } as any}>
                    <View style={styles.codeHeader}>
                      <Text style={styles.codeValue}>{c.code}</Text>
                      <View style={styles.codeBadges}>
                        <View style={[styles.typeBadge, { backgroundColor: c.rewardType === 'physical' ? Colors.friend + '20' : Colors.primary + '20' }]}>
                          <Text style={[styles.typeBadgeText, { color: c.rewardType === 'physical' ? Colors.friend : Colors.primary }]}>
                            {c.rewardType === 'physical' ? '实物' : '虚拟'}
                          </Text>
                        </View>
                        {!c.isActive && <Text style={styles.statusTag}>已作废</Text>}
                        {c.isActive && isExpired && <Text style={[styles.statusTag, { color: Colors.textHint }]}>已过期</Text>}
                        {c.isActive && !isExpired && isExhausted && <Text style={[styles.statusTag, { color: Colors.friend }]}>已兑完</Text>}
                      </View>
                    </View>
                    <Text style={styles.rewardName}>{c.rewardName}</Text>
                    {c.rewardDescription ? <Text style={styles.rewardDesc}>{c.rewardDescription}</Text> : null}
                    <View style={styles.codeMeta}>
                      <Text style={styles.metaText}>
                        已兑 {c.redeemedCount}/{c.maxRedemptions} · 限{c.perUserLimit}次/人
                      </Text>
                      {(c.targetPhone || c.targetUserId) && (
                        <Text style={styles.metaTarget}>
                          指定: {c.targetPhone || c.targetUserId}
                        </Text>
                      )}
                      <Text style={styles.metaDate}>
                        {new Date(c.validFrom).toLocaleDateString('zh-CN')} 至 {new Date(c.validUntil).toLocaleDateString('zh-CN')}
                      </Text>
                    </View>
                    {c.isActive && !batchMode && (
                      <TouchableOpacity style={styles.deactBtn} onPress={() => handleDeactivate(c)}>
                        <Text style={styles.deactText}>作废</Text>
                      </TouchableOpacity>
                    )}
                  </Card>
                </TouchableOpacity>
              );
            })
          )
        )}

        {/* 兑换记录列表 */}
        {activeTab === 'records' && (
          filteredRecords.length === 0 ? (
            <View style={styles.empty}>
              <Ionicons name="receipt-outline" size={48} color={Colors.textHint} />
              <Text style={styles.emptyText}>{records.length === 0 ? '暂无兑换记录' : '无匹配结果'}</Text>
            </View>
          ) : (
            filteredRecords.map((r) => (
              <Card key={r.id} style={styles.recordCard}>
                <View style={styles.recordHeader}>
                  <Text style={styles.recordCode}>{r.code}</Text>
                  <Text style={styles.recordReward}>{r.rewardName}</Text>
                  {r.status === 'cancelled' && <Text style={styles.cancelledTag}>已取消</Text>}
                </View>
                <Text style={styles.recordUser}>{r.username} ({r.phone})</Text>
                {r.shippingAddress && (
                  <View style={styles.addressBox}>
                    <Text style={styles.addressTitle}>收货地址：</Text>
                    <Text style={styles.addressText}>
                      {r.shippingAddress.name} {r.shippingAddress.phone}
                    </Text>
                    <Text style={styles.addressText}>
                      {r.shippingAddress.province}{r.shippingAddress.city}{r.shippingAddress.district} {r.shippingAddress.detail}
                    </Text>
                  </View>
                )}
                <Text style={styles.recordTime}>{new Date(r.redeemedAt).toLocaleString('zh-CN')}</Text>
                {r.status === 'success' && (
                  <TouchableOpacity style={styles.cancelBtn} onPress={() => handleCancelRecord(r)}>
                    <Text style={styles.cancelText}>取消兑换</Text>
                  </TouchableOpacity>
                )}
              </Card>
            ))
          )
        )}
        <View style={{ height: 40 }} />
      </ScrollView>

      {/* 新建兑换码弹窗 */}
      <Modal
        visible={showCreate}
        title="生成兑换码"
        onClose={() => setShowCreate(false)}
        confirmText={creating ? '生成中...' : '生成'}
        onConfirm={handleCreate}
      >
        <Text style={styles.formLabel}>奖励名称 *</Text>
        <TextInput style={styles.formInput} placeholder="如：VIP会员30天" placeholderTextColor={Colors.textHint} value={formRewardName} onChangeText={setFormRewardName} />

        <Text style={styles.formLabel}>奖励描述（选填）</Text>
        <TextInput style={styles.formInput} placeholder="简短描述" placeholderTextColor={Colors.textHint} value={formRewardDesc} onChangeText={setFormRewardDesc} />

        <Text style={styles.formLabel}>奖励类型</Text>
        <View style={styles.typeRow}>
          <TouchableOpacity
            style={[styles.typeBtn, formRewardType === 'virtual' && { backgroundColor: Colors.primary, borderColor: Colors.primary }]}
            onPress={() => setFormRewardType('virtual')}
          >
            <Text style={[styles.typeBtnText, formRewardType === 'virtual' && { color: '#FFF' }]}>虚拟奖励</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.typeBtn, formRewardType === 'physical' && { backgroundColor: Colors.friend, borderColor: Colors.friend }]}
            onPress={() => setFormRewardType('physical')}
          >
            <Text style={[styles.typeBtnText, formRewardType === 'physical' && { color: '#FFF' }]}>实物奖励</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.formLabel}>指定用户手机号（选填）</Text>
        <TextInput style={styles.formInput} placeholder="留空则全体用户可用" placeholderTextColor={Colors.textHint} keyboardType="phone-pad" maxLength={11} value={formTargetPhone} onChangeText={setFormTargetPhone} />

        <Text style={styles.formLabel}>指定用户ID（选填）</Text>
        <TextInput style={styles.formInput} placeholder="留空则全体用户可用" placeholderTextColor={Colors.textHint} value={formTargetUser} onChangeText={setFormTargetUser} />

        <View style={styles.formRow}>
          <View style={styles.formHalf}>
            <Text style={styles.formLabel}>总可兑次数</Text>
            <TextInput style={styles.formInput} keyboardType="number-pad" value={formMaxUse} onChangeText={setFormMaxUse} />
          </View>
          <View style={styles.formHalf}>
            <Text style={styles.formLabel}>每人限兑</Text>
            <TextInput style={styles.formInput} keyboardType="number-pad" value={formPerUser} onChangeText={setFormPerUser} />
          </View>
        </View>

        <View style={styles.formRow}>
          <View style={styles.formHalf}>
            <Text style={styles.formLabel}>延迟生效（天）</Text>
            <TextInput style={styles.formInput} keyboardType="number-pad" value={formValidFromDays} onChangeText={setFormValidFromDays} />
          </View>
          <View style={styles.formHalf}>
            <Text style={styles.formLabel}>有效期（天）</Text>
            <TextInput style={styles.formInput} keyboardType="number-pad" value={formValidDays} onChangeText={setFormValidDays} />
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  headerBtn: { padding: 2 },
  // 统计
  statsBar: {
    flexDirection: 'row', flexWrap: 'wrap', backgroundColor: Colors.bgWhite,
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  statItem: { alignItems: 'center', width: '16.66%' as any, paddingVertical: 2 },
  statValue: { fontSize: 16, fontWeight: '700', color: Colors.textPrimary },
  statLabel: { fontSize: 9, color: Colors.textHint, marginTop: 1 },
  // Tab
  tabRow: {
    flexDirection: 'row', backgroundColor: Colors.bgWhite,
    paddingHorizontal: Spacing.lg, paddingBottom: Spacing.md, gap: Spacing.md,
  },
  tab: {
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.input, backgroundColor: Colors.bgPrimary,
  },
  tabActive: { backgroundColor: Colors.admin },
  tabText: { fontSize: Typography.caption, color: Colors.textSecondary },
  tabTextActive: { color: Colors.white, fontWeight: '500' },
  // 搜索
  searchRow: {
    flexDirection: 'row', alignItems: 'center', marginHorizontal: Spacing.lg, marginBottom: Spacing.sm,
    backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.input,
    borderWidth: 1, borderColor: Colors.divider, paddingHorizontal: Spacing.md,
  },
  searchInput: {
    flex: 1, paddingVertical: Spacing.sm, fontSize: Typography.body, color: Colors.textPrimary,
  },
  // 筛选
  filterRow: {
    flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: Spacing.lg, gap: 4, marginBottom: Spacing.sm,
  },
  fBtn: {
    paddingHorizontal: Spacing.md, paddingVertical: 4,
    borderRadius: BorderRadius.input, borderWidth: 1, borderColor: Colors.divider,
  },
  fBtnActive: { backgroundColor: Colors.admin, borderColor: Colors.admin },
  fText: { fontSize: 11, color: Colors.textSecondary },
  fTextActive: { color: '#FFF' },
  fSep: { width: 8 },
  // 批量操作
  batchBar: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    marginHorizontal: Spacing.lg, marginBottom: Spacing.sm,
    backgroundColor: '#FFF3CD', borderRadius: BorderRadius.input,
    padding: Spacing.sm,
  },
  batchText: { fontSize: Typography.caption, color: '#856404' },
  batchBtn: { backgroundColor: Colors.lover, borderRadius: 4, paddingHorizontal: Spacing.md, paddingVertical: 4 },
  batchBtnText: { fontSize: Typography.caption, color: '#FFF', fontWeight: '600' },
  // 内容区
  container: { padding: Spacing.lg },
  // 兑换码卡片
  codeCard: { marginBottom: Spacing.sm, borderLeftWidth: 3, borderLeftColor: Colors.divider },
  codeInactive: { opacity: 0.5 },
  codeSelected: { borderLeftColor: Colors.admin, backgroundColor: '#F0F4FF' },
  codeHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: Spacing.xs },
  codeValue: { fontSize: Typography.subtitle, fontWeight: '700', color: Colors.admin, fontFamily: 'monospace' },
  codeBadges: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  typeBadge: { paddingHorizontal: 6, paddingVertical: 1, borderRadius: 3 },
  typeBadgeText: { fontSize: 10, fontWeight: '500' },
  statusTag: { fontSize: 10, color: Colors.lover, fontWeight: '500' },
  rewardName: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  rewardDesc: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  codeMeta: { marginTop: Spacing.sm, gap: 2 },
  metaText: { fontSize: Typography.caption, color: Colors.textSecondary },
  metaTarget: { fontSize: Typography.caption, color: Colors.friend },
  metaDate: { fontSize: 10, color: Colors.textHint },
  deactBtn: { alignSelf: 'flex-end', marginTop: Spacing.sm },
  deactText: { fontSize: Typography.caption, color: Colors.lover },
  // 兑换记录
  recordCard: { marginBottom: Spacing.sm },
  recordHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, marginBottom: 4 },
  recordCode: { fontSize: Typography.body, fontWeight: '600', color: Colors.admin, fontFamily: 'monospace' },
  recordReward: { fontSize: Typography.body, color: Colors.textPrimary, flex: 1 },
  cancelledTag: { fontSize: 10, color: Colors.lover },
  recordUser: { fontSize: Typography.caption, color: Colors.textSecondary },
  addressBox: {
    backgroundColor: Colors.bgPrimary, borderRadius: BorderRadius.input,
    padding: Spacing.sm, marginTop: Spacing.sm,
  },
  addressTitle: { fontSize: Typography.caption, fontWeight: '500', color: Colors.textSecondary },
  addressText: { fontSize: Typography.caption, color: Colors.textHint },
  recordTime: { fontSize: 10, color: Colors.textHint, marginTop: 4 },
  cancelBtn: { alignSelf: 'flex-end', marginTop: Spacing.sm },
  cancelText: { fontSize: Typography.caption, color: Colors.lover },
  // 弹窗
  formLabel: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary, marginBottom: 4, marginTop: Spacing.sm },
  formInput: {
    borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input,
    padding: Spacing.md, fontSize: Typography.body, color: Colors.textPrimary,
  },
  typeRow: { flexDirection: 'row', gap: Spacing.sm },
  typeBtn: {
    flex: 1, paddingVertical: Spacing.sm, borderRadius: BorderRadius.card,
    borderWidth: 1, borderColor: Colors.divider, alignItems: 'center',
  },
  typeBtnText: { fontSize: Typography.caption, fontWeight: '500' },
  formRow: { flexDirection: 'row', gap: Spacing.md },
  formHalf: { flex: 1 },
  // 空状态
  empty: { alignItems: 'center', paddingVertical: Spacing.xl * 3, gap: Spacing.lg },
  emptyText: { fontSize: Typography.body, color: Colors.textHint },
});

export default AdminRedemptionScreen;
