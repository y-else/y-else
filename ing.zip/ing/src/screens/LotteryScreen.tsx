/**
 * 抽奖大转盘页面（完整版）
 * 概率加权算法 / 每日签到 / 大转盘动画 / 奖品展示 / 中奖记录 / API同步
 *
 * 核心修复:
 * - 概率加权随机替代均等随机（致命Bug修复）
 * - 对接后端签到/抽奖API，本地AsyncStorage作为离线缓存
 * - 用户专属规则优先于全局配置
 * - ref锁防止重复点击竞态
 * - 活动时间校验(startAt/endAt)
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert,
  Animated, RefreshControl, Dimensions,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card, Button, Modal } from '../components';
import { useAuth } from '../context/AuthContext';
import { checkInToday, getLotteryChances, consumeLotteryChance, getCheckInStatus } from '../services/checkin';
import { getLotteryConfig } from '../services/admin';
import { api } from '../services/apiClient';
import { USE_REAL_API } from '../services/apiConfig';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

// 转盘扇区颜色
const PRIZE_COLORS = ['#FF6B6B', '#FFB347', '#4ECDC4', '#7B68EE', '#FFD93D', '#6BCB77', '#FF8C69', '#45B7D1'];

interface LotteryPrizeItem {
  id: string;
  name: string;
  type: 'virtual' | 'physical';
  totalCount: number;
  remainingCount: number;
  probability: number;
}

interface LotteryScreenProps {
  onBack: () => void;
}

const LotteryScreen: React.FC<LotteryScreenProps> = ({ onBack }) => {
  const { state } = useAuth();
  const user = state.user;

  // 签到
  const [checkinInfo, setCheckinInfo] = useState({ checkedIn: false, streak: 0, chances: 0 });
  const [checkingIn, setCheckingIn] = useState(false);

  // 抽奖
  const [spinning, setSpinning] = useState(false);
  const spinningRef = useRef(false); // ref锁防止竞态
  const [result, setResult] = useState<string | null>(null);
  const [resultWon, setResultWon] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const spinAnim = useRef(new Animated.Value(0)).current;
  const [wheelPrizes, setWheelPrizes] = useState<LotteryPrizeItem[]>([]);
  const [isActive, setIsActive] = useState(false);
  const [activityEnded, setActivityEnded] = useState(false);

  // 历史记录
  const [history, setHistory] = useState<any[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  const loadData = useCallback(async () => {
    // 签到状态
    const status = await getCheckInStatus();
    setCheckinInfo({ checkedIn: status.checkedInToday, streak: status.streak, chances: status.totalChances });

    // 抽奖配置
    const config = await getLotteryConfig();
    const now = Date.now();
    const startAt = config?.startAt ? new Date(config.startAt).getTime() : 0;
    const endAt = config?.endAt ? new Date(config.endAt).getTime() : now + 86400000 * 365;
    const active = config?.status === 'active' && now >= startAt && now <= endAt;
    setIsActive(active);
    setActivityEnded(config?.status === 'active' && now > endAt);

    const prizes: LotteryPrizeItem[] = (config?.prizes?.length > 0 ? config.prizes : [
      { id: 'default_1', name: '谢谢参与', type: 'virtual', totalCount: 9999, remainingCount: 9999, probability: 0.3 },
      { id: 'default_2', name: '优惠券5元', type: 'virtual', totalCount: 100, remainingCount: 100, probability: 0.25 },
      { id: 'default_3', name: 'VIP会员3天', type: 'virtual', totalCount: 50, remainingCount: 50, probability: 0.15 },
      { id: 'default_4', name: '精美礼品', type: 'physical', totalCount: 20, remainingCount: 20, probability: 0.12 },
      { id: 'default_5', name: '50元红包', type: 'virtual', totalCount: 10, remainingCount: 10, probability: 0.08 },
      { id: 'default_6', name: '耳机一副', type: 'physical', totalCount: 5, remainingCount: 5, probability: 0.05 },
      { id: 'default_7', name: '手机一部', type: 'physical', totalCount: 2, remainingCount: 2, probability: 0.03 },
      { id: 'default_8', name: '谢谢参与', type: 'virtual', totalCount: 9999, remainingCount: 9999, probability: 0.02 },
    ]) as LotteryPrizeItem[];

    setWheelPrizes(prizes);

    // 历史记录
    const m = await import('@react-native-async-storage/async-storage');
    const raw = await m.default.getItem('@ing_lottery_history');
    setHistory(raw ? JSON.parse(raw).slice(0, 20) : []);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  // ====== 概率加权随机选择算法 ======
  // 核心修复: 根据每个奖品的 probability 进行加权随机，而非均等随机
  const selectPrizeByProbability = useCallback((prizes: LotteryPrizeItem[]): { prize: LotteryPrizeItem; index: number } => {
    // 计算总概率
    const totalProb = prizes.reduce((sum, p) => sum + p.probability, 0);
    // 归一化后在 [0, totalProb) 范围内随机
    const rand = Math.random() * totalProb;
    let accumulated = 0;
    for (let i = 0; i < prizes.length; i++) {
      accumulated += prizes[i].probability;
      if (rand < accumulated) {
        return { prize: prizes[i], index: i };
      }
    }
    // 浮点精度兜底：返回最后一个
    return { prize: prizes[prizes.length - 1], index: prizes.length - 1 };
  }, []);

  // ====== 签到 ======
  const handleCheckIn = async () => {
    if (checkinInfo.checkedIn || checkingIn) return;
    setCheckingIn(true);

    // 先尝试后端API
    if (USE_REAL_API && user) {
      try {
        const res = await api.post('/checkin');
        if (res.code === 200 && res.data) {
          const data = res.data;
          Alert.alert('签到成功', `连续签到第 ${data.streak} 天！\n获得 1 次免费抽奖机会`);
          await loadData();
          setCheckingIn(false);
          return;
        }
        if (res.code === 400) {
          Alert.alert('提示', res.message || '今日已签到');
          setCheckingIn(false);
          return;
        }
      } catch { /* 降级到本地 */ }
    }

    // 本地签到（离线降级）
    const result = await checkInToday();
    setCheckingIn(false);
    if (result.success) {
      Alert.alert('签到成功', `连续签到第 ${result.streak} 天！\n获得 1 次免费抽奖机会`);
      setCheckinInfo({ checkedIn: true, streak: result.streak, chances: result.totalChances });
    } else {
      Alert.alert('提示', result.message);
    }
  };

  // ====== 大转盘旋转 ======
  const spinWheel = async () => {
    // ref锁防止竞态
    if (spinning || spinningRef.current) return;
    if (!isActive) {
      if (activityEnded) {
        Alert.alert('提示', '当前抽奖活动已结束');
      } else {
        Alert.alert('提示', '抽奖活动暂未开启');
      }
      return;
    }
    if (checkinInfo.chances <= 0) {
      Alert.alert('提示', '抽奖次数不足，请先签到领取');
      return;
    }

    spinningRef.current = true;
    setSpinning(true);
    setResult(null);

    // 消耗次数（本地）
    const consumed = await consumeLotteryChance();
    if (!consumed.success) {
      spinningRef.current = false;
      setSpinning(false);
      Alert.alert('提示', '抽奖机会不足，请先签到领取');
      return;
    }

    // 概率加权选择中奖奖品
    const { prize: wonPrize, index: wonIndex } = selectPrizeByProbability(wheelPrizes);

    // 计算旋转角度：确保指针指向中奖扇区
    // 每个扇区角度 = 360 / N，中奖扇区中心角度 = wonIndex * segmentAngle + segmentAngle/2
    const segmentAngle = 360 / wheelPrizes.length;
    const targetSegmentCenter = wonIndex * segmentAngle + segmentAngle / 2;
    // 因为指针在顶部(0度位置)，旋转后需要让中奖扇区对准顶部
    // 转盘顺时针旋转，所以目标角度 = 360 - targetSegmentCenter（多圈旋转+目标角度）
    const fullSpins = 360 * (5 + Math.floor(Math.random() * 3)); // 5-7圈
    const targetAngle = fullSpins + (360 - targetSegmentCenter);

    spinAnim.setValue(0);
    Animated.timing(spinAnim, {
      toValue: targetAngle,
      duration: 4000,
      useNativeDriver: true,
    }).start(() => {
      spinningRef.current = false;
      setSpinning(false);
      const displayName = wonPrize.name || '谢谢参与';
      const isWin = !displayName.includes('谢谢');
      setResult(displayName);
      setResultWon(isWin);
      setShowResult(true);
      setCheckinInfo((prev) => ({ ...prev, chances: consumed.remaining }));
      saveHistory(displayName);

      // 库存扣减：真实中奖时递减本地状态并同步后台
      if (isWin && wonPrize.id) {
        setWheelPrizes((prev) =>
          prev.map((p) =>
            p.id === wonPrize.id && p.remainingCount > 0
              ? { ...p, remainingCount: p.remainingCount - 1 }
              : p,
          ),
        );
        // 异步同步库存到AsyncStorage和服务端
        decrementPrizeStock(wonPrize.id);
      }

      // 异步调用后端抽奖API（服务端同时扣库存+记录中奖）
      if (USE_REAL_API && user) {
        api.post('/lottery/draw').catch(() => {});
      }
    });
  };

  // 库存递减：同步本地AsyncStorage配置 + 服务端
  const decrementPrizeStock = async (prizeId: string) => {
    const m = await import('@react-native-async-storage/async-storage');
    const raw = await m.default.getItem('@ing_admin_lottery_config');
    if (!raw) return;
    try {
      const config = JSON.parse(raw);
      if (config.prizes) {
        config.prizes = config.prizes.map((p: any) =>
          p.id === prizeId && p.remainingCount > 0
            ? { ...p, remainingCount: p.remainingCount - 1 }
            : p,
        );
        await m.default.setItem('@ing_admin_lottery_config', JSON.stringify(config));
      }
    } catch {}
  };

  const saveHistory = async (prize: string) => {
    const m = await import('@react-native-async-storage/async-storage');
    const raw = await m.default.getItem('@ing_lottery_history');
    const list = raw ? JSON.parse(raw) : [];
    list.unshift({ prize, time: new Date().toISOString() });
    await m.default.setItem('@ing_lottery_history', JSON.stringify(list));
    setHistory(list.slice(0, 20));
  };

  const handleRefresh = async () => { setRefreshing(true); await loadData(); setRefreshing(false); };

  // 旋转插值
  const rotate = spinAnim.interpolate({
    inputRange: [0, 360],
    outputRange: ['0deg', '360deg'],
    extrapolate: 'extend',
  });

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>幸运抽奖</Text>
        <TouchableOpacity onPress={() => setShowHistory(true)}>
          <Ionicons name="receipt-outline" size={22} color={Colors.textSecondary} />
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.container}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
      >
        {/* ====== 签到区 ====== */}
        <Card style={styles.checkinCard}>
          <View style={styles.checkinRow}>
            <View style={styles.checkinInfo}>
              <Text style={styles.checkinTitle}>
                {checkinInfo.checkedIn ? '今日已签到' : '每日签到领次数'}
              </Text>
              <Text style={styles.checkinStreak}>
                连续签到 <Text style={{ color: Colors.friend, fontWeight: '700' }}>{checkinInfo.streak}</Text> 天
              </Text>
            </View>
            <TouchableOpacity
              style={[styles.checkinBtn, checkinInfo.checkedIn && styles.checkinDone]}
              onPress={handleCheckIn}
              disabled={checkinInfo.checkedIn || checkingIn}
              activeOpacity={0.7}
            >
              <Ionicons
                name={checkinInfo.checkedIn ? 'checkmark-circle' : 'calendar-outline'}
                size={22}
                color="#FFF"
              />
              <Text style={styles.checkinBtnText}>
                {checkinInfo.checkedIn ? '已签到' : checkingIn ? '签到中...' : '签到'}
              </Text>
            </TouchableOpacity>
          </View>
        </Card>

        {/* ====== 大转盘 ====== */}
        <Card style={styles.wheelCard}>
          <Text style={styles.sectionTitle}>幸运大转盘</Text>
          <Text style={styles.chancesText}>
            剩余抽奖次数: <Text style={{ color: Colors.lover, fontWeight: '700' }}>{checkinInfo.chances}</Text>
          </Text>

          {/* 大转盘 */}
          <View style={styles.wheelWrapper}>
            {/* 指针（固定在顶部） */}
            <View style={styles.pointer}>
              <Ionicons name="caret-down" size={28} color={Colors.lover} />
            </View>
            {/* 转盘 */}
            <Animated.View
              style={[
                styles.wheel,
                { transform: [{ rotate }] },
              ]}
            >
              {wheelPrizes.map((prize, i) => {
                const angle = (360 / wheelPrizes.length) * i;
                const color = PRIZE_COLORS[i % PRIZE_COLORS.length];
                return (
                  <View
                    key={prize.id || i}
                    style={[
                      styles.segment,
                      {
                        backgroundColor: color,
                        transform: [
                          { rotate: angle + 'deg' },
                          { translateY: -SCREEN_WIDTH * 0.28 },
                        ],
                      },
                    ]}
                  >
                    <Text style={styles.segmentText} numberOfLines={1}>
                      {prize.name}
                    </Text>
                  </View>
                );
              })}
              {/* 中心圆 */}
              <View style={styles.wheelCenter}>
                <Text style={styles.wheelCenterText}>GO</Text>
              </View>
            </Animated.View>
          </View>

          <Button
            title={spinning ? '抽奖中...' : !isActive ? (activityEnded ? '活动已结束' : '活动未开启') : '开始抽奖'}
            onPress={spinWheel}
            loading={spinning}
            disabled={spinning || !isActive}
            style={styles.spinBtn}
          />
        </Card>

        {/* ====== 奖品列表 ====== */}
        <Card style={styles.prizeCard}>
          <Text style={styles.sectionTitle}>奖品列表</Text>
          {wheelPrizes.length > 0 ? (
            <View style={styles.prizeGrid}>
              {wheelPrizes.map((p, i) => (
                <View key={p.id || i} style={styles.prizeItem}>
                  <View style={[styles.prizeDot, { backgroundColor: PRIZE_COLORS[i % PRIZE_COLORS.length] }]} />
                  <Text style={styles.prizeName}>{p.name}</Text>
                  <Text style={styles.prizeProb}>{(p.probability * 100).toFixed(1)}%</Text>
                </View>
              ))}
            </View>
          ) : (
            <Text style={styles.emptyHint}>暂无奖品配置</Text>
          )}
        </Card>

        <View style={{ height: 40 }} />
      </ScrollView>

      {/* ====== 中奖弹窗 ====== */}
      <Modal
        visible={showResult}
        title="抽奖结果"
        onClose={() => setShowResult(false)}
        showFooter={false}
      >
        <View style={styles.resultContent}>
          <View style={styles.resultIcon}>
            <Ionicons
              name={resultWon ? 'gift' : 'sad-outline'}
              size={48}
              color={resultWon ? Colors.friend : Colors.textHint}
            />
          </View>
          <Text style={styles.resultTitle}>
            {resultWon ? '恭喜中奖！' : '很遗憾'}
          </Text>
          <Text style={styles.resultPrize}>{result}</Text>
          <Button
            title="知道了"
            onPress={() => setShowResult(false)}
            style={{ marginTop: Spacing.lg }}
          />
        </View>
      </Modal>

      {/* ====== 中奖历史弹窗 ====== */}
      <Modal
        visible={showHistory}
        title="中奖记录"
        onClose={() => setShowHistory(false)}
        showFooter={false}
      >
        <ScrollView style={{ maxHeight: 300 }}>
          {history.length === 0 ? (
            <View style={styles.emptyHistory}>
              <Ionicons name="receipt-outline" size={40} color={Colors.textHint} />
              <Text style={styles.emptyText}>暂无中奖记录</Text>
            </View>
          ) : (
            history.map((h, i) => (
              <View key={i} style={styles.historyItem}>
                <Ionicons
                  name={h.prize?.includes('谢谢') ? 'close-circle' : 'gift'}
                  size={18}
                  color={h.prize?.includes('谢谢') ? Colors.textHint : Colors.friend}
                />
                <Text style={styles.historyPrize}>{h.prize}</Text>
                <Text style={styles.historyTime}>
                  {new Date(h.time).toLocaleDateString('zh-CN')}
                </Text>
              </View>
            ))
          )}
        </ScrollView>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  container: { padding: Spacing.lg },
  // 签到
  checkinCard: { marginBottom: Spacing.md, padding: Spacing.lg },
  checkinRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  checkinInfo: {},
  checkinTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  checkinStreak: { fontSize: Typography.caption, color: Colors.textSecondary, marginTop: 4 },
  checkinBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: Colors.friend, paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    borderRadius: BorderRadius.card,
  },
  checkinDone: { backgroundColor: Colors.textHint },
  checkinBtnText: { color: '#FFF', fontWeight: '600', fontSize: Typography.body },
  // 大转盘
  wheelCard: { marginBottom: Spacing.md, alignItems: 'center' },
  sectionTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.xs },
  chancesText: { fontSize: Typography.body, color: Colors.textSecondary, marginBottom: Spacing.lg },
  wheelWrapper: {
    width: SCREEN_WIDTH - Spacing.lg * 4,
    height: SCREEN_WIDTH - Spacing.lg * 4,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: Spacing.xl, position: 'relative',
  },
  pointer: {
    position: 'absolute', top: -14, zIndex: 10,
    alignSelf: 'center',
  },
  wheel: {
    width: '100%', height: '100%', borderRadius: (SCREEN_WIDTH - Spacing.lg * 4) / 2,
    borderWidth: 4, borderColor: Colors.lover, overflow: 'hidden',
    alignItems: 'center', justifyContent: 'center',
    backgroundColor: '#FFF5F5',
  },
  segment: {
    position: 'absolute', width: '100%', height: '100%',
    alignItems: 'center', justifyContent: 'flex-start', paddingTop: 16,
  },
  segmentText: {
    fontSize: 11, fontWeight: '600', color: '#FFF',
    width: 60, textAlign: 'center',
    textShadowColor: 'rgba(0,0,0,0.3)', textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 2,
  },
  wheelCenter: {
    width: 52, height: 52, borderRadius: 26, backgroundColor: Colors.bgWhite,
    alignItems: 'center', justifyContent: 'center', zIndex: 5,
    elevation: 4, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.15, shadowRadius: 4,
  },
  wheelCenterText: { fontSize: 16, fontWeight: '800', color: Colors.lover },
  spinBtn: { width: '100%', marginTop: 0 },
  // 奖品列表
  prizeCard: { marginBottom: Spacing.md },
  prizeGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  prizeItem: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingVertical: Spacing.xs, width: '47%' },
  prizeDot: { width: 8, height: 8, borderRadius: 4 },
  prizeName: { fontSize: Typography.caption, color: Colors.textSecondary, flex: 1 },
  prizeProb: { fontSize: 10, color: Colors.textHint },
  emptyHint: { fontSize: Typography.caption, color: Colors.textHint, textAlign: 'center', paddingVertical: Spacing.lg },
  // 中奖弹窗
  resultContent: { alignItems: 'center', paddingVertical: Spacing.md },
  resultIcon: {
    width: 80, height: 80, borderRadius: 40, backgroundColor: Colors.bgPrimary,
    alignItems: 'center', justifyContent: 'center', marginBottom: Spacing.md,
  },
  resultTitle: { fontSize: Typography.title, fontWeight: '700', color: Colors.textPrimary, marginBottom: Spacing.xs },
  resultPrize: { fontSize: Typography.subtitle, color: Colors.primary, fontWeight: '600' },
  // 历史
  emptyHistory: { alignItems: 'center', paddingVertical: Spacing.xl, gap: Spacing.md },
  emptyText: { fontSize: Typography.body, color: Colors.textHint },
  historyItem: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
    paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  historyPrize: { flex: 1, fontSize: Typography.body, color: Colors.textPrimary },
  historyTime: { fontSize: Typography.caption, color: Colors.textHint },
});

export default LotteryScreen;
