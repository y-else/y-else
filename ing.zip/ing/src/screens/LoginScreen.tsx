/**
 * 登录页 — 共用入口
 * 登录页自动展示版本更新公告弹窗
 * 支持多账号切换（已保存账号列表）
 * 手机号000开头自动识别管理员
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  TouchableOpacity,
  Image,
  Alert,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing } from '../constants';
import { Input, Button, VersionUpdateModal } from '../components';
import { useAuth } from '../context/AuthContext';
import { checkAppVersion } from '../services/auth';
import type { AppVersion, SavedAccount } from '../types';

// 从 app.json 动态获取当前版本号
import appJson from '../../app.json';
const CURRENT_VERSION = appJson.expo.version;
const CURRENT_BUILD = appJson.expo.android?.versionCode ?? 1;

interface LoginScreenProps {
  onNavigateRegister: () => void;
  onNavigateForgotPassword: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({
  onNavigateRegister,
  onNavigateForgotPassword,
}) => {
  const { state, login, switchAccount, removeSavedAccount } = useAuth();

  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // 版本更新公告
  const [versionModalVisible, setVersionModalVisible] = useState(false);
  const [versionInfo, setVersionInfo] = useState<AppVersion | null>(null);
  const [showSavedAccounts, setShowSavedAccounts] = useState(false);

  // 管理员自动识别（内部使用，不对外展示提示文字）
  const isAdminPhone = phone.trim().startsWith('000');

  // 登录页自动检测版本更新（仅真实服务端数据才弹窗，离线降级数据不弹）
  useEffect(() => {
    (async () => {
      try {
        const resp = await checkAppVersion();
        if (resp.code === 200 && resp.data && resp.message !== '离线模式') {
          if (resp.data.buildNumber > CURRENT_BUILD) {
            setVersionInfo(resp.data);
            setVersionModalVisible(true);
          }
        }
      } catch { /* 静默 */ }
    })();
  }, []);

  const handleLogin = async () => {
    setError('');
    if (!phone.trim()) { setError('请输入手机号'); return; }
    if (!password.trim()) { setError('请输入密码'); return; }

    // 手机号格式校验（管理员000前缀除外）
    if (!isAdminPhone && !/^1[3-9]\d{9}$/.test(phone.trim())) {
      setError('请输入正确的手机号');
      return;
    }
    if (isAdminPhone && phone.trim().length < 8) {
      setError('管理员账号至少8位数字');
      return;
    }

    setLoading(true);
    const result = await login(phone.trim(), password);
    setLoading(false);

    if (!result.success) {
      setError(result.message);
    }
  };

  const handleSwitchAccount = async (account: SavedAccount) => {
    await switchAccount(account);
    setShowSavedAccounts(false);
  };

  const handleRemoveAccount = (userId: string) => {
    Alert.alert('移除账号', '确定移除该已保存账号？', [
      { text: '取消', style: 'cancel' },
      {
        text: '移除',
        style: 'destructive',
        onPress: () => removeSavedAccount(userId),
      },
    ]);
  };

  const handleVersionUpdate = () => {
    setVersionModalVisible(false);
    Alert.alert('提示', '请前往应用商店更新到最新版本');
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior="height"
      >
        <ScrollView
          style={styles.flex}
          contentContainerStyle={styles.container}
          keyboardShouldPersistTaps="handled"
        >
          {/* Logo区域 */}
          <View style={styles.logoArea}>
            <View style={styles.logoCircle}>
              <Ionicons name="heart" size={40} color={Colors.white} />
            </View>
            <Text style={styles.appName}>ing</Text>
            <Text style={styles.appSlogan}>社交陪伴</Text>
          </View>

          {/* 登录表单 */}
          <View style={styles.form}>
            <Input
              label="手机号"
              placeholder="请输入手机号"
              keyboardType="phone-pad"
              value={phone}
              onChangeText={(t) => { setPhone(t); setError(''); }}
            />
            <Input
              label="密码"
              placeholder="请输入密码"
              secureTextEntry
              value={password}
              onChangeText={(t) => { setPassword(t); setError(''); }}
            />
            {error ? <Text style={styles.error}>{error}</Text> : null}

            <Button
              title="登录"
              onPress={handleLogin}
              loading={loading}
              style={styles.loginBtn}
            />

            <View style={styles.links}>
              <TouchableOpacity onPress={onNavigateRegister}>
                <Text style={styles.link}>注册账号</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={onNavigateForgotPassword}>
                <Text style={styles.link}>忘记密码</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* 多账号切换 */}
          {state.savedAccounts.length > 0 && (
            <View style={styles.accountsSection}>
              <TouchableOpacity
                style={styles.accountsHeader}
                onPress={() => setShowSavedAccounts(!showSavedAccounts)}
              >
                <Text style={styles.accountsTitle}>
                  已保存的账号（{state.savedAccounts.length}）
                </Text>
                <Ionicons
                  name={showSavedAccounts ? 'chevron-up' : 'chevron-down'}
                  size={16}
                  color={Colors.textHint}
                />
              </TouchableOpacity>

              {showSavedAccounts && (
                <View style={styles.accountsList}>
                  {state.savedAccounts
                    .filter((account) => !account.phone.startsWith('000'))
                    .map((account) => (
                    <View key={account.userId} style={styles.accountRow}>
                      <TouchableOpacity
                        style={styles.accountInfo}
                        onPress={() => handleSwitchAccount(account)}
                      >
                        <View style={styles.avatarSmall}>
                          {account.avatar ? (
                            <Image source={{ uri: account.avatar }} style={styles.avatarImg} />
                          ) : (
                            <Ionicons name="person" size={20} color={Colors.textHint} />
                          )}
                        </View>
                        <View style={styles.accountText}>
                          <Text style={styles.accountName}>{account.username}</Text>
                          <Text style={styles.accountPhone}>{account.phone}</Text>
                        </View>
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => handleRemoveAccount(account.userId)}
                        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                      >
                        <Ionicons name="close-circle" size={20} color={Colors.textHint} />
                      </TouchableOpacity>
                    </View>
                  ))}
                </View>
              )}
            </View>
          )}
        </ScrollView>

        {/* 底部品牌文字 */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>本应用由y-else工作室出品</Text>
        </View>
      </KeyboardAvoidingView>

      {/* 版本更新公告弹窗 */}
      <VersionUpdateModal
        visible={versionModalVisible}
        versionInfo={versionInfo}
        onUpdate={handleVersionUpdate}
        onDismiss={() => setVersionModalVisible(false)}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: Colors.bgWhite,
  },
  flex: {
    flex: 1,
  },
  container: {
    flexGrow: 1,
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.xl * 3,
    paddingBottom: Spacing.xl,
  },
  // Logo
  logoArea: {
    alignItems: 'center',
    marginBottom: Spacing.xxl * 1.2,
  },
  logoCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.lg,
  },
  appName: {
    fontSize: 32,
    fontWeight: '700',
    color: Colors.primary,
  },
  appSlogan: {
    fontSize: Typography.body,
    color: Colors.textHint,
    marginTop: Spacing.xs,
  },
  // 表单
  form: {
    marginBottom: Spacing.xl,
  },
  error: {
    fontSize: Typography.caption,
    color: Colors.lover,
    marginBottom: Spacing.sm,
  },
  loginBtn: {
    marginTop: Spacing.lg,
  },
  links: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Spacing.lg,
  },
  link: {
    fontSize: Typography.body,
    color: Colors.primary,
  },
  // 多账号
  accountsSection: {
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: Colors.divider,
    paddingTop: Spacing.lg,
  },
  accountsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  accountsTitle: {
    fontSize: Typography.body,
    color: Colors.textSecondary,
    fontWeight: '500',
  },
  accountsList: {
    marginTop: Spacing.md,
  },
  accountRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: Spacing.sm,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: Colors.divider,
  },
  accountInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatarSmall: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.bgPrimary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.md,
    overflow: 'hidden',
  },
  avatarImg: {
    width: 36,
    height: 36,
    borderRadius: 18,
  },
  accountText: {
    flex: 1,
  },
  accountName: {
    fontSize: Typography.body,
    color: Colors.textPrimary,
    fontWeight: '500',
  },
  accountPhone: {
    fontSize: Typography.caption,
    color: Colors.textHint,
  },
  // 底部
  footer: {
    alignItems: 'center',
    paddingBottom: Spacing.xl,
  },
  footerText: {
    fontSize: Typography.caption,
    color: Colors.textHint,
  },
});

export default LoginScreen;
