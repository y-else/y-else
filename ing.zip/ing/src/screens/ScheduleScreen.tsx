/**
 * 日程页面（增强版）
 * 个人日程CRUD、共享、隐私权限、管理员查看
 *
 * 修复:
 * - 新增日期筛选（按天/周/月）
 * - 新增搜索（标题/内容）
 * - 共享通知未读标记
 * - 管理员全站筛选
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert,
  TextInput, RefreshControl, Switch,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card, Button, Modal, DatePicker, TimePicker } from '../components';
import { useAuth } from '../context/AuthContext';
import {
  getMySchedules, createSchedule, updateSchedule, deleteSchedule,
  shareSchedule, getAllSchedules, searchSchedules, getSharedSchedules,
  markShareNotifRead, getUnreadShareNotifCount,
} from '../services/schedule';
import { getContacts } from '../services/contacts';
import type { ScheduleItem, ScheduleVisibility, ScheduleShareNotification } from '../types';

interface ScheduleScreenProps {
  onBack: () => void;
}

const VISIBILITY_OPTIONS: { key: ScheduleVisibility; label: string; color: string; icon: string }[] = [
  { key: 'private', label: '私密', color: Colors.textHint, icon: 'lock-closed' },
  { key: 'friends_only', label: '好友可见', color: Colors.friend, icon: 'people' },
  { key: 'public', label: '公开', color: Colors.primary, icon: 'earth' },
];

type DateFilter = 'all' | 'today' | 'week' | 'month';

const ScheduleScreen: React.FC<ScheduleScreenProps> = ({ onBack }) => {
  const { state } = useAuth();
  const user = state.user;
  const isAdmin = user?.role === 'admin';

  const [schedules, setSchedules] = useState<ScheduleItem[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<ScheduleItem | null>(null);

  // 筛选与搜索
  const [searchQuery, setSearchQuery] = useState('');
  const [dateFilter, setDateFilter] = useState<DateFilter>('all');
  const [shareNotifs, setShareNotifs] = useState<ScheduleShareNotification[]>([]);
  const [unreadShareCount, setUnreadShareCount] = useState(0);

  // 表单
  const [formTitle, setFormTitle] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formDate, setFormDate] = useState('');
  const [formTime, setFormTime] = useState('');
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [formReminder, setFormReminder] = useState(false);
  const [formVisibility, setFormVisibility] = useState<ScheduleVisibility>('private');

  const loadData = useCallback(async () => {
    if (!user) return;
    if (isAdmin) {
      if (searchQuery.trim()) {
        const result = await searchSchedules(searchQuery.trim());
        setSchedules(result);
      } else {
        const all = await getAllSchedules();
        setSchedules(all);
      }
    } else {
      // 普通用户：获取自己的日程 + 共享给 ta 的日程
      let mine = await getMySchedules(user.id);

      // 搜索
      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase();
        mine = mine.filter(
          (s) =>
            s.title.toLowerCase().includes(q) ||
            s.content.toLowerCase().includes(q),
        );
      }

      // 日期筛选
      if (dateFilter !== 'all') {
        const now = new Date();
        const todayStr = now.toISOString().slice(0, 10);
        if (dateFilter === 'today') {
          mine = mine.filter((s) => s.scheduledAt.slice(0, 10) === todayStr);
        } else if (dateFilter === 'week') {
          const weekEnd = new Date(now.getTime() + 7 * 86400000).toISOString().slice(0, 10);
          mine = mine.filter((s) => s.scheduledAt.slice(0, 10) >= todayStr && s.scheduledAt.slice(0, 10) <= weekEnd);
        } else if (dateFilter === 'month') {
          const monthEnd = new Date(now.getTime() + 30 * 86400000).toISOString().slice(0, 10);
          mine = mine.filter((s) => s.scheduledAt.slice(0, 10) >= todayStr && s.scheduledAt.slice(0, 10) <= monthEnd);
        }
      }

      setSchedules(mine);

      // 共享通知
      const notifs = await getSharedSchedules(user.id);
      setShareNotifs(notifs.filter((n) => !n.isRead));
      const unread = await getUnreadShareNotifCount(user.id);
      setUnreadShareCount(unread);
    }
  }, [user, isAdmin, searchQuery, dateFilter]);

  useEffect(() => { loadData(); }, [loadData]);

  const handleRefresh = async () => { setRefreshing(true); await loadData(); setRefreshing(false); };

  const resetForm = () => {
    setFormTitle(''); setFormContent(''); setFormDate(''); setFormTime('');
    setFormReminder(false); setFormVisibility('private'); setEditingSchedule(null);
  };

  const handleCreate = async () => {
    if (!formTitle.trim()) { Alert.alert('提示', '请输入日程标题'); return; }
    if (!formDate.trim()) { Alert.alert('提示', '请输入日程日期'); return; }
    const scheduledAt = `${formDate}T${formTime || '12:00'}:00`;
    await createSchedule({
      userId: user?.id || '', username: user?.username || '',
      title: formTitle.trim(), content: formContent.trim(),
      scheduledAt,
      reminderAt: formReminder ? new Date(new Date(scheduledAt).getTime() - 1800000).toISOString() : null,
      reminderEnabled: formReminder,
      visibility: formVisibility,
      sharedTo: [],
    });
    resetForm();
    setShowCreate(false);
    await loadData();
    Alert.alert('创建成功', '日程已添加');
  };

  const handleEdit = (item: ScheduleItem) => {
    setEditingSchedule(item);
    setFormTitle(item.title);
    setFormContent(item.content);
    const dt = new Date(item.scheduledAt);
    setFormDate(dt.toISOString().slice(0, 10));
    setFormTime(dt.toTimeString().slice(0, 5));
    setFormReminder(item.reminderEnabled);
    setFormVisibility(item.visibility);
    setShowCreate(true);
  };

  const handleUpdate = async () => {
    if (!editingSchedule || !formTitle.trim()) return;
    const scheduledAt = `${formDate}T${formTime || '12:00'}:00`;
    await updateSchedule(editingSchedule.id, {
      title: formTitle.trim(), content: formContent.trim(),
      scheduledAt,
      reminderAt: formReminder ? new Date(new Date(scheduledAt).getTime() - 1800000).toISOString() : null,
      reminderEnabled: formReminder, visibility: formVisibility,
    });
    resetForm();
    setShowCreate(false);
    await loadData();
  };

  const handleDelete = (id: string) => {
    Alert.alert('删除日程', '确定删除此日程？', [
      { text: '取消', style: 'cancel' },
      { text: '删除', style: 'destructive', onPress: async () => { await deleteSchedule(id); await loadData(); } },
    ]);
  };

  const handleShare = async (schedule: ScheduleItem) => {
    const contacts = await getContacts();
    const boundContacts = contacts.filter((c) => !c.isBlocked);
    if (boundContacts.length === 0) {
      Alert.alert('提示', '暂无已绑定好友可共享');
      return;
    }
    const options: Array<{ text: string; onPress?: () => void; style?: 'cancel' | 'destructive' | 'default' }> = boundContacts.map((c) => ({
      text: `${c.username} (${c.group === 'family' ? '家人' : c.group === 'lover' ? '恋人' : '朋友'})${schedule.sharedTo.includes(c.userId) ? ' ✓' : ''}`,
      onPress: async () => {
        await shareSchedule(schedule.id, user?.id || '', user?.username || '', c.userId);
        Alert.alert('共享成功', `日程已共享给 ${c.username}`);
        await loadData();
      },
    }));
    options.push({ text: '取消', style: 'cancel' });
    Alert.alert('共享日程', `将「${schedule.title}」共享给：`, options);
  };

  const getVisibilityInfo = (v: ScheduleVisibility) =>
    VISIBILITY_OPTIONS.find((o) => o.key === v) || VISIBILITY_OPTIONS[0];

  const formatDateTime = (iso: string) => {
    const d = new Date(iso);
    return `${d.getMonth() + 1}月${d.getDate()}日 ${d.toTimeString().slice(0, 5)}`;
  };

  const isOverdue = (iso: string) => new Date(iso).getTime() < Date.now();

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>日程</Text>
        <TouchableOpacity onPress={() => { resetForm(); setShowCreate(true); }}>
          <Ionicons name="add-circle" size={28} color={Colors.primary} />
        </TouchableOpacity>
      </View>

      {/* 搜索栏 + 日期筛选 */}
      {!isAdmin && (
        <View style={styles.filterBar}>
          <View style={styles.searchWrap}>
            <Ionicons name="search" size={16} color={Colors.textHint} />
            <TextInput
              style={styles.searchInput}
              placeholder="搜索日程..."
              placeholderTextColor={Colors.textHint}
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
            {searchQuery.length > 0 && (
              <TouchableOpacity onPress={() => setSearchQuery('')}>
                <Ionicons name="close-circle" size={16} color={Colors.textHint} />
              </TouchableOpacity>
            )}
          </View>
          <View style={styles.dateFilters}>
            {[
              { key: 'all' as DateFilter, label: '全部' },
              { key: 'today' as DateFilter, label: '今天' },
              { key: 'week' as DateFilter, label: '本周' },
              { key: 'month' as DateFilter, label: '本月' },
            ].map((f) => (
              <TouchableOpacity
                key={f.key}
                style={[styles.dateFilterBtn, dateFilter === f.key && styles.dateFilterBtnActive]}
                onPress={() => setDateFilter(f.key)}
              >
                <Text style={[styles.dateFilterText, dateFilter === f.key && styles.dateFilterTextActive]}>
                  {f.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}

      {/* 共享通知 */}
      {!isAdmin && unreadShareCount > 0 && (
        <TouchableOpacity
          style={styles.shareNotifBar}
          onPress={async () => {
            if (shareNotifs.length > 0) {
              await markShareNotifRead(shareNotifs[0].id);
              await loadData();
            }
          }}
        >
          <Ionicons name="notifications-outline" size={16} color={Colors.primary} />
          <Text style={styles.shareNotifText}>
            {unreadShareCount} 条新的日程共享
          </Text>
          <Ionicons name="chevron-forward" size={14} color={Colors.primary} />
        </TouchableOpacity>
      )}

      {/* 管理员搜索 */}
      {isAdmin && (
        <View style={styles.adminSearch}>
          <Ionicons name="search" size={16} color={Colors.textHint} />
          <TextInput
            style={styles.adminSearchInput}
            placeholder="搜索日程标题/内容/用户名..."
            placeholderTextColor={Colors.textHint}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
      )}

      <ScrollView
        contentContainerStyle={styles.container}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={[Colors.primary]} />}
      >
        {schedules.length === 0 ? (
          <View style={styles.empty}>
            <Ionicons name="calendar-outline" size={48} color={Colors.textHint} />
            <Text style={styles.emptyText}>
              {isAdmin ? '暂无日程' : searchQuery || dateFilter !== 'all' ? '未找到匹配日程' : '暂无日程，点击右上角创建'}
            </Text>
          </View>
        ) : (
          schedules.map((s) => {
            const vis = getVisibilityInfo(s.visibility);
            const overdue = isOverdue(s.scheduledAt);
            return (
              <Card key={s.id} style={{ ...styles.scheduleCard, ...(overdue ? styles.overdueCard : {}) } as any}>
                <View style={styles.cardHeader}>
                  <View style={[styles.visBadge, { backgroundColor: vis.color + '20' }]}>
                    <Ionicons name={vis.icon as any} size={12} color={vis.color} />
                    <Text style={[styles.visText, { color: vis.color }]}>{vis.label}</Text>
                  </View>
                  {overdue && (
                    <View style={styles.overdueBadge}>
                      <Text style={styles.overdueText}>已过期</Text>
                    </View>
                  )}
                  {!isAdmin && (
                    <View style={styles.cardActions}>
                      <TouchableOpacity onPress={() => handleShare(s)} style={styles.actionBtn}>
                        <Ionicons name="share-outline" size={18} color={Colors.primary} />
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => handleEdit(s)} style={styles.actionBtn}>
                        <Ionicons name="create-outline" size={18} color={Colors.textSecondary} />
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => handleDelete(s.id)} style={styles.actionBtn}>
                        <Ionicons name="trash-outline" size={18} color={Colors.lover} />
                      </TouchableOpacity>
                    </View>
                  )}
                </View>
                <Text style={[styles.scheduleTitle, overdue && { color: Colors.textHint }]}>
                  {s.title}
                </Text>
                {s.content ? <Text style={styles.scheduleContent}>{s.content}</Text> : null}
                <View style={styles.scheduleMeta}>
                  <Ionicons name="time-outline" size={14} color={Colors.textHint} />
                  <Text style={styles.scheduleTime}>{formatDateTime(s.scheduledAt)}</Text>
                  {s.reminderEnabled && <Text style={styles.reminderTag}>已设提醒</Text>}
                  {s.sharedTo.length > 0 && (
                    <Text style={styles.sharedTag}>已共享({s.sharedTo.length}人)</Text>
                  )}
                  {!isAdmin && (
                    <Text style={[styles.ownerText, { color: vis.color }]}>{s.username}</Text>
                  )}
                </View>
              </Card>
            );
          })
        )}
        <View style={{ height: 40 }} />
      </ScrollView>

      {/* 新建/编辑弹窗 */}
      <Modal
        visible={showCreate}
        title={editingSchedule ? '编辑日程' : '新建日程'}
        onClose={() => { setShowCreate(false); resetForm(); }}
        confirmText={editingSchedule ? '保存' : '创建'}
        onConfirm={editingSchedule ? handleUpdate : handleCreate}
      >
        <Text style={styles.formLabel}>标题</Text>
        <TextInput style={styles.formInput} placeholder="日程标题" placeholderTextColor={Colors.textHint} value={formTitle} onChangeText={setFormTitle} />
        <Text style={styles.formLabel}>内容</Text>
        <TextInput style={[styles.formInput, styles.formArea]} placeholder="日程内容（选填）" placeholderTextColor={Colors.textHint} value={formContent} onChangeText={setFormContent} multiline numberOfLines={3} />
        <Text style={styles.formLabel}>日期</Text>
        <TouchableOpacity style={styles.formInput} onPress={() => setShowDatePicker(true)} activeOpacity={0.6}>
          <Text style={formDate ? styles.formInputText : styles.formPlaceholder}>{formDate || '请选择日期'}</Text>
        </TouchableOpacity>
        <Text style={styles.formLabel}>时间</Text>
        <TouchableOpacity style={styles.formInput} onPress={() => setShowTimePicker(true)} activeOpacity={0.6}>
          <Text style={formTime ? styles.formInputText : styles.formPlaceholder}>{formTime || '请选择时间'}</Text>
        </TouchableOpacity>
        <View style={styles.switchRow}>
          <Text style={styles.formLabel}>开启提醒</Text>
          <Switch value={formReminder} onValueChange={setFormReminder} trackColor={{ false: Colors.divider, true: Colors.primary + '60' }} thumbColor={formReminder ? Colors.primary : '#f4f3f4'} />
        </View>
        <Text style={styles.formLabel}>权限</Text>
        <View style={styles.visRow}>
          {VISIBILITY_OPTIONS.map((o) => (
            <TouchableOpacity
              key={o.key}
              style={[styles.visBtn, formVisibility === o.key && { backgroundColor: o.color, borderColor: o.color }]}
              onPress={() => setFormVisibility(o.key)}
            >
              <Ionicons name={o.icon as any} size={14} color={formVisibility === o.key ? '#FFF' : o.color} />
              <Text style={[styles.visBtnText, formVisibility === o.key && { color: '#FFF' }]}>{o.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </Modal>
      <DatePicker visible={showDatePicker} value={formDate} onConfirm={(v) => { setFormDate(v); setShowDatePicker(false); }} onClose={() => setShowDatePicker(false)} title="选择日期" />
      <TimePicker visible={showTimePicker} value={formTime} onConfirm={(v) => { setFormTime(v); setShowTimePicker(false); }} onClose={() => setShowTimePicker(false)} title="选择时间" />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  // 筛选栏
  filterBar: {
    backgroundColor: Colors.bgWhite, paddingHorizontal: Spacing.lg, paddingBottom: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  searchWrap: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.bgPrimary, borderRadius: BorderRadius.input,
    paddingHorizontal: Spacing.md, height: 36, gap: Spacing.sm,
  },
  searchInput: { flex: 1, fontSize: Typography.caption, color: Colors.textPrimary },
  dateFilters: { flexDirection: 'row', gap: Spacing.sm, marginTop: Spacing.sm },
  dateFilterBtn: {
    paddingHorizontal: Spacing.sm, paddingVertical: 4,
    borderRadius: 10, backgroundColor: Colors.bgPrimary,
  },
  dateFilterBtnActive: { backgroundColor: Colors.primary },
  dateFilterText: { fontSize: 11, color: Colors.textSecondary },
  dateFilterTextActive: { color: Colors.white },
  // 管理员搜索
  adminSearch: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.bgWhite, marginHorizontal: Spacing.lg, marginTop: Spacing.md,
    borderRadius: BorderRadius.input, paddingHorizontal: Spacing.md, height: 40, gap: Spacing.sm,
    borderWidth: 1, borderColor: Colors.divider,
  },
  adminSearchInput: { flex: 1, fontSize: Typography.body, color: Colors.textPrimary },
  // 共享通知
  shareNotifBar: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    backgroundColor: Colors.primary + '10', marginHorizontal: Spacing.lg, marginTop: Spacing.md,
    padding: Spacing.md, borderRadius: BorderRadius.card,
  },
  shareNotifText: { flex: 1, fontSize: Typography.body, color: Colors.primary },
  // 列表
  container: { padding: Spacing.lg },
  empty: { alignItems: 'center', paddingVertical: Spacing.xl * 3, gap: Spacing.lg },
  emptyText: { fontSize: Typography.body, color: Colors.textHint },
  scheduleCard: { marginBottom: Spacing.md },
  overdueCard: { opacity: 0.6 },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.sm },
  visBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: Spacing.sm, paddingVertical: 2, borderRadius: 4 },
  visText: { fontSize: Typography.caption, fontWeight: '500' },
  overdueBadge: {
    backgroundColor: Colors.textHint + '30', paddingHorizontal: Spacing.sm,
    paddingVertical: 1, borderRadius: 4,
  },
  overdueText: { fontSize: 10, color: Colors.textHint },
  cardActions: { flexDirection: 'row', gap: Spacing.sm },
  actionBtn: { padding: Spacing.xs },
  scheduleTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.xs },
  scheduleContent: { fontSize: Typography.body, color: Colors.textSecondary, marginBottom: Spacing.sm, lineHeight: 20 },
  scheduleMeta: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, flexWrap: 'wrap' },
  scheduleTime: { fontSize: Typography.caption, color: Colors.textHint },
  reminderTag: {
    fontSize: 10, color: Colors.family, backgroundColor: Colors.family + '20',
    paddingHorizontal: 6, paddingVertical: 1, borderRadius: 3, overflow: 'hidden',
  },
  sharedTag: {
    fontSize: 10, color: Colors.primary, backgroundColor: Colors.primary + '20',
    paddingHorizontal: 6, paddingVertical: 1, borderRadius: 3, overflow: 'hidden',
  },
  ownerText: { fontSize: 10, fontWeight: '500' },
  // 弹窗
  formLabel: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary, marginBottom: Spacing.xs, marginTop: Spacing.sm },
  formInput: {
    borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input,
    padding: Spacing.md, justifyContent: 'center', minHeight: 44,
  },
  formInputText: { fontSize: Typography.body, color: Colors.textPrimary },
  formPlaceholder: { fontSize: Typography.body, color: Colors.textHint },
  formArea: { minHeight: 80, textAlignVertical: 'top' },
  switchRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: Spacing.sm },
  visRow: { flexDirection: 'row', gap: Spacing.sm },
  visBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4,
    paddingVertical: Spacing.sm, borderRadius: BorderRadius.card, borderWidth: 1,
    borderColor: Colors.divider, backgroundColor: Colors.bgWhite,
  },
  visBtnText: { fontSize: Typography.caption, fontWeight: '500' },
});

export default ScheduleScreen;
