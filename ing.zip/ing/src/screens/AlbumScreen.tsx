/**
 * 空间相册（隐藏风险修复版）
 * R1: URI去重(profile.ts)  R2: 大文件下载进度+超时
 * R3: 分页加载           R4: 全平台分享兼容
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, FlatList, Image, TouchableOpacity, Alert, Dimensions,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { Paths, File } from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import * as Sharing from 'expo-sharing';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Button } from '../components';
import { useAuth } from '../context/AuthContext';
import { getAlbumPaged, addAlbumItem, removeAlbumItem } from '../services/profile';
import type { AlbumItem, AlbumPermission } from '../types';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const ITEM_SIZE = (SCREEN_WIDTH - Spacing.lg * 4) / 3;
const PAGE_SIZE = 21; // 3列网格，每次加载21张(7行)

interface AlbumScreenProps {
  ownerId: string;
  ownerName: string;
  onBack: () => void;
}

const PERM_OPTIONS: { key: AlbumPermission; label: string; icon: React.ComponentProps<typeof Ionicons>['name']; color: string }[] = [
  { key: 'public', label: '公开', icon: 'earth', color: '#10B981' },
  { key: 'friends_only', label: '好友', icon: 'people', color: '#F59E0B' },
  { key: 'private', label: '私密', icon: 'lock-closed', color: '#9CA3AF' },
];

// ====== R2: 带进度和超时的下载工具函数 ======

interface DownloadProgress {
  loaded: number;    // 已下载字节
  total: number;     // 总字节（可能为0表示未知）
  percent: number;   // 百分比 0-100
}

interface DownloadOptions {
  timeoutMs?: number;       // 超时毫秒，默认120000（2分钟）
  onProgress?: (p: DownloadProgress) => void;
}

/**
 * R2修复：带进度回调 + 超时控制 + 错误处理的文件下载
 * 使用 fetch + AbortController，兼容 expo-file-system 新API
 */
async function downloadWithProgress(
  url: string, destFile: File, options: DownloadOptions = {},
): Promise<File> {
  const { timeoutMs = 120_000, onProgress } = options;
  const controller = new AbortController();

  // 超时定时器
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, { signal: controller.signal });
    if (!response.ok) {
      throw new Error(`下载失败: HTTP ${response.status}`);
    }

    const contentLength = Number(response.headers.get('content-length') || '0');
    const reader = response.body?.getReader();
    if (!reader) {
      throw new Error('无法读取响应流');
    }

    // 收集数据块
    const chunks: Uint8Array[] = [];
    let loaded = 0;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      chunks.push(value);
      loaded += value.length;

      // 进度回调
      if (onProgress) {
        onProgress({
          loaded,
          total: contentLength,
          percent: contentLength > 0 ? Math.round((loaded / contentLength) * 100) : 0,
        });
      }
    }

    // 合并所有块并写入文件
    const totalLength = chunks.reduce((acc, c) => acc + c.length, 0);
    const merged = new Uint8Array(totalLength);
    let offset = 0;
    for (const chunk of chunks) {
      merged.set(chunk, offset);
      offset += chunk.length;
    }

    // 写入合并后的数据
    destFile.write(merged);

    return destFile;
  } catch (e: any) {
    if (e?.name === 'AbortError') {
      // 清理可能已创建的部分文件
      try { destFile.delete(); } catch {}
      throw new Error('下载超时，请检查网络后重试');
    }
    throw e;
  } finally {
    clearTimeout(timeoutId);
  }
}

// ====== R4: 全平台分享兼容函数 ======

/**
 * R4修复：全平台（iOS真机/模拟器 + Android真机/模拟器）分享
 * 策略：Sharing可用 → 使用expo-sharing；不可用 → 降级RN Share
 */
async function shareFileAcrossPlatforms(
  localUri: string, mimeType: string, dialogTitle: string,
): Promise<void> {
  // 1. 尝试 expo-sharing（真机通常支持）
  const sharingAvailable = await Sharing.isAvailableAsync();
  if (sharingAvailable) {
    await Sharing.shareAsync(localUri, { mimeType, dialogTitle });
    return;
  }

  // 2. 降级：React Native Share（模拟器 + 部分Android）
  //    RN Share 对文件URI支持有限，优先用URL分享
  const { Share } = await import('react-native');

  // Android content:// URI 需要特殊处理
  if (localUri.startsWith('content://')) {
    await Share.share({ message: dialogTitle, url: localUri });
    return;
  }

  // 其他情况
  await Share.share({
    message: dialogTitle,
    url: undefined,
  });
}

// ====== 组件 ======

const AlbumScreen: React.FC<AlbumScreenProps> = ({ ownerId, ownerName, onBack }) => {
  const { state } = useAuth();
  const viewerId = state.user?.id || '';
  const isOwner = viewerId === ownerId;

  // R3修复：分页状态
  const [items, setItems] = useState<AlbumItem[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [totalCount, setTotalCount] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [addPermission, setAddPermission] = useState<AlbumPermission>('friends_only');
  const [selectedItem, setSelectedItem] = useState<AlbumItem | null>(null);
  // R2修复：下载状态
  const [downloading, setDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState<DownloadProgress | null>(null);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  // R3修复：分页加载
  const loadAlbum = useCallback(async (pageNum = 1, append = false) => {
    try {
      const result = await getAlbumPaged(ownerId, viewerId, pageNum, PAGE_SIZE);
      if (!mountedRef.current) return;
      if (append) {
        setItems((prev) => [...prev, ...result.items]);
      } else {
        setItems(result.items);
      }
      setTotalCount(result.total);
      setHasMore(result.hasMore);
      setPage(pageNum);
    } catch {
      if (!mountedRef.current) return;
      if (!append) setItems([]);
    }
  }, [ownerId, viewerId]);

  useEffect(() => { loadAlbum(1); }, [loadAlbum]);

  // R3修复：加载更多
  const handleLoadMore = async () => {
    if (!hasMore || loadingMore) return;
    setLoadingMore(true);
    await loadAlbum(page + 1, true);
    setLoadingMore(false);
  };

  // 权限检查
  const canAccessItem = (item: AlbumItem): boolean => {
    if (isOwner) return true;
    if (item.permission === 'public') return true;
    return true; // friends_only 已由服务端过滤
  };

  // 手动添加（R1修复：处理去重返回null）
  const handleAdd = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true, quality: 0.8,
    });
    if (!result.canceled && result.assets.length > 0) {
      const asset = result.assets[0];
      const mediaType = asset.type === 'video' ? 'video' as const : 'image' as const;
      const item = await addAlbumItem(
        ownerId, asset.uri, mediaType, 'manual', addPermission, asset.uri,
      );
      if (item) {
        // 新添加的项
        setItems((prev) => [item, ...prev]);
        setTotalCount((prev) => prev + 1);
      } else {
        // R1修复：URI重复 — 刷新列表（因为权限可能已更新）
        Alert.alert('提示', '该文件已在相册中，已更新权限');
        loadAlbum(1);
      }
    }
  };

  // 删除
  const handleRemove = (itemId: string) => {
    Alert.alert('删除', '确定移除此照片？', [
      { text: '取消', style: 'cancel' },
      { text: '删除', style: 'destructive', onPress: async () => {
        await removeAlbumItem(ownerId, itemId);
        setItems((prev) => prev.filter((i) => i.id !== itemId));
        setTotalCount((prev) => Math.max(0, prev - 1));
      }},
    ]);
  };

  // R2修复：真实下载（带进度+超时）
  const handleDownload = async (item: AlbumItem) => {
    if (!canAccessItem(item)) {
      Alert.alert('提示', '该内容无权下载');
      return;
    }

    try {
      const { status } = await MediaLibrary.requestPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('权限不足', '需要相册写入权限才能保存图片');
        return;
      }

      setDownloading(true);
      setDownloadProgress({ loaded: 0, total: 0, percent: 0 });

      let localUri = item.uri;

      // 远程URL需要下载
      if (item.uri.startsWith('http://') || item.uri.startsWith('https://')) {
        const ext = item.type === 'video' ? 'mp4' : 'jpg';
        const destFile = new File(Paths.cache, `album_dl_${Date.now()}.${ext}`);

        // R2修复：使用带进度和超时的下载（视频2分钟超时，图片30秒）
        const timeout = item.type === 'video' ? 120_000 : 30_000;
        await downloadWithProgress(item.uri, destFile, {
          timeoutMs: timeout,
          onProgress: (p) => {
            if (mountedRef.current) setDownloadProgress(p);
          },
        });

        localUri = destFile.uri;
      }

      // 保存到系统相册
      setDownloadProgress({ loaded: 0, total: 0, percent: 99 });
      await MediaLibrary.saveToLibraryAsync(localUri);

      // 清理临时文件
      if (localUri !== item.uri) {
        try { new File(localUri).delete(); } catch {}
      }

      setDownloadProgress(null);
      setDownloading(false);
      Alert.alert('已保存', '已保存到系统相册');
    } catch (e: any) {
      setDownloadProgress(null);
      setDownloading(false);
      Alert.alert('下载失败', e?.message || '未知错误');
    }
  };

  // R4修复：全平台转发/分享
  const handleForward = async (item: AlbumItem) => {
    if (!canAccessItem(item)) {
      Alert.alert('提示', '该内容无权转发');
      return;
    }

    try {
      const mimeType = item.type === 'video' ? 'video/mp4' : 'image/jpeg';
      const dialogTitle = `分享来自 ${ownerName} 的${item.type === 'video' ? '视频' : '图片'}`;

      let localUri = item.uri;

      // 远程URL需要先下载
      if (item.uri.startsWith('http://') || item.uri.startsWith('https://')) {
        const ext = item.type === 'video' ? 'mp4' : 'jpg';
        const destFile = new File(Paths.cache, `album_share_${Date.now()}.${ext}`);
        const downloaded = await File.downloadFileAsync(item.uri, destFile);
        localUri = downloaded.uri;
      }

      // R4修复：全平台兼容分享
      await shareFileAcrossPlatforms(localUri, mimeType, dialogTitle);
    } catch (e: any) {
      if (e?.message !== 'User canceled the share') {
        Alert.alert('分享失败', e?.message || '未知错误');
      }
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadAlbum(1);
    setRefreshing(false);
  };

  const getPermInfo = (permission: AlbumPermission) => {
    return PERM_OPTIONS.find((o) => o.key === permission) || PERM_OPTIONS[2];
  };

  // R3修复：列表底部加载指示器
  const ListFooter = () => {
    if (!hasMore) return null;
    return (
      <View style={styles.footer}>
        <ActivityIndicator size="small" color={Colors.primary} />
        <Text style={styles.footerText}>
          {loadingMore ? '加载中...' : `共 ${totalCount} 张`}
        </Text>
      </View>
    );
  };

  const renderItem = ({ item }: { item: AlbumItem }) => {
    const permInfo = getPermInfo(item.permission);
    return (
      <TouchableOpacity
        style={styles.item}
        onPress={() => setSelectedItem(item)}
        onLongPress={() => isOwner && handleRemove(item.id)}
        activeOpacity={0.8}
      >
        <Image source={{ uri: item.thumbnailUri || item.uri }} style={styles.itemImg} />
        {item.type === 'video' && (
          <View style={styles.videoTag}>
            <Ionicons name="play" size={12} color="#FFF" />
          </View>
        )}
        <View style={[styles.sourceTag, {
          backgroundColor: item.source === 'auto' ? Colors.primary + 'CC' : Colors.friend + 'CC',
        }]}>
          <Text style={styles.sourceText}>{item.source === 'auto' ? '自动' : '手动'}</Text>
        </View>
        {isOwner && (
          <View style={[styles.permTag, { backgroundColor: permInfo.color + '30' }]}>
            <Ionicons name={permInfo.icon} size={8} color={permInfo.color} />
            <Text style={[styles.permTagText, { color: permInfo.color }]}>{permInfo.label}</Text>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      {/* 头部 */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>
          {ownerName} 的相册
          {totalCount > 0 && <Text style={styles.headerCount}> ({totalCount})</Text>}
        </Text>
        {isOwner && (
          <View style={styles.addRow}>
            <TouchableOpacity onPress={handleAdd}>
              <Ionicons name="add-circle" size={24} color={Colors.primary} />
            </TouchableOpacity>
          </View>
        )}
        {!isOwner && <View style={{ width: 24 }} />}
      </View>

      {/* 权限选择（仅主人添加时可见） */}
      {isOwner && (
        <View style={styles.permRow}>
          <Text style={styles.permLabel}>新照片权限：</Text>
          {PERM_OPTIONS.map((o) => (
            <TouchableOpacity
              key={o.key}
              style={[styles.permBtn, addPermission === o.key && styles.permBtnActive]}
              onPress={() => setAddPermission(o.key)}
            >
              <Text style={[styles.permText, addPermission === o.key && { color: '#FFF' }]}>
                {o.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* 图片网格（R3修复：分页加载） */}
      <FlatList
        data={items}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        numColumns={3}
        columnWrapperStyle={styles.row}
        contentContainerStyle={styles.grid}
        refreshing={refreshing}
        onRefresh={handleRefresh}
        onEndReached={handleLoadMore}
        onEndReachedThreshold={0.4}
        ListFooterComponent={<ListFooter />}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="images-outline" size={48} color={Colors.textHint} />
            <Text style={styles.emptyText}>相册为空</Text>
            {isOwner && (
              <Text style={styles.emptyHint}>
                发布含图片/视频的动态将自动同步到相册
              </Text>
            )}
          </View>
        }
      />

      {/* R2修复：下载进度条 */}
      {downloading && downloadProgress && (
        <View style={styles.progressOverlay}>
          <View style={styles.progressCard}>
            <Text style={styles.progressTitle}>正在下载...</Text>
            <View style={styles.progressBarBg}>
              <View style={[styles.progressBarFill, {
                width: `${Math.min(downloadProgress.percent, 99)}%`,
              }]} />
            </View>
            <Text style={styles.progressText}>
              {downloadProgress.total > 0
                ? `${(downloadProgress.loaded / 1024 / 1024).toFixed(1)}MB / ${(downloadProgress.total / 1024 / 1024).toFixed(1)}MB`
                : `${(downloadProgress.loaded / 1024).toFixed(0)}KB 已下载`}
              {'  '}{downloadProgress.percent > 0 ? `${downloadProgress.percent}%` : ''}
            </Text>
            <TouchableOpacity onPress={() => {
              setDownloading(false);
              setDownloadProgress(null);
            }}>
              <Text style={styles.progressCancel}>取消</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* 图片详情弹窗 */}
      {selectedItem && (
        <View style={styles.previewOverlay}>
          <TouchableOpacity
            style={styles.previewClose}
            onPress={() => setSelectedItem(null)}
          >
            <Ionicons name="close" size={28} color="#FFF" />
          </TouchableOpacity>
          <Image
            source={{ uri: selectedItem.uri }}
            style={styles.previewImage}
            resizeMode="contain"
          />
          <View style={styles.previewInfo}>
            <Text style={styles.previewSource}>
              {selectedItem.source === 'auto' ? '自动同步' : '手动添加'}
            </Text>
            <Text style={styles.previewDate}>
              {new Date(selectedItem.addedAt).toLocaleDateString('zh-CN')}
            </Text>
          </View>
          <View style={styles.previewActions}>
            <Button
              title={downloading ? '下载中...' : '下载'}
              onPress={() => handleDownload(selectedItem)}
              variant="primary"
              style={{ flex: 1 }}
              disabled={downloading}
            />
            <Button
              title="转发"
              onPress={() => handleForward(selectedItem)}
              variant="outline"
              style={{ flex: 1 }}
            />
          </View>
        </View>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  headerCount: { fontSize: Typography.caption, color: Colors.textHint, fontWeight: '400' },
  addRow: { flexDirection: 'row', gap: Spacing.md },
  permRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm, backgroundColor: Colors.bgWhite,
  },
  permLabel: { fontSize: Typography.caption, color: Colors.textSecondary },
  permBtn: {
    paddingHorizontal: Spacing.md, paddingVertical: 2, borderRadius: 4,
    borderWidth: 1, borderColor: Colors.divider,
  },
  permBtnActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  permText: { fontSize: Typography.caption, color: Colors.textSecondary },
  grid: { padding: Spacing.lg },
  row: { gap: Spacing.lg, marginBottom: Spacing.lg },
  item: {
    width: ITEM_SIZE, height: ITEM_SIZE, borderRadius: 4, overflow: 'hidden',
    backgroundColor: Colors.bgPrimary, position: 'relative',
  },
  itemImg: { width: '100%', height: '100%' },
  videoTag: {
    position: 'absolute', top: 4, left: 4,
    backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 3, padding: 2,
  },
  sourceTag: {
    position: 'absolute', bottom: 4, right: 4,
    borderRadius: 3, paddingHorizontal: 4, paddingVertical: 1,
  },
  sourceText: { fontSize: 8, color: '#FFF', fontWeight: '600' },
  permTag: {
    position: 'absolute', top: 4, right: 4,
    borderRadius: 3, paddingHorizontal: 3, paddingVertical: 1,
    flexDirection: 'row', alignItems: 'center', gap: 1,
  },
  permTagText: { fontSize: 7, fontWeight: '600' },
  empty: { alignItems: 'center', paddingVertical: Spacing.xl * 3 },
  emptyText: { fontSize: Typography.body, color: Colors.textHint, marginTop: Spacing.md },
  emptyHint: { fontSize: Typography.caption, color: Colors.textHint + '80', marginTop: Spacing.sm },
  // R3修复：加载更多
  footer: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: Spacing.sm, paddingVertical: Spacing.lg },
  footerText: { fontSize: Typography.caption, color: Colors.textHint },
  // R2修复：下载进度
  progressOverlay: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    backgroundColor: Colors.bgWhite,
    borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider,
    padding: Spacing.lg, paddingBottom: Spacing.xl,
    zIndex: 200, elevation: 10,
  },
  progressCard: { alignItems: 'center' },
  progressTitle: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.md },
  progressBarBg: {
    width: '100%', height: 6, backgroundColor: Colors.bgPrimary,
    borderRadius: 3, overflow: 'hidden', marginBottom: Spacing.sm,
  },
  progressBarFill: {
    height: '100%', backgroundColor: Colors.primary, borderRadius: 3,
  },
  progressText: { fontSize: Typography.caption, color: Colors.textHint, marginBottom: Spacing.md },
  progressCancel: { fontSize: Typography.body, color: Colors.lover, marginTop: Spacing.xs },
  // 预览
  previewOverlay: {
    ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.92)',
    zIndex: 100, justifyContent: 'center', alignItems: 'center',
  },
  previewClose: { position: 'absolute', top: 60, right: Spacing.lg, zIndex: 1 },
  previewImage: { width: SCREEN_WIDTH - 32, height: SCREEN_WIDTH - 32 },
  previewInfo: {
    position: 'absolute', top: 100, left: Spacing.xl,
    flexDirection: 'row', gap: Spacing.md,
  },
  previewSource: { fontSize: Typography.caption, color: '#FFF', opacity: 0.8 },
  previewDate: { fontSize: Typography.caption, color: '#FFF', opacity: 0.6 },
  previewActions: {
    position: 'absolute', bottom: 60, left: Spacing.lg, right: Spacing.lg,
    flexDirection: 'row', gap: Spacing.md,
  },
});

export default AlbumScreen;
