/**
 * 我的反馈列表页 — 查看所有提交的反馈及处理状态
 */
import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card } from '../components';
import { useAuth } from '../context/AuthContext';
import { getMyFeedbacks } from '../services/settings';
import type { Feedback } from '../types';

interface MyFeedbackScreenProps { onBack: () => void; }

const MyFeedbackScreen: React.FC<MyFeedbackScreenProps> = ({ onBack }) => {
  const { state } = useAuth();
  const user = state.user;
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);

  const loadData = useCallback(async () => {
    if (!user) return;
    const list = await getMyFeedbacks(user.id);
    setFeedbacks(list);
  }, [user]);

  useEffect(() => { loadData(); }, [loadData]);

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>我的反馈</Text>
        <View style={{ width: 24 }} />
      </View>
      <FlatList
        data={feedbacks}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="chatbubbles-outline" size={48} color={Colors.textHint} />
            <Text style={styles.emptyText}>暂无反馈记录</Text>
          </View>
        }
        renderItem={({ item }) => (
          <Card style={styles.card}>
            <View style={styles.cardHeader}>
              <Text style={styles.dateText}>{new Date(item.createdAt).toLocaleString('zh-CN')}</Text>
              <View style={[styles.statusBadge, { backgroundColor: item.status === 'pending' ? Colors.warning + '18' : Colors.family + '18' }]}>
                <View style={[styles.statusDot, { backgroundColor: item.status === 'pending' ? Colors.warning : Colors.family }]} />
                <Text style={[styles.statusText, { color: item.status === 'pending' ? Colors.warning : Colors.family }]}>
                  {item.status === 'pending' ? '处理中' : '已解决'}
                </Text>
              </View>
            </View>
            <Text style={styles.content}>{item.content}</Text>
            {item.contact ? <Text style={styles.contact}>联系方式: {item.contact}</Text> : null}
          </Card>
        )}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    backgroundColor: Colors.bgWhite, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  list: { padding: Spacing.lg },
  card: { marginBottom: Spacing.sm },
  cardHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  dateText: { fontSize: Typography.caption, color: Colors.textHint },
  statusBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 10 },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  statusText: { fontSize: 11, fontWeight: '600' },
  content: { fontSize: Typography.body, color: Colors.textPrimary, lineHeight: 22 },
  contact: { fontSize: Typography.caption, color: Colors.primary, marginTop: Spacing.xs },
  empty: { alignItems: 'center', paddingVertical: Spacing.xl * 3 },
  emptyText: { fontSize: Typography.body, color: Colors.textHint, marginTop: Spacing.md },
});

export default MyFeedbackScreen;
