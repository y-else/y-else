/**
 * 出行页面（增强版）
 * GPS定位、出行轨迹记录、实时共享、历史管理、管理员查看
 *
 * 修复:
 * - 集成GPS自动获取当前位置（不再是手动输入坐标）
 * - 实时位置共享集成gps.ts服务
 * - 管理员支持搜索和筛选进行中的出行
 * - mountedRef防内存泄漏
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert,
  TextInput, RefreshControl, ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card, Button, Modal } from '../components';
import { useAuth } from '../context/AuthContext';
import {
  getMyTravelRecords, startTravel, endTravel, deleteTravelRecord,
  shareTravelStatus, stopSharing, getActiveShares, getAllTravelRecords,
  searchTravelRecords, updateTravelRecord,
} from '../services/travel';
import { getContacts } from '../services/contacts';
import { getCurrentLocation } from '../services/gps';
import type { TravelRecord, LocationPoint, TravelShareStatus } from '../types';

interface TravelScreenProps {
  onBack: () => void;
}

const TravelScreen: React.FC<TravelScreenProps> = ({ onBack }) => {
  const { state } = useAuth();
  const user = state.user;
  const isAdmin = user?.role === 'admin';

  const [records, setRecords] = useState<TravelRecord[]>([]);
  const [activeRecord, setActiveRecord] = useState<TravelRecord | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [activeShares, setActiveShares] = useState<TravelShareStatus[]>([]);
  const [locating, setLocating] = useState(false);

  // 管理员搜索
  const [adminQuery, setAdminQuery] = useState('');
  const [adminActiveOnly, setAdminActiveOnly] = useState(false);

  // 表单
  const [startName, setStartName] = useState('');
  const [startLat, setStartLat] = useState('');
  const [startLng, setStartLng] = useState('');
  const [endName, setEndName] = useState('');
  const [endLat, setEndLat] = useState('');
  const [endLng, setEndLng] = useState('');
  const [notes, setNotes] = useState('');
  const [useAutoGPS, setUseAutoGPS] = useState(true);

  const mountedRef = useRef(true);
  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  const loadData = useCallback(async () => {
    if (!user) return;
    if (isAdmin) {
      if (adminQuery.trim() || adminActiveOnly) {
        const result = await searchTravelRecords(
          adminQuery.trim() || undefined,
          adminActiveOnly || undefined,
        );
        if (mountedRef.current) setRecords(result);
      } else {
        const all = await getAllTravelRecords();
        if (mountedRef.current) setRecords(all);
      }
    } else {
      const mine = await getMyTravelRecords(user.id);
      if (mountedRef.current) {
        setRecords(mine);
        setActiveRecord(mine.find((r) => r.isActive) || null);
      }
      const shares = await getActiveShares(user.id);
      if (mountedRef.current) setActiveShares(shares);
    }
  }, [user, isAdmin, adminQuery, adminActiveOnly]);

  useEffect(() => { loadData(); }, [loadData]);

  const handleRefresh = async () => { setRefreshing(true); await loadData(); setRefreshing(false); };

  // 自动获取GPS位置
  const handleAutoLocate = async () => {
    setLocating(true);
    const loc = await getCurrentLocation();
    setLocating(false);
    if (loc) {
      setStartName(loc.address || `经纬度: ${loc.latitude.toFixed(4)}, ${loc.longitude.toFixed(4)}`);
      setStartLat(loc.latitude.toString());
      setStartLng(loc.longitude.toString());
      Alert.alert('定位成功', `已获取当前位置：${loc.address || `${loc.latitude.toFixed(4)}, ${loc.longitude.toFixed(4)}`}`);
    } else {
      Alert.alert('定位失败', '无法获取当前位置，请检查GPS权限或手动输入');
    }
  };

  const handleStartTravel = async () => {
    if (!user || !startName.trim()) { Alert.alert('提示', '请输入起点名称'); return; }
    const loc: LocationPoint = {
      name: startName.trim(),
      latitude: startLat ? parseFloat(startLat) : 39.9042,
      longitude: startLng ? parseFloat(startLng) : 116.4074,
    };
    const record = await startTravel(user.id, user.username, loc);
    if (mountedRef.current) setActiveRecord(record);
    setStartName(''); setStartLat(''); setStartLng('');
    setShowCreate(false);
    await loadData();
    Alert.alert('出行开始', `已记录起点：${loc.name}`);
  };

  const handleEndTravel = async () => {
    if (!activeRecord || !endName.trim()) { Alert.alert('提示', '请输入终点名称'); return; }

    // 自动获取当前GPS位置作为终点
    let loc: LocationPoint;
    if (useAutoGPS) {
      setLocating(true);
      const current = await getCurrentLocation();
      setLocating(false);
      if (current) {
        loc = {
          name: current.address || endName.trim(),
          latitude: current.latitude,
          longitude: current.longitude,
        };
      } else {
        loc = {
          name: endName.trim(),
          latitude: endLat ? parseFloat(endLat) : 39.9150,
          longitude: endLng ? parseFloat(endLng) : 116.4040,
        };
      }
    } else {
      loc = {
        name: endName.trim(),
        latitude: endLat ? parseFloat(endLat) : 39.9150,
        longitude: endLng ? parseFloat(endLng) : 116.4040,
      };
    }

    await endTravel(activeRecord.id, loc, notes.trim() || undefined);
    if (mountedRef.current) setActiveRecord(null);
    setEndName(''); setEndLat(''); setEndLng(''); setNotes('');
    await loadData();
    Alert.alert('出行结束', `已记录终点：${loc.name}`);
  };

  const handleDelete = (id: string) => {
    Alert.alert('删除记录', '确定删除此出行记录？', [
      { text: '取消', style: 'cancel' },
      { text: '删除', style: 'destructive', onPress: async () => { await deleteTravelRecord(id); await loadData(); } },
    ]);
  };

  const handleShare = async (record: TravelRecord) => {
    const contacts = await getContacts();
    const bound = contacts.filter((c) => !c.isBlocked);
    if (bound.length === 0) { Alert.alert('提示', '暂无已绑定好友可共享'); return; }
    const options: Array<{ text: string; onPress?: () => void; style?: 'cancel' | 'destructive' | 'default' }> = bound.map((c) => ({
      text: c.username,
      onPress: async () => {
        if (!user) return;
        await shareTravelStatus(
          record.id, user.id, user.username,
          record.startLocation, c.userId,
        );
        Alert.alert('共享成功', `实时出行状态已共享给 ${c.username}`);
        await loadData();
      },
    }));
    options.push({ text: '取消', style: 'cancel' });
    Alert.alert('共享实时出行', '选择共享对象：', options);
  };

  const handleStopShare = async (record: TravelRecord) => {
    Alert.alert('停止共享', '确定停止共享此出行状态？', [
      { text: '取消', style: 'cancel' },
      { text: '确定', onPress: async () => { await stopSharing(record.id); await loadData(); } },
    ]);
  };

  const formatTime = (iso: string) => {
    const d = new Date(iso);
    return `${d.getMonth() + 1}月${d.getDate()}日 ${d.toTimeString().slice(0, 5)}`;
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>出行</Text>
        {!isAdmin && (
          <TouchableOpacity onPress={() => setShowCreate(true)}>
            <Ionicons name="add-circle" size={28} color={Colors.primary} />
          </TouchableOpacity>
        )}
        {isAdmin && <View style={{ width: 28 }} />}
      </View>

      <ScrollView
        contentContainerStyle={styles.container}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} colors={[Colors.primary]} />}
      >
        {/* 管理员搜索栏 */}
        {isAdmin && (
          <View style={styles.adminSearch}>
            <TextInput
              style={styles.searchInput}
              placeholder="搜索用户名/地点..."
              placeholderTextColor={Colors.textHint}
              value={adminQuery}
              onChangeText={setAdminQuery}
            />
            <TouchableOpacity
              style={[styles.filterToggle, adminActiveOnly && styles.filterToggleActive]}
              onPress={() => setAdminActiveOnly(!adminActiveOnly)}
            >
              <Text style={[styles.filterToggleText, adminActiveOnly && styles.filterToggleTextActive]}>
                进行中
              </Text>
            </TouchableOpacity>
          </View>
        )}

        {/* 当前出行状态（非管理员） */}
        {!isAdmin && (
          <Card style={styles.statusCard}>
            <Text style={styles.sectionTitle}>当前出行状态</Text>
            {activeRecord ? (
              <View>
                <View style={styles.statusBadge}>
                  <View style={styles.activeDot} />
                  <Text style={styles.activeText}>进行中</Text>
                </View>
                <View style={styles.locationRow}>
                  <Ionicons name="location" size={16} color={Colors.family} />
                  <Text style={styles.locationText}>起点：{activeRecord.startLocation.name}</Text>
                </View>
                <Text style={styles.startTime}>
                  开始时间：{formatTime(activeRecord.startedAt)}
                </Text>
                {activeRecord.sharedTo.length > 0 && (
                  <Text style={styles.shareStatus}>已共享给 {activeRecord.sharedTo.length} 人</Text>
                )}
                <View style={styles.endForm}>
                  <View style={styles.gpsRow}>
                    <Text style={styles.formLabel}>终点地点</Text>
                    <TouchableOpacity
                      style={[styles.autoGpsBtn, locating && styles.autoGpsBtnDisabled]}
                      onPress={async () => {
                        setLocating(true);
                        const loc = await getCurrentLocation();
                        setLocating(false);
                        if (loc) {
                          setEndName(loc.address || `位置 ${loc.latitude.toFixed(4)}, ${loc.longitude.toFixed(4)}`);
                          setEndLat(loc.latitude.toString());
                          setEndLng(loc.longitude.toString());
                        } else {
                          Alert.alert('定位失败', '请手动输入');
                        }
                      }}
                      disabled={locating}
                    >
                      {locating ? (
                        <ActivityIndicator size="small" color={Colors.primary} />
                      ) : (
                        <Ionicons name="locate-outline" size={18} color={Colors.primary} />
                      )}
                      <Text style={styles.autoGpsText}>自动定位</Text>
                    </TouchableOpacity>
                  </View>
                  <TextInput style={styles.formInput} placeholder="终点名称" placeholderTextColor={Colors.textHint} value={endName} onChangeText={setEndName} />
                  <View style={styles.coordRow}>
                    <TextInput style={[styles.formInput, styles.coordInput]} placeholder="纬度" placeholderTextColor={Colors.textHint} value={endLat} onChangeText={setEndLat} keyboardType="decimal-pad" />
                    <TextInput style={[styles.formInput, styles.coordInput]} placeholder="经度" placeholderTextColor={Colors.textHint} value={endLng} onChangeText={setEndLng} keyboardType="decimal-pad" />
                  </View>
                  <TextInput style={[styles.formInput, styles.notesInput]} placeholder="出行备注（选填）" placeholderTextColor={Colors.textHint} value={notes} onChangeText={setNotes} multiline />
                  <View style={styles.endActions}>
                    <Button title="结束出行" onPress={handleEndTravel} style={styles.endBtn} />
                    <Button title="共享位置" onPress={() => handleShare(activeRecord)} variant="outline" style={styles.endBtn} />
                    <Button title="停止共享" onPress={() => handleStopShare(activeRecord)} variant="ghost" style={styles.endBtn} />
                  </View>
                </View>
              </View>
            ) : (
              <View style={styles.noTravel}>
                <Ionicons name="walk-outline" size={32} color={Colors.textHint} />
                <Text style={styles.noTravelText}>暂无进行中的出行</Text>
                <Button title="开始出行" onPress={() => setShowCreate(true)} variant="outline" style={{ marginTop: Spacing.md }} />
              </View>
            )}
          </Card>
        )}

        {/* 出行历史 */}
        <Text style={styles.sectionTitle}>{isAdmin ? '全站出行定位历史' : '出行历史'}</Text>
        {records.length === 0 ? (
          <View style={styles.empty}>
            <Ionicons name="map-outline" size={48} color={Colors.textHint} />
            <Text style={styles.emptyText}>{isAdmin ? '暂无用户出行记录' : '暂无出行记录'}</Text>
          </View>
        ) : (
          records.map((r) => (
            <Card key={r.id} style={{ ...styles.historyCard, ...(r.isActive ? styles.activeHistoryCard : {}) } as any}>
              <View style={styles.historyHeader}>
                <View style={styles.historyIcon}>
                  <Ionicons
                    name={r.isActive ? 'navigate' : 'checkmark-circle'}
                    size={18}
                    color={r.isActive ? Colors.family : Colors.textHint}
                  />
                </View>
                <View style={styles.historyInfo}>
                  <Text style={styles.historyUser}>{r.username}</Text>
                  <Text style={styles.historyRoute}>
                    {r.startLocation.name} → {r.endLocation?.name || '进行中...'}
                  </Text>
                  <Text style={styles.historyTime}>
                    {formatTime(r.startedAt)}
                    {r.endedAt ? ` - ${formatTime(r.endedAt)}` : ''}
                  </Text>
                </View>
                {!isAdmin && !r.isActive && (
                  <TouchableOpacity onPress={() => handleDelete(r.id)}>
                    <Ionicons name="trash-outline" size={16} color={Colors.lover} />
                  </TouchableOpacity>
                )}
              </View>
              {r.notes ? <Text style={styles.notesText}>备注：{r.notes}</Text> : null}
              {r.sharedTo.length > 0 && (
                <Text style={styles.shareInfo}>已共享给 {r.sharedTo.length} 人</Text>
              )}
            </Card>
          ))
        )}
        <View style={{ height: 40 }} />
      </ScrollView>

      {/* 开始出行弹窗 */}
      <Modal
        visible={showCreate}
        title="开始出行"
        onClose={() => setShowCreate(false)}
        confirmText="开始"
        onConfirm={handleStartTravel}
      >
        <View style={styles.gpsRow}>
          <Text style={styles.formLabel}>起点名称</Text>
          <TouchableOpacity
            style={[styles.autoGpsBtn, locating && styles.autoGpsBtnDisabled]}
            onPress={handleAutoLocate}
            disabled={locating}
          >
            {locating ? (
              <ActivityIndicator size="small" color={Colors.primary} />
            ) : (
              <Ionicons name="locate-outline" size={18} color={Colors.primary} />
            )}
            <Text style={styles.autoGpsText}>自动定位</Text>
          </TouchableOpacity>
        </View>
        <TextInput
          style={styles.formInput}
          placeholder="如：北京市朝阳区XX路"
          placeholderTextColor={Colors.textHint}
          value={startName}
          onChangeText={setStartName}
        />
        <Text style={styles.formHint}>GPS坐标（自动定位优先，也可手动输入）</Text>
        <View style={styles.coordRow}>
          <TextInput style={[styles.formInput, styles.coordInput]} placeholder="纬度" placeholderTextColor={Colors.textHint} value={startLat} onChangeText={setStartLat} keyboardType="decimal-pad" />
          <TextInput style={[styles.formInput, styles.coordInput]} placeholder="经度" placeholderTextColor={Colors.textHint} value={startLng} onChangeText={setStartLng} keyboardType="decimal-pad" />
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary },
  container: { padding: Spacing.lg },
  // 管理员搜索
  adminSearch: { flexDirection: 'row', gap: Spacing.sm, marginBottom: Spacing.lg },
  searchInput: {
    flex: 1, borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input,
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    fontSize: Typography.body, color: Colors.textPrimary, backgroundColor: Colors.bgWhite,
  },
  filterToggle: {
    paddingHorizontal: Spacing.md, borderRadius: BorderRadius.input,
    backgroundColor: Colors.bgWhite, borderWidth: 1, borderColor: Colors.divider,
    alignItems: 'center', justifyContent: 'center',
  },
  filterToggleActive: { backgroundColor: Colors.family, borderColor: Colors.family },
  filterToggleText: { fontSize: Typography.caption, color: Colors.textSecondary },
  filterToggleTextActive: { color: Colors.white },
  sectionTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, marginBottom: Spacing.md, marginTop: Spacing.lg },
  // 当前状态
  statusCard: { marginBottom: Spacing.lg },
  statusBadge: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, marginBottom: Spacing.md },
  activeDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.family },
  activeText: { fontSize: Typography.body, fontWeight: '600', color: Colors.family },
  locationRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, marginBottom: 4 },
  locationText: { fontSize: Typography.body, color: Colors.textPrimary },
  startTime: { fontSize: Typography.caption, color: Colors.textHint, marginLeft: 22, marginBottom: Spacing.sm },
  shareStatus: { fontSize: Typography.caption, color: Colors.primary, marginLeft: 22, marginBottom: Spacing.sm },
  endForm: { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider, paddingTop: Spacing.md },
  formLabel: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary, marginBottom: Spacing.xs, marginTop: Spacing.sm },
  formInput: {
    borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input,
    padding: Spacing.md, fontSize: Typography.body, color: Colors.textPrimary,
  },
  formHint: { fontSize: Typography.caption, color: Colors.textHint, marginTop: Spacing.xs },
  // GPS
  gpsRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  autoGpsBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: Spacing.sm, paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.input, borderWidth: 1, borderColor: Colors.primary,
    marginTop: Spacing.sm,
  },
  autoGpsBtnDisabled: { borderColor: Colors.divider, opacity: 0.6 },
  autoGpsText: { fontSize: Typography.caption, color: Colors.primary },
  coordRow: { flexDirection: 'row', gap: Spacing.sm },
  coordInput: { flex: 1 },
  notesInput: { minHeight: 60, textAlignVertical: 'top', marginTop: Spacing.sm },
  endActions: { gap: Spacing.sm, marginTop: Spacing.lg },
  endBtn: { flex: 1 },
  noTravel: { alignItems: 'center', paddingVertical: Spacing.xl, gap: Spacing.sm },
  noTravelText: { fontSize: Typography.body, color: Colors.textHint },
  // 历史记录
  historyCard: { marginBottom: Spacing.sm },
  activeHistoryCard: { borderWidth: 1, borderColor: Colors.family + '40' },
  historyHeader: { flexDirection: 'row', alignItems: 'center' },
  historyIcon: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: Colors.bgPrimary, alignItems: 'center', justifyContent: 'center',
    marginRight: Spacing.md,
  },
  historyInfo: { flex: 1 },
  historyUser: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  historyRoute: { fontSize: Typography.caption, color: Colors.textSecondary, marginTop: 2 },
  historyTime: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  notesText: { fontSize: Typography.caption, color: Colors.textSecondary, marginTop: Spacing.sm, marginLeft: 44 },
  shareInfo: { fontSize: Typography.caption, color: Colors.primary, marginTop: 4, marginLeft: 44 },
  // 空状态
  empty: { alignItems: 'center', paddingVertical: Spacing.xl * 2, gap: Spacing.lg },
  emptyText: { fontSize: Typography.body, color: Colors.textHint },
});

export default TravelScreen;
