/**
 * 个人空间（全面修复版）
 * 修复：F3真实拉黑 + F5头像传入 + 管理员只读 + 举报/拉黑对接 + 虚拟列表优化
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TextInput, TouchableOpacity, Alert, Image,
  ScrollView, ImageBackground,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Button, PostCard, Card } from '../components';
import { useAuth } from '../context/AuthContext';
import {
  getSpacePosts, createSpacePost, deleteSpacePost,
  likeSpacePost, addSpaceComment, deleteSpaceComment,
  recordVisit, getVisitRecord, getPublicProfile,
  getOnlineStatus, blockSpacePostAuthor, reportSpacePost, blockSpaceCommentAuthor,
} from '../services/profile';
import { getLevelConfig } from '../services/level';
import { submitReport } from '../services/contentReport';
import type { SpacePost, SpaceVisibility, SpaceMedia, SpaceVisit, PublicProfile } from '../types';

const BG_KEY = '@ing_space_bg_';

interface PersonalSpaceScreenProps {
  ownerId: string; ownerName: string; onBack: () => void;
  onNavigateAlbum?: (ownerId: string, ownerName: string) => void;
  onNavigateEdit?: (userId: string) => void;
}

const VIS_OPTIONS: { key: SpaceVisibility; label: string }[] = [
  { key: 'public', label: '公开' }, { key: 'friends_only', label: '好友可见' }, { key: 'private', label: '仅自己' },
];

const POST_HEIGHT = 320; // 虚拟列表预估高度

const PersonalSpaceScreen: React.FC<PersonalSpaceScreenProps> = ({
  ownerId, ownerName, onBack, onNavigateAlbum, onNavigateEdit,
}) => {
  const { state } = useAuth();
  const viewerId = state.user?.id || '';
  const viewerName = state.user?.username || '';
  const viewerAvatar = state.user?.avatar || null;
  const viewerRole = state.user?.role || '';
  const isOwner = viewerId === ownerId;
  const isAdmin = viewerRole === 'admin';

  const [posts, setPosts] = useState<SpacePost[]>([]);
  const [profile, setProfile] = useState<PublicProfile | null>(null);
  const [visitRecord, setVisitRecord] = useState({ totalVisits: 0, visitorList: [] as SpaceVisit[] });
  const [showEditor, setShowEditor] = useState(false);
  const [editorContent, setEditorContent] = useState('');
  const [editorMedia, setEditorMedia] = useState<SpaceMedia[]>([]);
  const [editorVisibility, setEditorVisibility] = useState<SpaceVisibility>('friends_only');
  const [publishing, setPublishing] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  // 在线状态
  const [isOnline, setIsOnline] = useState(false);
  // 背景图
  const [bgImage, setBgImage] = useState<string | null>(null);

  useEffect(() => {
    // 记录访问（非主人）
    if (!isOwner && viewerId) recordVisit(ownerId, viewerId, viewerName, viewerAvatar);
    getPublicProfile(ownerId).then((p) => { if (p) setProfile(p); }).catch(() => {});
    getOnlineStatus(ownerId).then((o) => setIsOnline(o)).catch(() => {});
    AsyncStorage.getItem(BG_KEY + ownerId).then((uri) => { if (uri) setBgImage(uri); }).catch(() => {});
  }, [ownerId, isOwner, viewerId]);

  // R3修复：对接 getSpacePosts 分页返回值 + R2修复：拉黑后即时过滤
  const loadPosts = useCallback(async () => {
    const result = await getSpacePosts(ownerId, viewerId);
    setPosts(result.posts);
    const vr = await getVisitRecord(ownerId, viewerId);
    setVisitRecord(vr);
  }, [ownerId, viewerId]);
  useEffect(() => { loadPosts(); }, [loadPosts]);

  // 更换背景图
  const handleChangeBg = async () => {
    if (!isOwner) return;
    Alert.alert('更换背景', '选择图片来源', [
      { text: '相册', onPress: async () => {
        const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, quality: 0.7 });
        if (!r.canceled && r.assets[0]) { setBgImage(r.assets[0].uri); AsyncStorage.setItem(BG_KEY + ownerId, r.assets[0].uri); }
      }},
      { text: '恢复默认', style: 'destructive', onPress: () => { setBgImage(null); AsyncStorage.removeItem(BG_KEY + ownerId); }},
      { text: '取消', style: 'cancel' },
    ]);
  };

  // 发布
  const handlePickMedia = async (type: 'image' | 'video') => {
    const r = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: type === 'video' ? ImagePicker.MediaTypeOptions.Videos : ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true, quality: 0.8, videoMaxDuration: 60,
    });
    if (!r.canceled && r.assets.length > 0) {
      setEditorMedia((prev) => [...prev, ...r.assets.map((a) => ({
        uri: a.uri, type,
        thumbnailUri: a.uri,
      }))].slice(0, 9));
    }
  };

  const handlePublish = async () => {
    if (!editorContent.trim() && editorMedia.length === 0) {
      Alert.alert('提示', '请输入内容或添加图片/视频');
      return;
    }
    setPublishing(true);
    // F5修复：传入真实头像
    const post = await createSpacePost(
      ownerId, viewerName, viewerAvatar,
      editorContent.trim(), editorMedia, editorVisibility,
    );
    setPosts((prev) => [post, ...prev]);
    setEditorContent(''); setEditorMedia([]); setShowEditor(false); setPublishing(false);
  };

  // 点赞（F1修复：对接新返回值）
  const handleLike = async (postId: string) => {
    const result = await likeSpacePost(postId, viewerId, viewerName);
    if (result.post) {
      setPosts((prev) => prev.map((p) => p.id === postId ? result.post! : p));
    }
    if (!result.liked && result.message.includes('今日已点赞')) {
      Alert.alert('提示', result.message);
    }
  };

  // 评论
  const handleComment = async (postId: string, content: string) => {
    const u = await addSpaceComment(postId, viewerId, viewerName, viewerAvatar, content);
    if (u) setPosts((prev) => prev.map((p) => p.id === postId ? u : p));
  };

  // 删除动态（F4修复：管理员只读）
  const handleDeletePost = (postId: string) => {
    if (isAdmin) { Alert.alert('提示', '管理员无权删除用户动态'); return; }
    Alert.alert('删除动态', '确定删除？', [
      { text: '取消', style: 'cancel' },
      { text: '删除', style: 'destructive', onPress: async () => {
        const r = await deleteSpacePost(postId, viewerId, viewerRole);
        if (r.success) {
          setPosts((prev) => prev.filter((p) => p.id !== postId));
        } else {
          Alert.alert('提示', r.message);
        }
      }},
    ]);
  };

  // 删除评论（F4修复：管理员只读）
  const handleDeleteComment = async (postId: string, commentId: string) => {
    if (isAdmin) { Alert.alert('提示', '管理员无权删除评论'); return; }
    const r = await deleteSpaceComment(postId, commentId, viewerId, viewerRole);
    if (r.success) {
      // 本地更新
      setPosts((prev) => prev.map((p) => {
        if (p.id !== postId) return p;
        return {
          ...p,
          comments: p.comments.map((c) => c.id === commentId ? { ...c, isDeleted: true } : c),
        };
      }));
    } else {
      Alert.alert('提示', r.message);
    }
  };

  // 举报用户（整体举报）
  const handleReportUser = () => {
    Alert.alert('举报用户', '确定举报该用户？', [
      { text: '取消', style: 'cancel' },
      { text: '举报', style: 'destructive', onPress: async () => {
        const r = await submitReport({
          reporterId: viewerId, reporterName: viewerName,
          targetType: 'user', targetId: ownerId,
          targetPreview: ownerName, reason: '用户举报',
        });
        Alert.alert(r.success ? '已提交' : '提示', r.message);
      }},
    ]);
  };

  // 举报动态（F3修复：真实举报）
  const handleReportPost = async (postId: string) => {
    Alert.alert('举报动态', '确定举报这条动态？', [
      { text: '取消', style: 'cancel' },
      { text: '举报', style: 'destructive', onPress: async () => {
        const r = await reportSpacePost(postId, viewerId, viewerName, '违规内容');
        Alert.alert(r.success ? '已提交' : '提示', r.message);
      }},
    ]);
  };

  // 拉黑动态发布者（F3修复：真实拉黑 + R2修复：即时本地过滤）
  const handleBlockAuthor = async (postId: string) => {
    Alert.alert('拉黑', '拉黑后将不再看到该用户的动态和互动', [
      { text: '取消', style: 'cancel' },
      { text: '确认拉黑', style: 'destructive', onPress: async () => {
        const r = await blockSpacePostAuthor(postId, viewerId);
        Alert.alert('提示', r.message);
        if (r.success) {
          // R2修复：先从本地 state 中立即移除被拉黑者的所有动态（即时反馈）
          const blockedPost = posts.find((p) => p.id === postId);
          if (blockedPost) {
            const blockedAuthorId = blockedPost.authorId;
            setPosts((prev) => prev.filter((p) => p.authorId !== blockedAuthorId));
          }
          // 然后从服务端重新加载，确保数据一致性
          loadPosts();
        }
      }},
    ]);
  };

  // 拉黑评论者（F3修复：真实拉黑 + R2修复：重载清理评论）
  const handleBlockCommentAuthor = async (postId: string, commentId: string) => {
    Alert.alert('拉黑', '拉黑该评论者？', [
      { text: '取消', style: 'cancel' },
      { text: '确认拉黑', style: 'destructive', onPress: async () => {
        const r = await blockSpaceCommentAuthor(postId, commentId, viewerId);
        Alert.alert('提示', r.message);
        if (r.success) {
          // R2修复：拉黑评论者后重新加载，确保被拉黑者的所有评论从UI中移除
          loadPosts();
        }
      }},
    ]);
  };

  // 拉黑空间主人（整体拉黑 — F3修复 + R2修复：即时清空列表）
  const handleBlockUser = () => {
    Alert.alert('拉黑', '拉黑后将不再看到该用户的动态和互动', [
      { text: '取消', style: 'cancel' },
      { text: '确认拉黑', style: 'destructive', onPress: async () => {
        try {
          const { blockUser } = await import('../services/contacts');
          await blockUser(viewerId, ownerId, '空间页面拉黑');
          // R2修复：拉黑成功后立即清空本地动态列表
          setPosts([]);
          Alert.alert('已拉黑', '已拉黑该用户，动态已隐藏');
        } catch {
          Alert.alert('失败', '拉黑失败，请重试');
        }
      }},
    ]);
  };

  const handleRefresh = async () => { setRefreshing(true); await loadData(); setRefreshing(false); };
  const loadData = async () => { await loadPosts(); try { const p = await getPublicProfile(ownerId); if (p) setProfile(p); } catch {} };

  // 虚拟列表 getItemLayout（M4修复）
  const getItemLayout = (_data: any, index: number) => ({
    length: POST_HEIGHT,
    offset: POST_HEIGHT * index,
    index,
  });

  // 资料头部
  const ProfileHeader = () => (
    <Card style={styles.profileCard}>
      <TouchableOpacity onLongPress={handleChangeBg} activeOpacity={0.9} style={styles.bgTouchable}>
        {bgImage ? (
          <ImageBackground source={{ uri: bgImage }} style={styles.profileBg} imageStyle={{ opacity: 0.35 }}>
            <View style={styles.bgHint}><Ionicons name="camera" size={14} color={Colors.textHint} /><Text style={styles.bgHintText}>长按更换背景</Text></View>
          </ImageBackground>
        ) : (
          <View style={styles.profileBg}>
            <Ionicons name="image-outline" size={48} color={Colors.textHint + '40'} />
            {isOwner && <Text style={styles.bgHintText}>长按设置背景图</Text>}
          </View>
        )}
      </TouchableOpacity>
      <View style={styles.profileAvatarWrap}>
        <View style={styles.profileAvatar}>
          {profile?.avatar ? <Image source={{ uri: profile.avatar }} style={styles.avatarImg} /> : <Ionicons name="person" size={36} color={Colors.textHint} />}
        </View>
        {isOnline && <View style={styles.onlineDot} />}
      </View>
      <Text style={styles.profileName}>{profile?.username || ownerName}</Text>
      {profile?.level ? (
        <View style={styles.levelRow}>
          <View style={styles.levelBadge}><Ionicons name="star" size={14} color={Colors.friend} /><Text style={styles.levelText}>LV.{profile.level}</Text></View>
          <Text style={styles.levelTitleText}>{getLevelConfig(profile.level).title}</Text>
        </View>
      ) : null}
      {profile?.bio ? (
        <TouchableOpacity onPress={() => isOwner && onNavigateEdit?.(ownerId)}>
          <Text style={styles.bioText} numberOfLines={3}>{profile.bio}</Text>
        </TouchableOpacity>
      ) : (
        <TouchableOpacity onPress={() => isOwner && onNavigateEdit?.(ownerId)}>
          <Text style={styles.bioPlaceholder}>{isOwner ? '点击编辑资料，写一段个人简介吧' : '这个人很懒，什么都没写'}</Text>
        </TouchableOpacity>
      )}
      <View style={styles.statRow}>
        <View style={styles.statItem}><Text style={styles.statNum}>{posts.length}</Text><Text style={styles.statLabel}>动态</Text></View>
        <View style={styles.statItem}><Text style={styles.statNum}>{visitRecord.totalVisits}</Text><Text style={styles.statLabel}>访客</Text></View>
        {profile?.birthday && <View style={styles.statItem}><Text style={styles.statNum}>{profile.birthday.slice(5)}</Text><Text style={styles.statLabel}>生日</Text></View>}
      </View>
      {/* 操作按钮 — 管理员只读模式：隐藏举报/拉黑 */}
      <View style={styles.headerActions}>
        {isOwner && (
          <TouchableOpacity style={styles.headerActionItem} onPress={() => onNavigateAlbum?.(ownerId, ownerName)}>
            <Ionicons name="albums-outline" size={18} color={Colors.primary} /><Text style={styles.headerActionText}>相册</Text>
          </TouchableOpacity>
        )}
        {isOwner && (
          <TouchableOpacity style={styles.headerActionItem} onPress={() => onNavigateEdit?.(ownerId)}>
            <Ionicons name="create-outline" size={18} color={Colors.textSecondary} /><Text style={styles.headerActionText}>编辑资料</Text>
          </TouchableOpacity>
        )}
        {/* 管理员只读：不显示举报/拉黑按钮 */}
        {/* 非好友可举报用户 */}
        {!isOwner && !isAdmin && (
          <>
            <TouchableOpacity style={styles.headerActionItem} onPress={handleReportUser}>
              <Ionicons name="flag-outline" size={18} color={Colors.lover} /><Text style={styles.headerActionText}>举报</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.headerActionItem} onPress={handleBlockUser}>
              <Ionicons name="ban-outline" size={18} color={Colors.textHint} /><Text style={styles.headerActionText}>拉黑</Text>
            </TouchableOpacity>
          </>
        )}
      </View>
      {/* 管理员只读标记 */}
      {isAdmin && (
        <View style={styles.adminBadge}>
          <Ionicons name="shield-checkmark-outline" size={12} color={Colors.admin} />
          <Text style={styles.adminText}>管理员只读模式</Text>
        </View>
      )}
    </Card>
  );

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}><Ionicons name="arrow-back" size={24} color={Colors.textPrimary} /></TouchableOpacity>
        <View style={styles.headerCenter}><Text style={styles.headerTitle}>{ownerName} 的空间</Text></View>
        <View style={{ width: 32 }} />
      </View>
      <FlatList
        data={posts}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.postWrapper}>
            <PostCard
              post={item}
              viewerId={viewerId}
              viewerName={viewerName}
              isOwner={isOwner}
              isAdmin={isAdmin}
              onLike={handleLike}
              onComment={handleComment}
              onDelete={handleDeletePost}
              onDeleteComment={handleDeleteComment}
              onReport={handleReportPost}
              onBlockAuthor={handleBlockAuthor}
              onBlockCommentAuthor={handleBlockCommentAuthor}
            />
          </View>
        )}
        contentContainerStyle={styles.listContent}
        refreshing={refreshing}
        onRefresh={handleRefresh}
        getItemLayout={getItemLayout}
        removeClippedSubviews
        windowSize={7}
        maxToRenderPerBatch={7}
        initialNumToRender={7}
        updateCellsBatchingPeriod={50}
        ListHeaderComponent={<ProfileHeader />}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="images-outline" size={48} color={Colors.textHint} />
            <Text style={styles.emptyText}>{isOwner ? '发布你的第一条动态' : '暂无动态'}</Text>
          </View>
        }
      />
      {isOwner && !showEditor && (
        <TouchableOpacity style={styles.fab} onPress={() => setShowEditor(true)} activeOpacity={0.8}>
          <Ionicons name="camera" size={24} color="#FFF" />
        </TouchableOpacity>
      )}
      {showEditor && (
        <View style={styles.editor}>
          <View style={styles.editorTop}>
            <TouchableOpacity onPress={() => { setShowEditor(false); setEditorContent(''); setEditorMedia([]); }}>
              <Text style={styles.cancelText}>取消</Text>
            </TouchableOpacity>
            <Text style={styles.editorTitle}>发动态</Text>
            <Button title="发布" onPress={handlePublish} loading={publishing} style={{ paddingHorizontal: Spacing.lg }} />
          </View>
          {editorMedia.length > 0 && (
            <ScrollView horizontal style={{ marginBottom: Spacing.sm }} showsHorizontalScrollIndicator={false}>
              {editorMedia.map((m, i) => (
                <View key={i} style={{ position: 'relative', marginRight: Spacing.sm }}>
                  <Image source={{ uri: m.thumbnailUri || m.uri }} style={{ width: 72, height: 72, borderRadius: 4 }} />
                  <TouchableOpacity style={{ position: 'absolute', top: -6, right: -6 }} onPress={() => setEditorMedia((prev) => prev.filter((_, j) => j !== i))}>
                    <Ionicons name="close-circle" size={18} color={Colors.lover} />
                  </TouchableOpacity>
                </View>
              ))}
            </ScrollView>
          )}
          <TextInput style={styles.editorInput} placeholder="分享你的生活..." placeholderTextColor={Colors.textHint} multiline value={editorContent} onChangeText={setEditorContent} />
          <View style={{ flexDirection: 'row', gap: Spacing.xl, marginBottom: Spacing.md }}>
            <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }} onPress={() => handlePickMedia('image')}>
              <Ionicons name="image-outline" size={22} color={Colors.primary} /><Text style={{ fontSize: Typography.caption, color: Colors.textSecondary }}>图片</Text>
            </TouchableOpacity>
            <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }} onPress={() => handlePickMedia('video')}>
              <Ionicons name="videocam-outline" size={22} color={Colors.admin} /><Text style={{ fontSize: Typography.caption, color: Colors.textSecondary }}>视频</Text>
            </TouchableOpacity>
          </View>
          <View style={{ flexDirection: 'row', gap: Spacing.sm }}>
            {VIS_OPTIONS.map((o) => (
              <TouchableOpacity key={o.key} style={[styles.visBtn, editorVisibility === o.key && { backgroundColor: '#7B68EE', borderColor: '#7B68EE' }]} onPress={() => setEditorVisibility(o.key)}>
                <Text style={[styles.visBtnText, editorVisibility === o.key && { color: '#FFF' }]}>{o.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, backgroundColor: Colors.bgWhite, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider },
  headerCenter: { alignItems: 'center' },
  headerTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  listContent: { paddingHorizontal: Spacing.lg, paddingBottom: Spacing.xl },
  profileCard: { marginTop: Spacing.lg, alignItems: 'center', paddingTop: 0, overflow: 'hidden' },
  bgTouchable: { width: '120%', alignSelf: 'center' },
  profileBg: { width: '100%', height: 120, backgroundColor: Colors.bgPrimary, alignSelf: 'center', marginTop: -Spacing.md, marginBottom: -40, alignItems: 'center', justifyContent: 'center' },
  bgHint: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 60 },
  bgHintText: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 4 },
  profileAvatarWrap: { position: 'relative', marginBottom: Spacing.sm },
  profileAvatar: { width: 72, height: 72, borderRadius: 36, backgroundColor: Colors.bgWhite, alignItems: 'center', justifyContent: 'center', borderWidth: 3, borderColor: Colors.bgWhite, elevation: 3 },
  avatarImg: { width: 72, height: 72, borderRadius: 36 },
  onlineDot: { width: 14, height: 14, borderRadius: 7, backgroundColor: Colors.family, borderWidth: 2, borderColor: Colors.bgWhite, position: 'absolute', bottom: 0, right: 0 },
  profileName: { fontSize: Typography.title, fontWeight: '700', color: Colors.textPrimary, marginTop: Spacing.xs },
  levelRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, marginTop: Spacing.xs },
  levelBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: Colors.friend + '15', paddingHorizontal: Spacing.md, paddingVertical: 2, borderRadius: 10 },
  levelText: { fontSize: Typography.caption, color: Colors.friend, fontWeight: '600' },
  levelTitleText: { fontSize: Typography.caption, color: Colors.textSecondary },
  bioText: { fontSize: Typography.body, color: Colors.textSecondary, textAlign: 'center', paddingHorizontal: Spacing.xl, marginTop: Spacing.sm, lineHeight: 20 },
  bioPlaceholder: { fontSize: Typography.caption, color: Colors.primary, textAlign: 'center', paddingHorizontal: Spacing.xl, marginTop: Spacing.sm, textDecorationLine: 'underline' },
  statRow: { flexDirection: 'row', justifyContent: 'center', gap: Spacing.xl, marginTop: Spacing.lg, paddingTop: Spacing.md, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider, width: '100%' },
  statItem: { alignItems: 'center' },
  statNum: { fontSize: Typography.subtitle, fontWeight: '700', color: Colors.textPrimary },
  statLabel: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  headerActions: { flexDirection: 'row', justifyContent: 'center', gap: Spacing.xl, marginTop: Spacing.md, paddingTop: Spacing.sm, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider, width: '100%' },
  headerActionItem: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: Spacing.xs, paddingHorizontal: Spacing.md },
  headerActionText: { fontSize: Typography.caption, color: Colors.textSecondary },
  // 管理员只读标记
  adminBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: Spacing.md, paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, backgroundColor: Colors.admin + '15', borderRadius: 10 },
  adminText: { fontSize: Typography.caption, color: Colors.admin, fontWeight: '600' },
  postWrapper: { marginBottom: Spacing.sm },
  empty: { alignItems: 'center', paddingVertical: Spacing.xl * 3 },
  emptyText: { fontSize: Typography.body, color: Colors.textHint, marginTop: Spacing.md },
  fab: { position: 'absolute', right: Spacing.lg, bottom: Spacing.xl, width: 52, height: 52, borderRadius: 26, backgroundColor: '#7B68EE', alignItems: 'center', justifyContent: 'center', elevation: 6 },
  editor: { backgroundColor: Colors.bgWhite, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider, padding: Spacing.lg, paddingBottom: Spacing.xl },
  editorTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.md },
  editorTitle: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary },
  cancelText: { fontSize: Typography.body, color: Colors.textHint },
  editorInput: { minHeight: 60, maxHeight: 120, fontSize: Typography.body, color: Colors.textPrimary, borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.card, paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, textAlignVertical: 'top', marginBottom: Spacing.sm },
  visBtn: { flex: 1, alignItems: 'center', paddingVertical: Spacing.xs, borderRadius: 4, borderWidth: 1, borderColor: Colors.divider },
  visBtnText: { fontSize: Typography.caption, color: Colors.textSecondary },
});

export default PersonalSpaceScreen;
