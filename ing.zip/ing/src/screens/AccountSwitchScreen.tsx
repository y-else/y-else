/**
 * 账号切换页面（仿QQ账号切换）
 * 本地永久保留登录历史 / 改密需重新登录 / 未改密一键免密
 * 使用统一存储键 @ing_accounts（与 storage.ts 保持一致）
 *
 * 修复:
 * - 当前账号高亮标记
 * - 管理员账号不在切换列表中显示（不支持免密）
 * - 搜索过滤
 * - 通过 AuthContext.switchToAccount 真正执行切换
 * - 侧滑删除确认
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert,
  Image, TextInput, Platform,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card, Button } from '../components';
import { useAuth } from '../context/AuthContext';
import { getSavedAccounts, removeAccountFull } from '../services/storage';
import { isAdminPhone } from '../services/apiConfig';
import type { SavedAccount } from '../types';

interface Props {
  onBack: () => void;
  onAddAccount: () => void;
}

const AccountSwitchScreen: React.FC<Props> = ({ onBack, onAddAccount }) => {
  const { state, switchToAccount, removeSavedAccount } = useAuth();
  const currentUserId = state.user?.id;

  const [accounts, setAccounts] = useState<SavedAccount[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [switchingId, setSwitchingId] = useState<string | null>(null);

  const loadAccounts = useCallback(async () => {
    const list = await getSavedAccounts();
    // 过滤：管理员账号不显示（不支持免密切换）+ 非当前用户
    const filtered = list.filter(
      (a) => !isAdminPhone(a.phone),
    );
    setAccounts(filtered);
  }, []);

  useEffect(() => {
    loadAccounts();
  }, [loadAccounts]);

  // 搜索过滤
  const filteredAccounts = searchQuery.trim()
    ? accounts.filter(
        (a) =>
          a.username.includes(searchQuery.trim()) ||
          a.phone.includes(searchQuery.trim()) ||
          a.userId.includes(searchQuery.trim()),
      )
    : accounts;

  const handleSwitch = async (account: SavedAccount) => {
    if (account.passwordChanged) {
      Alert.alert('需重新登录', '该账号密码已变更，请重新输入密码登录', [
        { text: '取消', style: 'cancel' },
        {
          text: '去登录',
          onPress: () => {
            // 跳转到登录页，预填手机号
            onAddAccount();
          },
        },
      ]);
      return;
    }

    if (account.userId === currentUserId) {
      Alert.alert('提示', '当前已是该账号');
      return;
    }

    setSwitchingId(account.userId);
    const result = await switchToAccount(account);
    setSwitchingId(null);

    if (result.success) {
      onBack();
    } else {
      Alert.alert('切换失败', result.message, [
        { text: '取消', style: 'cancel' },
        { text: '去登录', onPress: () => onAddAccount() },
      ]);
    }
  };

  const handleRemove = (account: SavedAccount) => {
    Alert.alert(
      '移除账号',
      `确定移除「${account.username}」的登录记录？\n移除后需重新输入密码登录。`,
      [
        { text: '取消', style: 'cancel' },
        {
          text: '移除',
          style: 'destructive',
          onPress: async () => {
            await removeAccountFull(account.userId);
            await removeSavedAccount(account.userId);
            setAccounts((prev) => prev.filter((a) => a.userId !== account.userId));
          },
        },
      ],
    );
  };

  const formatLastLogin = (isoString: string): string => {
    const d = new Date(isoString);
    const now = new Date();
    const diffMs = now.getTime() - d.getTime();
    const diffHours = Math.floor(diffMs / 3600000);
    if (diffHours < 1) return '刚刚';
    if (diffHours < 24) return `${diffHours}小时前`;
    if (diffHours < 48) return '昨天';
    if (diffHours < 168) return `${Math.floor(diffHours / 24)}天前`;
    return d.toLocaleDateString('zh-CN');
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      {/* 头部 */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.title}>切换账号</Text>
        <View style={{ width: 24 }} />
      </View>

      {/* 搜索栏 */}
      {accounts.length > 3 && (
        <View style={styles.searchBar}>
          <Ionicons name="search" size={18} color={Colors.textHint} />
          <TextInput
            style={styles.searchInput}
            placeholder="搜索用户名/手机号"
            placeholderTextColor={Colors.textHint}
            value={searchQuery}
            onChangeText={setSearchQuery}
            autoCapitalize="none"
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <Ionicons name="close-circle" size={18} color={Colors.textHint} />
            </TouchableOpacity>
          )}
        </View>
      )}

      <ScrollView contentContainerStyle={styles.container}>
        {filteredAccounts.length === 0 ? (
          <View style={styles.empty}>
            <Ionicons name="people-outline" size={48} color={Colors.textHint} />
            <Text style={styles.emptyText}>
              {searchQuery ? '未找到匹配账号' : '暂无其他登录账号'}
            </Text>
          </View>
        ) : (
          filteredAccounts.map((acc) => {
            const isCurrent = acc.userId === currentUserId;
            const isSwitching = switchingId === acc.userId;

            return (
              <Card
                key={acc.userId}
                style={{ ...styles.accountCard, ...(isCurrent ? styles.accountCardCurrent : {}) } as any}
              >
                <TouchableOpacity
                  style={styles.accountRow}
                  onPress={() => handleSwitch(acc)}
                  activeOpacity={0.7}
                  disabled={isSwitching}
                >
                  {/* 头像 */}
                  <View style={styles.avatar}>
                    {acc.avatar ? (
                      <Image source={{ uri: acc.avatar }} style={styles.avatarImg} />
                    ) : (
                      <View style={[styles.avatarPlaceholder, isCurrent && styles.avatarPlaceholderCurrent]}>
                        <Ionicons
                          name="person"
                          size={24}
                          color={isCurrent ? Colors.primary : Colors.textHint}
                        />
                      </View>
                    )}
                    {isCurrent && <View style={styles.currentDot} />}
                  </View>

                  {/* 账号信息 */}
                  <View style={styles.accountInfo}>
                    <View style={styles.nameRow}>
                      <Text style={styles.accountName} numberOfLines={1}>
                        {acc.username}
                      </Text>
                      {isCurrent && (
                        <View style={styles.currentBadge}>
                          <Text style={styles.currentBadgeText}>当前</Text>
                        </View>
                      )}
                    </View>
                    <Text style={styles.accountPhone}>
                      {acc.phone} · ID:{acc.userId.slice(-4)}
                    </Text>
                    {acc.passwordChanged ? (
                      <View style={styles.pwdChangedRow}>
                        <Ionicons name="warning" size={12} color={Colors.lover} />
                        <Text style={styles.pwdChanged}>密码已变更，需重新登录</Text>
                      </View>
                    ) : (
                      <Text style={styles.lastLogin}>
                        {isSwitching ? '切换中...' : `最近登录: ${formatLastLogin(acc.lastLoginAt)}`}
                      </Text>
                    )}
                  </View>

                  {isSwitching ? (
                    <Ionicons name="timer-outline" size={18} color={Colors.primary} />
                  ) : (
                    <Ionicons name="chevron-forward" size={18} color={Colors.textHint} />
                  )}
                </TouchableOpacity>

                {/* 移除按钮 */}
                {!isCurrent && (
                  <TouchableOpacity
                    style={styles.removeBtn}
                    onPress={() => handleRemove(acc)}
                    hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                  >
                    <Ionicons name="trash-outline" size={16} color={Colors.textHint} />
                  </TouchableOpacity>
                )}
              </Card>
            );
          })
        )}

        {/* 添加新账号 */}
        <Button
          title="添加新账号"
          variant="outline"
          onPress={onAddAccount}
          style={styles.addBtn}
        />

        {/* 底部提示 */}
        <Text style={styles.footerHint}>
          切换账号将保留当前账号数据，可随时切换回来
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: Colors.divider,
  },
  title: {
    fontSize: Typography.title,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  // 搜索栏
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.bgWhite,
    marginHorizontal: Spacing.lg,
    marginTop: Spacing.md,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.input,
    height: 40,
    gap: Spacing.sm,
  },
  searchInput: {
    flex: 1,
    fontSize: Typography.body,
    color: Colors.textPrimary,
    paddingVertical: 0,
  },
  // 列表
  container: {
    padding: Spacing.lg,
    paddingBottom: Spacing.xl * 2,
  },
  empty: {
    alignItems: 'center',
    paddingVertical: Spacing.xl * 3,
  },
  emptyText: {
    fontSize: Typography.body,
    color: Colors.textHint,
    marginTop: Spacing.md,
  },
  // 账号卡片
  accountCard: {
    marginBottom: Spacing.sm,
    flexDirection: 'row',
    alignItems: 'center',
  },
  accountCardCurrent: {
    borderWidth: 1.5,
    borderColor: Colors.primary + '30',
  },
  accountRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingVertical: Spacing.sm,
  },
  // 头像
  avatar: {
    position: 'relative',
  },
  avatarPlaceholder: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.bgPrimary,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  avatarPlaceholderCurrent: {
    backgroundColor: Colors.primary + '12',
  },
  avatarImg: {
    width: 48,
    height: 48,
    borderRadius: 24,
  },
  currentDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: Colors.family,
    borderWidth: 2,
    borderColor: Colors.bgWhite,
    position: 'absolute',
    bottom: 0,
    right: 0,
  },
  // 账号信息
  accountInfo: {
    flex: 1,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  accountName: {
    fontSize: Typography.body,
    fontWeight: '600',
    color: Colors.textPrimary,
    maxWidth: '60%',
  },
  currentBadge: {
    backgroundColor: Colors.primary + '15',
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: 4,
  },
  currentBadgeText: {
    fontSize: 10,
    color: Colors.primary,
    fontWeight: '600',
  },
  accountPhone: {
    fontSize: Typography.caption,
    color: Colors.textHint,
    marginTop: 2,
  },
  pwdChangedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 2,
  },
  pwdChanged: {
    fontSize: 10,
    color: Colors.lover,
  },
  lastLogin: {
    fontSize: 10,
    color: Colors.textHint,
    marginTop: 1,
  },
  removeBtn: {
    padding: Spacing.md,
  },
  // 底部
  addBtn: {
    marginTop: Spacing.lg,
    borderColor: Colors.primary,
  },
  footerHint: {
    fontSize: Typography.caption,
    color: Colors.textHint,
    textAlign: 'center',
    marginTop: Spacing.lg,
  },
});

export default AccountSwitchScreen;
