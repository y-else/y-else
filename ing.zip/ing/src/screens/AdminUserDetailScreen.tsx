/**
 * 管理员查看单个用户完整数据 + 操作 + 权限管控
 * 审核注册/重置密码/强制解绑/功能授权/查看GPS/手机使用/禁用启用/注销用户/编辑信息
 *
 * 修复:
 * - 添加注销用户账号功能
 * - 添加编辑用户基础信息功能
 * - 功能权限真实持久化
 * - 所有操作真实生效
 */

import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, Switch,
  TextInput, Modal as RNModal,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Card, Button, DatePicker } from '../components';
import { useAuth } from '../context/AuthContext';
import {
  getUserFullData, auditRegister, adminResetPassword, forceUnbind,
  updateFunctionPermission, getFunctionPermission, getOfflineGPS, getPhoneData,
  deleteUser, updateUserBasicInfo,
} from '../services/admin';
import type { UserFullData, PhoneData, FunctionPermission } from '../types';

// 功能权限配置
type PermKey = Exclude<keyof FunctionPermission, 'userId'>;
const PERM_KEYS: PermKey[] = ['canSOS', 'canLocation', 'canMessage', 'canDiary', 'canSpacePost'];
const PERM_LABELS: Record<PermKey, string> = {
  canSOS: 'SOS求救', canLocation: '定位共享', canMessage: '消息接收', canDiary: '专属日记', canSpacePost: '空间动态',
};
const PERM_DESCS: Record<PermKey, string> = {
  canSOS: '允许用户发送SOS求救信号',
  canLocation: '允许用户共享GPS位置',
  canMessage: '允许用户接收消息',
  canDiary: '允许用户使用专属日记',
  canSpacePost: '允许用户发布空间动态',
};

interface AdminUserDetailScreenProps {
  userId: string;
  username: string;
  onBack: () => void;
}

const AdminUserDetailScreen: React.FC<AdminUserDetailScreenProps> = ({ userId, username, onBack }) => {
  const { state } = useAuth();
  const adminId = state.user?.id || 'admin_001';
  const adminName = state.user?.username || '管理员';
  const [data, setData] = useState<UserFullData | null>(null);
  const [phoneData, setPhoneData] = useState<PhoneData | null>(null);
  const [offlineGPS, setOfflineGPS] = useState<any[]>([]);
  const [showGPS, setShowGPS] = useState(false);
  const [showPhone, setShowPhone] = useState(false);
  const [perms, setPerms] = useState<FunctionPermission>({
    userId, canSOS: true, canLocation: true, canMessage: true, canDiary: true, canSpacePost: true,
  });
  // 展开控制
  const [showBasicInfo, setShowBasicInfo] = useState(true);
  const [showRealName, setShowRealName] = useState(true);
  const [showPerms, setShowPerms] = useState(true);
  const [showActions, setShowActions] = useState(true);

  // 编辑用户信息弹窗
  const [showEditModal, setShowEditModal] = useState(false);
  const [editForm, setEditForm] = useState({
    username: '', bio: '', location: '', birthday: '', gender: 'hidden' as string,
  });
  const [showBirthdayPicker, setShowBirthdayPicker] = useState(false);

  useEffect(() => {
    (async () => {
      const d = await getUserFullData(userId);
      setData(d);
      // 加载持久化权限
      const saved = await getFunctionPermission(userId);
      setPerms(saved);
    })();
  }, [userId]);

  const confirmAction = (title: string, message: string, onConfirm: () => void) => {
    Alert.alert(title, message + '\n\n此操作将被记录到审计日志。', [
      { text: '取消', style: 'cancel' },
      { text: '确认执行', style: 'destructive', onPress: onConfirm },
    ]);
  };

  // 重置密码
  const handleResetPassword = () => {
    confirmAction('重置密码', `确定重置用户 ${username} 的密码？`, async () => {
      const result = await adminResetPassword(adminId, adminName, userId, username);
      if (result.success) {
        Alert.alert('密码已重置', `新密码: ${result.newPassword}\n请通知用户及时修改`);
      }
    });
  };

  // 强制解绑
  const handleForceUnbind = () => {
    confirmAction('强制解绑', '确定强制解除该用户所有绑定关系？此操作不可撤销。', async () => {
      await forceUnbind(adminId, adminName, userId, username, '管理员强制解绑');
      Alert.alert('已解绑', '用户所有绑定关系已强制解除');
    });
  };

  // 审核注册
  const handleAuditRegister = (approved: boolean) => {
    confirmAction(
      approved ? '审核通过注册' : '驳回注册',
      `确定${approved ? '通过' : '驳回'}用户 ${username} 的注册？`,
      async () => {
        await auditRegister(adminId, adminName, userId, username, approved);
        Alert.alert('操作完成', approved ? '注册已通过审核' : '注册已驳回');
      },
    );
  };

  // 注销用户
  const handleDeleteUser = () => {
    confirmAction(
      '注销账号',
      `确定注销「${username}」的账号？\n\n注销后该用户将无法登录，所有数据将被清除。此操作不可撤销。`,
      async () => {
        await deleteUser(adminId, adminName, userId, username);
        Alert.alert('已注销', `用户「${username}」的账号已被注销`, [
          { text: '返回', onPress: onBack },
        ]);
      },
    );
  };

  // 查看GPS
  const handleViewOfflineGPS = async () => {
    if (showGPS) { setShowGPS(false); return; }
    const gps = await getOfflineGPS(userId);
    setOfflineGPS(gps);
    setShowGPS(true);
  };

  // 查看手机数据
  const handleViewPhoneData = async () => {
    if (showPhone) { setShowPhone(false); return; }
    const pd = await getPhoneData(userId);
    setPhoneData(pd);
    setShowPhone(true);
  };

  // 更新权限（真实持久化）
  const handleUpdatePermission = async (key: PermKey, value: boolean) => {
    const updated = { ...perms, [key]: value };
    setPerms(updated);
    await updateFunctionPermission(adminId, adminName, updated);
  };

  // 编辑用户信息
  const handleOpenEdit = () => {
    if (!data) return;
    setEditForm({
      username: data.basicInfo.username || username,
      bio: data.basicInfo.bio || '',
      location: data.basicInfo.location || '',
      birthday: data.basicInfo.birthday || '',
      gender: data.basicInfo.gender || 'hidden',
    });
    setShowEditModal(true);
  };

  const handleSaveEdit = async () => {
    if (!editForm.username.trim()) {
      Alert.alert('提示', '用户名不能为空');
      return;
    }
    await updateUserBasicInfo(adminId, adminName, userId, username, {
      username: editForm.username.trim(),
      bio: editForm.bio.trim(),
      location: editForm.location.trim(),
      birthday: editForm.birthday.trim() || undefined,
      gender: editForm.gender,
    });
    setShowEditModal(false);
    Alert.alert('已更新', '用户基础信息已更新');
    // 重新加载
    const d = await getUserFullData(userId);
    setData(d);
  };

  if (!data) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <View style={styles.loading}>
          <Text style={styles.loadingText}>加载中...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      {/* 头部 */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{username} · 用户详情</Text>
        <TouchableOpacity onPress={handleOpenEdit}>
          <Ionicons name="create-outline" size={20} color={Colors.primary} />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.container}>
        {/* 基础信息 */}
        <Card>
          <TouchableOpacity style={styles.sectionHeader} onPress={() => setShowBasicInfo(!showBasicInfo)} activeOpacity={0.7}>
            <Ionicons name="person" size={16} color={Colors.primary} />
            <Text style={styles.sectionTitle}>基础信息</Text>
            <Ionicons name={showBasicInfo ? 'chevron-up' : 'chevron-down'} size={16} color={Colors.textHint} />
          </TouchableOpacity>
          {showBasicInfo && (
            <>
              <Text style={styles.row}>用户名: {data.basicInfo.username || '未设置'}</Text>
              <Text style={styles.row}>等级: LV.{data.basicInfo.level}</Text>
              <Text style={styles.row}>使用时长: {data.basicInfo.totalMinutes}分钟</Text>
              <Text style={styles.row}>所在地: {data.basicInfo.location || '未设置'}</Text>
              <Text style={styles.row}>性别: {data.basicInfo.gender === 'male' ? '男' : data.basicInfo.gender === 'female' ? '女' : '未设置'}</Text>
              {data.basicInfo.birthday ? <Text style={styles.row}>生日: {data.basicInfo.birthday}</Text> : null}
              {data.basicInfo.bio ? <Text style={styles.row}>简介: {data.basicInfo.bio}</Text> : null}
            </>
          )}
        </Card>

        {/* 实名信息 */}
        <Card>
          <TouchableOpacity style={styles.sectionHeader} onPress={() => setShowRealName(!showRealName)} activeOpacity={0.7}>
            <Ionicons name="card" size={16} color={Colors.friend} />
            <Text style={styles.sectionTitle}>实名状态</Text>
            <Ionicons name={showRealName ? 'chevron-up' : 'chevron-down'} size={16} color={Colors.textHint} />
          </TouchableOpacity>
          {showRealName && (
            <>
              <Text style={styles.row}>
                状态: {data.realName?.status === 'verified' ? '已认证' : data.realName?.status === 'pending' ? '审核中' : '未认证'}
              </Text>
              {data.realName && <Text style={styles.row}>姓名: {data.realName.realName}</Text>}
              <View style={styles.btnRow}>
                <Button title="通过注册" onPress={() => handleAuditRegister(true)} variant="primary" style={styles.btn} />
                <Button title="驳回注册" onPress={() => handleAuditRegister(false)} variant="outline" style={styles.btn} />
              </View>
            </>
          )}
        </Card>

        {/* 功能权限管控 */}
        <Card>
          <TouchableOpacity style={styles.sectionHeader} onPress={() => setShowPerms(!showPerms)} activeOpacity={0.7}>
            <Ionicons name="toggle" size={16} color={Colors.admin} />
            <Text style={styles.sectionTitle}>功能权限管控</Text>
            <Ionicons name={showPerms ? 'chevron-up' : 'chevron-down'} size={16} color={Colors.textHint} />
          </TouchableOpacity>
          {showPerms && (
            <>
              <Text style={styles.sectionHint}>
                关闭权限后，用户对应功能将被禁用。修改即时生效并记录操作日志。
              </Text>
              {PERM_KEYS.map((key) => (
                <View key={key} style={styles.switchRow}>
                  <View style={styles.switchInfo}>
                    <Text style={styles.switchLabel}>{PERM_LABELS[key]}</Text>
                    <Text style={styles.switchDesc}>{PERM_DESCS[key]}</Text>
                  </View>
                  <Switch
                    value={perms[key] as boolean}
                    onValueChange={(v) => handleUpdatePermission(key, v)}
                    trackColor={{ false: Colors.divider, true: Colors.admin + '60' }}
                    thumbColor={(perms[key] as boolean) ? Colors.admin : '#f4f3f4'}
                  />
                </View>
              ))}
            </>
          )}
        </Card>

        {/* 数据监测 */}
        <Card>
          <Text style={styles.sectionTitle}>数据监测</Text>
          <TouchableOpacity style={styles.dataRow} onPress={handleViewOfflineGPS}>
            <Ionicons name="location" size={18} color={Colors.primary} />
            <Text style={styles.dataLabel}>离线GPS定位记录</Text>
            <Ionicons name={showGPS ? 'chevron-up' : 'chevron-down'} size={14} color={Colors.textHint} />
          </TouchableOpacity>
          {showGPS && (
            <View style={styles.dataContent}>
              {offlineGPS.length > 0 ? offlineGPS.map((g, i) => (
                <Text key={i} style={styles.gpsRow}>
                  {g.address || `${g.latitude},${g.longitude}`} · {new Date(g.updatedAt || g.timestamp).toLocaleTimeString('zh-CN')}
                </Text>
              )) : <Text style={styles.gpsRow}>暂无离线GPS记录</Text>}
            </View>
          )}
          <TouchableOpacity style={[styles.dataRow, { borderBottomWidth: 0 }]} onPress={handleViewPhoneData}>
            <Ionicons name="phone-portrait" size={18} color={Colors.admin} />
            <Text style={styles.dataLabel}>手机使用数据</Text>
            <Ionicons name={showPhone ? 'chevron-up' : 'chevron-down'} size={14} color={Colors.textHint} />
          </TouchableOpacity>
          {showPhone && phoneData && (
            <View style={styles.dataContent}>
              <Text style={styles.row}>日均屏幕: {phoneData.screenTimePerDay}分钟</Text>
              <Text style={styles.row}>APP使用: {phoneData.appUsageMinutes}分钟</Text>
              <Text style={styles.row}>充电次数: {phoneData.chargeCount}次</Text>
              <Text style={styles.row}>APP启停: {phoneData.appStartCount}次</Text>
              <Text style={styles.row}>电池健康: {phoneData.batteryHealth}</Text>
            </View>
          )}
        </Card>

        {/* 敏感操作 */}
        <Card>
          <TouchableOpacity style={styles.sectionHeader} onPress={() => setShowActions(!showActions)} activeOpacity={0.7}>
            <Ionicons name="warning" size={16} color={Colors.lover} />
            <Text style={styles.sectionTitle}>敏感操作</Text>
            <Ionicons name={showActions ? 'chevron-up' : 'chevron-down'} size={16} color={Colors.textHint} />
          </TouchableOpacity>
          {showActions && (
            <>
              <Text style={styles.sectionHint}>以下操作不可撤销，请谨慎执行。</Text>
              <View style={styles.dangerBtns}>
                <Button title="重置密码" onPress={handleResetPassword} variant="outline" style={styles.dangerBtn} />
                <Button title="强制解绑" onPress={handleForceUnbind} variant="outline" style={styles.dangerBtn} />
                <Button title="注销账号" onPress={handleDeleteUser} variant="outline" style={styles.deleteBtn} />
              </View>
            </>
          )}
        </Card>

        <View style={{ height: 40 }} />
      </ScrollView>

      {/* 编辑用户信息弹窗 */}
      <RNModal visible={showEditModal} transparent animationType="slide" onRequestClose={() => setShowEditModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>编辑用户信息</Text>
              <TouchableOpacity onPress={() => setShowEditModal(false)}>
                <Ionicons name="close" size={24} color={Colors.textPrimary} />
              </TouchableOpacity>
            </View>
            <ScrollView style={styles.modalBody}>
              <Text style={styles.formLabel}>用户名</Text>
              <TextInput
                style={styles.formInput}
                value={editForm.username}
                onChangeText={(t) => setEditForm({ ...editForm, username: t })}
                placeholder="请输入用户名"
                placeholderTextColor={Colors.textHint}
              />
              <Text style={styles.formLabel}>简介</Text>
              <TextInput
                style={styles.formInput}
                value={editForm.bio}
                onChangeText={(t) => setEditForm({ ...editForm, bio: t })}
                placeholder="个人简介"
                placeholderTextColor={Colors.textHint}
                multiline
              />
              <Text style={styles.formLabel}>所在地</Text>
              <TextInput
                style={styles.formInput}
                value={editForm.location}
                onChangeText={(t) => setEditForm({ ...editForm, location: t })}
                placeholder="所在地"
                placeholderTextColor={Colors.textHint}
              />
              <Text style={styles.formLabel}>生日</Text>
              <TouchableOpacity style={styles.formInput} onPress={() => setShowBirthdayPicker(true)} activeOpacity={0.6}>
                <Text style={editForm.birthday ? styles.formInputText : styles.formPlaceholder}>
                  {editForm.birthday || '如: 2000-01-01'}
                </Text>
              </TouchableOpacity>
              <Text style={styles.formLabel}>性别</Text>
              <View style={styles.genderRow}>
                {[
                  { key: 'hidden', label: '未设置' },
                  { key: 'male', label: '男' },
                  { key: 'female', label: '女' },
                ].map((g) => (
                  <TouchableOpacity
                    key={g.key}
                    style={[styles.genderBtn, editForm.gender === g.key && { backgroundColor: Colors.admin, borderColor: Colors.admin }]}
                    onPress={() => setEditForm({ ...editForm, gender: g.key })}
                  >
                    <Text style={[styles.genderBtnText, editForm.gender === g.key && { color: '#FFF' }]}>{g.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
            <View style={styles.modalFooter}>
              <Button title="取消" variant="outline" onPress={() => setShowEditModal(false)} style={styles.modalBtn} />
              <Button title="保存" onPress={handleSaveEdit} style={styles.modalBtn} />
            </View>
          </View>
        </View>
      </RNModal>
      <DatePicker visible={showBirthdayPicker} value={editForm.birthday} onConfirm={(v) => { setEditForm({ ...editForm, birthday: v }); setShowBirthdayPicker(false); }} onClose={() => setShowBirthdayPicker(false)} title="选择生日" />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgPrimary },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, flex: 1, textAlign: 'center' },
  container: { padding: Spacing.lg },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { fontSize: Typography.body, color: Colors.textHint },
  sectionHeader: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  sectionTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary, flex: 1 },
  sectionHint: { fontSize: Typography.caption, color: Colors.textHint, marginBottom: Spacing.md, lineHeight: 18 },
  row: { fontSize: Typography.body, color: Colors.textSecondary, marginBottom: Spacing.xs, lineHeight: 22 },
  btnRow: { flexDirection: 'row', gap: Spacing.sm, marginTop: Spacing.md },
  btn: { flex: 1 },
  // 权限开关
  switchRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  switchInfo: { flex: 1, marginRight: Spacing.md },
  switchLabel: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary },
  switchDesc: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
  // 数据监测
  dataRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  dataLabel: { fontSize: Typography.body, color: Colors.textPrimary, flex: 1 },
  dataContent: {
    backgroundColor: Colors.bgPrimary, borderRadius: BorderRadius.input,
    padding: Spacing.md, marginBottom: Spacing.md,
  },
  gpsRow: { fontSize: Typography.caption, color: Colors.textHint, marginBottom: 2 },
  // 敏感操作
  dangerBtns: { gap: Spacing.sm, marginTop: Spacing.sm },
  dangerBtn: { borderColor: Colors.lover },
  deleteBtn: { borderColor: '#FF0000' },
  // 编辑弹窗
  modalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContainer: {
    backgroundColor: Colors.bgWhite,
    borderTopLeftRadius: 16, borderTopRightRadius: 16,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  modalTitle: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  modalBody: { padding: Spacing.lg },
  modalFooter: {
    flexDirection: 'row', gap: Spacing.md,
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider,
  },
  modalBtn: { flex: 1 },
  formLabel: { fontSize: Typography.body, fontWeight: '500', color: Colors.textPrimary, marginBottom: 4, marginTop: Spacing.sm },
  formInput: {
    borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input,
    padding: Spacing.md, justifyContent: 'center', minHeight: 44,
  },
  formInputText: { fontSize: Typography.body, color: Colors.textPrimary },
  formPlaceholder: { fontSize: Typography.body, color: Colors.textHint },
  genderRow: { flexDirection: 'row', gap: Spacing.sm },
  genderBtn: {
    flex: 1, paddingVertical: Spacing.sm, borderRadius: BorderRadius.card,
    borderWidth: 1, borderColor: Colors.divider, alignItems: 'center',
  },
  genderBtnText: { fontSize: Typography.caption, fontWeight: '500', color: Colors.textSecondary },
});

export default AdminUserDetailScreen;
