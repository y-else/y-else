/**
 * 注册页（带验证码版）
 * 用户填写信息 → 输入验证码 → 提交申请 → 待管理员审核 → 审核通过后可用手机号+密码登录
 * 一个手机号仅能提交一次注册申请
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, KeyboardAvoidingView,
  TouchableOpacity, Alert,
} from 'react-native';
import { SafeAreaView } from '../components/SafeAreaCompat';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { Input, Button, AvatarPicker } from '../components';
import { useAuth } from '../context/AuthContext';
import { requestVerificationCode, verifyCode } from '../services/verificationCode';

interface RegisterScreenProps {
  onNavigateLogin: () => void;
}

const SMS_COUNTDOWN_SECONDS = 60;

const RegisterScreen: React.FC<RegisterScreenProps> = ({ onNavigateLogin }) => {
  const { register } = useAuth();

  const [avatarUri, setAvatarUri] = useState<string | null>(null);
  const [username, setUsername] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [smsCode, setSmsCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // 验证码倒计时
  const [countdown, setCountdown] = useState(0);
  const [sendingCode, setSendingCode] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // 清理倒计时定时器
  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  // 倒计时管理
  useEffect(() => {
    if (countdown <= 0) {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  }, [countdown]);

  const handleSendCode = async () => {
    if (!/^1[3-9]\d{9}$/.test(phone)) {
      setErrors((e) => ({ ...e, phone: '请先输入正确的手机号' }));
      return;
    }
    setSendingCode(true);
    const result = await requestVerificationCode(phone, 'register');
    setSendingCode(false);
    if (result.success) {
      setCountdown(SMS_COUNTDOWN_SECONDS);
      timerRef.current = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) return 0;
          return prev - 1;
        });
      }, 1000);
      Alert.alert('验证码已发送', '请输入收到的6位数字验证码');
    } else {
      Alert.alert('申请失败', result.message);
    }
  };

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!username.trim()) errs.username = '请输入用户名';
    else if (username.trim().length < 2) errs.username = '用户名至少2个字符';
    else if (username.trim().length > 20) errs.username = '用户名最多20个字符';
    if (phone.startsWith('000')) errs.phone = '不支持注册管理员账号';
    else if (!/^1[3-9]\d{9}$/.test(phone)) errs.phone = '请输入正确的手机号';
    if (password.length < 6) errs.password = '密码至少6位';
    else if (password.length > 32) errs.password = '密码最多32位';
    if (password !== confirmPassword) errs.confirmPassword = '两次密码不一致';
    if (!smsCode || smsCode.length !== 6) errs.smsCode = '请输入6位验证码';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleRegister = async () => {
    if (!validate()) return;

    // 先校验验证码
    const verifyResult = await verifyCode(phone, smsCode, 'register');
    if (!verifyResult.valid) {
      setErrors((e) => ({ ...e, smsCode: verifyResult.message }));
      return;
    }

    setLoading(true);
    const result = await register({
      phone,
      password,
      username: username.trim(),
      smsCode,
      avatarUri: avatarUri || undefined,
    });
    setLoading(false);

    if (result.success) {
      Alert.alert(
        '注册申请已提交',
        '您的账号正在等待管理员审核，审核通过后即可使用手机号 + 密码登录。',
        [{ text: '返回登录', onPress: () => onNavigateLogin() }],
      );
    } else {
      Alert.alert('提交失败', result.message);
    }
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <KeyboardAvoidingView style={styles.flex} behavior="height">
        <ScrollView style={styles.flex} contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
          <Text style={styles.title}>创建账号</Text>

          <AvatarPicker uri={avatarUri} onPick={setAvatarUri} />

          <Input label="用户名" placeholder="请输入用户名（2-20个字符）" value={username}
            onChangeText={(t) => { setUsername(t); setErrors((e) => ({ ...e, username: '' })); }}
            error={errors.username} autoCapitalize="none" maxLength={20} />
          <Input label="手机号" placeholder="请输入手机号" keyboardType="phone-pad" maxLength={11}
            value={phone}
            onChangeText={(t) => { setPhone(t); setErrors((e) => ({ ...e, phone: '' })); }}
            error={errors.phone} />
          <Input label="密码" placeholder="请设置密码（6-32位）" secureTextEntry
            value={password}
            onChangeText={(t) => { setPassword(t); setErrors((e) => ({ ...e, password: '' })); }}
            error={errors.password} maxLength={32} />
          <Input label="确认密码" placeholder="请再次输入密码" secureTextEntry
            value={confirmPassword}
            onChangeText={(t) => { setConfirmPassword(t); setErrors((e) => ({ ...e, confirmPassword: '' })); }}
            error={errors.confirmPassword} maxLength={32} />

          {/* 验证码输入 + 发送按钮 */}
          <Text style={styles.codeLabel}>验证码</Text>
          <View style={styles.codeRow}>
            <View style={styles.codeInputWrap}>
              <Input
                label=""
                placeholder="请输入6位验证码"
                keyboardType="number-pad"
                maxLength={6}
                value={smsCode}
                onChangeText={(t) => { setSmsCode(t); setErrors((e) => ({ ...e, smsCode: '' })); }}
                error={errors.smsCode}
              />
            </View>
            <TouchableOpacity
              style={[
                styles.sendCodeBtn,
                (countdown > 0 || sendingCode) && styles.sendCodeBtnDisabled,
              ]}
              onPress={handleSendCode}
              disabled={countdown > 0 || sendingCode}
              activeOpacity={0.7}
            >
              <Text style={styles.sendCodeBtnText}>
                {sendingCode ? '发送中...' : countdown > 0 ? `${countdown}秒` : '获取验证码'}
              </Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.hint}>
            提交后将由管理员审核，审核通过后即可使用手机号和密码登录。
          </Text>

          <Button title="提交申请" onPress={handleRegister} loading={loading} style={styles.registerBtn} />

          <TouchableOpacity onPress={onNavigateLogin} style={styles.loginLink}>
            <Text style={styles.loginLinkText}>已有账号？去登录</Text>
          </TouchableOpacity>
        </ScrollView>

        <View style={styles.footer}>
          <Text style={styles.footerText}>本应用由y-else工作室出品</Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.bgWhite },
  flex: { flex: 1 },
  container: { flexGrow: 1, paddingHorizontal: Spacing.lg, paddingTop: Spacing.xl, paddingBottom: Spacing.xl },
  title: { fontSize: Typography.title, fontWeight: '600', color: Colors.textPrimary, textAlign: 'center', marginBottom: Spacing.xl },
  // 验证码
  codeLabel: { fontSize: Typography.body, color: Colors.textPrimary, fontWeight: '500', marginBottom: Spacing.xs },
  codeRow: { flexDirection: 'row', gap: Spacing.sm, alignItems: 'flex-start', marginBottom: Spacing.md },
  codeInputWrap: { flex: 1 },
  sendCodeBtn: {
    height: 48, paddingHorizontal: Spacing.md,
    backgroundColor: Colors.primary, borderRadius: BorderRadius.input,
    alignItems: 'center', justifyContent: 'center',
    minWidth: 100, marginTop: 0,
  },
  sendCodeBtnDisabled: { backgroundColor: Colors.textHint },
  sendCodeBtnText: { fontSize: 13, color: Colors.white, fontWeight: '500', textAlign: 'center' },
  hint: { fontSize: Typography.caption, color: Colors.textHint, textAlign: 'center', marginTop: Spacing.lg, marginBottom: Spacing.sm, lineHeight: 18 },
  registerBtn: { marginTop: Spacing.sm },
  loginLink: { alignItems: 'center', marginTop: Spacing.lg },
  loginLinkText: { fontSize: Typography.body, color: Colors.primary },
  footer: { alignItems: 'center', paddingBottom: Spacing.xl },
  footerText: { fontSize: Typography.caption, color: Colors.textHint },
});

export default RegisterScreen;
