/**
 * 生产环境数据清理 & 过期数据自动清理
 * 打包前30天自动清理无效日志/缓存/过期记录
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

const CLEANUP_DONE_KEY = '@ing_last_production_cleanup';
const EXPIRE_DAYS = 30;

// ====== 需要定期清理的键前缀 ======

const EXPIRE_PREFIXES = [
  '@ing_t_',           // 临时缓存
  '@ing_s_',           // 会话缓存（7天TTL）
  '@ing_verification_codes', // 验证码记录
  '_cache',            // 各类缓存
];

// ====== 存储清理 ======

async function getStorageTimestamp(key: string): Promise<number | null> {
  try {
    const val = await AsyncStorage.getItem(key);
    if (!val) return null;
    const parsed = JSON.parse(val);
    // 尝试提取时间戳字段
    const ts = parsed.timestamp || parsed.createdAt || parsed.updatedAt || parsed.appliedAt;
    if (ts) return new Date(ts).getTime();
    return null;
  } catch {
    return null;
  }
}

/**
 * 清理过期数据（30天以上）
 */
export async function runProductionCleanup(): Promise<{
  removedKeys: number;
  freedBytes: number;
}> {
  const now = Date.now();
  const expireMs = EXPIRE_DAYS * 86400000;

  // 每天最多清理一次
  const lastCleanup = await AsyncStorage.getItem(CLEANUP_DONE_KEY);
  if (lastCleanup) {
    const lastTime = parseInt(lastCleanup, 10);
    if (now - lastTime < 86400000) return { removedKeys: 0, freedBytes: 0 };
  }

  const keys = await AsyncStorage.getAllKeys();
  const toRemove: string[] = [];
  let freedBytes = 0;

  for (const key of keys) {
    // 跳过持久化数据
    if (key.startsWith('@ing_p_')) continue;
    // 跳过非过期前缀
    const shouldCheck = EXPIRE_PREFIXES.some((p) => key.includes(p));
    if (!shouldCheck) continue;

    const ts = await getStorageTimestamp(key);
    if (ts && now - ts > expireMs) {
      const val = await AsyncStorage.getItem(key);
      if (val) freedBytes += val.length * 2; // UTF-16近似字节数（Hermes兼容）
      toRemove.push(key);
    }
  }

  if (toRemove.length > 0) {
    await AsyncStorage.multiRemove(toRemove);
  }

  // 标记已清理
  await AsyncStorage.setItem(CLEANUP_DONE_KEY, now.toString());

  console.log(`[ProductionCleanup] 已清理 ${toRemove.length} 个过期数据项，释放 ${(freedBytes / 1024).toFixed(1)}KB`);
  return { removedKeys: toRemove.length, freedBytes };
}

/**
 * 启动时自动清理（延迟执行，不阻塞首屏）
 */
export function scheduleProductionCleanup(): void {
  setTimeout(() => {
    runProductionCleanup().catch(() => {});
  }, 30000); // 启动30秒后执行
}
