/**
 * AsyncStorage 分片存储 + 分级缓存 + 自动清理
 * 解决大数据量一次性读写导致的卡顿白屏问题
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

// ====== 缓存分级定义 ======

export type CacheTier = 'permanent' | 'session' | 'temp';

const TTL_MAP: Record<CacheTier, number | null> = {
  permanent: null,        // 永不过期（用户数据）
  session: 86400000 * 7,  // 7天（会话缓存）
  temp: 3600000,          // 1小时（临时缓存）
};

const tierPrefix: Record<CacheTier, string> = {
  permanent: '@ing_p_',
  session: '@ing_s_',
  temp: '@ing_t_',
};

// ====== 分片存储（单key数据>100KB时自动分片） ======

const SHARD_THRESHOLD = 100 * 1024; // 100KB
const MAX_SHARD_SIZE = 50 * 1024;   // 50KB per shard

interface ShardMeta {
  totalShards: number;
  totalSize: number;
  updatedAt: string;
}

// Hermes安全字节长度计算（TextEncoder在Hermes中不可用）
function getByteLength(str: string): number {
  let len = 0;
  for (let i = 0; i < str.length; i++) {
    const code = str.charCodeAt(i);
    len += code < 0x80 ? 1 : code < 0x800 ? 2 : 3;
  }
  return len;
}

async function shardedSetItem(baseKey: string, value: string, tier: CacheTier = 'permanent'): Promise<void> {
  const prefixedKey = tierPrefix[tier] + baseKey;
  const byteLen = getByteLength(value);

  if (byteLen <= SHARD_THRESHOLD) {
    // 小数据直接存储
    await AsyncStorage.setItem(prefixedKey, value);
    await AsyncStorage.removeItem(prefixedKey + '__meta');
    return;
  }

  // 大数据分片存储
  const totalShards = Math.ceil(byteLen / MAX_SHARD_SIZE);
  const meta: ShardMeta = {
    totalShards,
    totalSize: byteLen,
    updatedAt: new Date().toISOString(),
  };

  // 并行写入所有分片
  const writeOps: Promise<void>[] = [];
  for (let i = 0; i < totalShards; i++) {
    const chunk = value.slice(
      i * Math.floor(value.length / totalShards),
      (i + 1) * Math.floor(value.length / totalShards),
    );
    writeOps.push(AsyncStorage.setItem(`${prefixedKey}__s${i}`, chunk));
  }
  writeOps.push(AsyncStorage.setItem(`${prefixedKey}__meta`, JSON.stringify(meta)));
  await Promise.all(writeOps);
}

async function shardedGetItem(baseKey: string, tier: CacheTier = 'permanent'): Promise<string | null> {
  const prefixedKey = tierPrefix[tier] + baseKey;
  const metaRaw = await AsyncStorage.getItem(prefixedKey + '__meta');

  if (!metaRaw) {
    // 无分片元数据 → 直接读取
    return AsyncStorage.getItem(prefixedKey);
  }

  // 有分片 → 合并读取
  const meta: ShardMeta = JSON.parse(metaRaw);
  const readOps: Promise<string | null>[] = [];
  for (let i = 0; i < meta.totalShards; i++) {
    readOps.push(AsyncStorage.getItem(`${prefixedKey}__s${i}`));
  }
  const chunks = await Promise.all(readOps);
  return chunks.filter(Boolean).join('');
}

async function shardedRemoveItem(baseKey: string, tier: CacheTier = 'permanent'): Promise<void> {
  const prefixedKey = tierPrefix[tier] + baseKey;
  const metaRaw = await AsyncStorage.getItem(prefixedKey + '__meta');

  const removeOps: Promise<void>[] = [AsyncStorage.removeItem(prefixedKey)];
  if (metaRaw) {
    const meta: ShardMeta = JSON.parse(metaRaw);
    for (let i = 0; i < meta.totalShards; i++) {
      removeOps.push(AsyncStorage.removeItem(`${prefixedKey}__s${i}`));
    }
    removeOps.push(AsyncStorage.removeItem(`${prefixedKey}__meta`));
  }
  await Promise.all(removeOps);
}

// ====== 带TTL的缓存写入 ======

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttl: number | null;
}

export async function cacheSet<T>(key: string, data: T, tier: CacheTier = 'permanent'): Promise<void> {
  const entry: CacheEntry<T> = {
    data,
    timestamp: Date.now(),
    ttl: TTL_MAP[tier],
  };
  await shardedSetItem(key, JSON.stringify(entry), tier);
}

export async function cacheGet<T>(key: string, tier: CacheTier = 'permanent'): Promise<T | null> {
  const raw = await shardedGetItem(key, tier);
  if (!raw) return null;

  try {
    const entry: CacheEntry<T> = JSON.parse(raw);
    // TTL检查
    if (entry.ttl && Date.now() - entry.timestamp > entry.ttl) {
      await shardedRemoveItem(key, tier);
      return null;
    }
    return entry.data;
  } catch {
    return null;
  }
}

// ====== 自动过期清理 ======

const CLEANUP_INTERVAL = 3600000; // 每小时清理一次
let cleanupTimer: ReturnType<typeof setTimeout> | null = null;

export function startAutoCleanup(): void {
  if (cleanupTimer) return;
  const runCleanup = async () => {
    try {
      const keys = await AsyncStorage.getAllKeys();
      const now = Date.now();
      const expiredKeys: string[] = [];

      for (const key of keys) {
        // 只清理临时和会话缓存
        if (key.startsWith(tierPrefix.temp) || key.startsWith(tierPrefix.session)) {
          const raw = await AsyncStorage.getItem(key);
          if (raw) {
            try {
              const entry: CacheEntry<any> = JSON.parse(raw);
              if (entry.ttl && now - entry.timestamp > entry.ttl) {
                expiredKeys.push(key);
              }
            } catch {
              // 非JSON数据跳过
            }
          }
        }
        // 移除过期分片元数据引用的孤立分片
        if (key.endsWith('__s0') || key.endsWith('__s1') || key.endsWith('__s2')) {
          const baseKey = key.replace(/__s\d+$/, '');
          const metaExists = keys.includes(baseKey + '__meta');
          const directExists = keys.includes(baseKey);
          if (!metaExists && !directExists) {
            expiredKeys.push(key);
          }
        }
      }

      if (expiredKeys.length > 0) {
        await AsyncStorage.multiRemove(expiredKeys);
        console.log(`[StorageCleanup] 已清理 ${expiredKeys.length} 个过期缓存`);
      }
    } catch {
      // 静默
    }
    cleanupTimer = setTimeout(runCleanup, CLEANUP_INTERVAL);
  };
  cleanupTimer = setTimeout(runCleanup, 10000); // 启动10秒后首次清理
}

export function stopAutoCleanup(): void {
  if (cleanupTimer) {
    clearTimeout(cleanupTimer);
    cleanupTimer = null;
  }
}

// ====== 按UID隔离 + 精简存储 ======

export function userStorageKey(userId: string, dataType: string): string {
  return `uid_${userId}_${dataType}`;
}

// ====== 导出分片API替换原生AsyncStorage ======

export const OptimizedStorage = {
  getItem: shardedGetItem,
  setItem: shardedSetItem,
  removeItem: shardedRemoveItem,
};
