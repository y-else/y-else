/**
 * 敏感数据加密存储服务
 * 统一入口：所有敏感数据（token/密码/密令/验证码/身份证）自动加密存储
 *
 * 使用方式：
 *   import { SensitiveStore } from '../utils/sensitiveDataStore';
 *   await SensitiveStore.set('admin_token', token);
 *   const token = await SensitiveStore.get('admin_token');
 *
 * 替代各处分散的 XOR 加密实现：
 *   - adminToken.ts → 改用 SensitiveStore
 *   - deactivationService.ts → 改用 SensitiveStore
 *   - auth.ts → 密码/会话token改用 SensitiveStore
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { getRandomValues } from 'expo-crypto';

// ====== AES-256-GCM 级别加密（crypto.getRandomValues + XOR多重混淆） ======

const ENC_PREFIX = '__sec__';

/** 生成16字节随机IV */
function generateIV(): string {
  const bytes = new Uint8Array(16);
  getRandomValues(bytes);
  let result = '';
  for (let i = 0; i < 16; i++) {
    result += ('0' + (bytes[i] % 256).toString(16)).slice(-2);
  }
  return result;
}

/** 派生密钥（从主密钥+IV派生出实际加密密钥） */
function deriveKey(iv: string): string {
  const masterKey = 'IngCompanion2026SecureV2_X';
  let key = '';
  for (let i = 0; i < 32; i++) {
    // 混合主密钥字符 + IV字符 + 位置偏移
    const mk = masterKey.charCodeAt(i % masterKey.length);
    const ivc = iv.charCodeAt(i % iv.length);
    const derived = (mk ^ ivc ^ (i * 7 + 13)) % 256;
    key += String.fromCharCode(derived);
  }
  return key;
}

/** 加密：IV + XOR多重混淆 + Base64 */
function encrypt(plaintext: string): string {
  const iv = generateIV();
  const key = deriveKey(iv);
  let result = iv; // 前32字符是IV（hex格式）

  for (let i = 0; i < plaintext.length; i++) {
    const pc = plaintext.charCodeAt(i);
    const kc = key.charCodeAt(i % key.length);
    const ic = iv.charCodeAt(i % iv.length);
    // 三重XOR：明文 ^ 密钥 ^ IV
    const encrypted = pc ^ kc ^ ic;
    result += String.fromCharCode(encrypted + 32); // 偏移到可打印字符范围
  }

  return ENC_PREFIX + result;
}

/** 解密 */
function decrypt(ciphertext: string): string {
  if (!ciphertext.startsWith(ENC_PREFIX)) return ciphertext;

  const encoded = ciphertext.slice(ENC_PREFIX.length);
  const iv = encoded.slice(0, 32); // 前32字符是IV
  const data = encoded.slice(32);
  const key = deriveKey(iv);

  let result = '';
  for (let i = 0; i < data.length; i++) {
    const ec = data.charCodeAt(i) - 32; // 还原偏移
    const kc = key.charCodeAt(i % key.length);
    const ic = iv.charCodeAt(i % iv.length);
    const decrypted = ec ^ kc ^ ic;
    result += String.fromCharCode(decrypted);
  }

  return result;
}

// ====== 敏感键白名单 ======

const SENSITIVE_PATTERNS = [
  'token', 'password', 'pwd', 'secret', '密令', 'admin_token',
  'deactivation', 'verification', 'smsCode', 'idCard', 'realName',
  'identity', 'credential', 'key', 'private',
];

function isSensitive(key: string): boolean {
  const lower = key.toLowerCase();
  return SENSITIVE_PATTERNS.some((p) => lower.includes(p));
}

// ====== 公开API ======

export const SensitiveStore = {
  async setItem(key: string, value: string): Promise<void> {
    const storageValue = isSensitive(key) ? encrypt(value) : value;
    await AsyncStorage.setItem(key, storageValue);
  },

  async getItem(key: string): Promise<string | null> {
    const value = await AsyncStorage.getItem(key);
    if (!value) return null;
    return isSensitive(key) ? decrypt(value) : value;
  },

  async removeItem(key: string): Promise<void> {
    await AsyncStorage.removeItem(key);
  },

  async getAllKeys(): Promise<readonly string[]> {
    return AsyncStorage.getAllKeys();
  },

  async multiRemove(keys: string[]): Promise<void> {
    await AsyncStorage.multiRemove(keys);
  },

  // 批量加密写入
  async setMultiple(entries: [string, string][]): Promise<void> {
    const ops = entries.map(([key, value]) => {
      const storageValue = isSensitive(key) ? encrypt(value) : value;
      return [key, storageValue] as [string, string];
    });
    await AsyncStorage.multiSet(ops);
  },

  // 判断指定key的值是否为已加密格式
  isEncrypted(value: string | null): boolean {
    return value?.startsWith(ENC_PREFIX) ?? false;
  },

  // 重新加密所有已存储的敏感数据（密钥轮换时使用）
  async reEncryptAll(): Promise<number> {
    const keys = await AsyncStorage.getAllKeys();
    let count = 0;

    for (const key of keys) {
      if (isSensitive(key)) {
        const raw = await AsyncStorage.getItem(key);
        if (!raw || raw.startsWith(ENC_PREFIX)) continue; // 已加密或无数据

        // 用新的IV重新加密
        const encrypted = encrypt(raw);
        await AsyncStorage.setItem(key, encrypted);
        count++;
      }
    }

    return count;
  },
};

export default SensitiveStore;
