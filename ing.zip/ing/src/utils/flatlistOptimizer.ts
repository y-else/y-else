/**
 * FlatList 虚拟列表渲染优化
 * 统一最优默认参数，减少布局层级，提升滚动帧率
 *
 * 使用方式：
 *   <FlatList {...optimizeFlatList({ data, renderItem })} />
 *   或直接展开: <FlatList data={...} renderItem={...} {...FLATLIST_OPTIMAL_PROPS} />
 */

import { Platform } from 'react-native';

/** FlatList 最优渲染参数 */
export const FLATLIST_OPTIMAL_PROPS = {
  // 虚拟列表核心优化
  removeClippedSubviews: true,      // 移除不可见视图（Android）
  maxToRenderPerBatch: 8,           // 每批次渲染数量
  updateCellsBatchingPeriod: 50,    // 批次间隔ms
  windowSize: 5,                    // 可视窗口的5倍（默认21，过大会内存压力）
  initialNumToRender: 10,           // 首屏渲染数
  getItemLayout: undefined as any,  // 由调用方按需提供（固定高度列表可大幅提升性能）

  // 滚动优化
  scrollEventThrottle: 16,          // ~60fps 滚动事件采样
  onEndReachedThreshold: 0.3,       // 触底阈值

  // 通用
  showsVerticalScrollIndicator: false,
  keyboardShouldPersistTaps: 'handled' as const,
};

/** 获取固定高度列表的 getItemLayout（禁用时返回 undefined） */
export function getFixedItemLayout(height: number): (data: any, index: number) => { length: number; offset: number; index: number } {
  return (_data: any, index: number) => ({
    length: height,
    offset: height * index,
    index,
  });
}

/** 合并默认优化参数与自定义props */
export function optimizeFlatList<T>(props: {
  data: T[];
  renderItem: any;
  keyExtractor?: (item: T, index: number) => string;
  itemHeight?: number;
  overrides?: Record<string, any>;
}): Record<string, any> {
  const layout = props.itemHeight ? { getItemLayout: getFixedItemLayout(props.itemHeight) } : {};

  return {
    ...FLATLIST_OPTIMAL_PROPS,
    ...layout,
    data: props.data,
    renderItem: props.renderItem,
    keyExtractor: props.keyExtractor || ((_item: T, index: number) => String(index)),
    ...(props.overrides || {}),
  };
}
