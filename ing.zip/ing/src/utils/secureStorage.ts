/**
 * 敏感数据安全加密存储 v3
 *
 * 三层策略（自动降级）：
 *   1. expo-secure-store (iOS Keychain / Android EncryptedSharedPreferences) — 生产首选
 *   2. SensitiveStore (AES-like XOR加密 + AsyncStorage) — secure-store 不可用时降级
 *   3. 明文 AsyncStorage — 仅非敏感键
 *
 * 安装: expo install expo-secure-store
 *
 * 使用方式：
 *   import { SecureStorage } from '../utils/secureStorage';
 *   await SecureStorage.setItem('admin_token', token);
 *   const token = await SecureStorage.getItem('admin_token');
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

// ====== 动态加载 expo-secure-store（失败不阻塞启动） ======

let SecureStoreModule: typeof import('expo-secure-store') | null = null;
let secureStoreAvailable = false;

async function ensureSecureStore(): Promise<boolean> {
  if (secureStoreAvailable && SecureStoreModule) return true;
  try {
    SecureStoreModule = await import('expo-secure-store');
    // 验证可用性：尝试写入/读取/删除测试键
    const testKey = '__sec_test__';
    await SecureStoreModule.setItemAsync(testKey, '1', { keychainAccessible: SecureStoreModule.ALWAYS_THIS_DEVICE_ONLY });
    const testVal = await SecureStoreModule.getItemAsync(testKey);
    await SecureStoreModule.deleteItemAsync(testKey);
    secureStoreAvailable = testVal === '1';
    return secureStoreAvailable;
  } catch {
    secureStoreAvailable = false;
    return false;
  }
}

// ====== 敏感键白名单（应始终使用安全存储） ======

const SENSITIVE_KEYS = [
  'admin_token',
  'token',
  'password',
  'pwd',
  'secret',
  '密令',
  'deactivation',
  'verification',
  'smsCode',
  'idCard',
  'realName',
  'identity',
  'credential',
  'key',
  'private',
];

function isSensitiveKey(key: string): boolean {
  return SENSITIVE_KEYS.some((sk) => key.toLowerCase().includes(sk.toLowerCase()));
}

// ====== 公开 API ======

export const SecureStorage = {
  async setItem(key: string, value: string): Promise<void> {
    if (isSensitiveKey(key)) {
      const available = await ensureSecureStore();
      if (available && SecureStoreModule) {
        await SecureStoreModule.setItemAsync(key, value, {
          keychainAccessible: SecureStoreModule.ALWAYS_THIS_DEVICE_ONLY,
        });
        return;
      }
      // 降级：使用加密版 AsyncStorage
      const { SensitiveStore } = await import('./sensitiveDataStore');
      await SensitiveStore.setItem(key, value);
      return;
    }
    // 非敏感键 → 明文 AsyncStorage
    await AsyncStorage.setItem(key, value);
  },

  async getItem(key: string): Promise<string | null> {
    if (isSensitiveKey(key)) {
      const available = await ensureSecureStore();
      if (available && SecureStoreModule) {
        return SecureStoreModule.getItemAsync(key);
      }
      // 降级
      const { SensitiveStore } = await import('./sensitiveDataStore');
      return SensitiveStore.getItem(key);
    }
    return AsyncStorage.getItem(key);
  },

  async removeItem(key: string): Promise<void> {
    if (isSensitiveKey(key)) {
      const available = await ensureSecureStore();
      if (available && SecureStoreModule) {
        await SecureStoreModule.deleteItemAsync(key);
        return;
      }
      const { SensitiveStore } = await import('./sensitiveDataStore');
      await SensitiveStore.removeItem(key);
      return;
    }
    await AsyncStorage.removeItem(key);
  },

  async getAllKeys(): Promise<readonly string[]> {
    // secure-store 不支持列举所有键，统一用 AsyncStorage
    return AsyncStorage.getAllKeys();
  },

  async multiRemove(keys: string[]): Promise<void> {
    await Promise.all(keys.map((k) => SecureStorage.removeItem(k)));
  },
};

// ====== 生产环境日志清理 ======

const isProduction = !__DEV__;

const _console = {
  log: console.log.bind(console),
  warn: console.warn.bind(console),
  error: console.error.bind(console),
};

export function initProductionMode(): void {
  if (isProduction) {
    console.log = () => {};
    console.warn = () => {};
    console.info = () => {};
    console.debug = () => {};
    if (typeof global !== 'undefined') {
      (global as any).__DEV__ = false;
    }
  }
}

export function logError(tag: string, error: unknown): void {
  _console.error(`[${tag}]`, error instanceof Error ? error.message : String(error));
}

export function isProductionBuild(): boolean {
  return isProduction;
}

// ====== 集中化生产日志系统 ======

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

const PROD_LOG_LEVEL: LogLevel = 'error';
const DEV_LOG_LEVEL: LogLevel = 'debug';

const LOG_LEVEL_WEIGHT: Record<LogLevel, number> = {
  debug: 0, info: 1, warn: 2, error: 3,
};

function shouldLog(level: LogLevel): boolean {
  const minWeight = LOG_LEVEL_WEIGHT[isProduction ? PROD_LOG_LEVEL : DEV_LOG_LEVEL];
  return LOG_LEVEL_WEIGHT[level] >= minWeight;
}

export const logger = {
  debug: (tag: string, message: string, data?: any) => {
    if (shouldLog('debug')) {
      _console.log(`[${tag}] ${message}`, data !== undefined ? data : '');
    }
  },
  info: (tag: string, message: string, data?: any) => {
    if (shouldLog('info')) {
      _console.log(`[${tag}] ${message}`, data !== undefined ? data : '');
    }
  },
  warn: (tag: string, message: string, data?: any) => {
    if (shouldLog('warn')) {
      _console.warn(`[${tag}] ${message}`, data !== undefined ? data : '');
    }
  },
  error: (tag: string, message: string, error?: unknown) => {
    if (shouldLog('error')) {
      _console.error(`[${tag}] ${message}`, error instanceof Error ? error.message : error !== undefined ? String(error) : '');
    }
  },
  /** API调用日志（生产环境仅记录错误请求） */
  api: (method: string, path: string, status: number, duration: number) => {
    if (shouldLog(status >= 400 ? 'error' : 'debug')) {
      const level = status >= 400 ? 'ERROR' : 'OK';
      _console.log(`[API] ${level} ${method} ${path} ${status} ${duration}ms`);
    }
  },
  /** 性能日志（生产环境关闭） */
  perf: (tag: string, operation: string, durationMs: number) => {
    if (shouldLog('debug')) {
      _console.log(`[Perf:${tag}] ${operation} took ${durationMs.toFixed(1)}ms`);
    }
  },
};

export { isProduction as IS_PRODUCTION };
