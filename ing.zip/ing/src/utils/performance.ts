/**
 * 全局性能优化工具集
 * 防抖/节流/请求去重/内存分页/懒加载控制
 */

// ====== 防抖（搜索输入、列表刷新等高频操作） ======

export function debounce<T extends (...args: any[]) => any>(
  fn: T,
  delayMs: number,
): (...args: Parameters<T>) => void {
  let timer: ReturnType<typeof setTimeout> | null = null;
  return (...args: Parameters<T>) => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      fn(...args);
      timer = null;
    }, delayMs);
  };
}

// ====== 节流（按钮点击、定位上报、滚动事件） ======

export function throttle<T extends (...args: any[]) => any>(
  fn: T,
  intervalMs: number,
): (...args: Parameters<T>) => void {
  let lastTime = 0;
  let pendingTimer: ReturnType<typeof setTimeout> | null = null;
  return (...args: Parameters<T>) => {
    const now = Date.now();
    if (now - lastTime >= intervalMs) {
      lastTime = now;
      fn(...args);
    } else if (!pendingTimer) {
      // 尾调用保证最后一次触发被执行
      pendingTimer = setTimeout(() => {
        lastTime = Date.now();
        fn(...args);
        pendingTimer = null;
      }, intervalMs - (now - lastTime));
    }
  };
}

// ====== 请求去重（2秒内相同请求自动合并） ======

const pendingRequests = new Map<string, Promise<any>>();
const REQUEST_DEDUP_TTL = 2000;

export async function dedupRequest<T>(
  key: string,
  fetcher: () => Promise<T>,
  ttlMs: number = REQUEST_DEDUP_TTL,
): Promise<T> {
  const existing = pendingRequests.get(key);
  if (existing) return existing as Promise<T>;

  const promise = fetcher().finally(() => {
    setTimeout(() => {
      pendingRequests.delete(key);
    }, ttlMs);
  });

  pendingRequests.set(key, promise);
  return promise;
}

// ====== 并发请求控制器（限制同时最大连接数） ======

export class ConcurrencyController {
  private running = 0;
  private queue: Array<() => void> = [];
  private maxConcurrent: number;

  constructor(maxConcurrent = 4) {
    this.maxConcurrent = maxConcurrent;
  }

  async execute<T>(task: () => Promise<T>): Promise<T> {
    while (this.running >= this.maxConcurrent) {
      await new Promise<void>((resolve) => this.queue.push(resolve));
    }
    this.running++;
    try {
      return await task();
    } finally {
      this.running--;
      const next = this.queue.shift();
      if (next) next();
    }
  }
}

export const networkConcurrency = new ConcurrencyController(4);

// ====== 内存数据分页读取 ======

export function paginateArray<T>(data: T[], page: number, pageSize: number): {
  items: T[];
  hasMore: boolean;
  total: number;
} {
  const start = page * pageSize;
  const end = start + pageSize;
  return {
    items: data.slice(start, end),
    hasMore: end < data.length,
    total: data.length,
  };
}

// ====== 简易内存用量监控（开发调试用） ======

export function getMemoryInfo(): { jsHeapSize: number } | null {
  try {
    const g = global as any;
    if (g.performance?.memory) {
      return { jsHeapSize: g.performance.memory.usedJSHeapSize };
    }
  } catch {}
  return null;
}

// ====== 请求重试（带指数退避） ======

export async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  maxRetries = 3,
  baseDelayMs = 1000,
): Promise<T> {
  for (let i = 0; i <= maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (i === maxRetries) throw error;
      const delay = baseDelayMs * Math.pow(2, i);
      await new Promise((r) => setTimeout(r, delay));
    }
  }
  throw new Error('unreachable');
}
