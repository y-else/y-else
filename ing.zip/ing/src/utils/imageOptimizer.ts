/**
 * 图片资源优化工具
 * 懒加载、分辨率限制、缓存复用、内存自动释放
 */

import { Image } from 'react-native';
import { useState, useEffect, useRef } from 'react';

// ====== 最大分辨率限制（防止OOM） ======

const MAX_DIMENSIONS = {
  avatar: { width: 200, height: 200 },
  post: { width: 1080, height: 1920 },
  thumbnail: { width: 400, height: 400 },
} as const;

export type ImageSizeType = keyof typeof MAX_DIMENSIONS;

/**
 * 获取合理的缩略尺寸
 */
export function getThumbnailSize(type: ImageSizeType = 'thumbnail') {
  return MAX_DIMENSIONS[type];
}

// ====== 图片懒加载 Hook ======

export function useLazyImage(uri: string | null | undefined) {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);
  const unmountedRef = useRef(false);

  useEffect(() => {
    unmountedRef.current = false;
    setLoaded(false);
    setError(false);

    if (!uri) return;

    // 预加载图片到缓存
    Image.prefetch(uri)
      .then(() => {
        if (!unmountedRef.current) setLoaded(true);
      })
      .catch(() => {
        if (!unmountedRef.current) setError(true);
      });

    return () => {
      unmountedRef.current = true;
    };
  }, [uri]);

  return { loaded, error };
}

// ====== 图片缓存释放（切换页面时调用） ======

const loadedUris = new Set<string>();

export function trackImageCache(uri: string) {
  loadedUris.add(uri);
}

export function releaseImageCache(uri: string) {
  loadedUris.delete(uri);
  // 通知原生层释放（Android）
  if (typeof (Image as any).resolveAssetSource === 'function') {
    try {
      Image.prefetch(uri).catch(() => {}); // 保持活跃
    } catch {}
  }
}

/**
 * 页面卸载时释放该页面所有图片缓存
 */
export function releasePageImages(uris: string[]) {
  uris.forEach((uri) => {
    loadedUris.delete(uri);
  });
}

// ====== 内联base64小图（减少网络请求） ======

const DATA_URI_PREFIX = 'data:image/png;base64,';

export function isBase64Image(uri: string): boolean {
  return uri.startsWith(DATA_URI_PREFIX);
}
