/**
 * 统一离线请求队列
 * 弱网离线缓存 → 网络恢复自动重放 → 持久化不丢失
 *
 * 修复:
 * - 原 network.ts 内存队列 (丢失风险) + apiClient.ts 独立队列 (重复逻辑) → 统一
 * - 持久化到 AsyncStorage，APP被杀后不丢失
 * - 网络恢复时自动重放 + SOS优先
 * - 队列上限200条，超限自动淘汰最旧
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

const QUEUE_KEY = '@ing_offline_queue';
const MAX_QUEUE_SIZE = 200;

export interface QueuedRequest {
  id: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  url?: string;       // fetchWithTimeout 风格
  path?: string;       // apiClient 风格
  body?: any;
  headers?: Record<string, string>;
  timestamp: number;
  priority: 'normal' | 'high'; // SOS等紧急请求优先
  retries: number;
}

// ====== 持久化读写 ======

async function readQueue(): Promise<QueuedRequest[]> {
  try {
    const raw = await AsyncStorage.getItem(QUEUE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

async function writeQueue(queue: QueuedRequest[]): Promise<void> {
  try {
    if (queue.length > MAX_QUEUE_SIZE) {
      queue = queue.slice(-MAX_QUEUE_SIZE);
    }
    await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
  } catch { /* 静默 */ }
}

// ====== 入队 ======

export async function enqueueRequest(params: Omit<QueuedRequest, 'id' | 'timestamp' | 'retries'>): Promise<void> {
  const queue = await readQueue();
  // 去重：同URL/PATH的重复请求合并
  const dupKey = params.url || params.path;
  const exists = queue.find((q) => (q.url || q.path) === dupKey && q.method === params.method);
  if (exists) return;

  const entry: QueuedRequest = {
    ...params,
    id: 'oq_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
    timestamp: Date.now(),
    retries: 0,
  };

  // 高优先级插队
  if (params.priority === 'high') {
    const firstNormal = queue.findIndex((q) => q.priority === 'normal');
    if (firstNormal >= 0) {
      queue.splice(firstNormal, 0, entry);
    } else {
      queue.push(entry);
    }
  } else {
    queue.push(entry);
  }

  await writeQueue(queue);
}

// ====== 出队/重放 ======

export async function getQueueSize(): Promise<number> {
  const queue = await readQueue();
  return queue.length;
}

export async function getPendingRequests(): Promise<QueuedRequest[]> {
  return readQueue();
}

/** 移除已处理的请求 */
export async function removeRequest(id: string): Promise<void> {
  const queue = await readQueue();
  await writeQueue(queue.filter((q) => q.id !== id));
}

/** 标记重试次数 */
export async function incrementRetry(id: string): Promise<void> {
  const queue = await readQueue();
  const item = queue.find((q) => q.id === id);
  if (item) item.retries++;
  await writeQueue(queue);
}

/** 清空所有队列 */
export async function clearQueue(): Promise<void> {
  await AsyncStorage.removeItem(QUEUE_KEY);
}

// ====== 重放回调注册 ======

type ReplayHandler = (req: QueuedRequest) => Promise<boolean>; // 返回true表示成功

let replayHandler: ReplayHandler | null = null;

export function setReplayHandler(handler: ReplayHandler): void {
  replayHandler = handler;
}

/** 网络恢复时自动重放全部离线请求（高优先级先行） */
export async function replayAllOfflineRequests(): Promise<{ processed: number; failed: number }> {
  const queue = await readQueue();
  if (queue.length === 0) return { processed: 0, failed: 0 };

  // 高优先级先行
  const sorted = [...queue].sort((a, b) => {
    if (a.priority === 'high' && b.priority !== 'high') return -1;
    if (a.priority !== 'high' && b.priority === 'high') return 1;
    return a.timestamp - b.timestamp;
  });

  let processed = 0;
  let failed = 0;

  for (const req of sorted) {
    if (!replayHandler) break;

    // 超过5次重试则放弃
    if (req.retries >= 5) {
      await removeRequest(req.id);
      failed++;
      continue;
    }

    try {
      const success = await replayHandler(req);
      if (success) {
        await removeRequest(req.id);
        processed++;
      } else {
        await incrementRetry(req.id);
        failed++;
      }
    } catch {
      await incrementRetry(req.id);
      failed++;
    }
  }

  return { processed, failed };
}
