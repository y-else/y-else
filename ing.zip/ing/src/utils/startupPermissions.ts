/**
 * @deprecated 此文件已合并至 src/services/permissions.ts
 * 保留此文件仅为向后兼容，所有新代码请直接从 '../services/permissions' 导入
 *
 * 迁移指南：
 *   import { checkAllPermissions } from '../utils/startupPermissions';
 *   → import { checkAllPermissions } from '../services/permissions';
 *
 *   类型 AllPermissions → UnifiedPermissions
 */

export {
  checkAllPermissions,
  requestAllPermissions,
  areAllGranted,
  getMissingPermissions,
  hasBlockedPermission,
  isAllPermissionsGranted,
  openAppSettings as openSystemSettings,
} from '../services/permissions';

export type {
  PermissionState,
  UnifiedPermissions as AllPermissions,
} from '../services/permissions';
