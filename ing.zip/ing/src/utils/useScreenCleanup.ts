/**
 * 屏幕卸载资源清理 Hook（增强版）
 *
 * 自动管理：定时器 / GPS监听 / WebSocket订阅 / Location订阅
 * 组件卸载时自动清理所有注册的资源，防止内存泄漏
 *
 * 使用方式：
 *   const cleanup = useScreenCleanup();
 *   cleanup.registerInterval('heartbeat', 30000, () => { ... });
 *   cleanup.registerGPSWatcher('tracking', subscription);
 *   cleanup.onUnmount(() => { /* 自定义清理 *\/ });
 */

import { useEffect, useRef, useCallback } from 'react';

interface CleanupHandle {
  id: string;
  cleanup: () => void;
}

/** GPS/Location订阅类型 */
interface LocationSubscriptionLike {
  remove: () => void;
}

/** WebSocket/EventEmitter订阅类型 */
interface EventSubscriptionLike {
  remove?: () => void;
  unsubscribe?: () => void;
}

export function useScreenCleanup() {
  const handlesRef = useRef<CleanupHandle[]>([]);
  const mountedRef = useRef(true);

  // 注册通用清理器
  const registerCleanup = useCallback((id: string, cleanup: () => void) => {
    // 去重
    const existing = handlesRef.current.findIndex((h) => h.id === id);
    if (existing >= 0) {
      try { handlesRef.current[existing].cleanup(); } catch {}
      handlesRef.current.splice(existing, 1);
    }
    handlesRef.current.push({ id, cleanup });
    return () => {
      try { cleanup(); } catch {}
      handlesRef.current = handlesRef.current.filter((h) => h.id !== id);
    };
  }, []);

  // 注册定时器（自动清理）
  const registerInterval = useCallback((id: string, ms: number, fn: () => void) => {
    const timer = setInterval(fn, ms);
    return registerCleanup(id, () => clearInterval(timer));
  }, [registerCleanup]);

  // 注册超时器
  const registerTimeout = useCallback((id: string, ms: number, fn: () => void) => {
    const timer = setTimeout(fn, ms);
    return registerCleanup(id, () => clearTimeout(timer));
  }, [registerCleanup]);

  // 注册GPS位置监听器
  const registerGPSWatcher = useCallback((id: string, subscription: LocationSubscriptionLike | null) => {
    if (!subscription) return;
    return registerCleanup(id, () => {
      try { subscription.remove(); } catch {}
    });
  }, [registerCleanup]);

  // 注册WebSocket/Event订阅
  const registerSubscription = useCallback((id: string, subscription: EventSubscriptionLike | (() => void) | null) => {
    if (!subscription) return;
    return registerCleanup(id, () => {
      try {
        if (typeof subscription === 'function') {
          subscription();
        } else if (subscription.remove) {
          subscription.remove();
        } else if (subscription.unsubscribe) {
          subscription.unsubscribe();
        }
      } catch {}
    });
  }, [registerCleanup]);

  // 注册AppState监听器
  const registerAppState = useCallback((id: string, subscription: { remove: () => void } | null) => {
    if (!subscription) return;
    return registerCleanup(id, () => {
      try { subscription.remove(); } catch {}
    });
  }, [registerCleanup]);

  // 注册任意类型资源的便捷方法（自动检测remove/unsubscribe/函数类型）
  const autoRegister = useCallback((id: string, resource: any) => {
    if (!resource) return;
    return registerCleanup(id, () => {
      try {
        if (typeof resource === 'function') {
          resource();
        } else if (typeof resource.remove === 'function') {
          resource.remove();
        } else if (typeof resource.unsubscribe === 'function') {
          resource.unsubscribe();
        } else if (typeof resource.close === 'function') {
          resource.close();
        } else if (typeof resource.stop === 'function') {
          resource.stop();
        }
      } catch {}
    });
  }, [registerCleanup]);

  // 组件卸载时全部清理
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      handlesRef.current.forEach((h) => {
        try {
          h.cleanup();
        } catch (e) {
          // 静默处理清理错误
        }
      });
      handlesRef.current = [];
    };
  }, []);

  // 一次性清理所有资源（不等待卸载）
  const cleanupAll = useCallback(() => {
    handlesRef.current.forEach((h) => {
      try { h.cleanup(); } catch {}
    });
    handlesRef.current = [];
  }, []);

  return {
    registerCleanup,
    registerInterval,
    registerTimeout,
    registerGPSWatcher,
    registerSubscription,
    registerAppState,
    autoRegister,
    cleanupAll,
    isMounted: () => mountedRef.current,
  };
}
