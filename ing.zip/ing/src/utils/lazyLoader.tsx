/**
 * 页面级懒加载 + 图片预加载控制
 *
 * React.lazy 屏幕组件懒加载，降低首屏JS解析开销。
 * 配合 InteractionManager 延迟非关键渲染。
 *
 * 使用方式：
 *   const LazyScreen = createLazyScreen(() => import('../screens/SomeScreen'));
 */

import React, { Suspense } from 'react';
import { View, ActivityIndicator, Text, StyleSheet, InteractionManager } from 'react-native';
import { Colors, Typography, Spacing } from '../constants';

// ====== 页面懒加载 ======

const LazyFallback: React.FC = () => (
  <View style={styles.fallback}>
    <ActivityIndicator size="small" color={Colors.primary} />
    <Text style={styles.fallbackText}>加载中...</Text>
  </View>
);

/**
 * 创建懒加载屏幕组件
 * 仅在路由导航到该页面时才下载JS bundle
 */
export function createLazyScreen<T extends React.ComponentType<any>>(
  factory: () => Promise<{ default: T }>,
): React.FC<React.ComponentProps<T>> {
  const LazyComponent = React.lazy(factory);

  return (props: React.ComponentProps<T>) => (
    <Suspense fallback={<LazyFallback />}>
      <LazyComponent {...props} />
    </Suspense>
  );
}

// ====== 延迟渲染（非首屏关键内容） ======

interface DeferredRenderProps {
  children: React.ReactNode;
  placeholder?: React.ReactNode;
}

/**
 * 延迟渲染组件：等主线程空闲时再渲染子组件
 * 用于非首屏关键内容（列表底部、详情面板等）
 */
export const DeferredRender: React.FC<DeferredRenderProps> = ({ children, placeholder }) => {
  const [mounted, setMounted] = React.useState(false);

  React.useEffect(() => {
    const handle = InteractionManager.runAfterInteractions(() => {
      setMounted(true);
    });
    return () => handle.cancel();
  }, []);

  if (!mounted) return placeholder ? <>{placeholder}</> : <View />;
  return <>{children}</>;
};

// ====== 图片懒加载阈值 ======

/** 屏幕外预加载距离（像素） */
export const IMAGE_PREFETCH_DISTANCE = 500;

/**
 * 图片URI优先级排序（高优先级的先加载）
 */
export function sortImageUris(uris: string[], visibleIndex: number): string[] {
  const result = [...uris];
  // 可见区域的图片移到前面优先加载
  const visible = result.splice(visibleIndex, 1);
  return [...visible, ...result];
}

const styles = StyleSheet.create({
  fallback: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.bgPrimary,
  },
  fallbackText: {
    fontSize: Typography.caption,
    color: Colors.textHint,
    marginTop: Spacing.md,
  },
});
