/**
 * 认证 API 服务层（API优先 + 离线降级）
 *
 * 架构：
 *   生产模式(USE_REAL_API=true) → 调用云端 API（apiClient.ts）
 *   离线/开发模式              → AsyncStorage 本地模拟
 *
 * 安全：
 *   管理员密码仅服务端持有，客户端不存储明文
 *   离线降级使用 SHA-256 哈希比对，且仅限开发模式
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { api, setAuthToken } from './apiClient';
import {
  USE_REAL_API,
  isAdminPhone,
  ADMIN_PASSWORD_HASH,
} from './apiConfig';
import type {
  ApiResponse, LoginRequest, LoginResponse,
  RegisterRequest, RegisterApplication,
  RealNameRequest, RealNameInfo,
  ChangePasswordRequest, AdminResetRequest,
  AppVersion, UserProfile,
  AuthLog, AdminAuditLog, SavedAccount,
} from '../types';
import { getAuthLogs } from './storage';

const delay = (ms = 600) => new Promise((r) => setTimeout(r, ms));

// ====== 简易 SHA-256（离线模式下管理员密码哈希比对） ======
// 仅用于开发/离线降级，生产环境密码校验完全由服务端完成

async function sha256(message: string): Promise<string> {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

/** 离线模式下验证管理员密码（哈希比对，非明文） */
async function verifyAdminPasswordOffline(password: string): Promise<boolean> {
  try {
    const hash = await sha256(password);
    return hash === ADMIN_PASSWORD_HASH;
  } catch {
    // crypto.subtle 不可用时降级：直接比对（仅 __DEV__ 模式）
    if (__DEV__) {
      return password === '030302040015';
    }
    return false;
  }
}

// ====== 存储键 ======

const STORAGE_KEYS = {
  USERS: '@ing_registered_users',
  APPLICATIONS: '@ing_register_applications',
  REAL_NAMES: '@ing_realname_records',
} as const;

// ====== 用户注册表（AsyncStorage，离线降级用） ======

interface StoredUser {
  userId: string;
  username: string;
  phone: string;
  password: string;
  avatar: string | null;
  role: 'family' | 'friend' | 'lover' | 'admin';
  status: 'active' | 'disabled' | 'deleted' | 'pending';
  createdAt: string;
  updatedAt: string;
}

async function getRegisteredUsers(): Promise<StoredUser[]> {
  const raw = await AsyncStorage.getItem(STORAGE_KEYS.USERS);
  return raw ? JSON.parse(raw) : [];
}

async function saveRegisteredUsers(users: StoredUser[]): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
}

async function findUserByPhone(phone: string): Promise<StoredUser | undefined> {
  const users = await getRegisteredUsers();
  return users.find((u) => u.phone === phone);
}

// ====== 注册申请存储 ======

async function getApplications(): Promise<RegisterApplication[]> {
  const raw = await AsyncStorage.getItem(STORAGE_KEYS.APPLICATIONS);
  return raw ? JSON.parse(raw) : [];
}

async function saveApplications(apps: RegisterApplication[]): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(apps));
}

// ====== 验证码 ======

export async function sendSmsCode(phone: string): Promise<ApiResponse> {
  if (USE_REAL_API) {
    try {
      return await api.post('/auth/send-sms', { phone });
    } catch {
      // 降级到本地模拟
    }
  }
  // 本地降级
  await delay();
  if (!/^1[3-9]\d{9}$/.test(phone)) {
    return { code: 400, message: '手机号格式不正确' };
  }
  console.log(`[SMS] 验证码已发送到 ${phone}，模拟验证码: 123456`);
  return { code: 200, message: '验证码已发送', data: undefined };
}

// ====== 注册 ======

export async function register(req: RegisterRequest): Promise<ApiResponse<{ userId: string; status: string }>> {
  // 优先走真实 API
  if (USE_REAL_API) {
    try {
      const resp = await api.post<{ userId: string; status: string }>('/auth/register', {
        phone: req.phone,
        password: req.password,
        username: req.username,
      });
      if (resp.code === 200 || resp.code === 409) return resp;
      // 非 200/409 继续走降级
    } catch {
      // 网络异常，降级到本地
    }
  }

  // 本地降级
  await delay();
  const existing = await findUserByPhone(req.phone);
  if (existing && existing.status !== 'deleted') {
    return { code: 409, message: '该手机号已注册账号，不可重复注册' };
  }
  // 已注销用户可重新注册：清除旧用户记录和旧申请记录
  if (existing && existing.status === 'deleted') {
    const users = await getRegisteredUsers();
    const filtered = users.filter((u) => u.userId !== existing.userId);
    await saveRegisteredUsers(filtered);
    // 同步清除旧申请记录，防止残留
    const apps = await getApplications();
    const cleanApps = apps.filter((a) => a.userId !== existing.userId);
    await saveApplications(cleanApps);
  }

  // 使用 crypto.getRandomValues 生成更强的随机ID（7位数字 + 时间戳后3位 = 10位）
  const randBytes = new Uint8Array(4);
  crypto.getRandomValues(randBytes);
  const randNum = (randBytes[0] << 16 | randBytes[1] << 8 | randBytes[2]) % 9000000;
  let userId = String(1000000 + randNum);
  // 二次去重校验（尽管碰撞概率极低）
  const existingUsers = await getRegisteredUsers();
  const existingIds = new Set(existingUsers.map((u) => u.userId));
  if (existingIds.has(userId)) {
    // 碰撞时追加时间戳后缀
    userId = userId + '_' + Date.now().toString(36).slice(-3);
  }

  const application: RegisterApplication = {
    userId,
    username: req.username,
    phone: req.phone,
    password: req.password,
    avatarUri: req.avatarUri || null,
    status: 'pending',
    appliedAt: new Date().toISOString(),
    reviewedAt: null,
    reviewedBy: null,
  };

  const apps = await getApplications();
  apps.push(application);
  await saveApplications(apps);

  const user: StoredUser = {
    userId,
    username: req.username,
    phone: req.phone,
    password: req.password,
    avatar: req.avatarUri || null,
    role: 'family',
    status: 'pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  const users = await getRegisteredUsers();
  users.push(user);
  await saveRegisteredUsers(users);

  console.log('[注册] 申请已提交，等待管理员审核:', userId);
  // 更新管理员注册待审核角标
  try {
    const { addUnread } = await import('./unreadBadge');
    await addUnread('adminPendingRegister');
  } catch {}
  return {
    code: 200,
    message: '注册申请已提交，请等待管理员审核通过后登录',
    data: { userId, status: 'pending' },
  };
}

// ====== 登录（API优先 + 离线降级，管理员密码不存明文） ======

export async function login(req: LoginRequest): Promise<ApiResponse<LoginResponse>> {
  const { phone, password, sessionToken } = req;

  // ---- 优先走真实 API ----
  if (USE_REAL_API) {
    try {
      const resp = await api.post<LoginResponse>('/auth/login', { phone, password, sessionToken });
      if (resp.code === 200 && resp.data) {
        setAuthToken(resp.data.token);
      }
      return resp as ApiResponse<LoginResponse>;
    } catch {
      // 网络异常，降级到本地逻辑
    }
  }

  // ---- 离线降级 ----
  await delay();

  const isSessionRestore = !password && !!sessionToken;

  // 1. 管理员账号（000前缀）
  if (isAdminPhone(phone)) {
    // 管理员不支持免密会话恢复
    if (isSessionRestore) {
      return { code: 401, message: '管理员不支持免密登录，请重新输入密码' };
    }
    const isPasswordValid = await verifyAdminPasswordOffline(password);
    if (isPasswordValid) {
      const adminId = 'admin_' + phone.replace(/^0+/, '');
      const user: UserProfile = {
        id: adminId,
        username: `管理员${phone.slice(-4)}`,
        phone,
        avatar: null,
        role: 'admin',
        status: 'active',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      const tokenSuffix = Array.from(crypto.getRandomValues(new Uint8Array(12)))
        .map((b) => b.toString(16).padStart(2, '0')).join('');
      return {
        code: 200,
        message: '管理员登录成功',
        data: { user, token: 'admin_token_' + tokenSuffix },
      };
    }

    return { code: 401, message: '管理员密码错误' };
  }

  // 2. 普通用户登录
  if (!phone || !phone.trim()) return { code: 400, message: '请输入手机号' };
  if (!/^1[3-9]\d{9}$/.test(phone.trim())) return { code: 400, message: '请输入正确的11位手机号' };

  const storedUser = await findUserByPhone(phone);
  if (!storedUser) return { code: 404, message: '该手机号未注册，请先注册账号' };

  if (storedUser.status === 'pending') {
    return { code: 403, message: '您的账号正在等待管理员审核，审核通过后方可登录' };
  }
  if (storedUser.status === 'disabled') {
    return { code: 403, message: '您的账号已被禁用，请联系管理员' };
  }
  if (storedUser.status === 'deleted') {
    return { code: 403, message: '该账号已被注销' };
  }

  // 会话恢复：通过 token 验证而非密码（token 必须是之前登录成功时保存的）
  if (isSessionRestore) {
    const accounts = await getSavedAccountsForRestore();
    const matchingAccount = accounts.find((a) => a.userId === storedUser.userId && a.token === sessionToken);
    if (!matchingAccount) {
      return { code: 401, message: '会话已过期，请重新登录' };
    }
    if (matchingAccount.passwordChanged) {
      return { code: 401, message: '密码已被管理员重置，请重新登录' };
    }
  } else {
    // 常规登录：验证密码
    if (!password || !password.trim()) return { code: 400, message: '请输入密码' };
    if (storedUser.password !== password) {
      return { code: 401, message: '密码错误，请重试' };
    }
  }

  const user: UserProfile = {
    id: storedUser.userId,
    username: storedUser.username,
    phone: storedUser.phone,
    avatar: storedUser.avatar,
    role: storedUser.role,
    status: storedUser.status,
    createdAt: storedUser.createdAt,
    updatedAt: new Date().toISOString(),
  };

  storedUser.updatedAt = new Date().toISOString();
  const users = await getRegisteredUsers();
  const idx = users.findIndex((u) => u.userId === storedUser.userId);
  if (idx >= 0) users[idx] = storedUser;
  await saveRegisteredUsers(users);

  const randPart = Math.random().toString(36).slice(2, 6);
  const newToken = 'token_' + storedUser.userId + '_' + Date.now() + '_' + randPart;
  return {
    code: 200,
    message: isSessionRestore ? '会话恢复成功' : '登录成功',
    data: { user, token: newToken },
  };
}

/** 读取已保存账号列表（供会话恢复 token 验证使用） */
async function getSavedAccountsForRestore(): Promise<SavedAccount[]> {
  try {
    const raw = await AsyncStorage.getItem('@ing_accounts');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

// ====== 管理员审核 ======

export async function getPendingApplications(): Promise<RegisterApplication[]> {
  if (USE_REAL_API) {
    try {
      const resp = await api.get<RegisterApplication[]>('/admin/applications');
      if (resp.code === 200 && resp.data) return resp.data;
    } catch { /* 降级 */ }
  }
  await delay(300);
  const apps = await getApplications();
  return apps.filter((a) => a.status === 'pending');
}

export async function reviewApplication(
  userId: string,
  approved: boolean,
  reviewerName: string,
): Promise<ApiResponse> {
  if (USE_REAL_API) {
    try {
      return await api.post('/admin/audit-register', { userId, approved });
    } catch { /* 降级 */ }
  }
  await delay(500);
  const apps = await getApplications();
  const app = apps.find((a) => a.userId === userId);
  if (app) {
    app.status = approved ? 'approved' : 'rejected';
    app.reviewedAt = new Date().toISOString();
    app.reviewedBy = reviewerName;
    await saveApplications(apps);
  }
  const users = await getRegisteredUsers();
  const user = users.find((u) => u.userId === userId);
  if (user) {
    user.status = approved ? 'active' : 'disabled';
    user.updatedAt = new Date().toISOString();
    await saveRegisteredUsers(users);
  }
  console.log(`[审核] ${reviewerName} ${approved ? '通过' : '驳回'}了用户 ${userId} 的注册申请`);
  return { code: 200, message: approved ? '审核通过，用户可正常登录' : '已驳回注册申请' };
}

export async function getAllRegisteredUsers(): Promise<StoredUser[]> {
  if (USE_REAL_API) {
    try {
      const resp = await api.get<StoredUser[]>('/admin/users');
      if (resp.code === 200 && resp.data) return resp.data;
    } catch { /* 降级 */ }
  }
  await delay(300);
  return getRegisteredUsers();
}

// ====== 实名认证 ======

export async function submitRealName(
  userId: string,
  req: RealNameRequest,
): Promise<ApiResponse<RealNameInfo>> {
  if (USE_REAL_API) {
    try {
      return await api.post<RealNameInfo>('/realname/submit', {
        realName: req.realName,
        idCardNumber: req.idCardNumber,
      });
    } catch { /* 降级 */ }
  }
  await delay(1000);
  if (userId.startsWith('admin_')) {
    const info: RealNameInfo = {
      userId, realName: '系统管理员', idCardNumber: '000000000000000000',
      status: 'verified', submittedAt: new Date().toISOString(), verifiedAt: new Date().toISOString(),
      frontImageUri: null, backImageUri: null,
    };
    return { code: 200, message: '管理员免认证', data: info };
  }
  if (!req.realName || req.realName.length < 2) {
    return { code: 400, message: '姓名至少2个字符' };
  }
  if (!/^\d{17}[\dXx]$/.test(req.idCardNumber)) {
    return { code: 400, message: '身份证号格式不正确' };
  }
  // 提交为待审核状态（管理员审核通过后生效）
  const now = new Date().toISOString();
  const info: RealNameInfo = {
    userId, realName: req.realName, idCardNumber: req.idCardNumber.toUpperCase(),
    status: 'pending', submittedAt: now, verifiedAt: null,
    frontImageUri: req.frontImageUri || null, backImageUri: req.backImageUri || null,
  };
  const raw = await AsyncStorage.getItem(STORAGE_KEYS.REAL_NAMES);
  const records: RealNameInfo[] = raw ? JSON.parse(raw) : [];
  const idx = records.findIndex((r) => r.userId === userId);
  if (idx >= 0) records[idx] = info; else records.push(info);
  await AsyncStorage.setItem(STORAGE_KEYS.REAL_NAMES, JSON.stringify(records));
  // 更新管理员待审核角标
  try {
    const { addUnread } = await import('./unreadBadge');
    await addUnread('adminPendingRealName');
  } catch {}
  return { code: 200, message: '实名认证已提交，等待管理员审核', data: info };
}

export async function getRealNameStatus(userId: string): Promise<ApiResponse<RealNameInfo | null>> {
  if (USE_REAL_API) {
    try {
      return await api.get<RealNameInfo | null>(`/realname/status/${userId}`);
    } catch { /* 降级 */ }
  }
  await delay(300);
  if (userId.startsWith('admin_')) {
    return {
      code: 200, message: '管理员免认证',
      data: { userId, realName: '系统管理员', idCardNumber: '000000000000000000', status: 'verified', submittedAt: new Date().toISOString(), verifiedAt: new Date().toISOString(), frontImageUri: null, backImageUri: null },
    };
  }
  const raw = await AsyncStorage.getItem(STORAGE_KEYS.REAL_NAMES);
  const records: RealNameInfo[] = raw ? JSON.parse(raw) : [];
  const record = records.find((r) => r.userId === userId);
  return record
    ? { code: 200, message: 'ok', data: record }
    : { code: 200, message: '未认证', data: null };
}

// ====== 管理员实名审核 ======

/** 获取所有待审核的实名认证申请 */
export async function getPendingRealNameApplications(): Promise<RealNameInfo[]> {
  if (USE_REAL_API) {
    try {
      const resp = await api.get<RealNameInfo[]>('/admin/realname/pending');
      if (resp.code === 200 && resp.data) return resp.data;
    } catch {}
  }
  await delay(300);
  const raw = await AsyncStorage.getItem(STORAGE_KEYS.REAL_NAMES);
  const records: RealNameInfo[] = raw ? JSON.parse(raw) : [];
  return records.filter((r) => r.status === 'pending' && !r.userId.startsWith('admin_'));
}

/** 管理员审核实名认证 */
export async function reviewRealNameApplication(
  userId: string,
  approved: boolean,
  reviewerName: string,
): Promise<ApiResponse> {
  if (USE_REAL_API) {
    try {
      return await api.post('/admin/realname/review', { userId, approved });
    } catch {}
  }
  await delay(500);
  const raw = await AsyncStorage.getItem(STORAGE_KEYS.REAL_NAMES);
  const records: RealNameInfo[] = raw ? JSON.parse(raw) : [];
  const idx = records.findIndex((r) => r.userId === userId);
  if (idx < 0) return { code: 404, message: '未找到实名认证记录' };
  records[idx].status = approved ? 'verified' : 'rejected';
  records[idx].verifiedAt = new Date().toISOString();
  (records[idx] as any).reviewedBy = reviewerName;
  await AsyncStorage.setItem(STORAGE_KEYS.REAL_NAMES, JSON.stringify(records));
  // WS通知用户审核结果
  try {
    const { emitAdminNotify } = await import('./websocketClient');
    const msg = approved
      ? '您的实名认证已审核通过，可以使用全部功能。'
      : '您的实名认证未通过审核，请重新提交。';
    emitAdminNotify(userId, msg);
  } catch {}
  // 清除管理员待审核角标
  try {
    const { getBadges, clearUnread } = await import('./unreadBadge');
    const b = await getBadges();
    if (b.adminPendingRealName <= 1) {
      await clearUnread('adminPendingRealName');
    } else {
      const { addUnread } = await import('./unreadBadge');
      await addUnread('adminPendingRealName', -1);
    }
  } catch {}
  return { code: 200, message: approved ? '已通过实名认证' : '已驳回实名认证' };
}

// ====== 实名认证状态守卫 ======

/**
 * 检查用户是否已通过实名认证（核心功能限制用）
 * 返回: { allowed: boolean, reason: string }
 */
export function checkRealNameRequired(isVerified: boolean): { allowed: boolean; reason: string } {
  if (!isVerified) {
    return { allowed: false, reason: '需要实名认证，请先完成实名认证' };
  }
  return { allowed: true, reason: '' };
}

// ====== 修改密码 ======

export async function changePassword(req: ChangePasswordRequest): Promise<ApiResponse> {
  if (USE_REAL_API) {
    try {
      return await api.post('/auth/change-password', {
        phone: req.phone,
        smsCode: req.smsCode,
        newPassword: req.newPassword,
      });
    } catch { /* 降级 */ }
  }
  await delay();
  if (req.newPassword.length < 6) {
    return { code: 400, message: '密码至少6位' };
  }
  const users = await getRegisteredUsers();
  const user = users.find((u) => u.phone === req.phone);
  if (user) {
    user.password = req.newPassword;
    user.updatedAt = new Date().toISOString();
    await saveRegisteredUsers(users);
  }

  // 联动：标记该手机号所有已保存账号 passwordChanged=true，强制其他设备重新登录
  try {
    const accountsRaw = await AsyncStorage.getItem('@ing_accounts');
    if (accountsRaw) {
      const accounts: SavedAccount[] = JSON.parse(accountsRaw);
      let changed = false;
      for (const acc of accounts) {
        if (acc.phone === req.phone && !acc.passwordChanged) {
          acc.passwordChanged = true;
          changed = true;
        }
      }
      if (changed) {
        await AsyncStorage.setItem('@ing_accounts', JSON.stringify(accounts));
      }
    }
  } catch { /* 静默 */ }

  console.log(`[改密] 手机号 ${req.phone} 密码已重置，已标记所有已保存会话需重新登录`);
  return { code: 200, message: '密码修改成功，请重新登录' };
}

export async function applyAdminReset(req: AdminResetRequest): Promise<ApiResponse> {
  if (USE_REAL_API) {
    try {
      return await api.post('/auth/apply-admin-reset', {
        phone: req.phone,
        reason: req.reason,
      });
    } catch { /* 降级 */ }
  }
  await delay(800);
  console.log(`[管理员改密申请] 手机号: ${req.phone}, 原因: ${req.reason}`);
  return { code: 200, message: '申请已提交，管理员将在24小时内处理' };
}

// ====== 版本检测（带 60 秒内存缓存去重） ======

let _cachedVersion: ApiResponse<AppVersion> | null = null;
let _cachedVersionAt = 0;

export async function checkAppVersion(): Promise<ApiResponse<AppVersion>> {
  // 60 秒内直接返回缓存，避免重复请求
  if (_cachedVersion && Date.now() - _cachedVersionAt < 60_000) {
    return _cachedVersion;
  }
  // 优先走真实 API
  if (USE_REAL_API) {
    try {
      const resp = await api.get<AppVersion>('/version');
      if (resp.code === 200 && resp.data) {
        _cachedVersion = resp as ApiResponse<AppVersion>;
        _cachedVersionAt = Date.now();
        return _cachedVersion;
      }
    } catch { /* 降级到本地缓存 */ }
  }
  // 本地降级：返回最近一次缓存的版本信息（标记为离线，调用方可据此跳过弹窗）
  await delay(200);
  return {
    code: 200, message: '离线模式',
    data: {
      version: '1.0.1', buildNumber: 2,
      releaseNotes: '1. 新增隐私政策弹窗\n2. 优化登录体验\n3. 修复已知问题',
      forceUpdate: false, releasedAt: new Date().toISOString(),
    },
  };
}

// ====== 管理员日志 ======

export async function fetchAdminAuditLogs(_adminId: string): Promise<ApiResponse<AdminAuditLog>> {
  if (USE_REAL_API) {
    try {
      const resp = await api.get<AdminAuditLog>('/admin/audit-logs');
      if (resp.code === 200 && resp.data) return resp as ApiResponse<AdminAuditLog>;
    } catch { /* 降级 */ }
  }
  await delay(500);
  const rawLogs = await getAuthLogs();
  const logs = rawLogs as AuthLog[];
  const logins = logs.filter((l) => l.action === 'login' || l.action === 'logout');
  const passwordChanges = logs.filter((l) => l.action === 'password_change');
  const realnameSubmissions = logs.filter((l) => l.action === 'realname_submit');
  const totalUsers = (await getRegisteredUsers()).length;
  return {
    code: 200, message: 'ok',
    data: { logins, passwordChanges, realnameSubmissions, totalUsers },
  };
}
