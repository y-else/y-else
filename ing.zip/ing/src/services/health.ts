/**
 * 健康服务层
 * 作息打卡、心情记录、身体备注、分享、好友动态、管理员台账
 *
 * 修复:
 * - 移除 mock 内存变量，统一 AsyncStorage
 * - getFriendsHealthUpdates 检查 visibleTo 权限
 * - 新增 updateHealthRecord 编辑功能
 * - 好友动态只展示分享给当前用户且有权限的记录
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import type { HealthRecord, HealthRecordType, MoodType } from '../types';

const STORAGE_KEY = '@ing_health_records';

// ====== 内部辅助 ======

async function readAll(): Promise<HealthRecord[]> {
  const raw = await AsyncStorage.getItem(STORAGE_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function writeAll(items: HealthRecord[]): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}

// ====== 个人健康记录 ======

export async function getMyHealthRecords(userId: string): Promise<HealthRecord[]> {
  const all = await readAll();
  return all
    .filter((r) => r.userId === userId)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export async function createHealthRecord(
  record: Omit<HealthRecord, 'id' | 'createdAt'>,
): Promise<HealthRecord> {
  const all = await readAll();
  const newRecord: HealthRecord = {
    ...record,
    id: 'hl_' + Date.now(),
    createdAt: new Date().toISOString(),
  };
  all.push(newRecord);
  await writeAll(all);
  return newRecord;
}

export async function updateHealthRecord(
  id: string,
  updates: Partial<Pick<HealthRecord, 'mood' | 'bodyNote' | 'checkinTime' | 'isShared'>>,
): Promise<HealthRecord | null> {
  const all = await readAll();
  const idx = all.findIndex((r) => r.id === id);
  if (idx < 0) return null;
  all[idx] = { ...all[idx], ...updates };
  await writeAll(all);
  return all[idx];
}

export async function deleteHealthRecord(id: string): Promise<boolean> {
  const all = await readAll();
  const filtered = all.filter((r) => r.id !== id);
  await writeAll(filtered);
  return true;
}

// ====== 分享 ======

export async function shareHealthStatus(
  recordId: string,
  targetUserId: string,
): Promise<boolean> {
  const all = await readAll();
  const r = all.find((r) => r.id === recordId);
  if (r && !r.visibleTo.includes(targetUserId)) {
    r.visibleTo.push(targetUserId);
    r.isShared = true;
    await writeAll(all);
  }
  return true;
}

/** 取消分享给特定用户 */
export async function unshareHealthStatus(
  recordId: string,
  targetUserId: string,
): Promise<boolean> {
  const all = await readAll();
  const r = all.find((r) => r.id === recordId);
  if (r) {
    r.visibleTo = r.visibleTo.filter((uid) => uid !== targetUserId);
    if (r.visibleTo.length === 0) r.isShared = false;
    await writeAll(all);
  }
  return true;
}

// ====== 好友健康动态 ======

/**
 * 获取好友的健康动态
 * 只返回：isShared=true 且 (visibleTo 包含 userId 或 visibleTo 为空表示公开)
 */
export async function getFriendsHealthUpdates(
  userId: string,
  limit = 20,
): Promise<HealthRecord[]> {
  const all = await readAll();
  return all
    .filter((r) => {
      if (!r.isShared) return false;
      if (r.userId === userId) return false;
      // visibleTo 为空 = 公开分享给所有好友
      if (r.visibleTo.length === 0) return true;
      // 或者当前用户在被分享名单中
      return r.visibleTo.includes(userId);
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, limit);
}

// ====== 管理员 ======

export async function getAllHealthRecords(): Promise<HealthRecord[]> {
  const all = await readAll();
  return all.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );
}

/** 管理员按类型筛选 */
export async function getHealthRecordsByType(
  type: HealthRecordType,
): Promise<HealthRecord[]> {
  const all = await readAll();
  return all
    .filter((r) => r.type === type)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}
