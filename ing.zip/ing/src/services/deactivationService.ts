/**
 * 账号注销服务 v2（完整清理版）
 *
 * 流程：用户申请注销 → 生成6位验证码 → 用户输入校验 → 全量清理 → 软删除标记
 * 软删除后保留30天，到期自动物理清理；30天内可联系管理员恢复。
 *
 * 清理范围（全部用户关联数据）：
 *   用户注册表 / 已保存账号 / 公开资料 / 空间动态 / 相册
 *   留言墙 / 点赞记录 / 访客记录 / 在线状态 / 位置历史
 *   绑定关系 / 通讯录 / 功能权限 / SOS记录 / 打卡记录
 *   兑换记录 / 反馈 / 公告已读 / 会话 / 管理员绑定
 *   全局数据中心(GlobalStore) 11个域
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { SecureStorage } from '../utils/secureStorage';
import { appendAudit } from './admin';
import { GlobalStore } from './globalDataStore';

const DEACTIVATION_KEY = '@ing_deactivation_codes';
const SECURE_CODE_PREFIX = '@ing_deact_code_';
const PURGE_SCHEDULE_KEY = '@ing_deactivation_purge_schedule';

export interface DeactivationCode {
  id: string;
  userId: string;
  username: string;
  phone: string;
  code: string;
  status: 'pending' | 'used' | 'cancelled';
  createdAt: string;
  usedAt: string | null;
}

/** 30天待清理记录 */
export interface PurgeScheduleEntry {
  userId: string;
  username: string;
  phone: string;
  deactivatedAt: string;
  scheduledPurgeAt: string; // 30天后
}

// ====== 安全随机6位验证码 ======

function generateCode(): string {
  const bytes = new Uint8Array(6);
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < 6; i++) bytes[i] = Math.floor(Math.random() * 256);
  }
  let code = '';
  for (let i = 0; i < 6; i++) code += (bytes[i] % 10).toString();
  return code;
}

async function getAllCodes(): Promise<DeactivationCode[]> {
  const raw = await AsyncStorage.getItem(DEACTIVATION_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function saveAllCodes(codes: DeactivationCode[]): Promise<void> {
  await AsyncStorage.setItem(DEACTIVATION_KEY, JSON.stringify(codes));
}

// ====== 安全存储验证码 ======

async function storeCodeSecurely(userId: string, code: string): Promise<void> {
  try { await SecureStorage.setItem(SECURE_CODE_PREFIX + userId, code); } catch {}
}

async function getStoredCode(userId: string): Promise<string | null> {
  try { return await SecureStorage.getItem(SECURE_CODE_PREFIX + userId); } catch { return null; }
}

async function removeStoredCode(userId: string): Promise<void> {
  try { await SecureStorage.removeItem(SECURE_CODE_PREFIX + userId); } catch {}
}

// ====== 全量数据清理（核心函数） ======

/** 所有需要清理的用户数据存储键 */
const ALL_USER_DATA_KEYS = [
  // 用户基础数据
  '@ing_registered_users',
  '@ing_accounts',
  '@ing_current_user_id',
  '@ing_public_profiles',
  '@ing_register_applications',
  '@ing_realname_records',
  // 空间与社交
  '@ing_space_posts',
  '@ing_album',
  '@ing_wall_messages',
  '@ing_profile_likes',
  '@ing_space_visits',
  '@ing_online_status',
  // 通讯录与绑定
  '@ing_contacts',
  '@ing_bind_requests',
  '@ing_admin_bindings',
  '@ing_user_addresses',
  // 功能数据
  '@ing_sos_records',
  '@ing_location_history',
  '@ing_checkin_records',
  '@ing_diaries',
  '@ing_schedules',
  '@ing_health_records',
  '@ing_travel_records',
  // 管理
  '@ing_admin_function_permissions',
  '@ing_announcement_read',
  '@ing_user_likes',
  '@ing_verification_codes',
  '@ing_deactivation_codes',
  // 全局数据中心 (11个域)
  '@ing_gds_users',
  '@ing_gds_sos',
  '@ing_gds_phone_usage',
  '@ing_gds_feedbacks',
  '@ing_gds_redemption_records',
  '@ing_gds_bindings',
  '@ing_gds_space_posts',
  '@ing_gds_album_items',
  '@ing_gds_location_history',
  '@ing_gds_app_usage',
  '@ing_gds_registration_logs',
  '@ing_gds_contact_messages',
  // 注销相关
  '@ing_deactivation_codes',
  '@ing_deactivation_purge_schedule',
];

/** 清理单个存储键中属于指定用户的数据 */
async function cleanKeyForUser(key: string, userId: string): Promise<void> {
  try {
    const raw = await AsyncStorage.getItem(key);
    if (!raw) return;
    const data = JSON.parse(raw);

    if (Array.isArray(data)) {
      // 数组型：过滤掉该用户的数据
      const filtered = data.filter((item: any) => {
        if (!item) return true;
        return item.userId !== userId &&
               item.senderId !== userId &&
               item.ownerId !== userId &&
               item.fromUserId !== userId &&
               item.toUserId !== userId &&
               item.visitorId !== userId &&
               item.authorId !== userId &&
               item.partnerId !== userId &&
               item.targetUserId !== userId;
      });
      if (filtered.length < data.length) {
        await AsyncStorage.setItem(key, JSON.stringify(filtered));
      }
    } else if (typeof data === 'object' && data !== null) {
      // Map型：删除该用户条目
      if (data[userId] !== undefined) {
        delete data[userId];
        await AsyncStorage.setItem(key, JSON.stringify(data));
      }
    }
  } catch { /* 静默 */ }
}

/** 执行全量用户数据清理 */
export async function purgeAllUserData(userId: string): Promise<{ cleaned: number }> {
  let cleaned = 0;
  for (const key of ALL_USER_DATA_KEYS) {
    try {
      await cleanKeyForUser(key, userId);
      cleaned++;
    } catch { /* 跳过失败的键 */ }
  }
  // 清理加密存储的验证码
  await removeStoredCode(userId);
  return { cleaned };
}

// ====== 软删除调度 ======

async function getPurgeSchedule(): Promise<PurgeScheduleEntry[]> {
  const raw = await AsyncStorage.getItem(PURGE_SCHEDULE_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function savePurgeSchedule(schedule: PurgeScheduleEntry[]): Promise<void> {
  await AsyncStorage.setItem(PURGE_SCHEDULE_KEY, JSON.stringify(schedule));
}

/** 将用户添加到30天自动清理计划 */
export async function scheduleAutoPurge(userId: string, username: string, phone: string): Promise<void> {
  const schedule = await getPurgeSchedule();
  const now = new Date();
  const purgeDate = new Date(now.getTime() + 30 * 24 * 3600_000);
  schedule.push({
    userId, username, phone,
    deactivatedAt: now.toISOString(),
    scheduledPurgeAt: purgeDate.toISOString(),
  });
  await savePurgeSchedule(schedule);
}

// ====== 公开API ======

/** 用户提交注销申请 */
export async function requestDeactivation(
  userId: string, username: string, phone: string,
): Promise<{ success: boolean; message: string; code?: string }> {
  const all = await getAllCodes();
  const existing = all.find((c) => c.userId === userId && c.status === 'pending');
  if (existing) {
    return {
      success: true,
      message: '注销申请已提交，验证码为：' + existing.code + '，请输入验证码确认注销',
      code: existing.code,
    };
  }
  const code = generateCode();
  const entry: DeactivationCode = {
    id: 'dc_' + Date.now(), userId, username, phone, code,
    status: 'pending', createdAt: new Date().toISOString(), usedAt: null,
  };
  all.push(entry);
  await saveAllCodes(all);
  await storeCodeSecurely(userId, code);
  return {
    success: true,
    message: '注销申请已提交，验证码：' + code + '，请输入验证码确认注销',
    code,
  };
}

/** 校验验证码并执行软删除 + 全量清理 */
export async function confirmDeactivation(
  userId: string, inputCode: string,
): Promise<{ success: boolean; message: string }> {
  const all = await getAllCodes();
  const entry = all.find((c) => c.userId === userId && c.status === 'pending');
  if (!entry) {
    return { success: false, message: '未找到注销申请，请先申请注销验证码' };
  }

  const storedCode = await getStoredCode(userId);
  const validCode = storedCode || entry.code;
  if (validCode !== inputCode.trim()) {
    return { success: false, message: '验证码错误，注销失败' };
  }

  // 标记验证码已使用
  entry.status = 'used';
  entry.usedAt = new Date().toISOString();
  await saveAllCodes(all);
  await removeStoredCode(userId);

  // 软删除：标记用户状态为 deleted（保留30天可恢复）
  try {
    const raw = await AsyncStorage.getItem('@ing_registered_users');
    if (raw) {
      const users = JSON.parse(raw);
      const idx = users.findIndex((u: any) => u.userId === userId);
      if (idx >= 0) {
        users[idx].status = 'deleted';
        users[idx].updatedAt = new Date().toISOString();
        users[idx].deactivatedAt = new Date().toISOString();
        await AsyncStorage.setItem('@ing_registered_users', JSON.stringify(users));
      }
    }
  } catch {}

  // 同步更新 GlobalStore 用户状态
  try {
    await GlobalStore.users.update(userId, { status: 'deleted' } as any);
  } catch {}

  // 执行全量数据清理
  await purgeAllUserData(userId);

  // 加入30天自动物理清理计划
  await scheduleAutoPurge(userId, entry.username, entry.phone);

  // 审计日志
  try {
    await appendAudit({
      adminId: 'system', adminName: '系统',
      action: 'delete_user' as any,
      targetUserId: userId, targetUsername: entry.username,
      detail: `${entry.username}(${entry.phone}) 账号已注销，数据已清理，30天后永久删除`,
    });
  } catch {}

  return { success: true, message: '账号已注销，所有数据已清理。30天内可联系管理员恢复。' };
}

// ====== 管理员端 ======

export async function getDeactivationRequests(): Promise<DeactivationCode[]> {
  return (await getAllCodes()).sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );
}

export async function cancelDeactivation(requestId: string): Promise<boolean> {
  const all = await getAllCodes();
  const entry = all.find((c) => c.id === requestId);
  if (entry) {
    entry.status = 'cancelled';
    await saveAllCodes(all);
    await removeStoredCode(entry.userId);
    return true;
  }
  return false;
}

/** 管理员手动一键清理所有已注销用户的数据 */
export async function adminPurgeAllDeactivatedUsers(): Promise<{ purged: number; errors: string[] }> {
  const schedule = await getPurgeSchedule();
  const now = new Date();
  const errors: string[] = [];
  let purged = 0;

  // 清理已到期的用户
  const dueForPurge = schedule.filter((s) => new Date(s.scheduledPurgeAt) <= now);
  const remaining = schedule.filter((s) => new Date(s.scheduledPurgeAt) > now);

  for (const entry of dueForPurge) {
    try {
      await purgeAllUserData(entry.userId);
      purged++;
    } catch {
      errors.push(entry.userId);
    }
  }

  await savePurgeSchedule(remaining);
  return { purged, errors };
}

/** 管理员立即物理删除指定用户（绕过30天等待） */
export async function adminForcePurgeUser(userId: string): Promise<boolean> {
  try {
    await purgeAllUserData(userId);
    // 从清理计划中移除
    const schedule = await getPurgeSchedule();
    await savePurgeSchedule(schedule.filter((s) => s.userId !== userId));
    await appendAudit({
      adminId: 'system', adminName: '管理员',
      action: 'delete_user' as any,
      targetUserId: userId, targetUsername: '已注销用户',
      detail: `管理员强制物理删除用户 ${userId} 的所有数据`,
    });
    return true;
  } catch {
    return false;
  }
}

/** 获取待清理用户列表（管理员面板用） */
export async function getPurgeScheduleList(): Promise<PurgeScheduleEntry[]> {
  return getPurgeSchedule();
}

/** 获取注销相关存储统计（管理员面板用） */
export async function getDeactivationStorageStats(): Promise<{
  pendingUsers: number;
  scheduledPurge: number;
  totalDeactivatedCodes: number;
}> {
  const all = await getAllCodes();
  const schedule = await getPurgeSchedule();
  return {
    pendingUsers: all.filter((c) => c.status === 'pending').length,
    scheduledPurge: schedule.length,
    totalDeactivatedCodes: all.filter((c) => c.status === 'used').length,
  };
}
