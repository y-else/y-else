/**
 * 消息服务层
 * 聚合私聊/快捷消息/系统公告/SOS消息，未读管理
 *
 * 修复:
 * - 移除 mock 内存变量，统一 AsyncStorage 持久化
 * - UnreadCount 补充 quick 类型计数
 * - getMessages 过滤 toUserId
 * - markAllRead 按 userId 隔离
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Message, MessageType, UnreadCount, PrivateChatMessage } from '../types';

const STORAGE_KEY = '@ing_messages';
const CHAT_KEY = '@ing_private_chats';

// ====== 内部辅助 ======

async function readAll(): Promise<Message[]> {
  const raw = await AsyncStorage.getItem(STORAGE_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function writeAll(items: Message[]): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}

async function readChats(): Promise<PrivateChatMessage[]> {
  const raw = await AsyncStorage.getItem(CHAT_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function writeChats(items: PrivateChatMessage[]): Promise<void> {
  await AsyncStorage.setItem(CHAT_KEY, JSON.stringify(items));
}

// ====== 聚合消息 ======

export async function getMessages(
  userId: string,
  type?: MessageType,
): Promise<Message[]> {
  const all = await readAll();
  // 只返回发送给当前用户的消息
  const userMessages = all.filter((m) => m.toUserId === userId);
  const filtered = type ? userMessages.filter((m) => m.type === type) : userMessages;
  return filtered.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );
}

export async function getUnreadCount(userId: string): Promise<UnreadCount> {
  const all = await readAll();
  const unread = all.filter((m) => m.toUserId === userId && !m.isRead);
  return {
    total: unread.length,
    private: unread.filter((m) => m.type === 'private').length,
    quick: unread.filter((m) => m.type === 'quick').length,
    announcement: unread.filter((m) => m.type === 'announcement').length,
    sos: unread.filter((m) => m.type === 'sos').length,
  };
}

export async function markAsRead(messageId: string): Promise<boolean> {
  const all = await readAll();
  const msg = all.find((m) => m.id === messageId);
  if (msg) {
    msg.isRead = true;
    await writeAll(all);
  }
  return true;
}

export async function markAllRead(userId: string): Promise<boolean> {
  const all = await readAll();
  let changed = false;
  for (const m of all) {
    if (m.toUserId === userId && !m.isRead) {
      m.isRead = true;
      changed = true;
    }
  }
  if (changed) {
    await writeAll(all);
  }
  return true;
}

/** 一键清空当前用户所有已读消息 */
export async function clearReadMessages(userId: string): Promise<number> {
  const all = await readAll();
  const keep = all.filter((m) => !(m.toUserId === userId && m.isRead));
  const removed = all.length - keep.length;
  await writeAll(keep);
  return removed;
}

export async function clearMessages(userId: string): Promise<boolean> {
  const all = await readAll();
  const filtered = all.filter((m) => m.toUserId !== userId);
  await writeAll(filtered);
  return true;
}

// ====== 发送消息（供其他模块调用） ======

export async function sendMessage(
  type: MessageType,
  fromUserId: string,
  fromUsername: string,
  fromAvatar: string | null,
  toUserId: string,
  content: string,
  relatedId?: string,
): Promise<Message> {
  const msg: Message = {
    id: 'msg_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
    type,
    fromUserId,
    fromUsername,
    fromAvatar,
    toUserId,
    content,
    isRead: false,
    createdAt: new Date().toISOString(),
    relatedId,
  };
  const all = await readAll();
  all.push(msg);
  // 每个用户最多保留 200 条消息
  const userMsgs = all.filter((m) => m.toUserId === toUserId);
  if (userMsgs.length > 200) {
    const oldest = userMsgs.sort(
      (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime(),
    )[0];
    const idx = all.findIndex((m) => m.id === oldest.id);
    if (idx >= 0) all.splice(idx, 1);
  }
  await writeAll(all);
  return msg;
}

export { sendMessage as sendPrivateMessage };

// ====== 私聊 ======

export async function getPrivateChat(
  userId: string,
  partnerId: string,
): Promise<PrivateChatMessage[]> {
  const all = await readChats();
  return all
    .filter(
      (m) =>
        (m.fromUserId === userId && m.toUserId === partnerId) ||
        (m.fromUserId === partnerId && m.toUserId === userId),
    )
    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
}

export async function sendChatMessage(
  fromUserId: string,
  fromUsername: string,
  fromAvatar: string | null,
  toUserId: string,
  content: string,
): Promise<PrivateChatMessage> {
  const chat: PrivateChatMessage = {
    id: 'chat_' + Date.now(),
    fromUserId,
    fromUsername,
    fromAvatar,
    toUserId,
    content,
    createdAt: new Date().toISOString(),
  };
  const all = await readChats();
  all.push(chat);
  await writeChats(all);
  return chat;
}
