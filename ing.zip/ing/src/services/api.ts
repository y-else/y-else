/**
 * API 接口合并缓存服务
 * 请求去重、响应缓存、批量合并
 */

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttl: number;
}

interface PendingRequest {
  resolve: (value: any) => void;
  reject: (error: any) => void;
  timestamp: number;
}

const DEFAULT_TTL = 30000; // 30秒缓存
const DEDUP_WINDOW = 2000;  // 2秒内相同请求合并

class ApiCache {
  private cache = new Map<string, CacheEntry<any>>();
  private pending = new Map<string, PendingRequest[]>();

  /** 生成缓存 key */
  key(method: string, url: string, params?: Record<string, any>): string {
    return `${method}:${url}:${params ? JSON.stringify(params) : ''}`;
  }

  /** 读取缓存 */
  get<T>(key: string, ttl = DEFAULT_TTL): T | null {
    const entry = this.cache.get(key);
    if (!entry) return null;
    if (Date.now() - entry.timestamp > (entry.ttl || ttl)) {
      this.cache.delete(key);
      return null;
    }
    return entry.data as T;
  }

  /** 写入缓存 */
  set<T>(key: string, data: T, ttl = DEFAULT_TTL): void {
    this.cache.set(key, { data, timestamp: Date.now(), ttl });
    // 清理过期缓存（保留最近 100 条）
    if (this.cache.size > 100) {
      const oldest = [...this.cache.entries()]
        .sort((a, b) => a[1].timestamp - b[1].timestamp)
        .slice(0, 30);
      oldest.forEach(([k]) => this.cache.delete(k));
    }
  }

  /** 清除缓存 */
  clear(pattern?: string): void {
    if (!pattern) {
      this.cache.clear();
      return;
    }
    for (const key of this.cache.keys()) {
      if (key.includes(pattern)) this.cache.delete(key);
    }
  }

  /** 请求去重 —— 2秒内相同请求只发一次 */
  dedupKey(method: string, url: string, params?: Record<string, any>): string {
    return `dedup:${method}:${url}:${params ? JSON.stringify(params) : ''}`;
  }

  isPending(dedupKey: string): boolean {
    return this.pending.has(dedupKey);
  }

  addPending(dedupKey: string, handlers: { resolve: (v: any) => void; reject: (e: any) => void }): void {
    if (!this.pending.has(dedupKey)) {
      this.pending.set(dedupKey, []);
    }
    this.pending.get(dedupKey)!.push({ ...handlers, timestamp: Date.now() });
  }

  resolvePending(dedupKey: string, data: any): void {
    const handlers = this.pending.get(dedupKey);
    if (handlers) {
      handlers.forEach((h) => h.resolve(data));
      this.pending.delete(dedupKey);
    }
  }

  rejectPending(dedupKey: string, error: any): void {
    const handlers = this.pending.get(dedupKey);
    if (handlers) {
      handlers.forEach((h) => h.reject(error));
      this.pending.delete(dedupKey);
    }
  }

  /** 清理超时的等待请求 */
  cleanStalePending(): void {
    const now = Date.now();
    for (const [key, handlers] of this.pending.entries()) {
      const filtered = handlers.filter((h) => now - h.timestamp < 30000);
      if (filtered.length === 0) {
        this.pending.delete(key);
      } else if (filtered.length !== handlers.length) {
        this.pending.set(key, filtered);
      }
    }
  }
}

export const apiCache = new ApiCache();

// 懒启动定期清理（避免模块加载时就创建计时器）
let _cleanupStarted = false;
export function ensureCacheCleanup(): void {
  if (_cleanupStarted) return;
  _cleanupStarted = true;
  setInterval(() => apiCache.cleanStalePending(), 60000);
}

/**
 * 缓存装饰器 —— 自动缓存 API 响应
 */
export function withCache<T>(
  cacheKey: string,
  ttl?: number,
): (fn: () => Promise<T>) => Promise<T> {
  return async (fn: () => Promise<T>): Promise<T> => {
    const cached = apiCache.get<T>(cacheKey, ttl);
    if (cached) return cached;

    const dedupKey = `dedup:${cacheKey}`;
    if (apiCache.isPending(dedupKey)) {
      return new Promise<T>((resolve, reject) => {
        apiCache.addPending(dedupKey, { resolve, reject });
      });
    }

    apiCache.addPending(dedupKey, { resolve: () => {}, reject: () => {} });
    try {
      const data = await fn();
      apiCache.set(cacheKey, data, ttl);
      apiCache.resolvePending(dedupKey, data);
      return data;
    } catch (error) {
      apiCache.rejectPending(dedupKey, error);
      throw error;
    }
  };
}
