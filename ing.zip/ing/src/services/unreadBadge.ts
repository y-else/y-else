/**
 * 全局未读消息小红点服务
 * 用户端：SOS回复+管理员通知+反馈回复+互动消息
 * 管理员端：未处理SOS+用户反馈+注册申请+联系消息
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

const BADGE_KEY = '@ing_unread_badges';

interface BadgeState {
  // 用户端
  userSOSReply: number;
  userAdminNotify: number;
  userFeedbackReply: number;
  userInteraction: number;
  // 管理员端
  adminPendingSOS: number;
  adminPendingFeedback: number;
  adminPendingRegister: number;
  adminPendingContact: number;
  adminPendingRealName: number;
}

const defaultBadges: BadgeState = {
  userSOSReply: 0, userAdminNotify: 0, userFeedbackReply: 0, userInteraction: 0,
  adminPendingSOS: 0, adminPendingFeedback: 0, adminPendingRegister: 0, adminPendingContact: 0, adminPendingRealName: 0,
};

export async function getBadges(): Promise<BadgeState> {
  const raw = await AsyncStorage.getItem(BADGE_KEY);
  return raw ? { ...defaultBadges, ...JSON.parse(raw) } : defaultBadges;
}

async function saveBadges(b: BadgeState): Promise<void> {
  await AsyncStorage.setItem(BADGE_KEY, JSON.stringify(b));
}

/** 用户总未读数 */
export async function getUserTotalUnread(): Promise<number> {
  const b = await getBadges();
  return b.userSOSReply + b.userAdminNotify + b.userFeedbackReply + b.userInteraction;
}

/** 管理员总未读数 */
export async function getAdminTotalUnread(): Promise<number> {
  const b = await getBadges();
  return b.adminPendingSOS + b.adminPendingFeedback + b.adminPendingRegister + b.adminPendingContact;
}

/** 增加未读数 */
export async function addUnread(key: keyof BadgeState, count = 1): Promise<void> {
  const b = await getBadges();
  b[key] += count;
  await saveBadges(b);
}

/** 清零指定类型 */
export async function clearUnread(key: keyof BadgeState): Promise<void> {
  const b = await getBadges();
  b[key] = 0;
  await saveBadges(b);
}

/** 清空所有 */
export async function clearAllUnread(): Promise<void> {
  await saveBadges(defaultBadges);
}
