/**
 * 数据同步桥
 *
 * 负责将各独立服务的数据自动同步到 GlobalDataStore 全局数据池。
 * APP启动时执行全量同步，确保管理员端始终有最新数据。
 *
 * 同步方向：各服务本地存储 → GlobalDataStore
 * 管理员读取：GlobalDataStore → admin.ts
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { GlobalStore, type StoreUser, type StoreFeedback } from './globalDataStore';

/** 启动全量数据同步（App.tsx调用） */
export async function syncAllDataToGlobalStore(): Promise<void> {
  try {
    await Promise.allSettled([
      syncUsers(),
      syncSOSRecords(),
      syncFeedbacks(),
      syncRedemptionRecords(),
      syncBindings(),
      syncSpacePosts(),
      syncRegistrationLogs(),
    ]);
    console.log('[DataSyncBridge] 全量同步完成');
  } catch (err) {
    console.warn('[DataSyncBridge] 同步异常:', err);
  }
}

/** 同步用户数据 */
async function syncUsers(): Promise<void> {
  const raw = await AsyncStorage.getItem('@ing_registered_users');
  if (!raw) return;
  const users: any[] = JSON.parse(raw);
  if (users.length === 0) return;

  const storeUsers: StoreUser[] = users
    .filter((u: any) => u.role !== 'admin')
    .map((u: any) => ({
      userId: u.userId,
      username: u.username,
      phone: u.phone,
      role: u.role,
      status: u.status,
      realNameStatus: 'unverified',
      isOnline: false,
      lastActive: u.updatedAt || u.createdAt,
      createdAt: u.createdAt,
    }));

  if (storeUsers.length > 0) {
    await GlobalStore.users.setAll(storeUsers);
  }
}

/** 同步SOS记录 */
async function syncSOSRecords(): Promise<void> {
  const raw = await AsyncStorage.getItem('@ing_sos_records');
  if (!raw) return;
  const records = JSON.parse(raw);
  if (records.length > 0) {
    await GlobalStore.sos.setAll(records);
  }
}

/** 同步反馈/联系管理员 */
async function syncFeedbacks(): Promise<void> {
  const raw = await AsyncStorage.getItem('@ing_feedbacks');
  if (!raw) return;
  const feedbacks: any[] = JSON.parse(raw);
  if (feedbacks.length > 0) {
    await GlobalStore.feedbacks.setAll(feedbacks);
    // 同时提取"联系管理员"类型的消息
    const contactMsgs = feedbacks.filter((f: any) =>
      f.content?.startsWith('[联系管理员]'),
    );
    if (contactMsgs.length > 0) {
      await GlobalStore.contactMessages.setAll(contactMsgs);
    }
  }
}

/** 同步兑换记录 */
async function syncRedemptionRecords(): Promise<void> {
  const raw = await AsyncStorage.getItem('@ing_redemption_records');
  if (!raw) return;
  const records = JSON.parse(raw);
  if (records.length > 0) {
    await GlobalStore.redemptionRecords.setAll(records);
  }
}

/** 同步绑定关系 */
async function syncBindings(): Promise<void> {
  const raw = await AsyncStorage.getItem('@ing_admin_bindings');
  if (!raw) return;
  const bindings = JSON.parse(raw);
  if (bindings.length > 0) {
    await GlobalStore.redemptionRecords.setAll(bindings);
  }
}

/** 同步空间动态 */
async function syncSpacePosts(): Promise<void> {
  const raw = await AsyncStorage.getItem('@ing_space_posts');
  if (!raw) return;
  const posts = JSON.parse(raw);
  if (posts.length > 0) {
    await GlobalStore.spacePosts.setAll(posts);
  }
}

/** 同步注册审核日志 */
async function syncRegistrationLogs(): Promise<void> {
  const raw = await AsyncStorage.getItem('@ing_register_applications');
  if (!raw) return;
  const apps: any[] = JSON.parse(raw);
  const logs: any[] = apps.map((a: any) => ({
    userId: a.userId,
    username: a.username,
    phone: a.phone,
    action: a.status === 'approved' ? 'approved' : a.status === 'rejected' ? 'rejected' : 'registered',
    reviewedBy: a.reviewedBy || undefined,
    timestamp: a.reviewedAt || a.appliedAt,
  }));
  if (logs.length > 0) {
    await GlobalStore.registrationLogs.setAll(logs);
  }
}

// ====== 实时写入辅助（供各服务调用，实现写入即同步） ======

/** 用户注册/状态变更 → 即时同步 */
export async function syncUserChange(user: StoreUser): Promise<void> {
  const all = await GlobalStore.users.getAll();
  const idx = all.findIndex((u) => u.userId === user.userId);
  if (idx >= 0) all[idx] = user;
  else all.unshift(user);
  await GlobalStore.users.setAll(all);
}

/** 反馈提交 → 即时同步 */
export async function syncFeedback(fb: StoreFeedback): Promise<void> {
  await GlobalStore.feedbacks.add(fb);
  if (fb.content?.startsWith('[联系管理员]')) {
    await GlobalStore.contactMessages.add(fb);
  }
}

/** SOS触发 → 即时同步 */
export async function syncSOS(record: any): Promise<void> {
  await GlobalStore.sos.add(record);
}
