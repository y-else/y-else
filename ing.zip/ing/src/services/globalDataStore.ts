/**
 * 全局数据中心 v2（GlobalDataStore）
 *
 * 解决用户端与管理员端数据完全割裂的核心问题。
 * 所有数据写入 → 自动存入全局池 → 管理员端实时可读取。
 * 基于 AsyncStorage 持久化存储，重启不丢失。
 *
 * v2 新增:
 *   - 补全 3 个缺失数据域（位置历史/相册/应用使用）
 *   - 跨模块订阅通知机制
 *   - 服务端数据批量同步加载
 *   - 数据容量上限自动裁剪
 *
 * 使用方式：
 *   import { GlobalStore } from '../services/globalDataStore';
 *   await GlobalStore.users.add(userData);
 *   const all = await GlobalStore.users.getAll();
 *
 *   // 订阅变更通知
 *   const unsub = GlobalStore.subscribe('users', () => { /* 刷新UI *\/ });
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

// ====== 全局存储键定义 ======

const KEYS = {
  USERS: '@ing_gds_users',
  SOS: '@ing_gds_sos',
  PHONE_USAGE: '@ing_gds_phone_usage',
  FEEDBACKS: '@ing_gds_feedbacks',
  REDEMPTION_RECORDS: '@ing_gds_redemption_records',
  BINDINGS: '@ing_gds_bindings',
  SPACE_POSTS: '@ing_gds_space_posts',
  ALBUM_ITEMS: '@ing_gds_album_items',
  LOCATION_HISTORY: '@ing_gds_location_history',
  APP_USAGE: '@ing_gds_app_usage',
  REGISTRATION_LOGS: '@ing_gds_registration_logs',
  CONTACT_MESSAGES: '@ing_gds_contact_messages',
} as const;

type StoreKey = (typeof KEYS)[keyof typeof KEYS];

// ====== 增量同步时间戳 ======

const SYNC_TS_PREFIX = '@ing_sync_ts_';

async function getSyncTimestamp(domain: string): Promise<string | null> {
  try { return await AsyncStorage.getItem(SYNC_TS_PREFIX + domain); } catch { return null; }
}

async function setSyncTimestamp(domain: string): Promise<void> {
  try { await AsyncStorage.setItem(SYNC_TS_PREFIX + domain, new Date().toISOString()); } catch {}
}

// ====== 跨模块通知 ======

type DomainName = keyof typeof KEYS;
type StoreListener = () => void;
const storeListeners = new Map<DomainName | '*', Set<StoreListener>>();

function notify(domain: DomainName) {
  const all = storeListeners.get('*');
  if (all) all.forEach((cb) => { try { cb(); } catch {} });
  const dom = storeListeners.get(domain);
  if (dom) dom.forEach((cb) => { try { cb(); } catch {} });
}

// ====== 数据容量配置 ======

const MAX_ITEMS: Partial<Record<DomainName, number>> = {
  SOS: 500,
  PHONE_USAGE: 500,
  FEEDBACKS: 200,
  SPACE_POSTS: 500,
  LOCATION_HISTORY: 1000,
  APP_USAGE: 1000,
  REGISTRATION_LOGS: 500,
};

// ====== 通用 CRUD 工具 ======

async function readArray<T>(key: string): Promise<T[]> {
  try {
    const raw = await AsyncStorage.getItem(key);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

async function writeArray<T>(key: string, data: T[]): Promise<void> {
  await AsyncStorage.setItem(key, JSON.stringify(data));
}

function makeStore<T>(storageKey: StoreKey) {
  const domainName = (Object.entries(KEYS).find(([, v]) => v === storageKey)?.[0] || '') as DomainName;

  return {
    /** 获取全部数据 */
    getAll: (): Promise<T[]> => readArray<T>(storageKey),

    /** 获取指定用户的数据 */
    getByUser: async (userId: string): Promise<T[]> => {
      const all = await readArray<T>(storageKey);
      return all.filter((item: any) =>
        item.userId === userId || item.senderId === userId || item.ownerId === userId,
      );
    },

    /** 新增一条记录 */
    add: async (item: T): Promise<void> => {
      const all = await readArray<T>(storageKey);
      all.unshift(item);
      // 超出容量限制则裁剪
      const max = MAX_ITEMS[domainName];
      const trimmed = max && all.length > max ? all.slice(0, max) : all;
      await writeArray(storageKey, trimmed);
      notify(domainName);
    },

    /** 批量新增 */
    addMany: async (items: T[]): Promise<void> => {
      const all = await readArray<T>(storageKey);
      all.unshift(...items);
      const max = MAX_ITEMS[domainName];
      const trimmed = max && all.length > max ? all.slice(0, max) : all;
      await writeArray(storageKey, trimmed);
      notify(domainName);
    },

    /** 更新指定id的记录 */
    update: async (id: string, updates: Partial<T>): Promise<T | null> => {
      const all = await readArray<T>(storageKey);
      const idx = all.findIndex((item: any) => item.id === id);
      if (idx < 0) return null;
      all[idx] = { ...all[idx], ...updates };
      await writeArray(storageKey, all);
      notify(domainName);
      return all[idx];
    },

    /** 按条件删除 */
    remove: async (predicate: (item: T) => boolean): Promise<number> => {
      const all = await readArray<T>(storageKey);
      const before = all.length;
      const filtered = all.filter((item) => !predicate(item));
      await writeArray(storageKey, filtered);
      if (before !== filtered.length) notify(domainName);
      return before - filtered.length;
    },

    /** 统计总数 */
    count: async (): Promise<number> => {
      const all = await readArray<T>(storageKey);
      return all.length;
    },

    /** 原始数组直接替换 */
    setAll: async (data: T[]): Promise<void> => {
      const max = MAX_ITEMS[domainName];
      const trimmed = max && data.length > max ? data.slice(0, max) : data;
      await writeArray(storageKey, trimmed);
      notify(domainName);
    },
  };
}

// ====== 各数据域定义 ======

/** 用户基础信息 */
export interface StoreUser {
  userId: string;
  username: string;
  phone: string;
  role: string;
  status: 'active' | 'disabled' | 'deleted' | 'pending';
  realNameStatus: string;
  isOnline: boolean;
  lastActive: string;
  createdAt: string;
}

/** SOS求助记录 */
export interface StoreSOSRecord {
  id: string;
  senderId: string;
  senderName: string;
  senderPhone: string;
  location: { latitude: number; longitude: number };
  address: string | null;
  triggeredAt: string;
  status: 'active' | 'resolved';
  sosStatus: 'pending' | 'processing' | 'resolved' | 'false_alarm' | 'cancelled';
  isSilent?: boolean;
  resolvedAt?: string;
  resolvedBy?: string;
}

/** 手机使用数据 */
export interface StorePhoneUsage {
  userId: string;
  username: string;
  phone: string;
  screenTimePerDay: number;
  appUsageMinutes: number;
  chargeCount: number;
  appStartCount: number;
  appStopCount: number;
  lastChargeAt: string;
  batteryHealth: string;
  foregroundRecords: { appName: string; startTime: string; endTime: string; durationMinutes: number }[];
  backgroundRecords: { appName: string; startTime: string; endTime: string; durationMinutes: number }[];
  dataUpdatedAt: string;
}

/** 反馈/联系管理员 */
export interface StoreFeedback {
  id: string;
  userId: string;
  username: string;
  content: string;
  contact: string;
  createdAt: string;
  status: 'pending' | 'resolved';
}

/** 兑换记录 */
export interface StoreRedemptionRecord {
  id: string;
  codeId: string;
  code: string;
  userId: string;
  username: string;
  phone: string;
  rewardType: string;
  rewardName: string;
  shippingAddress?: any;
  redeemedAt: string;
  status: string;
}

/** 空间动态 */
export interface StoreSpacePost {
  id: string;
  authorId: string;
  ownerId: string;
  authorName: string;
  content: string;
  visibility: string;
  createdAt: string;
  likes: string[];
  comments: any[];
  media: any[];
}

/** 绑定关系 */
export interface StoreBinding {
  id: string;
  fromUserId: string;
  fromUsername: string;
  toUserId: string;
  toUsername: string;
  type: 'family' | 'friend' | 'lover';
  status: 'pending' | 'accepted' | 'rejected' | 'cancelled';
  createdAt: string;
  updatedAt: string;
}

/** 位置历史记录 */
export interface StoreLocationRecord {
  id: string;
  userId: string;
  latitude: number;
  longitude: number;
  address: string | null;
  accuracy: number | null;
  speed: number | null;
  recordedAt: string;
}

/** 相册条目 */
export interface StoreAlbumItem {
  id: string;
  userId: string;
  uri: string;
  type: 'image' | 'video';
  permission: 'public' | 'friends_only' | 'private';
  addedAt: string;
}

/** 应用使用记录 */
export interface StoreAppUsage {
  id: string;
  userId: string;
  appName: string;
  startTime: string;
  endTime: string;
  durationMinutes: number;
}

/** 注册/审核日志 */
export interface StoreRegistrationLog {
  userId: string;
  username: string;
  phone: string;
  action: 'registered' | 'approved' | 'rejected';
  reviewedBy?: string;
  timestamp: string;
}

// ====== 导出全局数据中心 ======

export const GlobalStore = {
  // ---- 11 个数据域 ----

  /** 用户基础数据 */
  users: makeStore<StoreUser>(KEYS.USERS),

  /** SOS求助记录 */
  sos: makeStore<StoreSOSRecord>(KEYS.SOS),

  /** 手机使用数据 */
  phoneUsage: makeStore<StorePhoneUsage>(KEYS.PHONE_USAGE),

  /** 反馈/联系管理员消息 */
  feedbacks: makeStore<StoreFeedback>(KEYS.FEEDBACKS),

  /** 兑换记录 */
  redemptionRecords: makeStore<StoreRedemptionRecord>(KEYS.REDEMPTION_RECORDS),

  /** 空间动态 */
  spacePosts: makeStore<StoreSpacePost>(KEYS.SPACE_POSTS),

  /** 绑定关系记录 */
  bindings: makeStore<StoreBinding>(KEYS.BINDINGS),

  /** 相册条目 */
  albumItems: makeStore<StoreAlbumItem>(KEYS.ALBUM_ITEMS),

  /** 位置历史 */
  locationHistory: makeStore<StoreLocationRecord>(KEYS.LOCATION_HISTORY),

  /** 应用使用记录 */
  appUsage: makeStore<StoreAppUsage>(KEYS.APP_USAGE),

  /** 注册审核日志 */
  registrationLogs: makeStore<StoreRegistrationLog>(KEYS.REGISTRATION_LOGS),

  /** 联系管理员消息（独立于反馈） */
  contactMessages: makeStore<StoreFeedback>(KEYS.CONTACT_MESSAGES),

  // ====== 跨模块通知 ======

  /**
   * 订阅数据域变更通知
   * @param domain 数据域名或 '*' 订阅全部
   * @param callback 变更回调
   * @returns 取消订阅函数
   */
  subscribe: (domain: DomainName | '*', callback: StoreListener): (() => void) => {
    if (!storeListeners.has(domain)) storeListeners.set(domain, new Set());
    storeListeners.get(domain)!.add(callback);
    return () => {
      const set = storeListeners.get(domain);
      if (set) { set.delete(callback); if (set.size === 0) storeListeners.delete(domain); }
    };
  },

  /** 移除所有监听器 */
  clearAllListeners: () => {
    storeListeners.clear();
  },

  // ====== 服务端同步 ======

  /**
   * 批量同步服务端数据到本地存储（启动时调用）
   * @param domain 数据域名
   * @param data 服务端返回的数组
   */
  syncFromServer: async <T>(domain: DomainName, data: T[]): Promise<void> => {
    const key = KEYS[domain];
    if (!key) return;
    const store = makeStore<T>(key as StoreKey);
    await store.setAll(data);
    // 更新同步时间戳
    await setSyncTimestamp(domain);
  },

  /**
   * 增量同步：合并服务端增量数据到本地（而非全量覆盖）
   * @param domain 数据域名
   * @param newItems 服务端返回的增量数据（仅包含最近变更）
   * @param idField 用于去重的ID字段名，默认 'id'
   */
  syncIncremental: async <T>(domain: DomainName, newItems: T[], idField: string = 'id'): Promise<void> => {
    const key = KEYS[domain];
    if (!key || newItems.length === 0) return;
    const all = await readArray<T>(key as StoreKey);
    const existingIds = new Set(all.map((item: any) => item[idField]));
    const toAdd = newItems.filter((item: any) => !existingIds.has(item[idField]));
    if (toAdd.length > 0) {
      all.unshift(...toAdd);
      await writeArray(key as StoreKey, all);
    }
    await setSyncTimestamp(domain);
    notify(domain);
  },

  /** 获取指定域的最近同步时间 */
  getSyncTimestamp: async (domain: DomainName): Promise<string | null> => {
    return getSyncTimestamp(domain);
  },

  // ====== 快捷统计方法（管理员用） ======

  getTotalUsers: async (): Promise<number> => {
    return GlobalStore.users.count();
  },

  getOnlineUsers: async (): Promise<number> => {
    const all = await GlobalStore.users.getAll();
    return all.filter((u) => u.isOnline).length;
  },

  getSOSToday: async (): Promise<number> => {
    const all = await GlobalStore.sos.getAll();
    const today = new Date().toDateString();
    return all.filter((s) => new Date(s.triggeredAt).toDateString() === today).length;
  },

  getActiveUsersToday: async (): Promise<number> => {
    const all = await GlobalStore.users.getAll();
    const today = new Date().toDateString();
    return all.filter((u) => new Date(u.lastActive).toDateString() === today).length;
  },

  getTotalSpacePosts: async (): Promise<number> => {
    return GlobalStore.spacePosts.count();
  },
};

export default GlobalStore;
