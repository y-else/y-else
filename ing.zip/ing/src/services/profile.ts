/**
 * 用户主页 + 空间 API 服务层（持久化版）
 *
 * 修复清单：
 * - F1: 全量 AsyncStorage 持久化，不再使用内存对象
 * - F2: 昵称可编辑（updateProfile 接受 username）
 * - F3: 生日首次设置后正确记录 lastBirthdayEdit
 * - F5: getFriendBirthdays 从绑定联系人中查找当天生日
 * - S2: 在线状态管理（getOnlineStatus/setOnlineStatus）
 * - M4: 7位展示ID生成与持久化
 * - R1: 每日点赞存储90天过期自动清理
 * - R3: 空间动态分页 + 每用户200条上限 + 180天过期清理
 * - R4: 好友关系内存缓存(TTL 5min) + 离线降级保留缓存
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { emitVisit } from './websocketClient';
import type {
  PublicProfile, BirthdayInfo, BirthdayReminder,
  ProfileLike, LikeRecord, WallMessage,
  SpacePost, SpaceLike, SpaceComment, SpaceMedia, SpaceVisibility,
  SpaceVisit, VisitRecord, AlbumItem, AlbumPermission,
} from '../types';

const delay = (ms = 350) => new Promise((r) => setTimeout(r, ms));

// ====== 存储键 ======

const KEYS = {
  PROFILES: '@ing_public_profiles',
  LIKES: '@ing_profile_likes',
  WALL_MSGS: '@ing_wall_messages',
  SPACE_POSTS: '@ing_space_posts',
  VISITS: '@ing_space_visits',
  ALBUM: '@ing_album',
  ONLINE_STATUS: '@ing_online_status',
} as const;

// ====== R1: 每日点赞过期清理常量 ======

const DAILY_LIKES_PREFIX = '@ing_daily_likes_';
const DAILY_LIKES_MAX_AGE_DAYS = 90;

// ====== R3: 空间动态容量控制常量 ======

const MAX_POSTS_PER_USER = 200;
const POST_MAX_AGE_DAYS = 180;

// ====== R4: 好友关系内存缓存（TTL 5分钟） ======

const FRIEND_CACHE_TTL_MS = 300_000;

interface FriendCacheEntry {
  friendIds: Set<string>;
  ts: number;
}
const friendCache = new Map<string, FriendCacheEntry>();

// ====== 工具函数 ======

function getTodayKey(): string {
  return new Date().toISOString().slice(0, 10);
}

// ====== R1: 清理过期每日点赞键 ======

async function cleanupOldDailyLikes(): Promise<void> {
  try {
    const allKeys = await AsyncStorage.getAllKeys();
    const cutoff = getTodayKey();
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - DAILY_LIKES_MAX_AGE_DAYS);
    const cutoffStr = cutoffDate.toISOString().slice(0, 10);

    const expiredKeys = allKeys.filter((key) => {
      if (!key.startsWith(DAILY_LIKES_PREFIX)) return false;
      const dateStr = key.slice(DAILY_LIKES_PREFIX.length); // YYYY-MM-DD
      return dateStr < cutoffStr;
    });

    if (expiredKeys.length > 0) {
      await AsyncStorage.multiRemove(expiredKeys);
      console.log(`[点赞清理] 已清理 ${expiredKeys.length} 个过期每日点赞键`);
    }
  } catch { /* 静默清理失败不影响主流程 */ }
}

// ====== R3: 清理过期空间动态 + 每用户容量裁剪 ======

async function cleanupOldSpacePosts(posts: SpacePost[]): Promise<SpacePost[]> {
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - POST_MAX_AGE_DAYS);
  const cutoffStr = cutoffDate.toISOString();

  // 按作者分组
  const byAuthor = new Map<string, SpacePost[]>();
  for (const p of posts) {
    if (!byAuthor.has(p.authorId)) byAuthor.set(p.authorId, []);
    byAuthor.get(p.authorId)!.push(p);
  }

  const kept: SpacePost[] = [];

  for (const [authorId, authorPosts] of byAuthor) {
    // 按时间倒序排列
    const sorted = authorPosts.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    );

    // 过滤过期动态（超过180天）
    const fresh = sorted.filter((p) => p.createdAt > cutoffStr);

    // 每用户最多保留200条
    const trimmed = fresh.slice(0, MAX_POSTS_PER_USER);

    kept.push(...trimmed);

    const removed = sorted.length - trimmed.length;
    if (removed > 0) {
      console.log(`[动态清理] 用户${authorId}: 移除${removed}条旧动态, 保留${trimmed.length}条`);
    }
  }

  return kept;
}

// ====== R4: 好友关系缓存管理 ======

/** 刷新指定用户的好友ID缓存 */
export async function refreshFriendCache(userId: string): Promise<void> {
  try {
    const { getContacts } = await import('./contacts');
    const contacts = await getContacts();
    const friendIds = new Set<string>();
    for (const c of contacts) {
      if (c && !c.isBlocked && c.userId !== userId) {
        friendIds.add(c.userId);
      }
    }
    friendCache.set(userId, { friendIds, ts: Date.now() });
  } catch {
    // 刷新失败保留旧缓存
  }
}

/** 获取缓存的好友ID集合（TTL内有效，过期返回null） */
async function getCachedFriendIds(userId: string): Promise<Set<string> | null> {
  const entry = friendCache.get(userId);
  if (entry && Date.now() - entry.ts < FRIEND_CACHE_TTL_MS) {
    return entry.friendIds;
  }
  return null;
}

/** 判断 viewerId 是否是 ownerId 的好友（R4修复：缓存+降级） */
async function checkIsFriend(ownerId: string, viewerId: string): Promise<boolean> {
  // 1. 先查内存缓存
  const cached = await getCachedFriendIds(viewerId);
  if (cached !== null) {
    return cached.has(ownerId);
  }

  // 2. 缓存未命中 → 尝试从 contacts 加载
  try {
    const { getContactById } = await import('./contacts');
    const contact = await getContactById(ownerId);
    // 加载成功 → 顺便刷新缓存
    await refreshFriendCache(viewerId);
    return !!(contact && !contact.isBlocked);
  } catch {
    // 3. 离线/失败 → 刷新缓存再试一次（可能有旧缓存刚过期）
    await refreshFriendCache(viewerId).catch(() => {});
    const retryCached = await getCachedFriendIds(viewerId);
    if (retryCached !== null) {
      return retryCached.has(ownerId);
    }
    // 4. 确实没有任何数据 → 降级为公开可见（避免误伤friends_only动态）
    //    注：这里选择对用户可见而非隐藏，因为隐藏比可见的伤害更大
    console.log(`[好友检查] 无法获取好友数据，降级为非好友(ownerId=${ownerId})`);
    return false;
  }
}

// ====== 用户资料持久化 ======

async function readProfiles(): Promise<Record<string, PublicProfile>> {
  try {
    const raw = await AsyncStorage.getItem(KEYS.PROFILES);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

async function writeProfiles(all: Record<string, PublicProfile>): Promise<void> {
  await AsyncStorage.setItem(KEYS.PROFILES, JSON.stringify(all));
}

function getOrCreateProfile(
  store: Record<string, PublicProfile>,
  userId: string,
  username?: string,
): PublicProfile {
  if (!store[userId]) {
    store[userId] = {
      userId,
      username: username || '',
      avatar: null,
      bio: '',
      birthday: null,
      lastBirthdayEdit: null,
      gender: 'hidden',
      level: 1,
      totalMinutes: 0,
      location: '',
      createdAt: new Date().toISOString(),
    };
  }
  return store[userId];
}

// ====== 获取公开资料 ======

export async function getPublicProfile(userId: string): Promise<PublicProfile | null> {
  await delay();
  const all = await readProfiles();
  return all[userId] || null;
}

// ====== 更新资料（修复：昵称可编辑 + 生日限制 + 首次设置记录） ======

export async function updateProfile(
  userId: string,
  updates: Partial<Pick<PublicProfile, 'username' | 'bio' | 'gender' | 'location' | 'birthday' | 'avatar'>>,
): Promise<{ success: boolean; message: string }> {
  await delay(500);

  const all = await readProfiles();
  const profile = getOrCreateProfile(all, userId);

  // 生日一年仅可修改一次检查（修复F3：首次设置也记录lastBirthdayEdit）
  if (updates.birthday) {
    if (profile.lastBirthdayEdit) {
      const lastEdit = new Date(profile.lastBirthdayEdit);
      const oneYearAgo = new Date();
      oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
      if (lastEdit > oneYearAgo) {
        return {
          success: false,
          message: `生日一年仅可修改一次，上次修改于 ${lastEdit.toLocaleDateString('zh-CN')}`,
        };
      }
    }
    // 首次设置或满一年后修改，记录修改时间
    profile.lastBirthdayEdit = new Date().toISOString();
  }

  // 应用更新（F2修复：接受 username）
  if (updates.username !== undefined) {
    profile.username = updates.username;
  }
  if (updates.bio !== undefined) profile.bio = updates.bio;
  if (updates.gender !== undefined) profile.gender = updates.gender;
  if (updates.location !== undefined) profile.location = updates.location;
  if (updates.birthday !== undefined) profile.birthday = updates.birthday;
  if (updates.avatar !== undefined) profile.avatar = updates.avatar;

  all[userId] = profile;
  await writeProfiles(all);
  return { success: true, message: '资料更新成功' };
}

// ====== 更新等级/时长（由 level.ts 调用） ======

export async function syncLevelAndMinutes(
  userId: string,
  level: number,
  totalMinutes: number,
): Promise<void> {
  const all = await readProfiles();
  const profile = getOrCreateProfile(all, userId);
  profile.level = level;
  profile.totalMinutes = totalMinutes;
  all[userId] = profile;
  await writeProfiles(all);
}

// ====== 7位展示ID（F12修复） ======

export async function getDisplayId(userId: string): Promise<string> {
  const all = await readProfiles();
  const profile = all[userId];
  if (profile && (profile as any).displayId) {
    return (profile as any).displayId;
  }
  // 从 userId 生成稳定7位ID：取hash后7位
  let hash = 0;
  for (let i = 0; i < userId.length; i++) {
    hash = ((hash << 5) - hash) + userId.charCodeAt(i);
    hash |= 0;
  }
  const displayId = String(Math.abs(hash) % 9000000 + 1000000);
  // 持久化
  if (profile) {
    (profile as any).displayId = displayId;
    all[userId] = profile;
    await writeProfiles(all);
  }
  return displayId;
}

// ====== 在线状态管理（S2修复） ======

export async function getOnlineStatus(userId: string): Promise<boolean> {
  try {
    const raw = await AsyncStorage.getItem(KEYS.ONLINE_STATUS);
    const statuses: Record<string, number> = raw ? JSON.parse(raw) : {};
    const lastSeen = statuses[userId] || 0;
    // 5分钟内有心跳视为在线
    return Date.now() - lastSeen < 300000;
  } catch {
    return false;
  }
}

export async function setOnlineStatus(userId: string, isOnline: boolean): Promise<void> {
  try {
    const raw = await AsyncStorage.getItem(KEYS.ONLINE_STATUS);
    const statuses: Record<string, number> = raw ? JSON.parse(raw) : {};
    if (isOnline) {
      statuses[userId] = Date.now();
    }
    // 清理过期记录（超过1小时）
    const oneHourAgo = Date.now() - 3600000;
    for (const key of Object.keys(statuses)) {
      if (statuses[key] < oneHourAgo) delete statuses[key];
    }
    await AsyncStorage.setItem(KEYS.ONLINE_STATUS, JSON.stringify(statuses));
  } catch { /* 静默 */ }
}

/**
 * 心跳更新：App 在前台时每30秒调用一次
 */
export async function heartbeatOnline(userId: string): Promise<void> {
  await setOnlineStatus(userId, true);
}

// ====== 生日检查（F4修复：HomeScreen可调用） ======

export async function checkTodayBirthday(userId: string): Promise<BirthdayInfo | null> {
  await delay(200);
  const all = await readProfiles();
  const profile = all[userId];
  if (!profile?.birthday) return null;

  const today = new Date();
  const birthday = new Date(profile.birthday);
  const isToday = today.getMonth() === birthday.getMonth() && today.getDate() === birthday.getDate();

  return {
    userId,
    birthday: profile.birthday.slice(5),
    age: today.getFullYear() - birthday.getFullYear(),
    isToday,
  };
}

/**
 * 获取好友生日提醒（F5修复：从绑定联系人中找当天生日的人）
 */
export async function getFriendBirthdays(currentUserId: string): Promise<BirthdayReminder[]> {
  await delay(300);
  const all = await readProfiles();

  // 从联系人服务获取已绑定好友
  let contacts: any[] = [];
  try {
    const { getContacts } = await import('./contacts');
    contacts = await getContacts();
  } catch {
    return [];
  }

  const today = new Date();
  const reminders: BirthdayReminder[] = [];

  for (const c of contacts) {
    if (!c || c.isBlocked || c.userId === currentUserId) continue;
    const friendProfile = all[c.userId];
    if (!friendProfile?.birthday) continue;

    const bday = new Date(friendProfile.birthday);
    const isToday = today.getMonth() === bday.getMonth() && today.getDate() === bday.getDate();
    if (isToday) {
      reminders.push({
        friendUserId: c.userId,
        friendUsername: c.username || friendProfile.username,
        birthday: friendProfile.birthday.slice(5),
      });
    }
  }

  return reminders;
}

// ====== 主页点赞（单日单人限1赞，持久化） ======

async function readLikes(): Promise<Record<string, LikeRecord>> {
  try {
    const raw = await AsyncStorage.getItem(KEYS.LIKES);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

async function writeLikes(data: Record<string, LikeRecord>): Promise<void> {
  await AsyncStorage.setItem(KEYS.LIKES, JSON.stringify(data));
}

export async function toggleProfileLike(
  targetUserId: string,
  userId: string,
  username: string,
  avatar: string | null,
): Promise<{ liked: boolean; totalLikes: number; message: string }> {
  await delay(300);

  const all = await readLikes();
  if (!all[targetUserId]) {
    all[targetUserId] = { targetUserId, totalLikes: 0, likeList: [] };
  }
  const record = all[targetUserId];
  const today = getTodayKey();

  const todayLike = record.likeList.find(
    (l) => l.userId === userId && l.likedAt.startsWith(today),
  );

  if (todayLike) {
    record.likeList = record.likeList.filter((l) => l !== todayLike);
    record.totalLikes = Math.max(0, record.totalLikes - 1);
    await writeLikes(all);
    return { liked: false, totalLikes: record.totalLikes, message: '已取消点赞' };
  }

  record.likeList.push({ userId, username, avatar, likedAt: new Date().toISOString() });
  record.totalLikes++;
  await writeLikes(all);
  return { liked: true, totalLikes: record.totalLikes, message: '点赞成功' };
}

export async function getProfileLikes(targetUserId: string, viewerId: string): Promise<LikeRecord> {
  await delay(200);
  const all = await readLikes();
  const record = all[targetUserId] || { targetUserId, totalLikes: 0, likeList: [] };
  return {
    ...record,
    likeList: viewerId === targetUserId ? record.likeList : [],
  };
}

// ====== 留言墙（持久化） ======

async function readWallMsgs(): Promise<WallMessage[]> {
  try {
    const raw = await AsyncStorage.getItem(KEYS.WALL_MSGS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

async function writeWallMsgs(msgs: WallMessage[]): Promise<void> {
  if (msgs.length > 500) msgs.length = 500;
  await AsyncStorage.setItem(KEYS.WALL_MSGS, JSON.stringify(msgs));
}

export async function getWallMessages(targetUserId: string): Promise<WallMessage[]> {
  await delay(300);
  const msgs = await readWallMsgs();
  return msgs.filter((m) => m.targetUserId === targetUserId && !m.isDeleted);
}

export async function addWallMessage(
  targetUserId: string,
  authorId: string, authorName: string, authorAvatar: string | null,
  content: string,
): Promise<WallMessage> {
  await delay(400);
  const msgs = await readWallMsgs();
  const msg: WallMessage = {
    id: 'wm_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
    targetUserId,
    authorId, authorName, authorAvatar, content,
    createdAt: new Date().toISOString(),
    isDeleted: false,
  };
  msgs.unshift(msg);
  await writeWallMsgs(msgs);
  return msg;
}

export async function deleteWallMessage(messageId: string, _operatorId: string): Promise<boolean> {
  await delay(200);
  const msgs = await readWallMsgs();
  const msg = msgs.find((m) => m.id === messageId);
  if (msg) { msg.isDeleted = true; await writeWallMsgs(msgs); return true; }
  return false;
}

// ====== 空间动态（持久化 + R3分页容量控制 + R4好友缓存） ======

async function readSpacePosts(): Promise<SpacePost[]> {
  try {
    const raw = await AsyncStorage.getItem(KEYS.SPACE_POSTS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

async function writeSpacePosts(posts: SpacePost[]): Promise<void> {
  // R3修复：按用户裁剪 + 清理过期动态
  try {
    const cleaned = await cleanupOldSpacePosts(posts);
    await AsyncStorage.setItem(KEYS.SPACE_POSTS, JSON.stringify(cleaned));
  } catch {
    // 写入失败时至少保留原始数据不丢失
    try {
      if (posts.length > 600) posts.length = 600;
      await AsyncStorage.setItem(KEYS.SPACE_POSTS, JSON.stringify(posts));
    } catch { /* 最终降级 */ }
  }
}

/**
 * 获取空间动态（R3分页 + R4好友缓存 + F2权限过滤）
 * @param authorId 空间主人ID
 * @param viewerId 当前浏览者ID
 * @param page 页码（从1开始，不传则返回全部）
 * @param pageSize 每页条数（默认20）
 */
export async function getSpacePosts(
  authorId: string,
  viewerId: string,
  page?: number,
  pageSize = 20,
): Promise<{ posts: SpacePost[]; total: number; hasMore: boolean }> {
  await delay(400);
  const posts = await readSpacePosts();

  // R4修复：使用缓存+降级策略检查好友关系
  const isFriend = viewerId && viewerId !== authorId
    ? await checkIsFriend(authorId, viewerId)
    : false;

  // 权限过滤
  const filtered = posts.filter((p) => {
    if (p.authorId !== authorId) return false;
    // 被拉黑了发布者的不可见
    if (p.blockedBy?.includes(viewerId)) return false;
    if (p.visibility === 'public') return true;
    if (p.visibility === 'friends_only') return viewerId === authorId || isFriend;
    return viewerId === authorId;
  });

  // 按时间倒序
  const sorted = filtered.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );

  const total = sorted.length;

  // R3分页
  if (page && page > 0) {
    const start = (page - 1) * pageSize;
    const paged = sorted.slice(start, start + pageSize);
    return { posts: paged, total, hasMore: start + pageSize < total };
  }

  return { posts: sorted, total, hasMore: false };
}

export async function createSpacePost(
  authorId: string, authorName: string, authorAvatar: string | null,
  content: string, media: SpaceMedia[], visibility: SpaceVisibility,
): Promise<SpacePost> {
  await delay(600);

  // R3修复：发布前清理过期数据
  const posts = await readSpacePosts();
  const now = new Date().toISOString();

  const post: SpacePost = {
    id: 'sp_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
    authorId, authorName, authorAvatar,
    content, media, visibility,
    likes: [], comments: [],
    blockedBy: [], reportCount: 0,
    createdAt: now,
    updatedAt: now,
  };
  posts.unshift(post);

  // 写入时自动触发容量控制
  await writeSpacePosts(posts);

  // F2修复：自动同步动态媒体到相册
  if (media.length > 0) {
    syncPostMediaToAlbum(authorId, media, visibility).catch(() => {});
  }

  return post;
}

/**
 * F2修复：自动同步动态媒体到相册
 * 发布含图文/视频的动态时，自动将媒体添加到空间相册
 * 异步执行，不阻塞动态发布
 * R1修复：URI去重 — 相同媒体不会重复添加
 */
async function syncPostMediaToAlbum(
  authorId: string, media: SpaceMedia[], visibility: SpaceVisibility,
): Promise<void> {
  try {
    const albumPermission: AlbumPermission = visibility === 'public'
      ? 'public' : visibility === 'friends_only'
        ? 'friends_only' : 'private';

    let addedCount = 0;
    let skippedCount = 0;
    for (const m of media) {
      const result = await addAlbumItem(
        authorId, m.uri, m.type, 'auto', albumPermission, m.thumbnailUri,
      );
      if (result) addedCount++;
      else skippedCount++;
    }
    if (addedCount > 0 || skippedCount > 0) {
      console.log(`[相册同步] 用户${authorId}: 新增${addedCount}条, 跳过重复${skippedCount}条`);
    }
  } catch { /* 自动同步失败不影响主流程 */ }
}

export async function deleteSpacePost(
  postId: string, operatorId: string, operatorRole?: string,
): Promise<{ success: boolean; message: string }> {
  await delay(300);

  // 管理员只读：无权删除用户动态
  if (operatorRole === 'admin') {
    return { success: false, message: '管理员无权删除用户动态' };
  }

  const posts = await readSpacePosts();
  const idx = posts.findIndex((p) => p.id === postId);
  if (idx < 0) return { success: false, message: '动态不存在' };
  if (posts[idx].authorId !== operatorId) return { success: false, message: '仅作者可删除自己的动态' };

  posts.splice(idx, 1);
  await writeSpacePosts(posts);
  return { success: true, message: '已删除' };
}

export async function likeSpacePost(
  postId: string, userId: string, username: string,
): Promise<{ post: SpacePost | null; liked: boolean; message: string }> {
  await delay(200);
  const posts = await readSpacePosts();
  const post = posts.find((p) => p.id === postId);
  if (!post) return { post: null, liked: false, message: '动态不存在' };

  const today = getTodayKey();
  const existingIdx = post.likes.findIndex((l) => l.userId === userId);

  // 已点赞 → 取消点赞
  if (existingIdx >= 0) {
    post.likes.splice(existingIdx, 1);
    await writeSpacePosts(posts);
    return { post, liked: false, message: '已取消点赞' };
  }

  // 检查今日是否已点赞（单日单人仅1次，使用持久化记录追踪点赞→取消→再点赞）
  const dailyKey = DAILY_LIKES_PREFIX + today;
  try {
    const raw = await AsyncStorage.getItem(dailyKey);
    const dailyLikes: Record<string, string[]> = raw ? JSON.parse(raw) : {};
    const postLikes = dailyLikes[postId] || [];
    if (postLikes.includes(userId)) {
      return { post, liked: false, message: '今日已点赞过该动态，明天再来吧' };
    }
    postLikes.push(userId);
    dailyLikes[postId] = postLikes;
    await AsyncStorage.setItem(dailyKey, JSON.stringify(dailyLikes));

    // R1修复：每次点赞时附带清理90天前的过期键（异步，不阻塞）
    cleanupOldDailyLikes().catch(() => {});
  } catch {
    // 降级：不阻止点赞
  }

  post.likes.push({ userId, username, likedAt: new Date().toISOString() });
  await writeSpacePosts(posts);
  return { post, liked: true, message: '点赞成功' };
}

export async function addSpaceComment(
  postId: string, authorId: string, authorName: string, authorAvatar: string | null,
  content: string,
): Promise<SpacePost | null> {
  await delay(300);
  const posts = await readSpacePosts();
  const post = posts.find((p) => p.id === postId);
  if (!post) return null;
  post.comments.push({
    id: 'sc_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
    authorId, authorName, authorAvatar, content,
    createdAt: new Date().toISOString(),
    isDeleted: false,
  });
  await writeSpacePosts(posts);
  return post;
}

export async function deleteSpaceComment(
  postId: string, commentId: string, operatorId: string, operatorRole?: string,
): Promise<{ success: boolean; message: string }> {
  await delay(200);

  // 管理员只读：无权删除评论
  if (operatorRole === 'admin') {
    return { success: false, message: '管理员无权删除评论' };
  }

  const posts = await readSpacePosts();
  const post = posts.find((p) => p.id === postId);
  if (!post) return { success: false, message: '动态不存在' };

  const comment = post.comments.find((c) => c.id === commentId);
  if (!comment) return { success: false, message: '评论不存在' };

  // 动态作者可删除任何评论，评论作者可删除自己评论
  if (post.authorId === operatorId || comment.authorId === operatorId) {
    comment.isDeleted = true;
    await writeSpacePosts(posts);
    return { success: true, message: '已删除' };
  }

  return { success: false, message: '无权删除此评论' };
}

// ====== 空间动态拉黑/举报 ======

export async function blockSpacePostAuthor(
  postId: string, blockerId: string,
): Promise<{ success: boolean; message: string }> {
  await delay(200);
  const posts = await readSpacePosts();
  const post = posts.find((p) => p.id === postId);
  if (!post) return { success: false, message: '动态不存在' };
  if (post.authorId === blockerId) return { success: false, message: '不能拉黑自己' };

  if (!post.blockedBy) post.blockedBy = [];
  if (post.blockedBy.includes(blockerId)) {
    // 取消拉黑
    post.blockedBy = post.blockedBy.filter((id) => id !== blockerId);
    await writeSpacePosts(posts);
    return { success: true, message: '已取消拉黑' };
  }

  post.blockedBy.push(blockerId);
  await writeSpacePosts(posts);

  // 同步拉黑到联系人服务
  try {
    const { blockUser } = await import('./contacts');
    await blockUser(blockerId, post.authorId, '空间动态拉黑');
    // R4修复：拉黑后刷新好友缓存
    await refreshFriendCache(blockerId);
  } catch { /* 联系人拉黑失败不影响主流程 */ }

  return { success: true, message: '已拉黑该用户' };
}

export async function reportSpacePost(
  postId: string, reporterId: string, reporterName: string, reason: string,
): Promise<{ success: boolean; message: string }> {
  await delay(300);
  const posts = await readSpacePosts();
  const post = posts.find((p) => p.id === postId);
  if (!post) return { success: false, message: '动态不存在' };
  if (post.authorId === reporterId) return { success: false, message: '不能举报自己的动态' };

  try {
    const { submitReport } = await import('./contentReport');
    const r = await submitReport({
      reporterId, reporterName,
      targetType: 'space_post',
      targetId: postId,
      targetPreview: post.content?.slice(0, 100) || '[图片/视频动态]',
      reason,
    });
    if (r.success) {
      post.reportCount = (post.reportCount || 0) + 1;
      await writeSpacePosts(posts);
    }
    return r;
  } catch {
    return { success: false, message: '举报失败，请重试' };
  }
}

export async function blockSpaceCommentAuthor(
  _postId: string, commentId: string, blockerId: string,
): Promise<{ success: boolean; message: string }> {
  await delay(200);
  const posts = await readSpacePosts();
  // 找到包含该评论的动态
  const post = posts.find((p) => p.comments.some((c) => c.id === commentId));
  if (!post) return { success: false, message: '评论不存在' };
  const comment = post.comments.find((c) => c.id === commentId)!;
  if (comment.authorId === blockerId) return { success: false, message: '不能拉黑自己' };

  if (!comment.blockedBy) comment.blockedBy = [];
  if (!comment.blockedBy.includes(blockerId)) {
    comment.blockedBy.push(blockerId);
    await writeSpacePosts(posts);

    try {
      const { blockUser } = await import('./contacts');
      await blockUser(blockerId, comment.authorId, '空间评论拉黑');
      // R4修复：拉黑后刷新好友缓存
      await refreshFriendCache(blockerId);
    } catch { /* 静默 */ }
  }

  return { success: true, message: '已拉黑该用户' };
}

// ====== 空间访问记录（持久化） ======

async function readVisits(): Promise<Record<string, VisitRecord>> {
  try {
    const raw = await AsyncStorage.getItem(KEYS.VISITS);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

async function writeVisits(data: Record<string, VisitRecord>): Promise<void> {
  await AsyncStorage.setItem(KEYS.VISITS, JSON.stringify(data));
}

export async function recordVisit(targetUserId: string, visitorId: string, visitorName: string, visitorAvatar: string | null): Promise<void> {
  const all = await readVisits();
  if (!all[targetUserId]) {
    all[targetUserId] = { targetUserId, totalVisits: 0, visitorList: [] };
  }
  const record = all[targetUserId];
  const today = getTodayKey();
  const now = new Date().toISOString();

  const existingIdx = record.visitorList.findIndex((v) => v.visitorId === visitorId);
  if (existingIdx >= 0) {
    // 更新最近访问时间（保留最新访问记录）
    record.visitorList[existingIdx] = {
      ...record.visitorList[existingIdx],
      visitorName,
      visitorAvatar,
      visitedAt: now,
    };
  } else {
    // 新访客 → 记录并增加总访客数
    record.visitorList.push({ visitorId, visitorName, visitorAvatar, visitedAt: now });
    record.totalVisits++;
  }

  // 限制访客列表长度
  if (record.visitorList.length > 500) {
    record.visitorList = record.visitorList.slice(-500);
  }

  await writeVisits(all);

  // WS实时推送：通知被访问者
  try {
    emitVisit({ ownerId: targetUserId, visitorId, visitorName, visitorAvatar, visitedAt: now });
  } catch {}
}

export async function getVisitRecord(targetUserId: string, viewerId: string): Promise<VisitRecord> {
  await delay(200);
  const all = await readVisits();
  const record = all[targetUserId] || { targetUserId, totalVisits: 0, visitorList: [] };
  return {
    targetUserId,
    totalVisits: record.totalVisits,
    visitorList: viewerId === targetUserId ? record.visitorList : [],
  };
}

// ====== 相册（持久化） ======

async function readAlbum(): Promise<Record<string, AlbumItem[]>> {
  try {
    const raw = await AsyncStorage.getItem(KEYS.ALBUM);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

async function writeAlbum(data: Record<string, AlbumItem[]>): Promise<void> {
  await AsyncStorage.setItem(KEYS.ALBUM, JSON.stringify(data));
}

export async function getAlbum(ownerId: string, viewerId: string): Promise<AlbumItem[]> {
  await delay(300);

  // F3修复：使用好友缓存检查权限（与 getSpacePosts 一致）
  const isFriend = viewerId && viewerId !== ownerId
    ? await checkIsFriend(ownerId, viewerId)
    : false;

  const all = await readAlbum();
  const items = all[ownerId] || [];
  return items.filter((item) => {
    if (item.permission === 'public') return true;
    if (item.permission === 'friends_only') return viewerId === ownerId || isFriend;
    return viewerId === ownerId;
  });
}

/**
 * R3修复：分页获取相册
 * @param page 页码从1开始，不传则返回全部
 * @param pageSize 每页条数，默认21（3列网格的倍数）
 */
export async function getAlbumPaged(
  ownerId: string, viewerId: string, page?: number, pageSize = 21,
): Promise<{ items: AlbumItem[]; total: number; hasMore: boolean }> {
  const allItems = await getAlbum(ownerId, viewerId);
  // 按时间倒序
  const sorted = allItems.sort(
    (a, b) => new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime(),
  );
  const total = sorted.length;

  if (page && page > 0) {
    const start = (page - 1) * pageSize;
    return {
      items: sorted.slice(start, start + pageSize),
      total,
      hasMore: start + pageSize < total,
    };
  }

  return { items: sorted, total, hasMore: false };
}

export async function addAlbumItem(
  ownerId: string,
  uri: string, type: 'image' | 'video', source: 'auto' | 'manual',
  permission: AlbumPermission, thumbnailUri?: string,
): Promise<AlbumItem | null> {
  await delay(400);
  const all = await readAlbum();
  if (!all[ownerId]) all[ownerId] = [];

  // R1修复：URI去重 — 相同URI不重复添加（source='manual'时更新权限；source='auto'时静默跳过）
  const existingIdx = all[ownerId].findIndex((a) => a.uri === uri);
  if (existingIdx >= 0) {
    const existing = all[ownerId][existingIdx];
    if (source === 'manual') {
      // 手动添加：更新权限和缩略图，移到最前面
      existing.permission = permission;
      if (thumbnailUri) existing.thumbnailUri = thumbnailUri;
      existing.addedAt = new Date().toISOString();
      // 移到最前面
      all[ownerId].splice(existingIdx, 1);
      all[ownerId].unshift(existing);
      await writeAlbum(all);
    }
    // 自动同步时不抛错，静默返回已有项
    return null;
  }

  const item: AlbumItem = {
    id: 'alb_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
    uri, type, source,
    thumbnailUri: thumbnailUri || uri,
    addedAt: new Date().toISOString(), permission,
  };
  all[ownerId].unshift(item);
  await writeAlbum(all);
  return item;
}

export async function removeAlbumItem(ownerId: string, itemId: string): Promise<boolean> {
  const all = await readAlbum();
  const items = all[ownerId];
  if (!items) return false;
  const idx = items.findIndex((a) => a.id === itemId);
  if (idx >= 0) { items.splice(idx, 1); await writeAlbum(all); return true; }
  return false;
}
