/**
 * 公告服务（单一数据源）
 * 管理员发布 → AsyncStorage 持久化 → 用户启动自动弹窗
 * 已读状态按用户隔离，支持 USE_REAL_API 切换
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { api } from './apiClient';
import { USE_REAL_API } from './apiConfig';
import type { Announcement } from '../types';

const ANNOUNCEMENTS_KEY = '@ing_announcements';
const READ_ANNOUNCEMENTS_PREFIX = '@ing_read_announcements_';

function readKey(userId: string): string {
  return READ_ANNOUNCEMENTS_PREFIX + userId;
}

const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

// ====== 获取所有公告 ======

export async function getAllAnnouncements(): Promise<Announcement[]> {
  if (USE_REAL_API) {
    try {
      const resp = await api.get<Announcement[]>('/announcements');
      if (resp.code === 200 && resp.data) return resp.data;
    } catch { /* 降级到本地 */ }
  }
  await delay(200);
  const raw = await AsyncStorage.getItem(ANNOUNCEMENTS_KEY);
  return raw ? JSON.parse(raw) : [];
}

// ====== 获取未读公告（按用户隔离） ======

export async function getUnreadAnnouncements(userId: string): Promise<Announcement[]> {
  if (USE_REAL_API) {
    try {
      const resp = await api.get<Announcement[]>(`/announcements/unread?userId=${userId}`);
      if (resp.code === 200 && resp.data) return resp.data;
    } catch { /* 降级到本地 */ }
  }
  await delay(200);
  const all = await getAllAnnouncements();
  const raw = await AsyncStorage.getItem(readKey(userId));
  const readIds: string[] = raw ? JSON.parse(raw) : [];
  return all.filter((a) => !readIds.includes(a.id));
}

// ====== 标记公告已读 ======

export async function markAsRead(userId: string, announcementId: string): Promise<void> {
  if (USE_REAL_API) {
    try {
      await api.post('/announcements/mark-read', { userId, announcementId });
      return;
    } catch { /* 降级到本地 */ }
  }
  const raw = await AsyncStorage.getItem(readKey(userId));
  const readIds: string[] = raw ? JSON.parse(raw) : [];
  if (!readIds.includes(announcementId)) {
    readIds.push(announcementId);
    if (readIds.length > 200) readIds.splice(0, readIds.length - 200);
    await AsyncStorage.setItem(readKey(userId), JSON.stringify(readIds));
  }
}

// ====== 批量标记已读（一键全部关闭） ======

export async function markAllAsRead(userId: string, announcementIds: string[]): Promise<void> {
  if (USE_REAL_API) {
    try {
      await api.post('/announcements/mark-all-read', { userId, announcementIds });
      return;
    } catch { /* 降级到本地 */ }
  }
  const raw = await AsyncStorage.getItem(readKey(userId));
  const readIds: string[] = raw ? JSON.parse(raw) : [];
  for (const id of announcementIds) {
    if (!readIds.includes(id)) readIds.push(id);
  }
  if (readIds.length > 200) readIds.splice(0, readIds.length - 200);
  await AsyncStorage.setItem(readKey(userId), JSON.stringify(readIds));
}

// ====== 发布公告（管理员，写入持久化存储） ======

export async function publishAnnouncement(
  title: string,
  content: string,
  level: 'normal' | 'important' | 'urgent' = 'normal',
  adminName = '管理员',
): Promise<Announcement> {
  if (USE_REAL_API) {
    try {
      const resp = await api.post<Announcement>('/admin/announcements', { title, content, level });
      if (resp.code === 200 && resp.data) return resp.data;
    } catch { /* 降级到本地 */ }
  }
  const ann: Announcement = {
    id: 'ann_' + Date.now(),
    title,
    content,
    level,
    publishedBy: adminName,
    publishedAt: new Date().toISOString(),
  };
  const raw = await AsyncStorage.getItem(ANNOUNCEMENTS_KEY);
  const list: Announcement[] = raw ? JSON.parse(raw) : [];
  list.unshift(ann);
  await AsyncStorage.setItem(ANNOUNCEMENTS_KEY, JSON.stringify(list));
  return ann;
}

// ====== 清除某用户已读记录（账号移除时调用） ======

export async function clearReadHistory(userId: string): Promise<void> {
  await AsyncStorage.removeItem(readKey(userId));
}
