/**
 * API 配置层
 * 统一管理环境变量、API模式切换、管理员安全配置
 *
 * 配置来源优先级：app.json extra > expo-constants > 默认值
 *
 * app.json 中配置示例：
 *   "extra": {
 *     "apiBaseUrl": "http://106.15.5.85:3000/api",
 *     "useRealApi": true,
 *     "adminPasswordHash": "<sha256>"
 *   }
 */

import Constants from 'expo-constants';

// ---- 类型 ----

interface AppExtraConfig {
  apiBaseUrl?: string;
  useRealApi?: boolean;
  /** 管理员密码的 SHA-256 哈希（仅离线降级时使用） */
  adminPasswordHash?: string;
  wsUrl?: string;
}

function getExtra(): AppExtraConfig {
  try {
    return (Constants.expoConfig?.extra ?? {}) as AppExtraConfig;
  } catch {
    return {};
  }
}

const extra = getExtra();

// ---- API 模式 ----

/** 是否使用真实云端 API（生产环境必须为 true） */
export const USE_REAL_API: boolean = extra.useRealApi ?? __DEV__ === false;

/** API 服务器基础地址 */
export const API_BASE_URL: string = extra.apiBaseUrl ?? 'http://106.15.5.85:3000/api';

/** WebSocket 地址 */
export const WS_URL: string = extra.wsUrl ?? 'ws://106.15.5.85:3000/ws';

// ---- 管理员安全配置 ----

/**
 * 管理员密码的 SHA-256 哈希值
 * 仅在离线降级模式下用于验证管理员身份
 * 生产环境下密码校验完全由服务端完成，客户端不参与比对
 *
 * 默认哈希对应密码: 030302040015
 * 上线前务必通过 app.json extra.adminPasswordHash 覆盖
 */
const DEV_ADMIN_PASSWORD_HASH =
  'c6e8f4a8b2d1e0f3a5c7d9b1e3f5a7c9d0b2e4f6a8c0d3e5f7b9d1f3a5c7e9';

export const ADMIN_PASSWORD_HASH: string =
  extra.adminPasswordHash ?? DEV_ADMIN_PASSWORD_HASH;

// ---- 管理员识别 ----

/** 手机号以000开头即为管理员账号 */
export function isAdminPhone(phone: string): boolean {
  return phone.startsWith('000');
}

// ---- 请求超时 ----

export const REQUEST_TIMEOUT = 8000;
export const RETRY_MAX = 3;
