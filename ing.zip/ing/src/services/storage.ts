/**
 * 本地持久化存储 — AsyncStorage 封装
 * 存储多账号、当前登录态、隐私政策同意记录
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import type { SavedAccount } from '../types';

const KEYS = {
  ACCOUNTS: '@ing_accounts',
  CURRENT_USER_ID: '@ing_current_user_id',
  PRIVACY_AGREED: '@ing_privacy_agreed',
  PRIVACY_AGREED_VERSION: '@ing_privacy_agreed_version',
  LAST_APP_VERSION: '@ing_last_app_version',
  AUTH_LOGS: '@ing_auth_logs',
} as const;

// ---- 多账号管理 ----

export async function getSavedAccounts(): Promise<SavedAccount[]> {
  const raw = await AsyncStorage.getItem(KEYS.ACCOUNTS);
  return raw ? JSON.parse(raw) : [];
}

export async function saveAccount(account: SavedAccount): Promise<void> {
  const accounts = await getSavedAccounts();
  const idx = accounts.findIndex((a) => a.userId === account.userId);
  if (idx >= 0) {
    accounts[idx] = { ...accounts[idx], ...account, lastLoginAt: new Date().toISOString() };
  } else {
    accounts.push(account);
  }
  await AsyncStorage.setItem(KEYS.ACCOUNTS, JSON.stringify(accounts));
}

export async function removeAccount(userId: string): Promise<void> {
  const accounts = await getSavedAccounts();
  await AsyncStorage.setItem(
    KEYS.ACCOUNTS,
    JSON.stringify(accounts.filter((a) => a.userId !== userId)),
  );
}

// ---- 当前登录用户 ----

export async function getCurrentUserId(): Promise<string | null> {
  return AsyncStorage.getItem(KEYS.CURRENT_USER_ID);
}

export async function setCurrentUserId(userId: string | null): Promise<void> {
  if (userId) {
    await AsyncStorage.setItem(KEYS.CURRENT_USER_ID, userId);
  } else {
    await AsyncStorage.removeItem(KEYS.CURRENT_USER_ID);
  }
}

// ---- 隐私政策 ----

export async function getPrivacyAgreed(): Promise<boolean> {
  const val = await AsyncStorage.getItem(KEYS.PRIVACY_AGREED);
  return val === 'true';
}

export async function setPrivacyAgreed(version: string): Promise<void> {
  await AsyncStorage.setItem(KEYS.PRIVACY_AGREED, 'true');
  await AsyncStorage.setItem(KEYS.PRIVACY_AGREED_VERSION, version);
}

export async function getPrivacyAgreedVersion(): Promise<string | null> {
  return AsyncStorage.getItem(KEYS.PRIVACY_AGREED_VERSION);
}

// ---- 版本检测 ----

export async function getLastAppVersion(): Promise<string | null> {
  return AsyncStorage.getItem(KEYS.LAST_APP_VERSION);
}

export async function setLastAppVersion(version: string): Promise<void> {
  await AsyncStorage.setItem(KEYS.LAST_APP_VERSION, version);
}

// ---- 管理员日志（本地缓存，同步到服务器） ----

export async function appendAuthLog(log: object): Promise<void> {
  const raw = await AsyncStorage.getItem(KEYS.AUTH_LOGS);
  const logs: object[] = raw ? JSON.parse(raw) : [];
  logs.push({ ...log, timestamp: new Date().toISOString() });
  // 只保留最近 200 条本地日志
  if (logs.length > 200) logs.splice(0, logs.length - 200);
  await AsyncStorage.setItem(KEYS.AUTH_LOGS, JSON.stringify(logs));
}

export async function getAuthLogs(): Promise<object[]> {
  const raw = await AsyncStorage.getItem(KEYS.AUTH_LOGS);
  return raw ? JSON.parse(raw) : [];
}

/** 标记指定手机号所有已保存账号 passwordChanged=true */
export async function markPasswordChangedForPhone(phone: string): Promise<void> {
  const accounts = await getSavedAccounts();
  let changed = false;
  for (const acc of accounts) {
    if (acc.phone === phone && !acc.passwordChanged) {
      acc.passwordChanged = true;
      changed = true;
    }
  }
  if (changed) {
    await AsyncStorage.setItem(KEYS.ACCOUNTS, JSON.stringify(accounts));
  }
}

/** 完整移除账号：已保存记录 + 绑定 + 公告已读 */
export async function removeAccountFull(userId: string): Promise<void> {
  await removeAccount(userId);
  try {
    const bindingsRaw = await AsyncStorage.getItem('@ing_admin_bindings');
    if (bindingsRaw) {
      const bindings = JSON.parse(bindingsRaw);
      const filtered = bindings.filter((b: any) => b.userId !== userId);
      await AsyncStorage.setItem('@ing_admin_bindings', JSON.stringify(filtered));
    }
  } catch { /* 静默 */ }
  try {
    const readRaw = await AsyncStorage.getItem('@ing_announcement_read');
    if (readRaw) {
      const readMap = JSON.parse(readRaw);
      delete readMap[userId];
      await AsyncStorage.setItem('@ing_announcement_read', JSON.stringify(readMap));
    }
  } catch { /* 静默 */ }
}

// ---- 清除所有数据（用于版本更新后强制重登 / 手动退出） ----

/** 会话相关的存储 key（仅清除令牌/绑定/缓存，不删除用户数据） */
const SESSION_KEYS = [
  KEYS.ACCOUNTS,
  KEYS.CURRENT_USER_ID,
  KEYS.AUTH_LOGS,
  '@ing_admin_token',
  '@ing_admin_bindings',
  '@ing_offline_queue',
  '@ing_online_status',
  '@ing_unread_badges',
  '@ing_deactivation_codes',
  '@ing_verification_codes',
] as const;

export async function clearAuthData(): Promise<void> {
  await Promise.all(SESSION_KEYS.map((k) => AsyncStorage.removeItem(k)));
}

// ====== 数据过期清理 ======

/** 可过期域的TTL配置（毫秒） */
const DOMAIN_TTL: Record<string, number> = {
  '@ing_gds_location_history': 30 * 24 * 3600_000,  // 30天
  '@ing_gds_app_usage': 90 * 24 * 3600_000,         // 90天
  '@ing_gds_sos': 180 * 24 * 3600_000,              // 180天
  '@ing_offline_queue': 7 * 24 * 3600_000,          // 7天（过期请求清理）
};

/**
 * 启动时数据管家：清理过期数据、裁剪超量存储
 * 在 App.tsx 入口调用
 */
export async function performDataHousekeeping(): Promise<{ cleaned: number }> {
  let cleaned = 0;
  const now = Date.now();

  for (const [key, ttl] of Object.entries(DOMAIN_TTL)) {
    try {
      const raw = await AsyncStorage.getItem(key);
      if (!raw) continue;
      const items: any[] = JSON.parse(raw);
      if (!Array.isArray(items)) continue;

      const filtered = items.filter((item: any) => {
        const ts = item.timestamp || item.recordedAt || item.createdAt || item.dataUpdatedAt || item.triggeredAt;
        if (!ts) return true; // 无时间戳保留
        const itemTime = new Date(ts).getTime();
        return now - itemTime < ttl;
      });

      if (filtered.length < items.length) {
        cleaned += items.length - filtered.length;
        await AsyncStorage.setItem(key, JSON.stringify(filtered));
      }
    } catch { /* 静默 */ }
  }

  return { cleaned };
}
