/**
 * 管理员 API 服务层（数据池版）
 * 所有数据读取统一走 GlobalStore，确保管理员看到真实用户数据
 *
 * 修复要点:
 * - getAdminStats 真实计算 verifiedUsers/unverifiedUsers/newUsersThisWeek
 * - adminResetPassword 真实更新 @ing_registered_users 中的密码
 * - forceUnbind 真实解绑绑定关系 + 拉黑所有联系人
 * - auditRegister 真实改变用户状态
 * - updateFunctionPermission 持久化到 AsyncStorage
 * - getUserFullData 从多个数据源真实组装
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { GlobalStore, type StoreUser } from './globalDataStore';
import { publishAnnouncement, getAllAnnouncements } from './announcement';
import { api } from './apiClient';
import { USE_REAL_API } from './apiConfig';
import type {
  AdminStats, AdminOperationLog, UserFullData, FunctionPermission,
  PhoneData, LocationHistoryPoint, LotteryConfig, LotteryPrize,
} from '../types';

const delay = (ms = 300) => new Promise((r) => setTimeout(r, ms));

// ====== 审计日志（本地独立存储） ======
const AUDIT_KEY = '@ing_admin_audit_logs';

// ====== 功能权限存储键 ======
const PERMISSIONS_KEY = '@ing_admin_function_permissions';

interface AuditEntry {
  id: string;
  adminId: string;
  adminName: string;
  action: string;
  targetUserId?: string;
  targetUsername?: string;
  detail?: string;
  timestamp: string;
}

export async function appendAudit(entry: Omit<AuditEntry, 'id' | 'timestamp'>): Promise<void> {
  const raw = await AsyncStorage.getItem(AUDIT_KEY);
  const logs: AuditEntry[] = raw ? JSON.parse(raw) : [];
  logs.unshift({
    ...entry,
    id: 'audit_' + Date.now(),
    timestamp: new Date().toISOString(),
  });
  // 保留最近1000条（原500扩大一倍）
  if (logs.length > 1000) logs.length = 1000;
  await AsyncStorage.setItem(AUDIT_KEY, JSON.stringify(logs));
}

// ====== 审计日志定期清理（超过90天自动清除） ======
export async function cleanupOldAuditLogs(): Promise<number> {
  const raw = await AsyncStorage.getItem(AUDIT_KEY);
  if (!raw) return 0;
  const logs: AuditEntry[] = JSON.parse(raw);
  const cutoff = Date.now() - 90 * 86400000;
  const before = logs.length;
  const filtered = logs.filter((l) => new Date(l.timestamp).getTime() > cutoff);
  if (filtered.length < before) {
    await AsyncStorage.setItem(AUDIT_KEY, JSON.stringify(filtered));
  }
  return before - filtered.length;
}

export async function getAuditLogs(): Promise<AdminOperationLog[]> {
  // 加载前先清理过期日志
  await cleanupOldAuditLogs();
  const raw = await AsyncStorage.getItem(AUDIT_KEY);
  return raw ? JSON.parse(raw) : [];
}

// ====== 后台统计（实时从GlobalStore + 注册表计算） ======

export async function getAdminStats(): Promise<AdminStats> {
  await delay(200);
  const [
    totalUsers, onlineUsers, sosToday, activeToday, posts,
    registeredUsers,
  ] = await Promise.all([
    GlobalStore.getTotalUsers(),
    GlobalStore.getOnlineUsers(),
    GlobalStore.getSOSToday(),
    GlobalStore.getActiveUsersToday(),
    GlobalStore.getTotalSpacePosts(),
    (async () => {
      try {
        const raw = await AsyncStorage.getItem('@ing_registered_users');
        return raw ? JSON.parse(raw) : [];
      } catch { return []; }
    })(),
  ]);

  // 真实计算实名用户和未实名用户
  let verifiedUsers = 0;
  let unverifiedUsers = 0;
  for (const u of registeredUsers) {
    if (u.realNameStatus === 'verified' || u.realNameStatus === '已认证') {
      verifiedUsers++;
    } else {
      unverifiedUsers++;
    }
  }

  // 计算本周新增用户
  const now = Date.now();
  const weekAgo = now - 7 * 86400000;
  let newUsersThisWeek = 0;
  for (const u of registeredUsers) {
    if (new Date(u.createdAt).getTime() >= weekAgo) {
      newUsersThisWeek++;
    }
  }

  return {
    totalUsers,
    onlineUsers,
    verifiedUsers,
    unverifiedUsers,
    sosToday,
    activeUsersToday: activeToday,
    newUsersThisWeek,
    totalSpacePosts: posts,
  };
}

// ====== 用户列表（从GlobalStore读取 + 注册表补充） ======

export async function getAllUsersBrief(): Promise<{
  userId: string; username: string; phone: string; role: string;
  status: string; realNameStatus: string; isOnline: boolean; lastActive: string;
}[]> {
  await delay(300);
  const users = await GlobalStore.users.getAll();

  // 如果GlobalStore为空，尝试从注册表补充
  if (users.length === 0) {
    try {
      const raw = await AsyncStorage.getItem('@ing_registered_users');
      if (raw) {
        const regUsers = JSON.parse(raw);
        return regUsers.map((u: any) => ({
          userId: u.userId,
          username: u.username,
          phone: u.phone,
          role: u.role,
          status: u.status || 'active',
          realNameStatus: u.realNameStatus || '未认证',
          isOnline: false,
          lastActive: u.updatedAt || u.createdAt || new Date().toISOString(),
        }));
      }
    } catch { /* fall through */ }
  }

  return users.map((u) => ({
    userId: u.userId,
    username: u.username,
    phone: u.phone,
    role: u.role,
    status: u.status,
    realNameStatus: u.realNameStatus,
    isOnline: u.isOnline,
    lastActive: u.lastActive,
  }));
}

// ====== 用户完整数据 ======

export async function getUserFullData(userId: string): Promise<UserFullData> {
  await delay(400);
  const [user, sosRecords, posts, phoneList, regUsers] = await Promise.all([
    (await GlobalStore.users.getAll()).find((u) => u.userId === userId) || null,
    GlobalStore.sos.getByUser(userId),
    GlobalStore.spacePosts.getByUser(userId),
    GlobalStore.phoneUsage.getByUser(userId),
    (async () => {
      try {
        const raw = await AsyncStorage.getItem('@ing_registered_users');
        return raw ? JSON.parse(raw) : [];
      } catch { return []; }
    })(),
  ]);

  // 从注册表获取User的额外信息
  const regUser = regUsers.find((u: any) => u.userId === userId);

  return {
    basicInfo: {
      userId: user?.userId || userId,
      username: user?.username || regUser?.username || '',
      avatar: regUser?.avatar || null,
      bio: regUser?.bio || '',
      gender: regUser?.gender || ('hidden' as const),
      level: regUser?.level || 0,
      totalMinutes: regUser?.totalMinutes || 0,
      location: regUser?.location || '',
      birthday: regUser?.birthday || null,
      createdAt: user?.createdAt || regUser?.createdAt || new Date().toISOString(),
      updatedAt: user?.lastActive || regUser?.updatedAt || new Date().toISOString(),
      lastBirthdayEdit: regUser?.lastBirthdayEdit || null,
    },
    bindings: [],
    bindRequests: [],
    contacts: [],
    locationHistory: [],
    sosRecords: sosRecords.map((s) => ({
      id: s.id,
      triggeredAt: s.triggeredAt,
      status: s.status,
      address: s.address,
      latitude: s.location?.latitude || 0,
      longitude: s.location?.longitude || 0,
    })),
    spacePosts: posts.map((p: any) => ({
      id: p.id,
      authorId: p.authorId || p.ownerId,
      authorName: p.authorName,
      content: p.content || '',
      visibility: p.visibility || 'public',
      media: p.media || [],
      likes: p.likes || [],
      comments: p.comments || [],
      createdAt: p.createdAt || new Date().toISOString(),
      isReported: p.isReported || false,
    })),
    phoneUsage: phoneList[0] || null,
    permissions: {
      userId,
      canSOS: true, canLocation: true, canMessage: true,
      canDiary: true, canSpacePost: true,
    },
    albumItems: [],
    wallMessages: [],
    redemptionRecords: [],
  } as unknown as UserFullData;
}

// ====== 功能权限管理（持久化到AsyncStorage） ======

async function loadAllPermissions(): Promise<FunctionPermission[]> {
  const raw = await AsyncStorage.getItem(PERMISSIONS_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function saveAllPermissions(perms: FunctionPermission[]): Promise<void> {
  await AsyncStorage.setItem(PERMISSIONS_KEY, JSON.stringify(perms));
}

export async function getFunctionPermission(userId: string): Promise<FunctionPermission> {
  const all = await loadAllPermissions();
  const existing = all.find((p) => p.userId === userId);
  return existing || {
    userId, canSOS: true, canLocation: true, canMessage: true, canDiary: true, canSpacePost: true,
  };
}

export async function updateFunctionPermission(
  adminId: string, adminName: string, permission: FunctionPermission,
): Promise<void> {
  await delay(300);

  // 持久化权限
  const all = await loadAllPermissions();
  const idx = all.findIndex((p) => p.userId === permission.userId);
  if (idx >= 0) {
    all[idx] = permission;
  } else {
    all.push(permission);
  }
  await saveAllPermissions(all);

  await appendAudit({
    adminId, adminName, action: 'update_permission',
    targetUserId: permission.userId, targetUsername: '',
    detail: JSON.stringify(permission),
  });
}

// ====== 手机使用数据 ======

export async function getPhoneData(userId: string): Promise<PhoneData> {
  await delay(300);
  const list = await GlobalStore.phoneUsage.getByUser(userId);
  if (list.length > 0) return list[0] as unknown as PhoneData;
  return {
    userId,
    username: '', phone: '',
    chargeCount: 0, appUsageMinutes: 0,
    appStartCount: 0, appStopCount: 0,
    lastChargeAt: '', batteryHealth: '未知',
    screenTimePerDay: 0,
    foregroundRecords: [], backgroundRecords: [],
    dataUpdatedAt: new Date().toISOString(),
  };
}

export async function getAllUsersPhoneUsage() {
  await delay(300);
  const users = await GlobalStore.phoneUsage.getAll();
  const avgScreen = users.length > 0
    ? Math.round(users.reduce((s, u) => s + u.screenTimePerDay, 0) / users.length) : 0;
  const avgApp = users.length > 0
    ? Math.round(users.reduce((s, u) => s + u.appUsageMinutes, 0) / users.length) : 0;
  return { totalUsers: users.length, avgScreenTimePerDay: avgScreen, avgAppUsageMinutes: avgApp, users };
}

export async function getPhoneUsageByTimeRange(
  userId: string, start: string, end: string,
): Promise<PhoneData | null> {
  const pd = await getPhoneData(userId);
  if (!pd || !pd.dataUpdatedAt) return pd;

  // 如果指定了时间范围，过滤前台/后台记录
  if (start || end) {
    const startTs = start ? new Date(start).getTime() : 0;
    const endTs = end ? new Date(end).getTime() : Date.now() + 86400000;

    pd.foregroundRecords = (pd.foregroundRecords || []).filter((r) => {
      const t = new Date(r.startTime).getTime();
      return t >= startTs && t <= endTs;
    });
    pd.backgroundRecords = (pd.backgroundRecords || []).filter((r) => {
      const t = new Date(r.startTime).getTime();
      return t >= startTs && t <= endTs;
    });
  }

  return pd;
}

// ====== 离线GPS ======

export async function getOfflineGPS(userId: string): Promise<LocationHistoryPoint[]> {
  await delay(200);
  try {
    const raw = await AsyncStorage.getItem('@ing_location_history');
    if (!raw) return [];
    const all: LocationHistoryPoint[] = JSON.parse(raw);
    return all.filter((p: any) => p.userId === userId);
  } catch { return []; }
}

// ====== 管理员操作（真实生效） ======

/**
 * 管理员重置用户密码 — 真实更新 @ing_registered_users 中的密码
 */
export async function adminResetPassword(
  adminId: string, adminName: string, targetUserId: string, targetUsername: string,
): Promise<{ success: boolean; newPassword?: string }> {
  await delay(500);
  const newPwd = Math.random().toString(36).slice(-8);

  // 真实更新注册表中的密码
  try {
    const raw = await AsyncStorage.getItem('@ing_registered_users');
    if (raw) {
      const users = JSON.parse(raw);
      const user = users.find((u: any) => u.userId === targetUserId);
      if (user) {
        user.password = newPwd;
        user.updatedAt = new Date().toISOString();
        await AsyncStorage.setItem('@ing_registered_users', JSON.stringify(users));
        console.log(`[管理员] 已重置 ${targetUsername} 的密码`);
      }
    }
  } catch { /* 降级 */ }

  await appendAudit({
    adminId, adminName, action: 'reset_password',
    targetUserId, targetUsername,
    detail: `密码已重置为 ${newPwd}`,
  });
  return { success: true, newPassword: newPwd };
}

/**
 * 管理员强制解绑用户关系 — 真实解除管理员绑定 + 拉黑所有联系人
 */
export async function forceUnbind(
  adminId: string, adminName: string, targetUserId: string, targetUsername: string, reason: string,
): Promise<boolean> {
  await delay(500);

  // 1. 解除用户的管理员绑定
  try {
    const { unbindFromAdmin } = await import('./bindingService');
    await unbindFromAdmin(targetUserId);
  } catch { /* 降级 */ }

  // 2. 获取用户的所有联系人并逐一拉黑
  try {
    const { getContacts, blockUser } = await import('./contacts');
    const contacts = await getContacts();
    const userContacts = contacts.filter(
      (c: any) => c.userId === targetUserId || c.ownerId === targetUserId,
    );
    for (const c of userContacts) {
      try {
        await blockUser(targetUserId, c.userId, reason);
      } catch { /* 单个失败不阻塞 */ }
    }
  } catch { /* 降级 */ }

  await appendAudit({
    adminId, adminName, action: 'force_unbind',
    targetUserId, targetUsername,
    detail: reason,
  });
  return true;
}

/**
 * 审核注册 — 真实改变用户状态
 */
export async function auditRegister(
  adminId: string, adminName: string, userId: string, username: string, approved: boolean,
): Promise<void> {
  await delay(300);

  // 真实更新注册表中的用户状态
  try {
    const raw = await AsyncStorage.getItem('@ing_registered_users');
    if (raw) {
      const users = JSON.parse(raw);
      const user = users.find((u: any) => u.userId === userId);
      if (user) {
        user.status = approved ? 'active' : 'disabled';
        user.updatedAt = new Date().toISOString();
        await AsyncStorage.setItem('@ing_registered_users', JSON.stringify(users));
      }
    }
  } catch { /* 降级 */ }

  // 同步更新GlobalStore
  try {
    await GlobalStore.users.update(userId, {
      status: approved ? 'active' : 'disabled',
      lastActive: new Date().toISOString(),
    } as any);
  } catch { /* 降级 */ }

  await appendAudit({
    adminId, adminName,
    action: approved ? 'approve_register' : 'reject_register',
    targetUserId: userId, targetUsername: username,
    detail: approved ? '通过注册审核' : '驳回注册',
  });
}

/**
 * 管理员注销用户账号（完整清理版）
 * 标记deleted + 全量清理数据 + 加入30天自动清除计划
 */
export async function deleteUser(
  adminId: string, adminName: string, targetUserId: string, targetUsername: string,
): Promise<boolean> {
  await delay(400);

  // 1. 标记用户为deleted
  try {
    const raw = await AsyncStorage.getItem('@ing_registered_users');
    if (raw) {
      const users = JSON.parse(raw);
      const idx = users.findIndex((u: any) => u.userId === targetUserId);
      if (idx >= 0) {
        users[idx].status = 'deleted';
        users[idx].updatedAt = new Date().toISOString();
        users[idx].deactivatedAt = new Date().toISOString();
        await AsyncStorage.setItem('@ing_registered_users', JSON.stringify(users));
      }
    }
  } catch {}

  // 2. 同步更新GlobalStore用户状态
  try {
    await GlobalStore.users.update(targetUserId, { status: 'deleted' } as any);
  } catch {}

  // 3. 全量清理用户所有关联数据
  try {
    const { purgeAllUserData, scheduleAutoPurge } = await import('./deactivationService');
    await purgeAllUserData(targetUserId);
    await scheduleAutoPurge(targetUserId, targetUsername, '管理员操作');
  } catch {}

  // 4. 解除管理员绑定
  try {
    const { unbindFromAdmin } = await import('./bindingService');
    await unbindFromAdmin(targetUserId);
  } catch {}

  await appendAudit({
    adminId, adminName, action: 'delete_user' as any,
    targetUserId, targetUsername,
    detail: '管理员注销用户账号，全量数据已清理，30天后永久删除',
  });
  return true;
}

/**
 * 管理员编辑用户基础信息
 */
export async function updateUserBasicInfo(
  adminId: string, adminName: string,
  targetUserId: string, targetUsername: string,
  updates: { username?: string; bio?: string; location?: string; birthday?: string; gender?: string },
): Promise<boolean> {
  await delay(300);

  // 更新注册表中的用户信息
  try {
    const raw = await AsyncStorage.getItem('@ing_registered_users');
    if (raw) {
      const users = JSON.parse(raw);
      const idx = users.findIndex((u: any) => u.userId === targetUserId);
      if (idx >= 0) {
        if (updates.username) users[idx].username = updates.username;
        if (updates.bio !== undefined) users[idx].bio = updates.bio;
        if (updates.location !== undefined) users[idx].location = updates.location;
        if (updates.birthday !== undefined) users[idx].birthday = updates.birthday;
        if (updates.gender !== undefined) users[idx].gender = updates.gender;
        users[idx].updatedAt = new Date().toISOString();
        await AsyncStorage.setItem('@ing_registered_users', JSON.stringify(users));
      }
    }
  } catch { /* 降级 */ }

  // 同步更新GlobalStore
  try {
    const gdsUpdates: any = { lastActive: new Date().toISOString() };
    if (updates.username) gdsUpdates.username = updates.username;
    await GlobalStore.users.update(targetUserId, gdsUpdates);
  } catch { /* 降级 */ }

  await appendAudit({
    adminId, adminName, action: 'edit_user_info' as any,
    targetUserId, targetUsername,
    detail: JSON.stringify(updates),
  });
  return true;
}

// ====== 公告管理（统一走 announcement 服务） ======

export async function publishAdminAnnouncement(
  _adminId: string,
  _adminName: string,
  params: { title: string; content: string; level: string; publishedBy?: string },
): Promise<any> {
  await delay(200);
  const ann = await publishAnnouncement(
    params.title,
    params.content,
    params.level as 'normal' | 'important' | 'urgent',
    params.publishedBy || _adminName,
  );
  await appendAudit({ adminId: _adminId, adminName: _adminName, action: 'publish_announcement', detail: ann.title });
  return ann;
}

export async function getAdminAnnouncements(): Promise<any[]> {
  return getAllAnnouncements();
}

// ====== 抽奖管理 ======

const LOTTERY_CONFIG_KEY = '@ing_admin_lottery_config';
const LOTTERY_APPS_KEY = '@ing_admin_lottery_apps';
const LOTTERY_RECORDS_KEY = '@ing_admin_lottery_records';
const LOTTERY_USER_RULES_KEY = '@ing_admin_lottery_user_rules';

export async function getLotteryConfig(): Promise<LotteryConfig> {
  const raw = await AsyncStorage.getItem(LOTTERY_CONFIG_KEY);
  if (raw) {
    const parsed = JSON.parse(raw);
    return {
      id: parsed.id || 'default',
      status: parsed.status || 'inactive',
      prizes: (parsed.prizes || []).map((p: any) => ({
        id: p.id,
        name: p.name,
        imageUri: p.imageUri || null,
        totalCount: p.totalCount || 0,
        remainingCount: p.remainingCount ?? p.totalCount,
        probability: p.probability || 0,
      })),
      maxDrawsPerDay: parsed.maxDrawsPerDay ?? 3,
      startAt: parsed.startAt || '',
      endAt: parsed.endAt || '',
    };
  }
  return { id: 'default', status: 'inactive', prizes: [], maxDrawsPerDay: 3, startAt: '', endAt: '' };
}

export async function updateLotteryConfig(config: LotteryConfig): Promise<void> {
  if (USE_REAL_API) {
    try {
      const res = await api.post('/admin/lottery/config', {
        status: config.status,
        maxDrawsPerDay: config.maxDrawsPerDay,
        startAt: config.startAt || null,
        endAt: config.endAt || null,
        prizes: config.prizes.map((p) => ({
          id: p.id,
          name: p.name,
          type: p.type || 'virtual',
          totalCount: p.totalCount,
          remainingCount: p.remainingCount ?? p.totalCount,
          probability: p.probability,
        })),
      });
      if (res.code === 200) {
        await AsyncStorage.setItem(LOTTERY_CONFIG_KEY, JSON.stringify(config));
        await appendAudit({ adminId: 'admin', adminName: '管理员', action: 'update_lottery', detail: '更新抽奖配置(已同步服务端)' });
        return;
      }
    } catch { /* 网络失败降级到本地 */ }
  }
  await AsyncStorage.setItem(LOTTERY_CONFIG_KEY, JSON.stringify(config));
  await appendAudit({ adminId: 'admin', adminName: '管理员', action: 'update_lottery', detail: '更新抽奖配置(仅本地离线)' });
}

export async function getLotteryApplications(): Promise<any[]> {
  const raw = await AsyncStorage.getItem(LOTTERY_APPS_KEY);
  return raw ? JSON.parse(raw) : [];
}

export async function processLotteryApplication(appId: string, approved: boolean): Promise<void> {
  const apps = await getLotteryApplications();
  const idx = apps.findIndex((a: any) => a.id === appId);
  if (idx >= 0) {
    apps[idx].result = approved ? 'won' : 'lost';
    await AsyncStorage.setItem(LOTTERY_APPS_KEY, JSON.stringify(apps));
  }
}

// ====== 中奖记录管理 ======

export interface LotteryRecord {
  id: string;
  userId: string;
  username: string;
  prizeName: string;
  wonAt: string;
}

export async function getLotteryRecords(page = 1, pageSize = 20): Promise<{ records: LotteryRecord[]; total: number }> {
  const raw = await AsyncStorage.getItem(LOTTERY_RECORDS_KEY);
  const all: LotteryRecord[] = raw ? JSON.parse(raw) : [];
  const total = all.length;
  const start = (page - 1) * pageSize;
  const records = all.slice(start, start + pageSize);
  return { records, total };
}

export async function addLotteryRecord(record: Omit<LotteryRecord, 'id' | 'wonAt'>): Promise<void> {
  const raw = await AsyncStorage.getItem(LOTTERY_RECORDS_KEY);
  const all: LotteryRecord[] = raw ? JSON.parse(raw) : [];
  all.unshift({
    ...record,
    id: 'lr_' + Date.now(),
    wonAt: new Date().toISOString(),
  });
  if (all.length > 500) all.length = 500;
  await AsyncStorage.setItem(LOTTERY_RECORDS_KEY, JSON.stringify(all));
}

// ====== 用户专属规则 ======

export interface UserLotteryRule {
  id: string;
  userId: string;
  username: string;
  phone: string;
  prizes: LotteryPrize[];
  maxDrawsPerDay: number;
  isActive: boolean;
}

export async function getUserLotteryRules(): Promise<UserLotteryRule[]> {
  const raw = await AsyncStorage.getItem(LOTTERY_USER_RULES_KEY);
  return raw ? JSON.parse(raw) : [];
}

export async function saveUserLotteryRules(rules: UserLotteryRule[]): Promise<void> {
  if (USE_REAL_API) {
    try {
      for (const rule of rules) {
        await api.post('/admin/lottery/rules', {
          userId: rule.userId,
          prizeName: rule.prizes[0]?.name || '专属奖品',
          probability: rule.prizes[0]?.probability || 0.5,
          maxDraws: rule.maxDrawsPerDay,
          isActive: rule.isActive,
        });
      }
      await AsyncStorage.setItem(LOTTERY_USER_RULES_KEY, JSON.stringify(rules));
      return;
    } catch { /* 网络失败降级到本地 */ }
  }
  await AsyncStorage.setItem(LOTTERY_USER_RULES_KEY, JSON.stringify(rules));
}

export async function getUserLotteryRule(userId: string): Promise<UserLotteryRule | null> {
  const rules = await getUserLotteryRules();
  return rules.find((r) => r.userId === userId && r.isActive) || null;
}
