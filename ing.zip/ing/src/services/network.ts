/**
 * 网络状态监控 + 异常断网提示
 */

import { useState, useEffect } from 'react';
import { AppState, AppStateStatus } from 'react-native';

export type NetworkStatus = 'online' | 'offline' | 'unknown';

let currentStatus: NetworkStatus = 'unknown';
const listeners = new Set<(status: NetworkStatus) => void>();

// ====== AppState 监听（带清理） ======

let appStateSub: { remove: () => void } | null = null;
let intervalId: ReturnType<typeof setInterval> | null = null;

export function initNetworkMonitor(): void {
  if (appStateSub) return; // 已初始化，避免重复

  const handler = (nextState: AppStateStatus): void => {
    if (nextState === 'active') {
      checkNetwork();
    }
  };

  appStateSub = AppState.addEventListener('change', handler);
  checkNetwork();
  // 降低轮询频率：60s→120s，减少电量消耗
  intervalId = setInterval(checkNetwork, 120000);
}

export function destroyNetworkMonitor(): void {
  if (appStateSub) {
    appStateSub.remove();
    appStateSub = null;
  }
  if (intervalId) {
    clearInterval(intervalId);
    intervalId = null;
  }
}

// ====== 通知 ======

function notifyStatus(status: NetworkStatus): void {
  currentStatus = status;
  listeners.forEach((cb) => cb(status));
}

// ====== 网络检测（适配中国网络环境） ======

async function checkNetwork(): Promise<void> {
  try {
    // AbortController 在部分 Hermes 版本中可能不可用，做兼容处理
    let controller: AbortController | null = null;
    let timer: ReturnType<typeof setTimeout> | null = null;

    try {
      controller = new AbortController();
      timer = setTimeout(() => controller?.abort(), 5000);
    } catch {
      // AbortController 不可用 → 降级为普通 fetch
    }

    const fetchOptions: RequestInit = { method: 'HEAD' };
    if (controller) {
      fetchOptions.signal = controller.signal;
    }

    // 使用百度 CDN 检测（Google 在中国不可达）
    const response = await fetch('https://www.baidu.com/favicon.ico', fetchOptions);
    if (timer) clearTimeout(timer);
    notifyStatus(response.ok ? 'online' : 'offline');
  } catch {
    notifyStatus('offline');
  }
}

// ====== 状态查询 ======

export function getNetworkStatus(): NetworkStatus {
  return currentStatus;
}

export function addNetworkListener(cb: (status: NetworkStatus) => void): () => void {
  listeners.add(cb);
  return () => { listeners.delete(cb); };
}

// ====== React Hook ======

export function useNetworkStatus(): NetworkStatus {
  const [status, setStatus] = useState<NetworkStatus>(currentStatus);

  useEffect(() => {
    const unsub = addNetworkListener(setStatus);
    return unsub;
  }, []);

  return status;
}

// ====== fetch 包装器（超时 + 重试 + 统一持久化离线队列） ======

interface FetchOptions extends RequestInit {
  timeout?: number;
  retries?: number;
}

export async function fetchWithTimeout(url: string, options: FetchOptions = {}): Promise<Response> {
  const { timeout = 8000, retries = 2, ...fetchOptions } = options;

  // 离线 → 写入统一持久化队列
  if (currentStatus === 'offline') {
    const { enqueueRequest } = await import('../utils/offlineQueue');
    await enqueueRequest({
      method: (fetchOptions.method as any) || 'GET',
      url,
      body: fetchOptions.body ? (typeof fetchOptions.body === 'string' ? fetchOptions.body : undefined) : undefined,
      headers: fetchOptions.headers ? (fetchOptions.headers as Record<string, string>) : undefined,
      priority: 'normal',
    });
    throw new Error('离线状态，请求已加入队列');
  }

  let lastError: Error | null = null;
  for (let i = 0; i <= retries; i++) {
    try {
      let controller: AbortController | null = null;
      let timer: ReturnType<typeof setTimeout> | null = null;
      const reqOptions: RequestInit = { ...fetchOptions };

      try {
        controller = new AbortController();
        timer = setTimeout(() => controller?.abort(), timeout);
        reqOptions.signal = controller.signal;
      } catch {
        // AbortController 不可用，不使用超时控制
      }

      const response = await fetch(url, reqOptions);
      if (timer) clearTimeout(timer);
      if (!response.ok && i < retries) {
        await new Promise((r) => setTimeout(r, 1000 * Math.pow(2, i)));
        continue;
      }
      return response;
    } catch (error) {
      lastError = error as Error;
      if (i < retries) {
        await new Promise((r) => setTimeout(r, 1000 * Math.pow(2, i)));
      }
    }
  }
  throw lastError || new Error('请求失败');
}

// 网络恢复时自动重放离线队列 + SOS补发
addNetworkListener((status) => {
  if (status === 'online') {
    // 重放统一持久化离线队列
    import('../utils/offlineQueue').then(({ replayAllOfflineRequests }) => {
      replayAllOfflineRequests().catch(() => {});
    }).catch(() => {});
    // 补发离线缓存的SOS请求
    import('./sos').then(({ processOfflineSOSQueue }) => {
      processOfflineSOSQueue().catch(() => {});
    }).catch(() => {});
  }
});
