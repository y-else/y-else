/**
 * 统一权限管理服务（安卓专属）
 *
 * 权限状态检查 / 批量请求 / 强制始终允许 / 阻塞引导 / 持久化缓存
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform, Linking, PermissionsAndroid } from 'react-native';
import * as Location from 'expo-location';

// ====== 类型定义 ======

export type PermissionState = 'granted' | 'denied' | 'blocked';

export interface UnifiedPermissions {
  locationForeground: PermissionState;
  locationBackground: PermissionState;
  notification: PermissionState;
  storage: PermissionState;
}

// ====== 持久化键 ======

const ALL_GRANTED_KEY = '@ing_all_permissions_granted';
const PERMISSION_DENIAL_LOG_KEY = '@ing_permission_denial_log';

// ====== 权限被拒埋点 ======

export interface PermissionDenialEvent {
  permission: string;
  platform: string;
  status: PermissionState;
  canAskAgain: boolean;
  timestamp: string;
}

export async function trackPermissionDenial(
  permission: string,
  status: PermissionState,
  canAskAgain: boolean,
): Promise<void> {
  const event: PermissionDenialEvent = {
    permission,
    platform: 'android',
    status,
    canAskAgain,
    timestamp: new Date().toISOString(),
  };
  try {
    const raw = await AsyncStorage.getItem(PERMISSION_DENIAL_LOG_KEY);
    const log: PermissionDenialEvent[] = raw ? JSON.parse(raw) : [];
    log.push(event);
    const trimmed = log.length > 200 ? log.slice(-200) : log;
    await AsyncStorage.setItem(PERMISSION_DENIAL_LOG_KEY, JSON.stringify(trimmed));
  } catch { /* 静默 */ }
}

export async function getPermissionDenialLog(): Promise<PermissionDenialEvent[]> {
  try {
    const raw = await AsyncStorage.getItem(PERMISSION_DENIAL_LOG_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

export async function getPermissionDenialStats(): Promise<Record<string, { total: number; blocked: number }>> {
  const log = await getPermissionDenialLog();
  const stats: Record<string, { total: number; blocked: number }> = {};
  for (const e of log) {
    if (!stats[e.permission]) stats[e.permission] = { total: 0, blocked: 0 };
    stats[e.permission].total++;
    if (e.status === 'blocked') stats[e.permission].blocked++;
  }
  return stats;
}

// ====== 持久化缓存 ======

export async function isAllPermissionsGranted(): Promise<boolean> {
  try {
    const raw = await AsyncStorage.getItem(ALL_GRANTED_KEY);
    return raw === 'true';
  } catch { return false; }
}

async function markAllPermissionsGranted(): Promise<void> {
  try { await AsyncStorage.setItem(ALL_GRANTED_KEY, 'true'); } catch {}
}

export async function clearPermissionsGrantedMark(): Promise<void> {
  try { await AsyncStorage.removeItem(ALL_GRANTED_KEY); } catch {}
}

// ====== 跳转系统设置 ======

export function openAppSettings(): void {
  try {
    Linking.openSettings();
  } catch {}
}

// ====== 检查所有权限状态 ======

export async function checkAllPermissions(): Promise<UnifiedPermissions> {
  const result: UnifiedPermissions = {
    locationForeground: 'denied',
    locationBackground: 'denied',
    notification: 'denied',
    storage: 'denied',
  };

  try {
    // 前台定位
    const fg = await Location.getForegroundPermissionsAsync();
    result.locationForeground = fg.status === 'granted' ? 'granted'
      : fg.canAskAgain ? 'denied' : 'blocked';
    if (result.locationForeground !== 'granted') {
      trackPermissionDenial('locationForeground', result.locationForeground, fg.canAskAgain);
    }

    // 后台定位（安卓原生）
    const bg = await Location.getBackgroundPermissionsAsync();
    result.locationBackground = bg.status === 'granted' ? 'granted'
      : bg.canAskAgain ? 'denied' : 'blocked';
    if (result.locationBackground !== 'granted') {
      trackPermissionDenial('locationBackground', result.locationBackground, true);
    }

    // 通知权限
    const notifState = await checkNotificationPermission();
    result.notification = notifState;

    // 存储权限（Android 13以下需要）
    if (Platform.Version < 33) {
      try {
        const granted = await PermissionsAndroid.request(
          'android.permission.WRITE_EXTERNAL_STORAGE' as any,
          {
            title: '存储权限',
            message: '需要存储权限以保存相册和缓存数据',
            buttonPositive: '始终允许',
            buttonNegative: '拒绝',
          },
        );
        result.storage = granted === 'granted' ? 'granted' : 'denied';
      } catch {
        result.storage = 'granted';
      }
    } else {
      result.storage = 'granted';
    }
  } catch {}

  return result;
}

async function checkNotificationPermission(): Promise<PermissionState> {
  try {
    const checkResult = await PermissionsAndroid.check(
      'android.permission.POST_NOTIFICATIONS' as any,
    );
    return checkResult ? 'granted' : 'denied';
  } catch {
    return 'denied';
  }
}

// ====== 状态判定 ======

export function areAllGranted(perms: UnifiedPermissions): boolean {
  return (
    perms.locationForeground === 'granted' &&
    perms.locationBackground === 'granted' &&
    perms.notification === 'granted' &&
    perms.storage === 'granted'
  );
}

export function getMissingPermissions(perms: UnifiedPermissions): string[] {
  const missing: string[] = [];
  if (perms.locationForeground !== 'granted') missing.push('精准定位（前台）');
  if (perms.locationBackground !== 'granted') missing.push('后台定位');
  if (perms.notification !== 'granted') missing.push('通知推送');
  if (perms.storage !== 'granted') missing.push('设备存储');
  return missing;
}

export function hasBlockedPermission(perms: UnifiedPermissions): boolean {
  return (
    perms.locationForeground === 'blocked' ||
    perms.locationBackground === 'blocked' ||
    perms.notification === 'blocked' ||
    perms.storage === 'blocked'
  );
}

// ====== 请求所有权限 ======

export async function requestAllPermissions(): Promise<UnifiedPermissions> {
  await Location.requestForegroundPermissionsAsync();
  await Location.requestBackgroundPermissionsAsync();

  // 通知权限
  try {
    await PermissionsAndroid.request(
      'android.permission.POST_NOTIFICATIONS' as any,
      {
        title: '通知权限',
        message: '需要通知权限接收SOS提醒',
        buttonPositive: '允许',
        buttonNegative: '拒绝',
      },
    );
  } catch {}

  // 存储权限（Android 13以下）
  if (Platform.Version < 33) {
    try {
      await PermissionsAndroid.request(
        'android.permission.WRITE_EXTERNAL_STORAGE' as any,
        {
          title: '存储权限',
          message: '需要存储权限以保存相册和缓存数据',
          buttonPositive: '允许',
          buttonNegative: '拒绝',
        },
      );
    } catch {}
  }

  const result = await checkAllPermissions();
  if (areAllGranted(result)) {
    await markAllPermissionsGranted();
  }
  return result;
}

// ====== 强制定位始终允许 ======

export async function forceLocationAlwaysPermission(): Promise<{
  granted: boolean;
  blocked: boolean;
}> {
  const fg = await Location.requestForegroundPermissionsAsync();
  if (fg.status !== 'granted') {
    return { granted: false, blocked: !fg.canAskAgain };
  }

  const bg = await Location.requestBackgroundPermissionsAsync();
  if (bg.status !== 'granted') {
    return { granted: false, blocked: !bg.canAskAgain };
  }

  return { granted: true, blocked: false };
}

// ====== 权限被拒阻塞提示 ======

export function showPermissionBlockedAlert(permissionType: '定位' | '通知'): void {
  const { Alert } = require('react-native');
  Alert.alert(
    `${permissionType}权限已禁用`,
    `为了保障您的安全和正常使用 APP 功能，需要始终允许${permissionType}权限。\n\n请前往系统设置中开启"始终允许"。`,
    [
      { text: '退出应用', style: 'cancel' },
      { text: '前往设置', onPress: () => openAppSettings() },
    ],
    { cancelable: false },
  );
}

// ====== Android 原生通知权限请求 ======

export async function requestAndroidNotificationPermission(): Promise<boolean> {
  try {
    const result = await PermissionsAndroid.request(
      'android.permission.POST_NOTIFICATIONS' as any,
      {
        title: '通知权限',
        message: '需要通知权限以接收 SOS 求救提醒和重要消息',
        buttonPositive: '允许',
        buttonNegative: '拒绝',
      },
    );
    return result === 'granted';
  } catch {
    return false;
  }
}
