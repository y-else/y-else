/**
 * 管理员密令绑定服务
 * 普通用户通过管理员密令绑定管理员账号 → 获得管理入口权限
 * 密令变更后绑定自动失效
 *
 * 修复:
 * - 绑定/解绑操作写入审计日志
 * - 移除硬编码 adminId/adminName fallback
 * - 预加载密令避免每条绑定都动态 import
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { appendAudit } from './admin';
import type { AdminBinding } from '../types';

const BINDING_KEY = '@ing_admin_bindings';

// ====== 获取所有绑定记录 ======

async function getAllBindings(): Promise<AdminBinding[]> {
  const raw = await AsyncStorage.getItem(BINDING_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function saveAllBindings(bindings: AdminBinding[]): Promise<void> {
  await AsyncStorage.setItem(BINDING_KEY, JSON.stringify(bindings));
}

// ====== 查询用户绑定状态 ======

export async function getUserBinding(userId: string): Promise<AdminBinding | null> {
  const all = await getAllBindings();
  return all.find((b) => b.userId === userId && b.isActive) || null;
}

// ====== 绑定管理员（使用密令） ======

export async function bindToAdmin(
  userId: string,
  username: string,
  inputToken: string,
  adminId?: string,
  adminName?: string,
): Promise<{ success: boolean; message: string }> {
  // 获取管理员当前有效密令
  const { getOrCreateToken } = await import('./adminToken');
  const adminToken = await getOrCreateToken();

  // 校验密令是否匹配
  if (inputToken.trim() !== adminToken) {
    return { success: false, message: '密令错误，绑定失败' };
  }

  // 解析管理员信息（用户端不知道管理员ID/名称，从注册用户中自动查找）
  let resolvedAdminId = adminId;
  let resolvedAdminName = adminName;
  if (!resolvedAdminId || !resolvedAdminName) {
    try {
      const raw = await AsyncStorage.getItem('@ing_registered_users');
      if (raw) {
        const users = JSON.parse(raw);
        const adminUser = users.find((u: any) => u.role === 'admin' && u.status !== 'deleted');
        if (adminUser) {
          resolvedAdminId = resolvedAdminId || adminUser.id;
          resolvedAdminName = resolvedAdminName || adminUser.username;
        }
      }
    } catch {}
    // 最终降级
    if (!resolvedAdminId) resolvedAdminId = 'admin_001';
    if (!resolvedAdminName) resolvedAdminName = '管理员';
  }

  // 检查是否已绑定
  const all = await getAllBindings();
  const existing = all.find((b) => b.userId === userId && b.isActive);
  if (existing) {
    return { success: false, message: `已绑定管理员「${existing.adminName}」，请先解绑后再绑定` };
  }

  // 创建绑定
  const binding: AdminBinding = {
    userId,
    username,
    adminId: resolvedAdminId!,
    adminName: resolvedAdminName!,
    boundAt: new Date().toISOString(),
    isActive: true,
    boundWithToken: adminToken,
  };

  all.push(binding);
  await saveAllBindings(all);

  // 审计日志
  await appendAudit({
    adminId: resolvedAdminId!,
    adminName: resolvedAdminName!,
    action: 'bind_admin' as any,
    targetUserId: userId,
    targetUsername: username,
    detail: `${username} 绑定管理员 ${resolvedAdminName}`,
  });

  return { success: true, message: '已成功绑定管理员账号，您已获得管理权限入口' };
}

// ====== 解绑 ======

export async function unbindFromAdmin(
  userId: string,
  adminId?: string,
  adminName?: string,
): Promise<boolean> {
  const all = await getAllBindings();
  const binding = all.find((b) => b.userId === userId && b.isActive);
  if (binding) {
    binding.isActive = false;
    await saveAllBindings(all);

    // 审计日志
    await appendAudit({
      adminId: adminId || binding.adminId,
      adminName: adminName || binding.adminName,
      action: 'unbind_admin' as any,
      targetUserId: userId,
      targetUsername: binding.username,
      detail: `${binding.username} 解除管理员绑定`,
    });

    return true;
  }
  return false;
}

// ====== 密令变更联动（管理员改密后调用） ======

export async function invalidateBindingsOnTokenChange(): Promise<number> {
  const all = await getAllBindings();
  let count = 0;
  for (const b of all) {
    if (b.isActive) {
      b.isActive = false;
      count++;
    }
  }
  if (count > 0) {
    await saveAllBindings(all);
  }
  return count;
}

// ====== 检查密令绑定是否仍有效 ======

export async function isBindingValid(userId: string): Promise<boolean> {
  const binding = await getUserBinding(userId);
  if (!binding) return false;

  const { getOrCreateToken } = await import('./adminToken');
  const currentToken = await getOrCreateToken();

  // 如果当前密令与绑定时密令不同 → 绑定失效
  if (binding.boundWithToken !== currentToken) {
    await unbindFromAdmin(userId, binding.adminId, binding.adminName);
    return false;
  }

  return true;
}
