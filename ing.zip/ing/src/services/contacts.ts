/**
 * 通讯录 + 绑定 + 拉黑 API 服务层（持久化版）
 * 基于 AsyncStorage 持久化，支持 GlobalStore 数据池互通
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { GlobalStore } from './globalDataStore';
import { emitBindingChange } from './websocketClient';
import type {
  Contact, ContactGroup, BindRequest, BindRequestStatus,
  UnbindNotification, UnbindRequest, BindNotification, BlockRecord, QuickMessage, OnlineStatus,
} from '../types';

const CONTACTS_KEY = '@ing_contacts';
const BIND_REQUESTS_KEY = '@ing_bind_requests';

const delay = (ms = 200) => new Promise((r) => setTimeout(r, ms));

// ====== 手机号脱敏工具 ======

export function maskPhone(phone: string): string {
  if (!phone) return '';
  // 已脱敏则直接返回
  if (phone.includes('****')) return phone;
  // 中国大陆手机号 11 位脱敏
  if (/^1\d{10}$/.test(phone)) {
    return phone.slice(0, 3) + '****' + phone.slice(7);
  }
  // 其他号码：保留前3后2
  if (phone.length >= 6) {
    const stars = '*'.repeat(Math.min(phone.length - 5, 4));
    return phone.slice(0, 3) + stars + phone.slice(-2);
  }
  return phone;
}

// ====== 联系人排序（置顶 > 最近联系时间降序 > 姓名首字母A-Z） ======

function getFirstLetter(name: string): string {
  if (!name) return '#';
  const first = name.charAt(0).toUpperCase();
  if (/[A-Z]/.test(first)) return first;
  return '#';
}

export function sortContacts(contacts: Contact[]): Contact[] {
  return [...contacts].sort((a, b) => {
    // 置顶优先
    if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1;
    // 最近联系时间降序
    if (a.lastContactAt !== b.lastContactAt) {
      return new Date(b.lastContactAt).getTime() - new Date(a.lastContactAt).getTime();
    }
    // 姓名首字母A-Z
    const la = getFirstLetter(a.remark || a.username);
    const lb = getFirstLetter(b.remark || b.username);
    if (la !== lb) return la === '#' ? 1 : lb === '#' ? -1 : la.localeCompare(lb);
    return (a.remark || a.username).localeCompare(b.remark || b.username, 'zh-Hans');
  });
}

// ====== 持久化读写 ======

async function readContacts(): Promise<Contact[]> {
  try {
    const raw = await AsyncStorage.getItem(CONTACTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

async function writeContacts(contacts: Contact[]): Promise<void> {
  try {
    await AsyncStorage.setItem(CONTACTS_KEY, JSON.stringify(contacts));
  } catch (e) {
    console.warn('[通讯录] 写入失败:', e);
  }
}

// ====== 快捷消息预设 ======

const QUICK_MESSAGES: QuickMessage[] = [
  { id: 'qm_1', text: '你好，很高兴认识你', category: 'greeting' },
  { id: 'qm_2', text: '今天过得怎么样？', category: 'care' },
  { id: 'qm_3', text: '记得按时吃饭哦', category: 'care' },
  { id: 'qm_4', text: '我想你了', category: 'care' },
  { id: 'qm_5', text: '注意安全！', category: 'emergency' },
  { id: 'qm_6', text: '需要帮忙吗？', category: 'emergency' },
  { id: 'qm_7', text: '好的，收到', category: 'greeting' },
  { id: 'qm_8', text: '晚安，好梦', category: 'care' },
];

// ====== 通讯录 CRUD ======

export async function getContacts(): Promise<Contact[]> {
  await delay(100);
  const contacts = await readContacts();
  return sortContacts(contacts);
}

export async function getContactById(userId: string): Promise<Contact | null> {
  await delay(50);
  const contacts = await readContacts();
  return contacts.find((c) => c.userId === userId) || null;
}

/** 向通讯录添加联系人（去重） */
export async function addContact(contact: Contact): Promise<void> {
  const contacts = await readContacts();
  const exists = contacts.findIndex((c) => c.userId === contact.userId);
  // 确保手机号已脱敏
  const safe = { ...contact, phone: maskPhone(contact.phone || contact.rawPhone) };
  if (exists >= 0) {
    contacts[exists] = { ...contacts[exists], ...safe };
  } else {
    contacts.unshift(safe);
  }
  await writeContacts(contacts);
}

// ====== 模糊搜索 ======

export async function searchContacts(query: string): Promise<Contact[]> {
  await delay(50);
  const q = query.toLowerCase().trim();
  if (!q) return getContacts();

  const contacts = await readContacts();
  const matched = contacts.filter(
    (c) =>
      c.username.toLowerCase().includes(q) ||
      c.phone.includes(q) ||
      c.rawPhone?.includes(q) ||
      (c.remark && c.remark.toLowerCase().includes(q)),
  );
  // 搜索结果保持原排序，不额外重排
  return matched;
}

// ====== 联系人操作 ======

export async function togglePin(userId: string): Promise<Contact | null> {
  const contacts = await readContacts();
  const c = contacts.find((c) => c.userId === userId);
  if (c) {
    c.isPinned = !c.isPinned;
    await writeContacts(contacts);
  }
  return c || null;
}

export async function setRemark(userId: string, remark: string): Promise<boolean> {
  const contacts = await readContacts();
  const c = contacts.find((c) => c.userId === userId);
  if (c) {
    c.remark = remark.trim() || null;
    await writeContacts(contacts);
    return true;
  }
  return false;
}

/** 批量删除联系人（原子操作：先验证全部存在，再一次性删除） */
export async function deleteContacts(userIds: string[]): Promise<{ success: boolean; deleted: number }> {
  const contacts = await readContacts();
  const before = contacts.length;
  const remaining = contacts.filter((c) => !userIds.includes(c.userId));
  const deleted = before - remaining.length;
  if (deleted > 0) {
    await writeContacts(remaining);
  }
  return { success: true, deleted };
}

/** 批量置顶/取消置顶 */
export async function batchTogglePin(userIds: string[], pinned: boolean): Promise<number> {
  const contacts = await readContacts();
  let count = 0;
  for (const c of contacts) {
    if (userIds.includes(c.userId) && c.isPinned !== pinned) {
      c.isPinned = pinned;
      count++;
    }
  }
  if (count > 0) await writeContacts(contacts);
  return count;
}

// ====== 绑定 ======

async function readBindRequests(): Promise<BindRequest[]> {
  try {
    const raw = await AsyncStorage.getItem(BIND_REQUESTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

async function writeBindRequests(reqs: BindRequest[]): Promise<void> {
  try {
    await AsyncStorage.setItem(BIND_REQUESTS_KEY, JSON.stringify(reqs));
  } catch (e) { console.warn('[绑定] 写入失败:', e); }
}

// ====== 解绑请求持久化 ======

const UNBIND_REQUESTS_KEY = '@ing_unbind_requests';

async function readUnbindRequests(): Promise<UnbindRequest[]> {
  try {
    const raw = await AsyncStorage.getItem(UNBIND_REQUESTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

async function writeUnbindRequests(reqs: UnbindRequest[]): Promise<void> {
  try {
    await AsyncStorage.setItem(UNBIND_REQUESTS_KEY, JSON.stringify(reqs));
  } catch (e) { console.warn('[解绑] 写入失败:', e); }
}

// ====== 系统通知持久化 ======

const NOTIFICATIONS_KEY = '@ing_bind_notifications';

async function readNotifications(): Promise<BindNotification[]> {
  try {
    const raw = await AsyncStorage.getItem(NOTIFICATIONS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

async function writeNotifications(notifs: BindNotification[]): Promise<void> {
  try {
    await AsyncStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(notifs));
  } catch (e) { console.warn('[通知] 写入失败:', e); }
}

/** 创建系统通知并持久化 */
async function createNotification(
  type: BindNotification['type'],
  fromUserId: string,
  fromUsername: string,
  toUserId: string,
  toUsername: string,
  relationType: ContactGroup,
  message: string,
): Promise<BindNotification> {
  const notif: BindNotification = {
    id: 'notif_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
    type, fromUserId, fromUsername, toUserId, toUsername,
    relationType, message, isRead: false,
    createdAt: new Date().toISOString(),
  };
  const all = await readNotifications();
  all.unshift(notif);
  if (all.length > 200) all.length = 200;
  await writeNotifications(all);
  // 更新未读角标
  try {
    const { addUnread } = await import('./unreadBadge');
    await addUnread('userInteraction');
  } catch {}
  return notif;
}

/** 从GlobalStore获取用户信息 */
async function getUserInfo(userId: string): Promise<{ username: string; phone: string; avatar: string | null } | null> {
  const users = await GlobalStore.users.getAll();
  const user = users.find((u) => u.userId === userId);
  if (!user) return null;
  return { username: user.username, phone: user.phone, avatar: null };
}

// ====== 手机号搜索绑定 ======

export async function searchByPhone(
  phone: string,
  currentUserId?: string,
): Promise<{
  found: boolean; username?: string; userId?: string; avatar?: string | null; alreadyBound?: boolean;
}> {
  await delay(300);
  const users = await GlobalStore.users.getAll();

  // 排除自己
  const candidate = currentUserId
    ? users.find((u) => u.phone === phone && u.userId !== currentUserId)
    : users.find((u) => u.phone === phone);

  if (!candidate) return { found: false };

  // 检查是否已在通讯录中（非拉黑状态）
  const contacts = await readContacts();
  const alreadyBound = contacts.some(
    (c) => c.userId === candidate.userId && !c.isBlocked,
  );

  return {
    found: true,
    username: candidate.username,
    userId: candidate.userId,
    avatar: null,
    alreadyBound,
  };
}

// ====== 发送绑定请求 ======

export async function sendBindRequest(
  fromUserId: string,
  fromUsername: string,
  fromPhone: string,
  fromAvatar: string | null,
  toUserId: string,
  type: ContactGroup,
  message: string,
): Promise<BindRequest> {
  await delay(400);

  // 1. 禁止自绑定
  if (fromUserId === toUserId) {
    throw new Error('无法绑定自己，请输入他人的手机号');
  }

  // 2. 检查是否已在通讯录中（非拉黑）
  const contacts = await readContacts();
  const alreadyBound = contacts.find(
    (c) => c.userId === toUserId && !c.isBlocked,
  );
  if (alreadyBound) {
    throw new Error(`「${alreadyBound.remark || alreadyBound.username}」已在您的通讯录中，无需重复绑定`);
  }

  // 3. 双向查重：检查是否已有待处理的绑定请求
  const allReqs = await readBindRequests();
  const duplicate = allReqs.find(
    (r) =>
      r.status === 'pending' &&
      ((r.fromUserId === fromUserId && r.toUserId === toUserId) ||
       (r.fromUserId === toUserId && r.toUserId === fromUserId)),
  );
  if (duplicate) {
    throw new Error('已存在待处理的绑定请求，请等待对方处理后再试');
  }

  // 4. 恋人唯一绑定校验（既查已接受关系，也查待处理请求）
  if (type === 'lover') {
    // 4a. 检查发起者是否已有恋人
    const existingLover = contacts.find(
      (c) => c.group === 'lover' && !c.isBlocked,
    );
    if (existingLover) {
      throw new Error(
        `您已绑定恋人「${existingLover.remark || existingLover.username}」，恋人关系仅支持同时绑定一位对象。`,
      );
    }

    // 4b. 检查发起者是否有待处理的恋人请求（发送或收到）
    const pendingLover = allReqs.find(
      (r) =>
        r.type === 'lover' &&
        r.status === 'pending' &&
        (r.fromUserId === fromUserId || r.toUserId === fromUserId),
    );
    if (pendingLover) {
      throw new Error('您已有待处理的恋人绑定请求，请先处理后再发起新请求');
    }
  }
  // 5. 家人/朋友无人数上限 — 不校验

  // 6. 从GlobalStore获取目标用户信息
  const targetInfo = await getUserInfo(toUserId);
  const toUsername = targetInfo?.username || '未知用户';
  const toPhone = targetInfo?.phone ? maskPhone(targetInfo.phone) : '****';

  // 7. 创建绑定请求
  const req: BindRequest = {
    id: 'bind_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
    fromUserId, fromUsername, fromPhone, fromAvatar,
    toUserId, toUsername, toPhone,
    type, status: 'pending', message,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  allReqs.push(req);
  await writeBindRequests(allReqs);

  // 8. 给对方发送系统通知
  const typeLabel = type === 'family' ? '家人' : type === 'friend' ? '朋友' : '恋人';
  await createNotification(
    'bind_request',
    fromUserId, fromUsername,
    toUserId, toUsername,
    type,
    `${fromUsername} 请求添加您为${typeLabel}：${message || '请求添加为联系人'}`,
  );

  // WS实时推送：通知目标用户有新绑定请求
  try {
    emitBindingChange({ fromUserId, fromUsername, toUserId, changeType: 'request', bindingType: type === 'blocked' ? 'friend' : type, message });
  } catch {}

  return req;
}

// ====== 响应绑定请求（接受/拒绝） ======

export async function respondBindRequest(
  requestId: string,
  accept: boolean,
): Promise<BindRequest | null> {
  await delay(300);
  const all = await readBindRequests();
  const req = all.find((r) => r.id === requestId);

  if (!req) {
    throw new Error('绑定请求不存在');
  }
  if (req.status !== 'pending') {
    throw new Error('该请求已处理，无法重复操作');
  }

  if (accept) {
    // 接受时必须校验恋人唯一性
    if (req.type === 'lover') {
      const contacts = await readContacts();
      const existingLover = contacts.find(
        (c) => c.group === 'lover' && !c.isBlocked,
      );
      if (existingLover) {
        throw new Error(
          `您已绑定恋人「${existingLover.remark || existingLover.username}」，恋人关系仅支持同时绑定一位对象。\n\n请先解绑后再接受新请求。`,
        );
      }
    }

    // 创建双向联系人记录
    const contacts = await readContacts();
    const now = new Date().toISOString();

    const makeContact = (userId: string, username: string, phone: string, avatar: string | null): Contact => ({
      userId,
      username,
      phone: maskPhone(phone),
      rawPhone: phone,
      avatar,
      role: 'friend',
      group: req.type,
      remark: null,
      status: 'offline' as const,
      lastOnlineAt: now,
      isPinned: false,
      lastContactAt: now,
      isBlocked: false,
      blockedAt: null,
      lastKnownLocation: null,
    });

    // 为发起方添加目标用户
    const fromIdx = contacts.findIndex((c) => c.userId === req.toUserId);
    if (fromIdx >= 0) {
      // 之前可能是blocked状态，恢复
      contacts[fromIdx] = { ...contacts[fromIdx], ...makeContact(req.toUserId, req.toUsername, req.toPhone, null), isBlocked: false, group: req.type };
    } else {
      contacts.unshift(makeContact(req.toUserId, req.toUsername, req.toPhone, null));
    }

    // 为接受方添加发起用户
    const toIdx = contacts.findIndex((c) => c.userId === req.fromUserId);
    if (toIdx >= 0) {
      contacts[toIdx] = { ...contacts[toIdx], ...makeContact(req.fromUserId, req.fromUsername, req.fromPhone, req.fromAvatar), isBlocked: false, group: req.type };
    } else {
      contacts.unshift(makeContact(req.fromUserId, req.fromUsername, req.fromPhone, req.fromAvatar));
    }

    await writeContacts(contacts);

    // 同步写入GlobalStore.BINDINGS
    try {
      const bindingId1 = 'gb_' + Date.now() + '_a';
      const bindingId2 = 'gb_' + (Date.now() + 1) + '_b';
      await GlobalStore.bindings.add({
        id: bindingId1, fromUserId: req.fromUserId, fromUsername: req.fromUsername,
        toUserId: req.toUserId, toUsername: req.toUsername,
        type: req.type === 'blocked' ? 'friend' : req.type, status: 'accepted',
        createdAt: now, updatedAt: now,
      });
      await GlobalStore.bindings.add({
        id: bindingId2, fromUserId: req.toUserId, fromUsername: req.toUsername,
        toUserId: req.fromUserId, toUsername: req.fromUsername,
        type: req.type === 'blocked' ? 'friend' : req.type, status: 'accepted',
        createdAt: now, updatedAt: now,
      });
    } catch { /* GlobalStore写入失败不影响主流程 */ }

    req.status = 'accepted';
    req.updatedAt = now;
    await writeBindRequests(all);

    // 通知发起方：请求已接受
    const typeLabel = req.type === 'family' ? '家人' : req.type === 'friend' ? '朋友' : '恋人';
    await createNotification(
      'bind_accepted',
      req.toUserId, req.toUsername,
      req.fromUserId, req.fromUsername,
      req.type,
      `${req.toUsername} 已接受您的${typeLabel}绑定请求`,
    );
  } else {
    // 拒绝
    req.status = 'rejected';
    req.updatedAt = new Date().toISOString();
    await writeBindRequests(all);

    const typeLabel = req.type === 'family' ? '家人' : req.type === 'friend' ? '朋友' : '恋人';
    await createNotification(
      'bind_rejected',
      req.toUserId, req.toUsername,
      req.fromUserId, req.fromUsername,
      req.type,
      `${req.toUsername} 拒绝了您的${typeLabel}绑定请求`,
    );
  }

  // WS实时推送：通知绑定关系变更
  try {
    emitBindingChange({
      fromUserId: req.toUserId,
      fromUsername: req.toUsername,
      toUserId: req.fromUserId,
      changeType: req.status,
      bindingType: req.type === 'blocked' ? 'friend' : req.type,
    });
  } catch {}

  return req;
}

// ====== 取消绑定请求 ======

export async function cancelBindRequest(requestId: string): Promise<boolean> {
  const all = await readBindRequests();
  const req = all.find((r) => r.id === requestId);
  if (!req || req.status !== 'pending') return false;

  req.status = 'cancelled';
  req.updatedAt = new Date().toISOString();
  await writeBindRequests(all);

  await createNotification(
    'bind_cancelled',
    req.fromUserId, req.fromUsername,
    req.toUserId, req.toUsername,
    req.type,
    `${req.fromUsername} 已取消绑定请求`,
  );

  return true;
}

// ====== 获取绑定请求 ======

export async function getPendingBindRequests(userId: string): Promise<BindRequest[]> {
  await delay(200);
  const all = await readBindRequests();
  return all.filter((r) => r.toUserId === userId && r.status === 'pending');
}

/** 获取自己发出的待处理请求 */
export async function getSentBindRequests(userId: string): Promise<BindRequest[]> {
  await delay(200);
  const all = await readBindRequests();
  return all.filter((r) => r.fromUserId === userId && r.status === 'pending');
}

/** 获取所有与自己相关的待处理请求（收+发） */
export async function getAllPendingBindRequests(userId: string): Promise<{
  incoming: BindRequest[]; outgoing: BindRequest[];
}> {
  await delay(200);
  const all = await readBindRequests();
  return {
    incoming: all.filter((r) => r.toUserId === userId && r.status === 'pending'),
    outgoing: all.filter((r) => r.fromUserId === userId && r.status === 'pending'),
  };
}

// ====== 解绑 ======

export async function requestUnbind(
  fromUserId: string,
  fromUsername: string,
  targetUserId: string,
  targetUsername: string,
  relationType: ContactGroup,
): Promise<UnbindRequest> {
  await delay(300);

  // 1. 检查是否已存在待处理的解绑请求（防重复）
  const existing = await readUnbindRequests();
  const duplicate = existing.find(
    (r) =>
      r.fromUserId === fromUserId &&
      r.targetUserId === targetUserId &&
      r.status === 'pending',
  );
  if (duplicate) {
    throw new Error('已存在待处理的解绑请求，请等待对方确认');
  }

  // 2. 确认关系确实存在
  const contacts = await readContacts();
  const relation = contacts.find(
    (c) => c.userId === targetUserId && c.group === relationType && !c.isBlocked,
  );
  if (!relation) {
    throw new Error('未找到该绑定关系，可能已被解除');
  }

  // 3. 创建解绑请求并持久化
  const unbindReq: UnbindRequest = {
    id: 'unbind_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
    fromUserId, fromUsername,
    targetUserId, targetUsername,
    relationType,
    status: 'pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  existing.push(unbindReq);
  await writeUnbindRequests(existing);

  // 4. 通知对方
  const typeLabel = relationType === 'family' ? '家人' : relationType === 'friend' ? '朋友' : '恋人';
  await createNotification(
    'unbind_request',
    fromUserId, fromUsername,
    targetUserId, targetUsername,
    relationType,
    `${fromUsername} 请求解除与您的${typeLabel}关系，请确认`,
  );

  return unbindReq;
}

export async function confirmUnbind(requestId: string): Promise<{ success: boolean; message: string }> {
  await delay(200);

  const all = await readUnbindRequests();
  const req = all.find((r) => r.id === requestId);

  if (!req) {
    return { success: false, message: '解绑请求不存在' };
  }
  if (req.status !== 'pending') {
    return { success: false, message: '该解绑请求已处理' };
  }

  // 1. 更新解绑请求状态
  req.status = 'confirmed';
  req.updatedAt = new Date().toISOString();
  await writeUnbindRequests(all);

  // 2. 从通讯录中移除双方关系
  const contacts = await readContacts();
  const remaining = contacts.filter(
    (c) =>
      !((c.userId === req.targetUserId && c.group === req.relationType) ||
        (c.userId === req.fromUserId && c.group === req.relationType)),
  );
  await writeContacts(remaining);

  // 3. 同步移除GlobalStore中的绑定记录
  try {
    await GlobalStore.bindings.remove(
      (b: any) =>
        (b.userId === req.fromUserId && b.targetUserId === req.targetUserId && b.type === req.relationType) ||
        (b.userId === req.targetUserId && b.targetUserId === req.fromUserId && b.type === req.relationType),
    );
  } catch { /* 静默 */ }

  // 4. 通知双方
  const typeLabel = req.relationType === 'family' ? '家人' : req.relationType === 'friend' ? '朋友' : '恋人';
  await createNotification(
    'unbind_confirmed',
    req.fromUserId, req.fromUsername,
    req.targetUserId, req.targetUsername,
    req.relationType,
    `${req.targetUsername} 已确认解除与您的${typeLabel}关系`,
  );
  await createNotification(
    'unbind_confirmed',
    req.targetUserId, req.targetUsername,
    req.fromUserId, req.fromUsername,
    req.relationType,
    `您与 ${req.fromUsername} 的${typeLabel}关系已解除`,
  );

  return { success: true, message: '解绑成功' };
}

// ====== 系统通知查询 ======

/** 获取用户的所有系统通知（按时间倒序） */
export async function getBindNotifications(userId: string): Promise<BindNotification[]> {
  await delay(100);
  const all = await readNotifications();
  return all
    .filter((n) => n.toUserId === userId)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

/** 标记通知为已读 */
export async function markNotificationRead(notificationId: string): Promise<boolean> {
  const all = await readNotifications();
  const notif = all.find((n) => n.id === notificationId);
  if (notif) {
    notif.isRead = true;
    await writeNotifications(all);
    return true;
  }
  return false;
}

/** 获取未读通知数量 */
export async function getUnreadNotificationCount(userId: string): Promise<number> {
  const all = await readNotifications();
  return all.filter((n) => n.toUserId === userId && !n.isRead).length;
}

// ====== 拉黑/取消拉黑 ======

export async function blockUser(
  userId: string, blockedUserId: string, reason?: string,
): Promise<BlockRecord> {
  await delay(300);
  const contacts = await readContacts();
  let c = contacts.find((c) => c.userId === blockedUserId);

  // GPS冻结在拉黑前最后位置（尝试从定位历史获取）
  const frozenLocation = c?.lastKnownLocation || {
    latitude: 39.9150, longitude: 116.4040, address: '北京市东城区', updatedAt: new Date().toISOString(),
  };

  if (c) {
    c.isBlocked = true;
    c.group = 'blocked';
    c.blockedAt = new Date().toISOString();
    c.lastKnownLocation = { ...frozenLocation, updatedAt: new Date().toISOString() };
    c.status = 'offline'; // 拉黑后强制显示离线
  } else {
    // 被拉黑用户不在通讯录中，也添加到blocked分组
    const blocked: Contact = {
      userId: blockedUserId,
      username: '未知用户',
      phone: '****',
      rawPhone: '',
      avatar: null,
      role: 'friend' as any,
      group: 'blocked',
      remark: null,
      status: 'offline',
      lastOnlineAt: new Date().toISOString(),
      isPinned: false,
      lastContactAt: new Date().toISOString(),
      isBlocked: true,
      blockedAt: new Date().toISOString(),
      lastKnownLocation: { ...frozenLocation, updatedAt: new Date().toISOString() },
    };
    contacts.push(blocked);
  }
  await writeContacts(contacts);

  return {
    userId, blockedUserId,
    blockedUsername: c?.username || '未知用户',
    reason: reason || null,
    blockedAt: new Date().toISOString(),
    frozenLocation,
  };
}

export async function unblockUser(userId: string, blockedUserId: string): Promise<boolean> {
  await delay(300);
  const contacts = await readContacts();
  const c = contacts.find((c) => c.userId === blockedUserId);
  if (c) {
    c.isBlocked = false;
    c.blockedAt = null;
    c.lastKnownLocation = null;
    // 恢复到默认分组（无法知道原来分组，默认归入friend）
    c.group = 'friend';
    await writeContacts(contacts);
    return true;
  }
  return false;
}

export async function getBlockedUsers(): Promise<Contact[]> {
  await delay(100);
  const contacts = await readContacts();
  return contacts.filter((c) => c.isBlocked);
}

// ====== 快捷消息 ======

export async function getQuickMessages(): Promise<QuickMessage[]> {
  await delay(50);
  return [...QUICK_MESSAGES];
}

export async function sendQuickMessage(toUserId: string, message: QuickMessage): Promise<boolean> {
  await delay(150);
  const contacts = await readContacts();
  const c = contacts.find((c) => c.userId === toUserId);

  // 对方不存在于通讯录中
  if (!c) {
    console.log(`[快捷消息] 目标 ${toUserId} 不在通讯录中，跳过`);
    return false;
  }

  // 对方已被拉黑，禁止发送
  if (c.isBlocked) {
    console.log(`[快捷消息] 目标 ${toUserId} 已被拉黑，禁止发送`);
    return false;
  }

  // 更新最近联系时间
  c.lastContactAt = new Date().toISOString();
  await writeContacts(contacts);
  console.log(`[快捷消息] 发送给 ${toUserId}: ${message.text}`);
  return true;
}

// ====== 在线状态 ======

export async function getUserOnlineStatus(userId: string): Promise<{
  status: OnlineStatus; lastOnlineAt: string;
}> {
  await delay(50);
  const contacts = await readContacts();
  const c = contacts.find((c) => c.userId === userId);
  return {
    status: c?.status || 'offline',
    lastOnlineAt: c?.lastOnlineAt || new Date().toISOString(),
  };
}

/** 批量更新在线状态 */
export async function updateOnlineStatus(
  userId: string, status: OnlineStatus,
): Promise<void> {
  const contacts = await readContacts();
  const c = contacts.find((c) => c.userId === userId);
  if (c) {
    c.status = status;
    c.lastOnlineAt = new Date().toISOString();
    await writeContacts(contacts);
  }
}
