/**
 * 缓存管理器
 * 缓存统计、一键清理、存储空间统计、个人数据导出
 *
 * 修复:
 * - clearAppCache 匹配 @ing_ 前缀的临时key（之前匹配 _s_/_t_ 完全无效）
 * - 新增 getStorageStats 按类别统计存储空间
 * - exportUserData 正确筛选用户关联数据 + 返回可分享JSON
 * - 新增 getExportDataJson 获取导出数据字符串
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

// Hermes兼容字节计算（不使用TextEncoder）
function getByteLength(str: string): number {
  let len = 0;
  for (let i = 0; i < str.length; i++) {
    const code = str.charCodeAt(i);
    len += code < 0x80 ? 1 : code < 0x800 ? 2 : 3;
  }
  return len;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1048576).toFixed(1) + ' MB';
}

// ====== 存储空间统计 ======

export interface StorageStats {
  totalBytes: number;
  totalKeys: number;
  categories: {
    name: string;
    keys: number;
    bytes: number;
  }[];
}

/** 获取存储空间统计（按类别分组） */
export async function getStorageStats(): Promise<StorageStats> {
  const allKeys = await AsyncStorage.getAllKeys();
  let totalBytes = 0;

  const categoryRules: { name: string; match: (k: string) => boolean }[] = [
    { name: '用户账号', match: (k) => k === '@ing_accounts' || k === '@ing_current_user_id' || k === '@ing_registered_users' },
    { name: '个人资料', match: (k) => k.startsWith('@ing_profile_') || k.startsWith('@ing_user_addresses') || k.startsWith('@ing_wall_messages') },
    { name: '互动权限', match: (k) => k === '@ing_interaction_settings' },
    { name: '联系人', match: (k) => k.startsWith('@ing_contacts_') },
    { name: '消息', match: (k) => k.startsWith('@ing_messages_') },
    { name: '公告', match: (k) => k.startsWith('@ing_announcement') },
    { name: '出行记录', match: (k) => k === '@ing_travel_records' || k === '@ing_travel_shares' },
    { name: '健康记录', match: (k) => k.startsWith('@ing_health_') },
    { name: '日程', match: (k) => k.startsWith('@ing_schedule_') },
    { name: 'SOS记录', match: (k) => k === '@ing_sos_records' || k.startsWith('@ing_sos_') },
    { name: '空间动态', match: (k) => k.startsWith('@ing_space_posts') },
    { name: '举报记录', match: (k) => k === '@ing_content_reports' },
    { name: '反馈', match: (k) => k === '@ing_feedbacks' || k === '@ing_contact_admin_msgs' },
    { name: '绑定关系', match: (k) => k === '@ing_admin_bindings' || k === '@ing_admin_token' },
    { name: '兑换码', match: (k) => k.startsWith('@ing_redemption') },
    { name: '全局数据池', match: (k) => k.startsWith('@ing_gds_') },
    { name: '临时缓存', match: (k) => k.startsWith('@ing_export_') || k === '@ing_offline_queue' || k === '@ing_unread_badges' || k === '@ing_auth_logs' || k === '@ing_online_status' || k.startsWith('@ing_deactivation_codes') || k.startsWith('@ing_verification_codes') },
    { name: '隐私/版本', match: (k) => k.startsWith('@ing_privacy_') || k === '@ing_last_app_version' },
    { name: '其他', match: () => true },
  ];

  const categoryData: Map<string, { keys: number; bytes: number }> = new Map();

  for (const key of allKeys) {
    const val = await AsyncStorage.getItem(key);
    const bytes = val ? getByteLength(val) : 0;
    totalBytes += bytes;

    for (const rule of categoryRules) {
      if (rule.match(key)) {
        const existing = categoryData.get(rule.name) || { keys: 0, bytes: 0 };
        existing.keys++;
        existing.bytes += bytes;
        categoryData.set(rule.name, existing);
        break;
      }
    }
  }

  const categories = categoryRules
    .filter((r) => categoryData.has(r.name))
    .map((r) => ({ name: r.name, ...categoryData.get(r.name)! }));

  return { totalBytes, totalKeys: allKeys.length, categories };
}

// ====== 缓存清理 ======

/** 临时缓存key匹配规则（@ing_前缀） */
const TEMP_CACHE_PATTERNS = [
  '@ing_export_',        // 旧的数据导出
  '@ing_offline_queue',  // 离线队列
  '@ing_unread_badges',  // 未读角标缓存
  '@ing_auth_logs',      // 操作日志缓存
  '@ing_online_status',  // 在线状态缓存
  '@ing_deactivation_codes', // 注销验证码
  '@ing_verification_codes', // 通用验证码
  '@ing_gds_',           // 全局数据池（下次同步会重建）
];

/** 一键清理缓存（保留用户数据，仅清临时/派生数据） */
export async function clearAppCache(): Promise<{ removedKeys: number; freedBytes: number }> {
  const allKeys = await AsyncStorage.getAllKeys();
  const tempKeys = allKeys.filter((k) =>
    TEMP_CACHE_PATTERNS.some((p) => k.startsWith(p)),
  );

  let freedBytes = 0;
  for (const key of tempKeys) {
    const val = await AsyncStorage.getItem(key);
    if (val) freedBytes += getByteLength(val);
  }

  if (tempKeys.length > 0) {
    await AsyncStorage.multiRemove(tempKeys);
  }

  return { removedKeys: tempKeys.length, freedBytes };
}

// ====== 数据导出 ======

/** 用户数据相关的存储key前缀 */
const USER_DATA_PATTERNS: { category: string; key: string; filter: (k: string, userId: string) => boolean }[] = [
  { category: '个人资料', key: '@ing_profile_', filter: (k, uid) => k.includes(uid) },
  { category: '联系人', key: '@ing_contacts_', filter: (k, uid) => k.includes(uid) },
  { category: '空间动态', key: '@ing_space_posts', filter: (k, uid) => true }, // 整个key读取后按userId过滤
  { category: '消息', key: '@ing_messages_', filter: (k, uid) => k.includes(uid) },
  { category: '出行记录', key: '@ing_travel_records', filter: (k, uid) => true },
  { category: '出行共享', key: '@ing_travel_shares', filter: (k, uid) => true },
  { category: '健康记录', key: '@ing_health_', filter: (k, uid) => k.includes(uid) },
  { category: '日程', key: '@ing_schedule_', filter: (k, uid) => k.includes(uid) },
  { category: 'SOS记录', key: '@ing_sos_records', filter: (k, uid) => true },
  { category: '反馈', key: '@ing_feedbacks', filter: (k, uid) => true },
  { category: '互动权限', key: '@ing_interaction_settings', filter: (k, uid) => true },
  { category: '收货地址', key: '@ing_user_addresses', filter: (k, uid) => k.includes(uid) },
];

export interface ExportResult {
  totalEntries: number;
  totalBytes: number;
  exportedAt: string;
  /** 可分享的JSON字符串 */
  json: string;
}

/** 导出个人数据并返回可分享的结果 */
export async function exportUserData(userId: string): Promise<ExportResult> {
  const allKeys = await AsyncStorage.getAllKeys();

  // 先收集匹配key
  const matchedKeys = allKeys.filter((k) =>
    USER_DATA_PATTERNS.some((p) => k.startsWith(p.key)),
  );

  const exportData: Record<string, any> = {};
  let totalEntries = 0;
  let totalBytes = 0;

  for (const key of matchedKeys) {
    const val = await AsyncStorage.getItem(key);
    if (!val) continue;

    let parsed: any;
    try {
      parsed = JSON.parse(val);
    } catch {
      parsed = val;
    }

    // 对数组类型数据按userId筛选
    if (Array.isArray(parsed)) {
      const userItems = parsed.filter((item: any) =>
        item.userId === userId ||
        item.reporterId === userId ||
        item.senderId === userId ||
        item.ownerId === userId ||
        item.authorId === userId ||
        (typeof item === 'object' && JSON.stringify(item).includes(userId)),
      );
      if (userItems.length > 0) {
        const categoryName = USER_DATA_PATTERNS.find((p) => key.startsWith(p.key))?.category || key;
        exportData[categoryName] = userItems;
        totalEntries += userItems.length;
        const bytes = getByteLength(JSON.stringify(userItems));
        totalBytes += bytes;
      }
    } else if (parsed && typeof parsed === 'object' && parsed.userId === userId) {
      exportData[key] = parsed;
      totalEntries++;
      const bytes = getByteLength(JSON.stringify(parsed));
      totalBytes += bytes;
    } else if (parsed && typeof parsed === 'string' && parsed.includes(userId)) {
      exportData[key] = parsed;
      totalEntries++;
      totalBytes += getByteLength(parsed);
    }
  }

  const exportedAt = new Date().toISOString();
  const exportResult: ExportResult = {
    totalEntries,
    totalBytes,
    exportedAt,
    json: JSON.stringify({ exportedAt, userId, data: exportData }, null, 2),
  };

  // 持久化导出记录
  await AsyncStorage.setItem(
    '@ing_export_' + userId + '_' + Date.now(),
    JSON.stringify({ exportedAt, totalEntries, totalBytes }),
  );

  return exportResult;
}
