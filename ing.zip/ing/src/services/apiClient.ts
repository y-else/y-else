/**
 * 云端API统一请求层 v2
 * Token注入 / 超时重试 / 离线队列 / 请求去重 / 响应缓存
 * 配置来源: apiConfig.ts
 */

import { API_BASE_URL, REQUEST_TIMEOUT, RETRY_MAX } from './apiConfig';
import { logger } from '../utils/secureStorage';
import appJson from '../../app.json';

// 客户端版本（用于 X-Client-Version 请求头）
const CLIENT_VERSION = appJson.expo?.version || '1.0.0';

// ====== Token管理 ======

let authToken: string | null = null;

export function setAuthToken(token: string | null) {
  authToken = token;
}

export function getAuthToken(): string | null {
  return authToken;
}

// ====== 响应缓存（GET请求内存缓存，TTL 30秒） ======

interface CacheEntry {
  data: any;
  cachedAt: number;
}

const responseCache = new Map<string, CacheEntry>();
const CACHE_TTL_MS = 30000;

function getCacheKey(method: string, path: string, body?: any): string {
  return method + ':' + path + ':' + (body ? JSON.stringify(body) : '');
}

function getFromCache<T>(cacheKey: string): T | null {
  const entry = responseCache.get(cacheKey);
  if (!entry) return null;
  if (Date.now() - entry.cachedAt > CACHE_TTL_MS) {
    responseCache.delete(cacheKey);
    return null;
  }
  return entry.data as T;
}

function setCache<T>(cacheKey: string, data: T): void {
  responseCache.set(cacheKey, { data, cachedAt: Date.now() });
  // 缓存上限 200 条，超出清理最旧一半
  if (responseCache.size > 200) {
    const entries = Array.from(responseCache.entries());
    entries.sort((a, b) => a[1].cachedAt - b[1].cachedAt);
    entries.slice(0, 100).forEach(([k]) => responseCache.delete(k));
  }
}

/** 清除所有响应缓存（登录/登出/切账号时调用） */
export function clearResponseCache(): void {
  responseCache.clear();
}

/** 清除指定路径前缀的缓存 */
export function invalidateCache(pathPrefix: string): void {
  responseCache.forEach((_, key) => {
    if (key.includes(pathPrefix)) responseCache.delete(key);
  });
}

// ====== 统一请求 ======

interface ApiResponse<T = any> {
  code: number;
  message: string;
  data?: T;
}

const pendingRequests = new Map<string, Promise<any>>();

export async function apiRequest<T = any>(
  method: 'GET' | 'POST' | 'PUT' | 'DELETE',
  path: string,
  body?: any,
  retries = RETRY_MAX,
): Promise<ApiResponse<T>> {
  const url = API_BASE_URL + path;
  const cacheKey = getCacheKey(method, path, body);
  const requestKey = method + ':' + url + ':' + (body ? JSON.stringify(body) : '');

  // 请求去重（相同请求合并为一个Promise）
  const pending = pendingRequests.get(requestKey);
  if (pending) return pending;

  // GET请求：优先返回缓存
  if (method === 'GET') {
    const cached = getFromCache<ApiResponse<T>>(cacheKey);
    if (cached) return cached;
  }

  const doRequest = async (): Promise<ApiResponse<T>> => {
    const startTime = Date.now();
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), REQUEST_TIMEOUT);

    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        'X-Client-Version': CLIENT_VERSION,
      };
      if (authToken) headers['Authorization'] = 'Bearer ' + authToken;

      const options: RequestInit = { method, headers, signal: controller.signal };
      if (body && method !== 'GET') options.body = JSON.stringify(body);

      const response = await fetch(url, options);
      const duration = Date.now() - startTime;
      clearTimeout(timeoutId);

      // 记录 API 请求日志
      try { logger.api(method, path, response.status, duration); } catch {}

      // 401 → token 过期，清除 token 和缓存
      if (response.status === 401) {
        setAuthToken(null);
        clearResponseCache();
      }

      const json = await response.json();

      pendingRequests.delete(requestKey);

      // 成功响应缓存GET请求
      if (method === 'GET' && response.ok) {
        setCache(cacheKey, json);
      }

      return json;
    } catch (error: any) {
      const duration = Date.now() - startTime;
      clearTimeout(timeoutId);
      pendingRequests.delete(requestKey);

      // 记录失败日志
      try { logger.api(method, path, 0, duration); } catch {}

      if (error.name === 'AbortError' && retries > 0) {
        // 超时重试（指数退避）
        await new Promise(r => setTimeout(r, 1000 * (RETRY_MAX - retries + 1)));
        return apiRequest(method, path, body, retries - 1);
      }

      // 弱网→写统一持久化离线队列
      if (method !== 'GET' && retries === 0) {
        const { enqueueRequest } = await import('../utils/offlineQueue');
        await enqueueRequest({
          method,
          path,
          body,
          priority: path.includes('sos') ? 'high' : 'normal',
        });
      }

      return { code: 500, message: '网络异常，请稍后重试' };
    }
  };

  const promise = doRequest();
  pendingRequests.set(requestKey, promise);
  return promise;
}

// ====== 统一离线队列重放处理 ======

import { setReplayHandler } from '../utils/offlineQueue';

// 注册重放处理器：将 QueuedRequest 转换回 apiRequest 调用
setReplayHandler(async (req) => {
  if (req.path) {
    const result = await apiRequest(req.method, req.path, req.body, 0);
    return result.code !== 500;
  }
  if (req.url) {
    try {
      const resp = await fetch(req.url, { method: req.method, headers: req.headers, body: req.body });
      return resp.ok;
    } catch {
      return false;
    }
  }
  return false;
});

// ====== 快捷方法 ======

export const api = {
  get: <T = any>(path: string) => apiRequest<T>('GET', path),
  post: <T = any>(path: string, body?: any) => apiRequest<T>('POST', path, body),
  put: <T = any>(path: string, body?: any) => apiRequest<T>('PUT', path, body),
  delete: <T = any>(path: string) => apiRequest<T>('DELETE', path),
};
