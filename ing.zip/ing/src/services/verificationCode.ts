/**
 * 验证码服务 — 管理员审核式验证码体系
 * 用户申请 → 自动生成6位随机码 → 同步管理员后台 → 用户输入校验
 * 验证码与手机号+申请类型绑定，管理员可实时查看
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

const CODES_KEY = '@ing_verification_codes';

export type CodeRequestType = 'register' | 'reset_password';

export interface VerificationCodeEntry {
  id: string;
  phone: string;
  code: string;
  type: CodeRequestType;
  createdAt: string;
  isUsed: boolean;
}

// ====== 随机生成6位纯数字验证码 ======

function generateCode(): string {
  const bytes = new Uint8Array(6);
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < 6; i++) {
      bytes[i] = Math.floor(Math.random() * 256);
    }
  }
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += (bytes[i] % 10).toString();
  }
  return code;
}

// ====== 获取所有验证码记录 ======

async function getAllCodes(): Promise<VerificationCodeEntry[]> {
  const raw = await AsyncStorage.getItem(CODES_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function saveAllCodes(codes: VerificationCodeEntry[]): Promise<void> {
  await AsyncStorage.setItem(CODES_KEY, JSON.stringify(codes));
}

// ====== 申请验证码（用户端调用） ======

/**
 * 用户点击【向管理员申请验证码】
 * 自动生成6位验证码、持久化存储、返回验证码（管理员后台可同步查看）
 */
export async function requestVerificationCode(
  phone: string,
  type: CodeRequestType,
): Promise<{ success: boolean; message: string }> {
  if (!/^1[3-9]\d{9}$/.test(phone)) {
    return { success: false, message: '手机号格式不正确' };
  }

  // 检查是否已有未使用的同类型验证码（防止重复申请）
  const all = await getAllCodes();
  const existing = all.find(
    (c) => c.phone === phone && c.type === type && !c.isUsed,
  );
  if (existing) {
    // 已有未使用的验证码，直接返回（不重复生成）
    return {
      success: true,
      message: `验证码已生成，请输入收到的6位数字验证码（验证码: ${existing.code}）`,
    };
  }

  // 生成新验证码
  const code = generateCode();
  const entry: VerificationCodeEntry = {
    id: 'vc_' + Date.now(),
    phone,
    code,
    type,
    createdAt: new Date().toISOString(),
    isUsed: false,
  };

  all.push(entry);
  await saveAllCodes(all);

  console.log(`[验证码] 已生成: ${phone} (${type}) → ${code}`);
  return {
    success: true,
    message: `已向管理员申请验证码，请输入收到的6位数字`,
  };
}

// ====== 校验验证码（注册/改密时调用） ======

/**
 * 校验用户输入的验证码是否正确
 * 校验成功后标记验证码为已使用
 */
export async function verifyCode(
  phone: string,
  inputCode: string,
  type: CodeRequestType,
): Promise<{ valid: boolean; message: string }> {
  if (!inputCode || inputCode.length !== 6) {
    return { valid: false, message: '请输入6位验证码' };
  }

  const all = await getAllCodes();
  // 找最新一条匹配的未使用验证码
  const entry = all
    .filter((c) => c.phone === phone && c.type === type && !c.isUsed)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0];

  if (!entry) {
    return { valid: false, message: '验证码不正确，请重新输入' };
  }

  if (entry.code !== inputCode.trim()) {
    return { valid: false, message: '验证码不正确，请重新输入' };
  }

  // 校验成功 → 标记已使用
  entry.isUsed = true;
  await saveAllCodes(all);

  return { valid: true, message: '验证码正确' };
}

// ====== 管理员端：获取所有验证码列表 ======

/**
 * 管理员后台查看所有验证码申请记录
 */
export async function getAllVerificationCodes(): Promise<VerificationCodeEntry[]> {
  const all = await getAllCodes();
  return all.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );
}

/**
 * 管理员清除已使用的验证码（清理历史记录）
 */
export async function clearUsedCodes(): Promise<void> {
  const all = await getAllCodes();
  const unused = all.filter((c) => !c.isUsed);
  await saveAllCodes(unused);
}
