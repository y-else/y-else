/**
 * 每日签到 + 抽奖次数服务
 * 每日签到免费领取 1 次抽奖机会
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

const KEYS = {
  LAST_CHECKIN_DATE: '@ing_last_checkin_date',
  LOTTERY_CHANCES: '@ing_lottery_chances',
  CHECKIN_STREAK: '@ing_checkin_streak',
} as const;

const delay = (ms = 300) => new Promise((r) => setTimeout(r, ms));

// ====== 签到 ======

export async function checkInToday(): Promise<{
  success: boolean;
  message: string;
  chancesAdded: number;
  totalChances: number;
  streak: number;
}> {
  const today = new Date().toISOString().slice(0, 10);
  const lastDate = await AsyncStorage.getItem(KEYS.LAST_CHECKIN_DATE);

  if (lastDate === today) {
    const total = await getLotteryChances();
    const streak = await getStreak();
    return {
      success: false,
      message: '今日已签到，明天再来吧',
      chancesAdded: 0,
      totalChances: total,
      streak,
    };
  }

  // 计算连续签到
  let streak = await getStreak();
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  if (lastDate === yesterday) {
    streak += 1;
  } else {
    streak = 1;
  }

  // 增加 1 次抽奖机会
  const current = await getLotteryChances();
  const newTotal = current + 1;

  await AsyncStorage.setItem(KEYS.LAST_CHECKIN_DATE, today);
  await AsyncStorage.setItem(KEYS.LOTTERY_CHANCES, String(newTotal));
  await AsyncStorage.setItem(KEYS.CHECKIN_STREAK, String(streak));

  return {
    success: true,
    message: `签到成功！连续签到 ${streak} 天`,
    chancesAdded: 1,
    totalChances: newTotal,
    streak,
  };
}

export async function getCheckInStatus(): Promise<{
  checkedInToday: boolean;
  streak: number;
  totalChances: number;
}> {
  const today = new Date().toISOString().slice(0, 10);
  const lastDate = await AsyncStorage.getItem(KEYS.LAST_CHECKIN_DATE);
  const streak = await getStreak();
  const totalChances = await getLotteryChances();

  return {
    checkedInToday: lastDate === today,
    streak,
    totalChances,
  };
}

// ====== 抽奖次数 ======

export async function getLotteryChances(): Promise<number> {
  const raw = await AsyncStorage.getItem(KEYS.LOTTERY_CHANCES);
  return raw ? parseInt(raw, 10) : 0;
}

export async function consumeLotteryChance(): Promise<{
  success: boolean;
  remaining: number;
}> {
  const current = await getLotteryChances();
  if (current <= 0) {
    return { success: false, remaining: 0 };
  }
  const remaining = current - 1;
  await AsyncStorage.setItem(KEYS.LOTTERY_CHANCES, String(remaining));
  return { success: true, remaining };
}

export async function addLotteryChances(count: number): Promise<number> {
  const current = await getLotteryChances();
  const newTotal = current + count;
  await AsyncStorage.setItem(KEYS.LOTTERY_CHANCES, String(newTotal));
  return newTotal;
}

// ====== 连续签到 ======

async function getStreak(): Promise<number> {
  const raw = await AsyncStorage.getItem(KEYS.CHECKIN_STREAK);
  return raw ? parseInt(raw, 10) : 0;
}
