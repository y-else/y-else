/**
 * 兑换码服务
 * 生成/校验/兑换/记录管理
 * 密令特殊逻辑：输入密令时触发绑定流程，不执行兑换
 *
 * 修复:
 * - 所有管理员操作写入审计日志
 * - cancelRedemption 回退 redeemedCount
 * - 输入统一大写处理后比对
 * - createRedemptionCode 支持 validFrom
 * - 添加 search/filter/stats API
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { appendAudit } from './admin';
import type { RedemptionCode, RedemptionRecord, ShippingAddress, RedemptionStats } from '../types';

const CODES_KEY = '@ing_redemption_codes';
const RECORDS_KEY = '@ing_redemption_records';
const ADDRESSES_KEY = '@ing_user_addresses';

// ====== 存储操作 ======

async function getAllCodes(): Promise<RedemptionCode[]> {
  const raw = await AsyncStorage.getItem(CODES_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function saveAllCodes(codes: RedemptionCode[]): Promise<void> {
  await AsyncStorage.setItem(CODES_KEY, JSON.stringify(codes));
}

async function getAllRecords(): Promise<RedemptionRecord[]> {
  const raw = await AsyncStorage.getItem(RECORDS_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function saveAllRecords(records: RedemptionRecord[]): Promise<void> {
  await AsyncStorage.setItem(RECORDS_KEY, JSON.stringify(records));
}

// ====== 兑换码生成（管理员端） ======

function generateCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 剔除易混淆字符 I/O/0/1
  let code = '';
  for (let i = 0; i < 8; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

export async function createRedemptionCode(params: {
  rewardType: 'virtual' | 'physical';
  rewardName: string;
  rewardDescription: string;
  targetPhone: string | null;
  targetUserId: string | null;
  maxRedemptions: number;
  perUserLimit: number;
  validFrom: string;
  validUntil: string;
  createdBy: string;
  adminId?: string;
  adminName?: string;
}): Promise<RedemptionCode> {
  const all = await getAllCodes();

  // 生成唯一兑换码（大写）
  let code: string;
  let attempts = 0;
  do {
    code = generateCode();
    attempts++;
    if (attempts > 100) {
      // 极端情况：扩展到更大字符集避免碰撞
      code = generateCode() + generateCode().slice(0, 2);
    }
  } while (all.some((c) => c.code === code));

  const entry: RedemptionCode = {
    id: 'rc_' + Date.now(),
    code,
    rewardType: params.rewardType,
    rewardName: params.rewardName,
    rewardDescription: params.rewardDescription,
    targetPhone: params.targetPhone || null,
    targetUserId: params.targetUserId || null,
    maxRedemptions: params.maxRedemptions,
    redeemedCount: 0,
    perUserLimit: params.perUserLimit || 1,
    validFrom: params.validFrom || new Date().toISOString(),
    validUntil: params.validUntil,
    isActive: true,
    createdBy: params.createdBy,
    createdAt: new Date().toISOString(),
  };

  all.push(entry);
  await saveAllCodes(all);

  // 审计日志
  await appendAudit({
    adminId: params.adminId || 'admin',
    adminName: params.adminName || params.createdBy,
    action: 'create_redemption' as any,
    detail: `创建兑换码 ${code}（${params.rewardName} / ${params.rewardType}）`,
  });

  return entry;
}

// ====== 用户兑换 ======

export async function redeemCode(
  userId: string,
  username: string,
  phone: string,
  inputCode: string,
  shippingAddress?: ShippingAddress,
): Promise<{ success: boolean; message: string; isAdminToken?: boolean }> {
  const normalizedInput = inputCode.trim().toUpperCase();

  // 先检查是否为管理员密令
  try {
    const { getOrCreateToken } = await import('./adminToken');
    const adminToken = await getOrCreateToken();
    if (normalizedInput === adminToken.toUpperCase()) {
      return { success: false, message: 'ADMIN_TOKEN_DETECTED', isAdminToken: true };
    }
  } catch {}

  // 查找有效兑换码
  const all = await getAllCodes();
  const entry = all.find((c) => c.code === normalizedInput && c.isActive);
  if (!entry) {
    return { success: false, message: '兑换码无效或已作废' };
  }

  // 检查有效期
  const now = new Date();
  if (new Date(entry.validUntil) < now) {
    return { success: false, message: '兑换码已过期' };
  }
  if (new Date(entry.validFrom) > now) {
    return { success: false, message: '兑换码尚未生效' };
  }

  // 检查指定用户限制（手机号或用户ID）
  if (entry.targetUserId && entry.targetUserId !== userId) {
    return { success: false, message: '此兑换码仅限指定用户使用' };
  }
  if (entry.targetPhone && entry.targetPhone !== phone) {
    return { success: false, message: '此兑换码仅限指定用户使用' };
  }

  // 检查兑换次数上限
  if (entry.redeemedCount >= entry.maxRedemptions) {
    return { success: false, message: '兑换码已达使用上限' };
  }

  // 检查每人限兑
  const records = await getAllRecords();
  const userRedemptions = records.filter(
    (r) => r.codeId === entry.id && r.userId === userId && r.status === 'success',
  );
  if (userRedemptions.length >= entry.perUserLimit) {
    return { success: false, message: `您已兑换过此奖励（限${entry.perUserLimit}次）` };
  }

  // 实物奖励 → 必须填写地址
  if (entry.rewardType === 'physical' && !shippingAddress) {
    return { success: false, message: '实物奖励需要填写收货地址' };
  }

  // 执行兑换
  entry.redeemedCount++;
  await saveAllCodes(all);

  const record: RedemptionRecord = {
    id: 'rr_' + Date.now(),
    codeId: entry.id,
    code: entry.code,
    userId,
    username,
    phone,
    rewardType: entry.rewardType,
    rewardName: entry.rewardName,
    shippingAddress: shippingAddress || undefined,
    redeemedAt: new Date().toISOString(),
    status: 'success',
  };
  records.push(record);
  await saveAllRecords(records);

  // 审计日志
  await appendAudit({
    adminId: userId,
    adminName: username,
    action: 'redeem_code' as any,
    targetUserId: userId,
    targetUsername: username,
    detail: `兑换 ${entry.code} → ${entry.rewardName}`,
  });

  return {
    success: true,
    message: `兑换成功！获得${entry.rewardType === 'physical' ? '实物奖励' : '虚拟奖励'}：${entry.rewardName}`,
  };
}

// ====== 管理员端接口 ======

export async function getAllRedemptionCodes(): Promise<RedemptionCode[]> {
  return (await getAllCodes()).sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );
}

export async function getAllRedemptionRecords(): Promise<RedemptionRecord[]> {
  return (await getAllRecords()).sort(
    (a, b) => new Date(b.redeemedAt).getTime() - new Date(a.redeemedAt).getTime(),
  );
}

export async function getRedemptionRecordsByUser(userId: string): Promise<RedemptionRecord[]> {
  const records = await getAllRecords();
  return records
    .filter((r) => r.userId === userId)
    .sort((a, b) => new Date(b.redeemedAt).getTime() - new Date(a.redeemedAt).getTime());
}

/** 兑换码统计 */
export async function getRedemptionStats(): Promise<RedemptionStats> {
  const [codes, records] = await Promise.all([getAllCodes(), getAllRecords()]);
  const now = new Date();

  let activeCodes = 0;
  let exhaustedCodes = 0;
  let expiredCodes = 0;
  let inactiveCodes = 0;

  for (const c of codes) {
    if (!c.isActive) {
      inactiveCodes++;
    } else if (new Date(c.validUntil) < now) {
      expiredCodes++;
    } else if (c.redeemedCount >= c.maxRedemptions) {
      exhaustedCodes++;
    } else {
      activeCodes++;
    }
  }

  return {
    totalCodes: codes.length,
    activeCodes,
    exhaustedCodes,
    expiredCodes,
    inactiveCodes,
    totalRedemptions: records.filter((r) => r.status === 'success').length,
    totalCancelled: records.filter((r) => r.status === 'cancelled').length,
  };
}

/** 搜索兑换码 */
export async function searchCodes(query: string): Promise<RedemptionCode[]> {
  const all = await getAllCodes();
  if (!query.trim()) return all;
  const q = query.trim().toUpperCase();
  return all.filter(
    (c) =>
      c.code.includes(q) ||
      c.rewardName.includes(q) ||
      (c.targetPhone && c.targetPhone.includes(q)),
  );
}

/** 搜索兑换记录 */
export async function searchRecords(query: string): Promise<RedemptionRecord[]> {
  const all = await getAllRecords();
  if (!query.trim()) return all;
  const q = query.trim();
  return all.filter(
    (r) =>
      r.code.includes(q) ||
      r.username.includes(q) ||
      r.phone.includes(q) ||
      r.rewardName.includes(q),
  );
}

/** 作废兑换码 */
export async function deactivateCode(
  codeId: string,
  adminId?: string,
  adminName?: string,
): Promise<boolean> {
  const all = await getAllCodes();
  const entry = all.find((c) => c.id === codeId);
  if (entry && entry.isActive) {
    entry.isActive = false;
    await saveAllCodes(all);

    await appendAudit({
      adminId: adminId || 'admin',
      adminName: adminName || '管理员',
      action: 'deactivate_redemption' as any,
      detail: `作废兑换码 ${entry.code}（${entry.rewardName}）`,
    });

    return true;
  }
  return false;
}

/** 批量作废兑换码 */
export async function batchDeactivateCodes(
  codeIds: string[],
  adminId?: string,
  adminName?: string,
): Promise<number> {
  const all = await getAllCodes();
  let count = 0;
  for (const entry of all) {
    if (codeIds.includes(entry.id) && entry.isActive) {
      entry.isActive = false;
      count++;
    }
  }
  if (count > 0) {
    await saveAllCodes(all);
    await appendAudit({
      adminId: adminId || 'admin',
      adminName: adminName || '管理员',
      action: 'deactivate_redemption' as any,
      detail: `批量作废 ${count} 个兑换码`,
    });
  }
  return count;
}

/** 取消兑换记录（同时回退兑换码 redeemedCount） */
export async function cancelRedemption(
  recordId: string,
  adminId?: string,
  adminName?: string,
): Promise<boolean> {
  const records = await getAllRecords();
  const rec = records.find((r) => r.id === recordId);
  if (!rec || rec.status !== 'success') return false;

  rec.status = 'cancelled';
  rec.cancelledAt = new Date().toISOString();
  rec.cancelledBy = adminName || '管理员';
  await saveAllRecords(records);

  // 回退兑换码的 redeemedCount
  const codes = await getAllCodes();
  const code = codes.find((c) => c.id === rec.codeId);
  if (code && code.redeemedCount > 0) {
    code.redeemedCount--;
    await saveAllCodes(codes);
  }

  await appendAudit({
    adminId: adminId || 'admin',
    adminName: adminName || '管理员',
    action: 'cancel_redemption' as any,
    targetUserId: rec.userId,
    targetUsername: rec.username,
    detail: `取消 ${rec.username} 对 ${rec.code} 的兑换`,
  });

  return true;
}

// ====== 用户地址管理 ======

export async function getUserAddress(userId: string): Promise<ShippingAddress | null> {
  const raw = await AsyncStorage.getItem(ADDRESSES_KEY);
  const all: Record<string, ShippingAddress> = raw ? JSON.parse(raw) : {};
  return all[userId] || null;
}

export async function saveUserAddress(userId: string, address: ShippingAddress): Promise<void> {
  // 基础验证
  const phoneRegex = /^1[3-9]\d{9}$/;
  if (!phoneRegex.test(address.phone)) {
    throw new Error('手机号格式不正确');
  }
  if (!address.name.trim() || !address.detail.trim()) {
    throw new Error('收件人和详细地址不能为空');
  }

  const raw = await AsyncStorage.getItem(ADDRESSES_KEY);
  const all: Record<string, ShippingAddress> = raw ? JSON.parse(raw) : {};
  all[userId] = address;
  await AsyncStorage.setItem(ADDRESSES_KEY, JSON.stringify(all));
}

/** 获取所有用户地址（管理员查看实物奖励发货信息） */
export async function getAllAddresses(): Promise<Record<string, ShippingAddress>> {
  const raw = await AsyncStorage.getItem(ADDRESSES_KEY);
  return raw ? JSON.parse(raw) : {};
}
