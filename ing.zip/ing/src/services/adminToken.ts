/**
 * 管理员密令服务
 * 密令生成、存储、校验、更新
 * 规则：首次进入设置页自动生成 → 永久有效 → 修改密码后自动更新
 *
 * 修复:
 * - 使用 SecureStorage 加密存储密令
 * - 使用 crypto.getRandomValues() 替代 Math.random()
 * - regenerateToken 联动失效所有绑定
 */

import { SecureStorage } from '../utils/secureStorage';
import { appendAudit } from './admin';

const TOKEN_KEY = '@ing_admin_token';

// ====== 密令生成器（安全随机） ======
// 由大小写英文字母、数字、下划线随机组合，长度16位

function generateToken(): string {
  const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const lower = 'abcdefghijklmnopqrstuvwxyz';
  const digits = '0123456789';
  const special = '_';
  const pool = upper + lower + digits + special;

  // 使用 crypto.getRandomValues 获取安全随机数
  const randBytes = new Uint8Array(16);
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    crypto.getRandomValues(randBytes);
  } else {
    // 降级：Math.random（非安全环境）
    for (let i = 0; i < 16; i++) {
      randBytes[i] = Math.floor(Math.random() * 256);
    }
  }

  let token = '';
  // 确保至少包含每种类型各一个
  token += upper[randBytes[0] % upper.length];
  token += lower[randBytes[1] % lower.length];
  token += digits[randBytes[2] % digits.length];
  token += '_';

  // 填充剩余12位
  for (let i = 0; i < 12; i++) {
    token += pool[randBytes[(i + 4) % 16] % pool.length];
  }

  // Fisher-Yates 洗牌打乱顺序
  const arr = token.split('');
  for (let i = arr.length - 1; i > 0; i--) {
    const j = randBytes[i % 16] % (i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }

  return arr.join('');
}

// ====== 密令存储与获取 ======

/**
 * 获取当前管理员密令
 * 首次调用时自动生成并持久化
 */
export async function getOrCreateToken(): Promise<string> {
  try {
    const existing = await SecureStorage.getItem(TOKEN_KEY);
    if (existing) return existing;

    // 首次进入 — 自动生成密令并加密存储
    const newToken = generateToken();
    await SecureStorage.setItem(TOKEN_KEY, newToken);
    return newToken;
  } catch {
    // 降级：返回内存中的临时密令（不会持久化）
    return generateToken();
  }
}

/**
 * 校验密令是否匹配
 */
export async function verifyToken(inputToken: string): Promise<boolean> {
  try {
    const stored = await SecureStorage.getItem(TOKEN_KEY);
    if (!stored) return false;
    return stored === inputToken.trim();
  } catch {
    return false;
  }
}

/**
 * 强制更新密令（修改密码成功后调用）
 * 旧密令自动失效，同时联动失效所有绑定
 * 返回全新密令和失效绑定数
 */
export async function regenerateToken(
  adminId?: string,
  adminName?: string,
): Promise<{ token: string; invalidatedCount: number }> {
  const newToken = generateToken();
  try {
    await SecureStorage.setItem(TOKEN_KEY, newToken);
  } catch {
    // 更新失败但返回新密令（此时旧密令仍有效）
  }

  let invalidatedCount = 0;
  // 联动：旧密令变更 → 所有绑定失效
  try {
    const { invalidateBindingsOnTokenChange } = await import('./bindingService');
    invalidatedCount = await invalidateBindingsOnTokenChange();

    // 审计日志
    await appendAudit({
      adminId: adminId || 'admin',
      adminName: adminName || '管理员',
      action: 'regenerate_token' as any,
      detail: `密令已更新，${invalidatedCount} 个绑定自动失效`,
    });
  } catch {
    // 绑定失效失败不影响密令更新
  }

  return { token: newToken, invalidatedCount };
}

/**
 * 复制密令到剪贴板
 */
export async function copyTokenToClipboard(): Promise<boolean> {
  try {
    const token = await getOrCreateToken();
    try {
      const Clipboard = require('expo-clipboard');
      await Clipboard.setStringAsync(token);
      return true;
    } catch {
      return false;
    }
  } catch {
    return false;
  }
}

/**
 * 清除密令（管理员注销时调用，可选）
 */
export async function clearToken(): Promise<void> {
  try {
    await SecureStorage.removeItem(TOKEN_KEY);
  } catch {
    // 静默
  }
}
