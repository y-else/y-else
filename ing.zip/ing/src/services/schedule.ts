/**
 * 日程服务层
 * 个人日程CRUD、共享、提醒、管理员查看
 *
 * 修复:
 * - 移除 mock 内存变量，统一使用 AsyncStorage 持久化
 * - shareSchedule 通知也持久化到 AsyncStorage
 * - 共享日程支持标记已读
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import type { ScheduleItem, ScheduleShareNotification } from '../types';

const STORAGE_KEY = '@ing_schedules';
const NOTIF_KEY = '@ing_schedule_notifications';

// ====== 内部辅助 ======

async function readAll(): Promise<ScheduleItem[]> {
  const raw = await AsyncStorage.getItem(STORAGE_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function writeAll(items: ScheduleItem[]): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}

async function readNotifs(): Promise<ScheduleShareNotification[]> {
  const raw = await AsyncStorage.getItem(NOTIF_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function writeNotifs(items: ScheduleShareNotification[]): Promise<void> {
  await AsyncStorage.setItem(NOTIF_KEY, JSON.stringify(items));
}

// ====== 个人日程 ======

export async function getMySchedules(userId: string): Promise<ScheduleItem[]> {
  const all = await readAll();
  return all
    .filter((s) => s.userId === userId)
    .sort((a, b) => new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime());
}

export async function createSchedule(
  item: Omit<ScheduleItem, 'id' | 'createdAt' | 'updatedAt'>,
): Promise<ScheduleItem> {
  const all = await readAll();
  const newItem: ScheduleItem = {
    ...item,
    id: 'sch_' + Date.now(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  all.push(newItem);
  await writeAll(all);
  return newItem;
}

export async function updateSchedule(
  id: string,
  updates: Partial<ScheduleItem>,
): Promise<ScheduleItem | null> {
  const all = await readAll();
  const idx = all.findIndex((s) => s.id === id);
  if (idx < 0) return null;
  all[idx] = { ...all[idx], ...updates, updatedAt: new Date().toISOString() };
  await writeAll(all);
  return all[idx];
}

export async function deleteSchedule(id: string): Promise<boolean> {
  const all = await readAll();
  const filtered = all.filter((s) => s.id !== id);
  await writeAll(filtered);
  // 同时清理相关通知
  const notifs = await readNotifs();
  await writeNotifs(notifs.filter((n) => n.scheduleId !== id));
  return true;
}

// ====== 共享日程 ======

export async function shareSchedule(
  scheduleId: string,
  fromUserId: string,
  fromUsername: string,
  toUserId: string,
): Promise<boolean> {
  const all = await readAll();
  const s = all.find((s) => s.id === scheduleId);
  if (s && !s.sharedTo.includes(toUserId)) {
    s.sharedTo.push(toUserId);
    s.updatedAt = new Date().toISOString();
    await writeAll(all);
  }

  // 创建共享通知（持久化）
  const notifs = await readNotifs();
  const notif: ScheduleShareNotification = {
    id: 'ssn_' + Date.now(),
    scheduleId,
    fromUserId,
    fromUsername,
    toUserId,
    scheduleTitle: s?.title || '未知日程',
    createdAt: new Date().toISOString(),
    isRead: false,
  };
  notifs.push(notif);
  await writeNotifs(notifs);

  return true;
}

export async function getSharedSchedules(
  userId: string,
): Promise<ScheduleShareNotification[]> {
  const notifs = await readNotifs();
  return notifs
    .filter((n) => n.toUserId === userId)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

/** 标记共享通知为已读 */
export async function markShareNotifRead(notifId: string): Promise<void> {
  const notifs = await readNotifs();
  const n = notifs.find((n) => n.id === notifId);
  if (n) {
    n.isRead = true;
    await writeNotifs(notifs);
  }
}

/** 获取共享通知未读数 */
export async function getUnreadShareNotifCount(userId: string): Promise<number> {
  const notifs = await readNotifs();
  return notifs.filter((n) => n.toUserId === userId && !n.isRead).length;
}

// ====== 管理员 ======

export async function getAllSchedules(): Promise<ScheduleItem[]> {
  const all = await readAll();
  return all.sort(
    (a, b) => new Date(b.scheduledAt).getTime() - new Date(a.scheduledAt).getTime(),
  );
}

/** 按日期范围搜索日程 */
export async function searchSchedules(
  query?: string,
  dateFrom?: string,
  dateTo?: string,
): Promise<ScheduleItem[]> {
  let all = await readAll();

  if (query) {
    const q = query.toLowerCase();
    all = all.filter(
      (s) =>
        s.title.toLowerCase().includes(q) ||
        s.content.toLowerCase().includes(q) ||
        s.username.toLowerCase().includes(q),
    );
  }

  if (dateFrom) {
    all = all.filter((s) => s.scheduledAt >= dateFrom);
  }
  if (dateTo) {
    all = all.filter((s) => s.scheduledAt <= dateTo + 'T23:59:59');
  }

  return all.sort(
    (a, b) => new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime(),
  );
}
