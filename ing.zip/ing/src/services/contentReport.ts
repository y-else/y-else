/**
 * 内容举报 + 管理员审核服务
 * 用户举报违规内容 → 管理员审核处理（批量/单个）
 *
 * 新增:
 * - getMyReports 用户查看自己的举报历史
 * - batchReviewReports 批量审核
 * - getReportStats 举报统计
 * - handleReportedContent 服务层统一联动删除被举报内容
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

const REPORTS_KEY = '@ing_content_reports';

export type ReportTargetType = 'space_post' | 'wall_message' | 'album_item' | 'diary' | 'user';
export type ReportStatus = 'pending' | 'reviewed' | 'dismissed';

export interface ContentReport {
  id: string;
  reporterId: string;
  reporterName: string;
  targetType: ReportTargetType;
  targetId: string;
  targetPreview: string;
  reason: string;
  status: ReportStatus;
  reviewedBy?: string;
  reviewedAt?: string;
  reviewNote?: string;
  createdAt: string;
}

export interface ReportStats {
  total: number;
  pending: number;
  reviewed: number;
  dismissed: number;
}

// ====== 存储 ======

async function getAllReports(): Promise<ContentReport[]> {
  const raw = await AsyncStorage.getItem(REPORTS_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function saveAllReports(reports: ContentReport[]): Promise<void> {
  if (reports.length > 500) reports.length = 500;
  await AsyncStorage.setItem(REPORTS_KEY, JSON.stringify(reports));
}

// ====== 用户举报 ======

export async function submitReport(params: {
  reporterId: string;
  reporterName: string;
  targetType: ReportTargetType;
  targetId: string;
  targetPreview: string;
  reason: string;
}): Promise<{ success: boolean; message: string }> {
  if (!params.reason.trim()) {
    return { success: false, message: '请填写举报原因' };
  }

  if (params.reason.trim().length < 4) {
    return { success: false, message: '举报原因至少4个字符' };
  }

  // 防止重复举报（同一用户对同一内容的pending举报）
  const all = await getAllReports();
  const existing = all.find(
    (r) => r.reporterId === params.reporterId &&
      r.targetId === params.targetId &&
      r.status === 'pending',
  );
  if (existing) {
    return { success: false, message: '您已举报过此内容，管理员正在处理中' };
  }

  const report: ContentReport = {
    id: 'rpt_' + Date.now(),
    ...params,
    status: 'pending',
    createdAt: new Date().toISOString(),
  };
  all.push(report);
  await saveAllReports(all);
  return { success: true, message: '举报已提交，管理员将尽快处理' };
}

/** 用户查看自己的举报历史 */
export async function getMyReports(userId: string): Promise<ContentReport[]> {
  const all = await getAllReports();
  return all
    .filter((r) => r.reporterId === userId)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

// ====== 管理员审核 ======

export async function getAllPendingReports(): Promise<ContentReport[]> {
  const all = await getAllReports();
  return all
    .filter((r) => r.status === 'pending')
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

/** 获取全量举报（支持状态筛选和搜索） */
export async function getAllReportsFiltered(
  status?: ReportStatus | 'all',
  search?: string,
): Promise<ContentReport[]> {
  let all = await getAllReports();

  if (status && status !== 'all') {
    all = all.filter((r) => r.status === status);
  }

  if (search) {
    const q = search.toLowerCase();
    all = all.filter(
      (r) =>
        r.reporterName.toLowerCase().includes(q) ||
        r.targetPreview.toLowerCase().includes(q) ||
        r.reason.toLowerCase().includes(q),
    );
  }

  return all.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );
}

/** 获取举报统计 */
export async function getReportStats(): Promise<ReportStats> {
  const all = await getAllReports();
  return {
    total: all.length,
    pending: all.filter((r) => r.status === 'pending').length,
    reviewed: all.filter((r) => r.status === 'reviewed').length,
    dismissed: all.filter((r) => r.status === 'dismissed').length,
  };
}

/** 单个审核 */
export async function reviewReport(
  reportId: string,
  action: 'reviewed' | 'dismissed',
  reviewerName: string,
  note?: string,
): Promise<boolean> {
  const all = await getAllReports();
  const r = all.find((r) => r.id === reportId);
  if (!r) return false;
  r.status = action;
  r.reviewedBy = reviewerName;
  r.reviewedAt = new Date().toISOString();
  if (note) r.reviewNote = note;
  await saveAllReports(all);
  return true;
}

/** 批量审核 */
export async function batchReviewReports(
  reportIds: string[],
  action: 'reviewed' | 'dismissed',
  reviewerName: string,
  note?: string,
): Promise<{ processed: number; failed: number }> {
  const all = await getAllReports();
  let processed = 0;
  let failed = 0;

  for (const id of reportIds) {
    const r = all.find((r) => r.id === id);
    if (!r) { failed++; continue; }
    r.status = action;
    r.reviewedBy = reviewerName;
    r.reviewedAt = new Date().toISOString();
    if (note) r.reviewNote = note;
    processed++;
  }

  await saveAllReports(all);
  return { processed, failed };
}

// ====== 联动处理被举报内容（审核通过后删除内容） ======

/** 审核通过后联动删除被举报的真实内容 */
export async function handleReportedContent(report: ContentReport): Promise<boolean> {
  try {
    const { GlobalStore } = await import('./globalDataStore');

    switch (report.targetType) {
      case 'space_post': {
        const posts = await GlobalStore.spacePosts.getAll();
        const filtered = posts.filter((p: any) => p.id !== report.targetId);
        if (filtered.length < posts.length) {
          await GlobalStore.spacePosts.setAll(filtered);
          // 同时清理原始存储
          const raw = await AsyncStorage.getItem('@ing_space_posts');
          if (raw) {
            const originalPosts = JSON.parse(raw);
            const originalFiltered = originalPosts.filter((p: any) => p.id !== report.targetId);
            await AsyncStorage.setItem('@ing_space_posts', JSON.stringify(originalFiltered));
          }
          return true;
        }
        break;
      }
      case 'wall_message': {
        // 清理留言（存储在 @ing_wall_messages 中）
        const raw = await AsyncStorage.getItem('@ing_wall_messages');
        if (raw) {
          const msgs = JSON.parse(raw);
          const filtered = msgs.filter((m: any) => m.id !== report.targetId);
          if (filtered.length < msgs.length) {
            await AsyncStorage.setItem('@ing_wall_messages', JSON.stringify(filtered));
            return true;
          }
        }
        break;
      }
      case 'album_item': {
        const raw = await AsyncStorage.getItem('@ing_gds_album_items');
        if (raw) {
          const items = JSON.parse(raw);
          const filtered = items.filter((a: any) => a.id !== report.targetId);
          if (filtered.length < items.length) {
            await AsyncStorage.setItem('@ing_gds_album_items', JSON.stringify(filtered));
            return true;
          }
        }
        break;
      }
      case 'diary': {
        // 日记存储在 @ing_diary_posts_<userId>
        const allKeys = await AsyncStorage.getAllKeys();
        for (const key of allKeys) {
          if (key.startsWith('@ing_diary_posts_')) {
            const raw = await AsyncStorage.getItem(key);
            if (raw) {
              const posts = JSON.parse(raw);
              const filtered = posts.filter((p: any) => p.id !== report.targetId);
              if (filtered.length < posts.length) {
                await AsyncStorage.setItem(key, JSON.stringify(filtered));
                return true;
              }
            }
          }
        }
        break;
      }
      default:
        break;
    }
  } catch (e) {
    console.warn('[内容审核] 联动处理内容失败:', e);
  }
  return false;
}
