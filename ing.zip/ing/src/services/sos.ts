/**
 * SOS 求救服务（全面重写版）
 *
 * 修复清单：
 * - C1: WebSocket emitSOS 接入，远程接收者可实时收到SOS
 * - C2: 振动安全定时器可追踪/可清理
 * - C4: processOfflineSOSQueue 加入频率限制
 * - C6: SOS轨迹数据持久化到 AsyncStorage 关联SOS记录
 * - 新增 getSOSTrajectory / getSOSRecordsPaginated / 异常标记持久化
 */

import { Vibration } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Crypto from 'expo-crypto';
import { getCurrentLocation, startRealtimeTracking, stopRealtimeTracking } from './gps';
import { emitSOS } from './websocketClient';
import type { SOSAlert, SOSReceiver } from '../types';
import type { LocationData } from './gps';

// ====== 存储键 ======

const SOS_RECORDS_KEY = '@ing_sos_records';
const SOS_CACHE_KEY = '@ing_sos_offline_cache';
const SOS_TRAJECTORY_PREFIX = '@ing_sos_trajectory_';

// ====== SOS状态类型 ======

export type SOSStatusType = 'pending' | 'processing' | 'resolved' | 'false_alarm' | 'cancelled';

export interface SOSRecord extends SOSAlert {
  resolvedAt?: string;
  resolvedBy?: string;
  sosStatus: SOSStatusType;
  isSilent: boolean;
  retryCount: number;
  isAbnormal?: boolean;          // 异常标记（持久化）
}

// ====== 监听器 ======

type SOSEventCallback = (alert: SOSAlert) => void;
type SOSLocationCallback = (location: LocationData) => void;

let sosEventListeners: SOSEventCallback[] = [];
let sosLocationListeners: SOSLocationCallback[] = [];
let isSOSTracking = false;

// 频率限制：10秒内最多触发1次
let lastTriggerTime = 0;
const RATE_LIMIT_MS = 10000;

// 振动安全定时器引用（C2修复：可追踪可清理）
let vibrationSafetyTimer: ReturnType<typeof setTimeout> | null = null;

// 当前SOS对应的轨迹收集
let currentSOSTrajectory: LocationData[] = [];
let currentSOSAlertId: string | null = null;

// ====== 持久化存储 ======

async function getSOSRecords(): Promise<SOSRecord[]> {
  const raw = await AsyncStorage.getItem(SOS_RECORDS_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function saveSOSRecords(records: SOSRecord[]): Promise<void> {
  await AsyncStorage.setItem(SOS_RECORDS_KEY, JSON.stringify(records));
}

async function getOfflineCache(): Promise<{ senderId: string; senderName: string; senderPhone: string; isSilent: boolean }[]> {
  const raw = await AsyncStorage.getItem(SOS_CACHE_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function saveOfflineCache(cache: any[]): Promise<void> {
  await AsyncStorage.setItem(SOS_CACHE_KEY, JSON.stringify(cache));
}

// SOS轨迹持久化（C6修复）
async function saveSOSTrajectory(alertId: string, trajectory: LocationData[]): Promise<void> {
  await AsyncStorage.setItem(SOS_TRAJECTORY_PREFIX + alertId, JSON.stringify(trajectory));
}

// ====== 监听器管理 ======

export function addSOSEventListener(callback: SOSEventCallback): () => void {
  sosEventListeners.push(callback);
  return () => {
    // 防御：destroySOSResources 先清空数组后组件卸载时回调仍会触发
    if (!sosEventListeners) return;
    sosEventListeners = sosEventListeners.filter((cb) => cb !== callback);
  };
}

export function addSOSLocationListener(callback: SOSLocationCallback): () => void {
  sosLocationListeners.push(callback);
  return () => {
    // 防御：destroySOSResources 先清空数组后组件卸载时回调仍会触发
    if (!sosLocationListeners) return;
    sosLocationListeners = sosLocationListeners.filter((cb) => cb !== callback);
  };
}

// ====== 触发SOS（全面重写版） ======

export async function triggerSOS(
  senderId: string,
  senderName: string,
  senderPhone: string,
  options?: { isSilent?: boolean },
): Promise<{ alert: SOSAlert | null; reason?: 'rate_limited' | 'permission_denied' | 'network_error' | 'success' }> {
  // 频率限制
  const now = Date.now();
  if (now - lastTriggerTime < RATE_LIMIT_MS) {
    console.warn('[SOS] 触发频率过高，已限制');
    return { alert: null, reason: 'rate_limited' };
  }
  lastTriggerTime = now;

  const isSilent = options?.isSilent ?? false;

  try {
    // 0. 权限校验
    try {
      const raw = await AsyncStorage.getItem('@ing_interaction_settings');
      if (raw) {
        const settings = JSON.parse(raw);
        if (settings.sosAlert === false) {
          console.warn('[SOS] 管理员已禁用该用户SOS权限');
          return { alert: null, reason: 'permission_denied' };
        }
      }
    } catch {}

    // 1. 获取高精度GPS位置
    let location: LocationData | null = null;
    try {
      location = await getCurrentLocation();
    } catch {}

    let finalLat = 0;
    let finalLng = 0;
    let address: string | null = null;
    if (location) {
      finalLat = location.latitude;
      finalLng = location.longitude;
      address = location.address || null;
    } else {
      const lastLoc = await AsyncStorage.getItem('@ing_last_known_location');
      if (lastLoc) {
        const parsed = JSON.parse(lastLoc);
        finalLat = parsed.latitude;
        finalLng = parsed.longitude;
        address = parsed.address;
      }
      console.warn('[SOS] 无法获取GPS，使用最后已知位置兜底');
    }

    const alert: SOSAlert = {
      id: Crypto.randomUUID(),
      senderId,
      senderName,
      senderPhone,
      location: { latitude: finalLat, longitude: finalLng },
      address,
      triggeredAt: new Date().toISOString(),
      status: 'active',
    };

    // 2. 持久化SOS记录
    const record: SOSRecord = {
      ...alert,
      sosStatus: 'pending',
      isSilent,
      retryCount: 0,
    };
    const records = await getSOSRecords();
    records.unshift(record);
    await saveSOSRecords(records);

    // 保存最后已知位置
    if (finalLat !== 0 || finalLng !== 0) {
      await AsyncStorage.setItem('@ing_last_known_location', JSON.stringify({
        latitude: finalLat, longitude: finalLng, address,
      }));
    }

    console.log('[SOS] 求救已触发:', alert.id, alert.senderName, isSilent ? '(静音)' : '');

    // 3. 通知本地监听者
    sosEventListeners.forEach((cb) => cb(alert));

    // 4. WebSocket实时推送给远程接收者（C1修复）
    try {
      emitSOS({
        alertId: alert.id,
        senderId,
        senderName,
        senderPhone,
        latitude: finalLat,
        longitude: finalLng,
        address,
        triggeredAt: alert.triggeredAt,
        isSilent,
      });
    } catch {
      console.warn('[SOS] WebSocket推送失败，已持久化，接收者刷新后可查看');
    }

    // 5. 开始实时追踪GPS位置并持久化轨迹（C6修复）
    currentSOSAlertId = alert.id;
    currentSOSTrajectory = [];
    if (!isSOSTracking) {
      isSOSTracking = true;
      await startRealtimeTracking(senderId, (loc) => {
        // 收集轨迹
        currentSOSTrajectory.push(loc);
        // 每5个点存一次盘（降低IO频率）
        if (currentSOSTrajectory.length % 5 === 0 && currentSOSAlertId) {
          saveSOSTrajectory(currentSOSAlertId, [...currentSOSTrajectory]);
        }
        // 通知监听者
        sosLocationListeners.forEach((cb) => cb(loc));
      }, 10000);
    }

    // 6. 振动（非静音模式）
    if (!isSilent) {
      triggerSOSVibration();
    }

    // 7. 检测短时间多次触发
    await checkRepeatedTriggers(senderId);

    // 8. 更新管理员SOS未读角标
    try {
      const { addUnread } = await import('./unreadBadge');
      await addUnread('adminPendingSOS');
    } catch {}

    return { alert, reason: 'success' };
  } catch (error) {
    console.error('[SOS] 触发失败:', error);
    return { alert: null, reason: 'network_error' };
  }
}

// ====== 静音SOS模式 ======

export async function triggerSilentSOS(
  senderId: string, senderName: string, senderPhone: string,
): Promise<{ alert: SOSAlert | null; reason?: string }> {
  return triggerSOS(senderId, senderName, senderPhone, { isSilent: true });
}

// ====== 短时间多次触发预警 ======

async function checkRepeatedTriggers(userId: string): Promise<boolean> {
  const records = await getSOSRecords();
  const recentCount = records.filter(
    (r) => r.senderId === userId &&
      Date.now() - new Date(r.triggeredAt).getTime() < 300000,
  ).length;

  if (recentCount >= 3) {
    console.warn(`[SOS异常] 用户 ${userId} 5分钟内触发 ${recentCount} 次SOS，已标记预警`);
    // 持久化异常标记
    const updated = records.map((r) => {
      if (r.senderId === userId && Date.now() - new Date(r.triggeredAt).getTime() < 300000) {
        return { ...r, isAbnormal: true };
      }
      return r;
    });
    await saveSOSRecords(updated);
    return true;
  }
  return false;
}

// ====== 停止SOS实时追踪（同时保存剩余轨迹） ======

export async function stopSOSTracking(): Promise<void> {
  isSOSTracking = false;
  stopRealtimeTracking();
  // 保存剩余轨迹（C6修复）
  if (currentSOSAlertId && currentSOSTrajectory.length > 0) {
    await saveSOSTrajectory(currentSOSAlertId, [...currentSOSTrajectory]);
  }
  currentSOSAlertId = null;
  currentSOSTrajectory = [];
}

// ====== 振动控制（C2修复：可追踪定时器） ======

const MAX_VIBRATION_DURATION = 15000;

export function triggerSOSVibration(): void {
  // 先清除旧定时器
  if (vibrationSafetyTimer) {
    clearTimeout(vibrationSafetyTimer);
    vibrationSafetyTimer = null;
  }

  const pattern = [0, 500, 200, 500, 200, 500];
  Vibration.vibrate(pattern);

  vibrationSafetyTimer = setTimeout(() => {
    Vibration.cancel();
    vibrationSafetyTimer = null;
  }, MAX_VIBRATION_DURATION);
}

export function stopAllVibration(): void {
  Vibration.cancel();
  if (vibrationSafetyTimer) {
    clearTimeout(vibrationSafetyTimer);
    vibrationSafetyTimer = null;
  }
}

// ====== 模拟接收SOS ======

export function simulateReceiveSOS(callback: SOSEventCallback): () => void {
  return addSOSEventListener(callback);
}

// ====== 获取SOS接收者列表 ======

export function getSOSReceivers(): SOSReceiver[] {
  return [
    { userId: 'bound_user_1', type: 'bound' },
    { userId: 'admin_001', type: 'admin' },
  ];
}

// ====== SOS解决/状态管理 ======

let activeAlert: SOSAlert | null = null;

export function getActiveAlert(): SOSAlert | null {
  return activeAlert;
}

export function setActiveAlert(alert: SOSAlert): void {
  activeAlert = alert;
}

export async function resolveSOSAlert(
  alertId: string,
  resolvedBy: string,
  status: SOSStatusType = 'resolved',
): Promise<boolean> {
  const records = await getSOSRecords();
  const idx = records.findIndex((r) => r.id === alertId);
  if (idx < 0) return false;

  records[idx].sosStatus = status;
  records[idx].status = 'resolved';
  records[idx].resolvedAt = new Date().toISOString();
  records[idx].resolvedBy = resolvedBy;
  await saveSOSRecords(records);

  if (activeAlert?.id === alertId) {
    activeAlert = null;
  }
  await stopSOSTracking();
  stopAllVibration();

  return true;
}

export function resolveAlert(): void {
  activeAlert = null;
  // 注意：resolveAlert 不清除持久化状态（仅清内存），
  // 实际解决请调用 resolveSOSAlert
  stopAllVibration();
}

// ====== SOS轨迹查询（C6新增） ======

export async function getSOSTrajectory(alertId: string): Promise<LocationData[]> {
  const raw = await AsyncStorage.getItem(SOS_TRAJECTORY_PREFIX + alertId);
  return raw ? JSON.parse(raw) : [];
}

// ====== 管理员接口 ======

export async function getAllSOSRecords(): Promise<SOSRecord[]> {
  return (await getSOSRecords()).sort(
    (a, b) => new Date(b.triggeredAt).getTime() - new Date(a.triggeredAt).getTime(),
  );
}

export async function getSOSRecordsPaginated(page: number, pageSize: number = 20): Promise<{ records: SOSRecord[]; hasMore: boolean; total: number }> {
  const all = await getAllSOSRecords();
  const start = page * pageSize;
  return {
    records: all.slice(start, start + pageSize),
    hasMore: start + pageSize < all.length,
    total: all.length,
  };
}

export async function getAbnormalSOSRecords(): Promise<SOSRecord[]> {
  const records = await getSOSRecords();
  // 优先使用持久化的异常标记，再结合24h高频检测
  const abnormal = records.filter((r) => {
    if (r.isAbnormal) return true;
    return false;
  });

  // 同时检测24h内高频触发
  const userCounts: Record<string, SOSRecord[]> = {};
  for (const r of records) {
    if (Date.now() - new Date(r.triggeredAt).getTime() > 86400000) continue;
    if (!userCounts[r.senderId]) userCounts[r.senderId] = [];
    userCounts[r.senderId].push(r);
  }

  for (const [, userRecords] of Object.entries(userCounts)) {
    if (userRecords.length >= 3) {
      for (const r of userRecords) {
        if (!abnormal.find((a) => a.id === r.id)) {
          abnormal.push(r);
        }
      }
    }
  }

  return abnormal;
}

export async function getUserSOSRecords(userId: string): Promise<SOSRecord[]> {
  const records = await getSOSRecords();
  return records.filter((r) => r.senderId === userId);
}

// ====== 离线SOS缓存 ======

export async function cacheOfflineSOS(
  senderId: string, senderName: string, senderPhone: string, isSilent: boolean,
): Promise<void> {
  const cache = await getOfflineCache();
  cache.push({ senderId, senderName, senderPhone, isSilent });
  await saveOfflineCache(cache);
  console.log('[SOS离线] 已缓存，联网后自动补发');
}

/**
 * 处理离线缓存队列（C4修复：加入频率限制）
 */
export async function processOfflineSOSQueue(): Promise<number> {
  const cache = await getOfflineCache();
  if (cache.length === 0) return 0;

  let processed = 0;
  for (const item of cache) {
    // C4修复：频率限制检查
    if (Date.now() - lastTriggerTime < RATE_LIMIT_MS) {
      console.warn('[SOS离线] 补发频率受限，剩余 ' + (cache.length - processed) + ' 条将在下次重试');
      break;
    }
    try {
      await triggerSOS(item.senderId, item.senderName, item.senderPhone, { isSilent: item.isSilent });
      processed++;
    } catch {
      break; // 失败则保留在队列中，下次网络恢复时重试
    }
  }

  const remaining = cache.slice(processed);
  await saveOfflineCache(remaining);
  console.log(`[SOS离线] 已补发 ${processed}/${cache.length} 条`);
  return processed;
}

// ====== 资源销毁（C2修复：完整清理） ======

export function destroySOSResources(): void {
  isSOSTracking = false;
  stopRealtimeTracking();
  stopAllVibration(); // 内部已清理 vibrationSafetyTimer
  sosEventListeners = [];
  sosLocationListeners = [];
  lastTriggerTime = 0;
  currentSOSAlertId = null;
  currentSOSTrajectory = [];
}
