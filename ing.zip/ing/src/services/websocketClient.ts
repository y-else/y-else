/**
 * WebSocket 实时通信客户端 v2
 * JWT鉴权连接 / 指数退避重连 / 心跳保活双向检测 / 重连状态暴露
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { WS_URL } from './apiConfig';

// ====== 类型 ======

type Listener = (data: any) => void;
export type WSConnectionState = 'disconnected' | 'connecting' | 'connected' | 'reconnecting';
type ConnectionStateListener = (state: WSConnectionState) => void;

// ====== 重连配置 ======

const RECONNECT_BASE_MS = 1000;
const RECONNECT_MAX_MS = 32000;
const RECONNECT_JITTER_MS = 500;
const HEARTBEAT_INTERVAL = 25000;
/** 连续3个心跳周期未收到ack视为连接死亡 */
const MISSED_HEARTBEAT_DEAD = 3;

// ====== 模块级状态 ======

const listeners: Record<string, Listener[]> = {};
const connectionStateListeners: ConnectionStateListener[] = [];

let socket: WebSocket | null = null;
let heartbeatTimer: ReturnType<typeof setInterval> | null = null;
let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
let healthCheckTimer: ReturnType<typeof setInterval> | null = null;

let currentUserId: string | null = null;
let currentUsername = '';
let currentPhone = '';
let currentToken: string | null = null;

let reconnectAttempts = 0;
let missedHeartbeats = 0;
let intentionalClose = false;
let connectionState: WSConnectionState = 'disconnected';

// ====== 连接状态 ======

function setConnectionState(state: WSConnectionState) {
  if (connectionState === state) return;
  connectionState = state;
  connectionStateListeners.forEach((cb) => { try { cb(state); } catch {} });
}

export function getConnectionState(): WSConnectionState {
  return connectionState;
}

export function onConnectionStateChange(callback: ConnectionStateListener): () => void {
  connectionStateListeners.push(callback);
  // 立即发送当前状态
  try { callback(connectionState); } catch {}
  return () => {
    const idx = connectionStateListeners.indexOf(callback);
    if (idx >= 0) connectionStateListeners.splice(idx, 1);
  };
}

// ====== 连接 ======

export function connectWebSocket(userId: string, username: string, phone: string, token?: string) {
  // 已有同用户活跃连接则跳过
  if (socket?.readyState === WebSocket.OPEN && currentUserId === userId) return;

  disconnectWebSocket();
  intentionalClose = false;
  currentUserId = userId;
  currentUsername = username;
  currentPhone = phone;
  currentToken = token || null;

  doConnect();
}

function doConnect() {
  if (!currentUserId) return;
  setConnectionState('connecting');

  try {
    // 通过URL查询参数传递JWT token（服务端verifyClient校验）
    const url = currentToken ? WS_URL + '?token=' + encodeURIComponent(currentToken) : WS_URL;
    socket = new WebSocket(url);

    socket.onopen = () => {
      reconnectAttempts = 0;
      missedHeartbeats = 0;
      setConnectionState('connected');
      // 发送上线注册
      send({ type: 'user:online', userId: currentUserId, username: currentUsername, phone: currentPhone });
      startHeartbeat(currentUserId!);
      startHealthCheck();
    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        // 心跳应答（更新健康状态）
        if (data.type === 'heartbeat:ack') {
          missedHeartbeats = 0;
          return;
        }
        // 事件路由
        if (data.type && listeners[data.type]) {
          listeners[data.type].forEach((cb) => { try { cb(data); } catch {} });
        }
      } catch {}
    };

    socket.onclose = () => {
      stopHeartbeat();
      stopHealthCheck();
      if (!intentionalClose && currentUserId) {
        scheduleReconnect();
      } else {
        setConnectionState('disconnected');
      }
    };

    socket.onerror = () => {
      // 关闭触发onclose继而重连
      socket?.close();
    };
  } catch {
    if (!intentionalClose && currentUserId) scheduleReconnect();
  }
}

// ====== 断开 ======

export function disconnectWebSocket() {
  intentionalClose = true;
  stopHeartbeat();
  stopHealthCheck();
  clearReconnect();
  if (socket) {
    socket.onclose = null; // 防止触发重连
    socket.close();
    socket = null;
  }
  currentUserId = null;
  currentToken = null;
  reconnectAttempts = 0;
  missedHeartbeats = 0;
  setConnectionState('disconnected');
}

export function reconnectWebSocket() {
  reconnectAttempts = 0;
  clearReconnect();
  stopHeartbeat();
  stopHealthCheck();
  if (socket) {
    socket.onclose = null;
    socket.close();
    socket = null;
  }
  if (currentUserId) doConnect();
}

// ====== 重连（指数退避 + 随机抖动） ======

function scheduleReconnect() {
  setConnectionState('reconnecting');
  clearReconnect();
  const delay = Math.min(
    RECONNECT_BASE_MS * Math.pow(2, reconnectAttempts),
    RECONNECT_MAX_MS,
  ) + Math.random() * RECONNECT_JITTER_MS;
  reconnectAttempts++;
  reconnectTimer = setTimeout(() => {
    if (!intentionalClose && currentUserId) doConnect();
  }, delay);
}

function clearReconnect() {
  if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
}

// ====== 心跳 ======

function startHeartbeat(userId: string) {
  stopHeartbeat();
  heartbeatTimer = setInterval(() => {
    send({ type: 'heartbeat', userId });
    missedHeartbeats++;
  }, HEARTBEAT_INTERVAL);
}

function stopHeartbeat() {
  if (heartbeatTimer) { clearInterval(heartbeatTimer); heartbeatTimer = null; }
}

// ====== 健康监测（心跳ack超时 → 主动重连） ======

function startHealthCheck() {
  stopHealthCheck();
  healthCheckTimer = setInterval(() => {
    if (missedHeartbeats >= MISSED_HEARTBEAT_DEAD) {
      // 连接已死亡，主动重连
      if (socket) {
        socket.onclose = null;
        socket.close();
        socket = null;
      }
      stopHeartbeat();
      stopHealthCheck();
      if (!intentionalClose && currentUserId) scheduleReconnect();
    }
  }, HEARTBEAT_INTERVAL);
}

function stopHealthCheck() {
  if (healthCheckTimer) { clearInterval(healthCheckTimer); healthCheckTimer = null; }
}

// ====== 发送 ======

function send(data: any) {
  if (socket?.readyState === WebSocket.OPEN) {
    try { socket.send(JSON.stringify(data)); } catch {}
  }
}

// ====== 事件监听 ======

export function on(event: string, callback: Listener): () => void {
  if (!listeners[event]) listeners[event] = [];
  listeners[event].push(callback);
  return () => {
    if (!listeners[event]) return;
    listeners[event] = listeners[event].filter((cb) => cb !== callback);
  };
}

// ====== 主动推送 ======

export function emitSOS(data: any) { send({ type: 'sos:trigger', ...data }); }
export function emitLocation(data: any) { send({ type: 'location:update', ...data }); }
export function emitNewPost(data: any) { send({ type: 'space:newPost', ...data }); }
export function emitVisit(data: any) { send({ type: 'visit:new', ...data }); }
export function emitBindingChange(data: any) { send({ type: 'binding:change', ...data }); }
export function emitAdminNotify(targetUserId: string, message: string) {
  send({ type: 'admin:notify', targetUserId, message });
}

// ====== 在线状态缓存 ======

const ONLINE_CACHE_KEY = '@ing_online_status';
let onlineStatusCache: Record<string, boolean> = {};

export async function loadOnlineCache() {
  try {
    const raw = await AsyncStorage.getItem(ONLINE_CACHE_KEY);
    onlineStatusCache = raw ? JSON.parse(raw) : {};
  } catch { onlineStatusCache = {}; }
}

export function isUserOnline(userId: string): boolean {
  return onlineStatusCache[userId] ?? false;
}

on('user:status', (data) => {
  if (data.userId) {
    onlineStatusCache[data.userId] = data.status === 'online';
    AsyncStorage.setItem(ONLINE_CACHE_KEY, JSON.stringify(onlineStatusCache)).catch(() => {});
  }
});

// ====== SOS实时推送监听 ======

export function onSOSAlert(callback: (data: any) => void): () => void {
  return on('sos:new', callback);
}

export function onSOSLocationUpdate(callback: (data: any) => void): () => void {
  return on('location:update', callback);
}

export function onNewPost(callback: (data: any) => void): () => void {
  return on('space:newPost', callback);
}

export function onVisit(callback: (data: any) => void): () => void {
  return on('visit:new', callback);
}

export function onBindingChange(callback: (data: any) => void): () => void {
  return on('binding:change', callback);
}

export function onAdminNotification(callback: (data: any) => void): () => void {
  return on('admin:notify', callback);
}

export function onAnnouncement(callback: (data: any) => void): () => void {
  return on('announcement:new', callback);
}

// ====== 资源销毁 ======

export function destroyWebSocketResources(): void {
  disconnectWebSocket();
  // 清空所有模块级监听器
  Object.keys(listeners).forEach((key) => {
    delete listeners[key];
  });
  connectionStateListeners.length = 0;
  onlineStatusCache = {};
}
