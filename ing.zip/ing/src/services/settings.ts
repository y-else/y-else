/**
 * 设置服务（持久化版）
 *
 * - 互动权限7项开关（AsyncStorage 持久化）
 * - 手机使用数据（AsyncStorage 持久化 + 仅管理员可见）
 * - 意见反馈（AsyncStorage 持久化 + 状态管理）
 * - 联系管理员留言（独立API，不复用反馈）
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import type { InteractionSettings, PhoneData, Feedback } from '../types';

const KEYS = {
  INTERACTION: '@ing_interaction_settings',
  FEEDBACKS: '@ing_feedbacks',
  PHONE_USAGE: '@ing_phone_usage',
  CONTACT_ADMIN_MSGS: '@ing_contact_admin_msgs',
} as const;

const delay = (ms = 300) => new Promise((r) => setTimeout(r, ms));

// ====== 互动权限开关 ======

const DEFAULT_INTERACTION: InteractionSettings = {
  quickMessage: true,
  vibration: true,
  popupNotify: true,
  sosAlert: true,
  onlineStatus: true,
  locationVisible: true,
  messageReceive: true,
};

export async function getInteractionSettings(): Promise<InteractionSettings> {
  try {
    const raw = await AsyncStorage.getItem(KEYS.INTERACTION);
    if (!raw) return { ...DEFAULT_INTERACTION };
    const parsed = JSON.parse(raw);
    // 合并默认值防止新增字段缺失
    return { ...DEFAULT_INTERACTION, ...parsed };
  } catch {
    return { ...DEFAULT_INTERACTION };
  }
}

export async function updateInteractionSetting(
  key: keyof InteractionSettings,
  value: boolean,
): Promise<InteractionSettings> {
  const current = await getInteractionSettings();
  const updated = { ...current, [key]: value };
  await AsyncStorage.setItem(KEYS.INTERACTION, JSON.stringify(updated));
  return updated;
}

export async function resetInteractionSettings(): Promise<InteractionSettings> {
  await AsyncStorage.setItem(KEYS.INTERACTION, JSON.stringify(DEFAULT_INTERACTION));
  return { ...DEFAULT_INTERACTION };
}

// ====== 意见反馈（持久化） ======

async function readFeedbacks(): Promise<Feedback[]> {
  try {
    const raw = await AsyncStorage.getItem(KEYS.FEEDBACKS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

async function writeFeedbacks(list: Feedback[]): Promise<void> {
  try {
    if (list.length > 500) list.length = 500;
    await AsyncStorage.setItem(KEYS.FEEDBACKS, JSON.stringify(list));
  } catch { /* 静默 */ }
}

export async function submitFeedback(
  userId: string,
  username: string,
  content: string,
  contact: string,
): Promise<Feedback> {
  await delay(500);
  const fb: Feedback = {
    id: 'fb_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
    userId,
    username,
    content,
    contact,
    createdAt: new Date().toISOString(),
    status: 'pending',
  };
  const all = await readFeedbacks();
  all.unshift(fb);
  await writeFeedbacks(all);
  // 更新管理员反馈未读角标
  try {
    const { addUnread } = await import('./unreadBadge');
    await addUnread('adminPendingFeedback');
  } catch {}
  return fb;
}

export async function getMyFeedbacks(userId: string): Promise<Feedback[]> {
  await delay(300);
  const all = await readFeedbacks();
  return (all ?? []).filter((f) => f.userId === userId);
}

/** 管理员获取全站反馈 */
export async function getAllFeedbacks(): Promise<Feedback[]> {
  await delay(300);
  const all = await readFeedbacks();
  return all.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );
}

/** 更新反馈处理状态 */
export async function updateFeedbackStatus(
  feedbackId: string,
  status: 'pending' | 'resolved',
): Promise<boolean> {
  const all = await readFeedbacks();
  const item = all.find((f) => f.id === feedbackId);
  if (!item) return false;
  item.status = status;
  await writeFeedbacks(all);
  return true;
}

// ====== 联系管理员留言（独立持久化） ======

interface ContactAdminMessage {
  id: string;
  userId: string;
  username: string;
  phone: string;
  message: string;
  createdAt: string;
  status: 'unread' | 'read' | 'replied';
}

async function readContactAdminMsgs(): Promise<ContactAdminMessage[]> {
  try {
    const raw = await AsyncStorage.getItem(KEYS.CONTACT_ADMIN_MSGS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

async function writeContactAdminMsgs(list: ContactAdminMessage[]): Promise<void> {
  try {
    if (list.length > 200) list.length = 200;
    await AsyncStorage.setItem(KEYS.CONTACT_ADMIN_MSGS, JSON.stringify(list));
  } catch { /* 静默 */ }
}

export async function sendContactAdminMessage(
  userId: string,
  username: string,
  phone: string,
  message: string,
): Promise<ContactAdminMessage> {
  await delay(400);
  const msg: ContactAdminMessage = {
    id: 'cam_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
    userId,
    username,
    phone,
    message,
    createdAt: new Date().toISOString(),
    status: 'unread',
  };
  const all = await readContactAdminMsgs();
  all.unshift(msg);
  await writeContactAdminMsgs(all);
  return msg;
}

/** 管理员获取全部联系消息 */
export async function getAllContactAdminMessages(): Promise<ContactAdminMessage[]> {
  await delay(200);
  const all = await readContactAdminMsgs();
  return all.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );
}

/** 标记联系消息为已读 */
export async function markContactMessageRead(messageId: string): Promise<boolean> {
  const all = await readContactAdminMsgs();
  const msg = all.find((m) => m.id === messageId);
  if (!msg) return false;
  msg.status = 'read';
  await writeContactAdminMsgs(all);
  return true;
}

// ====== 手机使用数据（持久化 + 管理员可见） ======

async function readPhoneUsages(): Promise<PhoneData[]> {
  try {
    const raw = await AsyncStorage.getItem(KEYS.PHONE_USAGE);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

async function writePhoneUsages(list: PhoneData[]): Promise<void> {
  try {
    if (list.length > 200) list.length = 200;
    await AsyncStorage.setItem(KEYS.PHONE_USAGE, JSON.stringify(list));
  } catch { /* 静默 */ }
}

/** 上报或更新手机使用数据 */
export async function reportPhoneUsage(data: PhoneData): Promise<PhoneData> {
  const all = await readPhoneUsages();
  const now = new Date().toISOString();
  const existing = all.findIndex((p) => p.userId === data.userId);

  const entry: PhoneData = {
    ...data,
    dataUpdatedAt: now,
  };

  if (existing >= 0) {
    all[existing] = entry;
  } else {
    all.unshift(entry);
  }

  await writePhoneUsages(all);
  return entry;
}

/** 普通用户查看自己的手机使用数据 */
export async function getMyPhoneUsage(userId: string): Promise<PhoneData | null> {
  const all = await readPhoneUsages();
  return all.find((p) => p.userId === userId) || null;
}

/** 管理员查看全站手机使用数据（仅管理员角色可调，调用方做权限校验） */
export async function getAllPhoneUsage(): Promise<{
  totalUsers: number;
  avgScreenTimePerDay: number;
  avgAppUsageMinutes: number;
  avgChargeCount: number;
  users: PhoneData[];
}> {
  const users = await readPhoneUsages();
  const totalUsers = users.length;
  const avgScreen = totalUsers > 0
    ? Math.round(users.reduce((s, u) => s + (u.screenTimePerDay || 0), 0) / totalUsers)
    : 0;
  const avgApp = totalUsers > 0
    ? Math.round(users.reduce((s, u) => s + (u.appUsageMinutes || 0), 0) / totalUsers)
    : 0;
  const avgCharge = totalUsers > 0
    ? Math.round(users.reduce((s, u) => s + (u.chargeCount || 0), 0) / totalUsers)
    : 0;

  return {
    totalUsers,
    avgScreenTimePerDay: avgScreen,
    avgAppUsageMinutes: avgApp,
    avgChargeCount: avgCharge,
    users,
  };
}

export { DEFAULT_INTERACTION };
export type { ContactAdminMessage };
