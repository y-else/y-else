/**
 * 专属日记 API 服务层（持久化版）
 *
 * 基于 AsyncStorage 持久化，绑定双方专属可见。
 * 权限模型：仅绑定关系内的两人可读/写，仅作者可编辑/删除。
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import type { DiaryPost, DiaryMedia, ContactGroup } from '../types';
import { emitNewPost } from './websocketClient';

const DIARY_KEY = '@ing_diaries';
const delay = (ms = 300) => new Promise((r) => setTimeout(r, ms));

// ====== 持久化读写 ======

async function readAllDiaries(): Promise<DiaryPost[]> {
  try {
    const raw = await AsyncStorage.getItem(DIARY_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

async function writeAllDiaries(posts: DiaryPost[]): Promise<void> {
  try {
    await AsyncStorage.setItem(DIARY_KEY, JSON.stringify(posts));
  } catch (e) {
    console.warn('[日记] 写入失败:', e);
  }
}

// ====== 绑定关系校验 ======

/**
 * 导入通讯录读取函数（内部使用，避免循环依赖）
 * contacts.ts 中 readContacts 是本模块内联使用，
 * 这里直接读 AsyncStorage 避免跨模块循环引用
 */
async function _readContacts(): Promise<Array<{
  userId: string; group: ContactGroup; isBlocked: boolean;
}>> {
  try {
    const raw = await AsyncStorage.getItem('@ing_contacts');
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

/** 验证两个用户是否存在有效的绑定关系（非拉黑、非blocked分组） */
async function validateBinding(userA: string, userB: string): Promise<boolean> {
  const contacts = await _readContacts();
  const aHasB = contacts.find(
    (c: any) => c.userId === userB && !c.isBlocked && c.group !== 'blocked',
  );
  const bHasA = contacts.find(
    (c: any) => c.userId === userA && !c.isBlocked && c.group !== 'blocked',
  );
  return !!(aHasB && bHasA);
}

// ====== 获取日记列表 ======

export async function getDiaries(
  userId: string,
  partnerId: string,
  page = 1,
  pageSize = 20,
): Promise<{ posts: DiaryPost[]; total: number; hasMore: boolean }> {
  await delay(300);
  const all = await readAllDiaries();

  const visible = all
    .filter((p) => p.visibleTo.includes(userId) && p.visibleTo.includes(partnerId))
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const total = visible.length;
  const start = (page - 1) * pageSize;
  const posts = visible.slice(start, start + pageSize);

  return { posts, total, hasMore: start + pageSize < total };
}

// ====== 发布日记 ======

export async function createDiary(
  authorId: string,
  authorName: string,
  authorAvatar: string | null,
  partnerId: string,
  partnerName: string,
  content: string,
  media: DiaryMedia[],
): Promise<DiaryPost> {
  await delay(400);

  // 1. 内容校验
  const trimmed = content.trim();
  if (!trimmed && media.length === 0) {
    throw new Error('请输入内容或添加图片/视频');
  }
  if (trimmed.length > 2000) {
    throw new Error('日记内容不能超过2000字');
  }
  if (media.length > 9) {
    throw new Error('最多添加9个图片/视频');
  }

  // 2. 绑定关系校验（非拉黑状态下有绑定关系才能发日记）
  const isValid = await validateBinding(authorId, partnerId);
  if (!isValid) {
    throw new Error('您与该用户没有绑定关系，无法发布专属日记');
  }

  // 3. 创建日记
  const now = new Date().toISOString();
  const post: DiaryPost = {
    id: 'diary_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
    authorId, authorName, authorAvatar,
    partnerId, partnerName,
    content: trimmed,
    media,
    createdAt: now,
    updatedAt: now,
    visibleTo: [authorId, partnerId],
  };

  const all = await readAllDiaries();
  all.unshift(post);
  // 限制单对用户日记总数 500 条
  const pairDiaries = all.filter(
    (p) => p.visibleTo.includes(authorId) && p.visibleTo.includes(partnerId),
  );
  if (pairDiaries.length > 500) {
    // 移除最旧的日记
    const oldest = pairDiaries[pairDiaries.length - 1];
    const idx = all.findIndex((p) => p.id === oldest.id);
    if (idx >= 0) all.splice(idx, 1);
  }
  await writeAllDiaries(all);

  // WS实时推送：通知绑定伙伴有新日记
  try {
    emitNewPost({
      postId: post.id,
      authorId,
      authorName,
      partnerId,
      content: trimmed,
      media,
      createdAt: now,
    });
  } catch {}

  return post;
}

// ====== 编辑日记 ======

export async function updateDiary(
  postId: string,
  userId: string,
  content: string,
  media: DiaryMedia[],
): Promise<DiaryPost | null> {
  await delay(300);

  const trimmed = content.trim();
  if (!trimmed && media.length === 0) {
    throw new Error('请输入内容或添加图片/视频');
  }
  if (trimmed.length > 2000) {
    throw new Error('日记内容不能超过2000字');
  }
  if (media.length > 9) {
    throw new Error('最多添加9个图片/视频');
  }

  const all = await readAllDiaries();
  const post = all.find((p) => p.id === postId);

  if (!post) {
    throw new Error('日记不存在');
  }
  if (post.authorId !== userId) {
    throw new Error('仅作者可以编辑日记');
  }

  post.content = trimmed;
  post.media = media;
  post.updatedAt = new Date().toISOString();
  await writeAllDiaries(all);

  return post;
}

// ====== 删除日记 ======

export async function deleteDiary(
  postId: string,
  userId: string,
): Promise<{ success: boolean; message: string }> {
  await delay(200);

  const all = await readAllDiaries();
  const idx = all.findIndex((p) => p.id === postId);

  if (idx < 0) {
    return { success: false, message: '日记不存在' };
  }
  if (all[idx].authorId !== userId) {
    return { success: false, message: '仅作者可以删除日记' };
  }

  all.splice(idx, 1);
  await writeAllDiaries(all);

  return { success: true, message: '日记已删除' };
}

// ====== 统计 ======

/** 获取与某用户的日记总数 */
export async function getDiaryCount(userId: string, partnerId: string): Promise<number> {
  const all = await readAllDiaries();
  return all.filter(
    (p) => p.visibleTo.includes(userId) && p.visibleTo.includes(partnerId),
  ).length;
}

/** 获取日记媒体列表（用于相册视图） */
export async function getDiaryMedia(
  userId: string,
  partnerId: string,
): Promise<{ uri: string; type: 'image' | 'video'; thumbnailUri?: string; postId: string }[]> {
  const all = await readAllDiaries();
  const mediaList: Array<{ uri: string; type: 'image' | 'video'; thumbnailUri?: string; postId: string }> = [];

  for (const post of all) {
    if (post.visibleTo.includes(userId) && post.visibleTo.includes(partnerId)) {
      for (const m of post.media) {
        mediaList.push({ ...m, postId: post.id });
      }
    }
  }

  return mediaList;
}
