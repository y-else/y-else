/**
 * 使用时长统计 + 等级计算服务
 * 1-100 级，按时长梯度自动升级
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { LEVEL_CONFIGS, type LevelConfig } from '../types';

const KEYS = {
  USAGE_MINUTES: '@ing_usage_minutes',
  CURRENT_LEVEL: '@ing_current_level',
  SESSION_START: '@ing_session_start',
};

// ====== 会话计时 ======

export async function startSession(): Promise<void> {
  await AsyncStorage.setItem(KEYS.SESSION_START, Date.now().toString());
}

export async function endSession(): Promise<number> {
  const startStr = await AsyncStorage.getItem(KEYS.SESSION_START);
  if (!startStr) return 0;

  const start = parseInt(startStr, 10);
  const elapsed = Math.floor((Date.now() - start) / 60000); // 转换为分钟
  await AsyncStorage.removeItem(KEYS.SESSION_START);

  if (elapsed > 0 && elapsed < 1440) { // 忽略超过24小时的异常数据
    const current = await getTotalMinutes();
    const newTotal = current + elapsed;
    await AsyncStorage.setItem(KEYS.USAGE_MINUTES, newTotal.toString());
    // 重新计算等级
    const newLevel = calculateLevel(newTotal);
    await AsyncStorage.setItem(KEYS.CURRENT_LEVEL, newLevel.toString());
    return elapsed;
  }
  return 0;
}

// ====== 时长与等级 ======

export async function getTotalMinutes(): Promise<number> {
  const raw = await AsyncStorage.getItem(KEYS.USAGE_MINUTES);
  return raw ? parseInt(raw, 10) : 0;
}

export function calculateLevel(totalMinutes: number): number {
  for (let i = LEVEL_CONFIGS.length - 1; i >= 0; i--) {
    if (totalMinutes >= LEVEL_CONFIGS[i].minMinutes) {
      return LEVEL_CONFIGS[i].level;
    }
  }
  return 1;
}

export function getLevelConfig(level: number): LevelConfig {
  return LEVEL_CONFIGS[Math.min(level, 100) - 1] || LEVEL_CONFIGS[0];
}

export async function getCurrentLevel(): Promise<number> {
  const raw = await AsyncStorage.getItem(KEYS.CURRENT_LEVEL);
  return raw ? parseInt(raw, 10) : 1;
}

// ====== 下一级所需时长 ======

export async function getNextLevelProgress(): Promise<{
  currentLevel: number;
  currentMinutes: number;
  nextLevelMinutes: number;
  progress: number; // 0-1
}> {
  const level = await getCurrentLevel();
  const minutes = await getTotalMinutes();
  const config = getLevelConfig(level);
  const nextConfig = level < 100 ? getLevelConfig(level + 1) : null;

  const nextMinutes = nextConfig ? nextConfig.minMinutes : config.minMinutes;
  const currentMin = config.minMinutes;
  const range = nextMinutes - currentMin;
  const progress = nextConfig ? Math.min(1, (minutes - currentMin) / (range || 1)) : 1;

  return {
    currentLevel: level,
    currentMinutes: minutes,
    nextLevelMinutes: nextMinutes,
    progress,
  };
}
