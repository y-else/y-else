/**
 * 出行服务层
 * GPS定位、出行轨迹记录、实时共享、管理员查看
 *
 * 修复:
 * - 移除 mock 内存变量，统一 AsyncStorage
 * - shareTravelStatus / stopSharing / getActiveShares 完全持久化
 * - endTravel 正确清理共享状态
 * - 新增 updateTravelRecord 和 searchTravelRecords
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import type { TravelRecord, LocationPoint, TravelShareStatus } from '../types';

const STORAGE_KEY = '@ing_travel_records';
const SHARE_KEY = '@ing_travel_shares';

// ====== 内部辅助 ======

async function readAll(): Promise<TravelRecord[]> {
  const raw = await AsyncStorage.getItem(STORAGE_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function writeAll(items: TravelRecord[]): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}

async function readShares(): Promise<TravelShareStatus[]> {
  const raw = await AsyncStorage.getItem(SHARE_KEY);
  return raw ? JSON.parse(raw) : [];
}

async function writeShares(items: TravelShareStatus[]): Promise<void> {
  await AsyncStorage.setItem(SHARE_KEY, JSON.stringify(items));
}

// ====== 个人出行记录 ======

export async function getMyTravelRecords(userId: string): Promise<TravelRecord[]> {
  const all = await readAll();
  return all
    .filter((r) => r.userId === userId)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export async function startTravel(
  userId: string,
  username: string,
  startLocation: LocationPoint,
): Promise<TravelRecord> {
  // 同一个用户只能有一个进行中的出行
  const all = await readAll();
  const existing = all.find((r) => r.userId === userId && r.isActive);
  if (existing) {
    // 自动结束旧的出行
    existing.isActive = false;
    existing.endedAt = new Date().toISOString();
  }

  const record: TravelRecord = {
    id: 'trv_' + Date.now(),
    userId,
    username,
    startLocation,
    endLocation: null,
    startedAt: new Date().toISOString(),
    endedAt: null,
    isActive: true,
    sharedTo: [],
    notes: '',
    createdAt: new Date().toISOString(),
  };
  all.push(record);
  await writeAll(all);
  return record;
}

export async function endTravel(
  travelId: string,
  endLocation: LocationPoint,
  notes?: string,
): Promise<TravelRecord | null> {
  const all = await readAll();
  const r = all.find((r) => r.id === travelId);
  if (!r) return null;
  r.endLocation = endLocation;
  r.endedAt = new Date().toISOString();
  r.isActive = false;
  if (notes) r.notes = notes;
  await writeAll(all);

  // 清除关联的共享状态
  const shares = await readShares();
  await writeShares(shares.filter((s) => s.travelId !== travelId));

  return r;
}

export async function updateTravelRecord(
  id: string,
  updates: Partial<Pick<TravelRecord, 'notes' | 'endLocation'>>,
): Promise<TravelRecord | null> {
  const all = await readAll();
  const idx = all.findIndex((r) => r.id === id);
  if (idx < 0) return null;
  all[idx] = { ...all[idx], ...updates };
  await writeAll(all);
  return all[idx];
}

export async function deleteTravelRecord(id: string): Promise<boolean> {
  const all = await readAll();
  const filtered = all.filter((r) => r.id !== id);
  await writeAll(filtered);
  // 清除关联共享
  const shares = await readShares();
  await writeShares(shares.filter((s) => s.travelId !== id));
  return true;
}

// ====== 实时共享 ======

export async function shareTravelStatus(
  travelId: string,
  userId: string,
  username: string,
  currentLocation: LocationPoint,
  targetUserId: string,
): Promise<boolean> {
  const shares = await readShares();
  // 同一出行 + 同一目标用户去重
  const existing = shares.find(
    (s) => s.travelId === travelId && s.userId === userId,
  );
  if (existing) {
    existing.currentLocation = currentLocation;
    existing.sharedAt = new Date().toISOString();
  } else {
    shares.push({
      travelId,
      userId,
      username,
      currentLocation,
      sharedAt: new Date().toISOString(),
    });
  }
  await writeShares(shares);

  // 更新出行记录的 sharedTo
  const all = await readAll();
  const r = all.find((r) => r.id === travelId);
  if (r && !r.sharedTo.includes(targetUserId)) {
    r.sharedTo.push(targetUserId);
    await writeAll(all);
  }

  return true;
}

export async function stopSharing(travelId: string): Promise<boolean> {
  const shares = await readShares();
  await writeShares(shares.filter((s) => s.travelId !== travelId));

  // 清除出行记录的 sharedTo
  const all = await readAll();
  const r = all.find((r) => r.id === travelId);
  if (r) {
    r.sharedTo = [];
    await writeAll(all);
  }

  return true;
}

/** 更新共享的实时位置（GPS回调调用） */
export async function updateShareLocation(
  travelId: string,
  userId: string,
  location: LocationPoint,
): Promise<void> {
  const shares = await readShares();
  const share = shares.find(
    (s) => s.travelId === travelId && s.userId === userId,
  );
  if (share) {
    share.currentLocation = location;
    share.sharedAt = new Date().toISOString();
    await writeShares(shares);
  }
}

export async function getActiveShares(
  userId: string,
): Promise<TravelShareStatus[]> {
  const shares = await readShares();
  return shares.filter((s) => s.userId === userId);
}

/** 获取共享给我（我可以看到哪些人的实时出行） */
export async function getSharesForMe(
  userId: string,
): Promise<TravelShareStatus[]> {
  // 先获取所有被分享给我的出行记录
  const all = await readAll();
  const sharedToMe = all.filter((r) => r.sharedTo.includes(userId) && r.isActive);
  const travelIds = new Set(sharedToMe.map((r) => r.id));

  const shares = await readShares();
  return shares.filter((s) => travelIds.has(s.travelId));
}

// ====== 管理员 ======

export async function getAllTravelRecords(): Promise<TravelRecord[]> {
  const all = await readAll();
  return all.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );
}

/** 管理员搜索出行记录 */
export async function searchTravelRecords(
  query?: string,
  activeOnly?: boolean,
): Promise<TravelRecord[]> {
  let all = await readAll();

  if (activeOnly) {
    all = all.filter((r) => r.isActive);
  }

  if (query) {
    const q = query.toLowerCase();
    all = all.filter(
      (r) =>
        r.username.toLowerCase().includes(q) ||
        r.startLocation.name.toLowerCase().includes(q) ||
        (r.endLocation?.name || '').toLowerCase().includes(q) ||
        r.notes.toLowerCase().includes(q),
    );
  }

  return all.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );
}
