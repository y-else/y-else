/**
 * 出行模块 — 类型定义
 */

export interface LocationPoint {
  name: string;
  latitude: number;
  longitude: number;
}

export interface TravelRecord {
  id: string;
  userId: string;
  username: string;
  startLocation: LocationPoint;
  endLocation: LocationPoint | null;
  startedAt: string;
  endedAt: string | null;
  isActive: boolean;        // 是否进行中
  sharedTo: string[];       // 共享目标用户ID
  notes: string;
  createdAt: string;
}

export interface TravelShareStatus {
  travelId: string;
  userId: string;
  username: string;
  currentLocation: LocationPoint;
  sharedAt: string;
}
