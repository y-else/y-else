/**
 * 通讯录 + 绑定 + 拉黑 + 专属日记 — 完整类型定义
 */

import type { RoleType } from './auth';

// ====== 联系人 ======

export type OnlineStatus = 'online' | 'offline' | 'busy';

export type ContactGroup = 'family' | 'friend' | 'lover' | 'blocked';

export interface Contact {
  userId: string;
  username: string;
  phone: string;        // 脱敏显示：138****8000
  rawPhone: string;     // 真实手机号（仅自己/管理员可见）
  avatar: string | null;
  role: RoleType;
  group: ContactGroup;
  remark: string | null;      // 自定义备注（仅自己可见）
  status: OnlineStatus;
  lastOnlineAt: string;
  isPinned: boolean;          // 置顶
  lastContactAt: string;      // 最近联系时间
  isBlocked: boolean;
  blockedAt: string | null;
  lastKnownLocation: {        // 拉黑后冻结在此位置
    latitude: number;
    longitude: number;
    address: string | null;
    updatedAt: string;
  } | null;
}

// ====== 绑定 ======

export type BindRequestStatus = 'pending' | 'accepted' | 'rejected' | 'cancelled';

export interface BindRequest {
  id: string;
  fromUserId: string;
  fromUsername: string;
  fromPhone: string;
  fromAvatar: string | null;
  toUserId: string;
  toUsername: string;
  toPhone: string;
  type: ContactGroup;         // family / friend / lover
  status: BindRequestStatus;
  message: string;            // 验证消息
  createdAt: string;
  updatedAt: string;
}

export interface UnbindNotification {
  id: string;
  fromUserId: string;
  fromUsername: string;
  targetUserId: string;
  targetUsername: string;
  relationType: ContactGroup;
  type: 'unbind_request' | 'unbind_confirmed';
  createdAt: string;
}

// ====== 解绑请求（持久化，含状态流转） ======

export interface UnbindRequest {
  id: string;
  fromUserId: string;
  fromUsername: string;
  targetUserId: string;
  targetUsername: string;
  relationType: ContactGroup;
  status: 'pending' | 'confirmed' | 'cancelled';
  createdAt: string;
  updatedAt: string;
}

// ====== 系统通知（绑定/解绑事件消息） ======

export interface BindNotification {
  id: string;
  type: 'bind_request' | 'bind_accepted' | 'bind_rejected' | 'bind_cancelled' | 'unbind_request' | 'unbind_confirmed';
  fromUserId: string;
  fromUsername: string;
  toUserId: string;
  toUsername: string;
  relationType: ContactGroup;
  message: string;
  isRead: boolean;
  createdAt: string;
}

// ====== 快捷消息 ======

export interface QuickMessage {
  id: string;
  text: string;
  category: 'greeting' | 'care' | 'emergency' | 'custom';
}

// ====== 拉黑 ======

export interface BlockRecord {
  userId: string;
  blockedUserId: string;
  blockedUsername: string;
  reason: string | null;
  blockedAt: string;
  frozenLocation: {        // 冻结的 GPS 位置
    latitude: number;
    longitude: number;
    address: string | null;
  } | null;
}

// ====== 专属日记 ======

export type DiaryMediaType = 'image' | 'video';

export interface DiaryMedia {
  uri: string;
  type: DiaryMediaType;
  thumbnailUri?: string;
}

export interface DiaryPost {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string | null;
  partnerId: string;
  partnerName: string;
  content: string;
  media: DiaryMedia[];
  createdAt: string;
  updatedAt: string;
  // 谁可以看：仅绑定双方
  visibleTo: [string, string]; // [authorId, partnerId]
}
