/**
 * 健康模块 — 类型定义
 */

export type HealthRecordType = 'checkin' | 'mood' | 'body_note';

export type MoodType = 'happy' | 'calm' | 'sad' | 'anxious' | 'energetic';

export const MOOD_OPTIONS: { type: MoodType; label: string; emoji: string; color: string }[] = [
  { type: 'happy', label: '开心', emoji: '😊', color: '#F0AD4E' },
  { type: 'calm', label: '平静', emoji: '😌', color: '#4A90E2' },
  { type: 'sad', label: '难过', emoji: '😢', color: '#7B68EE' },
  { type: 'anxious', label: '焦虑', emoji: '😰', color: '#E74C3C' },
  { type: 'energetic', label: '精力充沛', emoji: '⚡', color: '#5CB85C' },
];

export interface HealthRecord {
  id: string;
  userId: string;
  username: string;
  type: HealthRecordType;
  mood?: MoodType;
  bodyNote?: string;
  checkinTime?: string;     // 作息打卡时间
  isShared: boolean;
  visibleTo: string[];      // 可见用户ID
  createdAt: string;
}
