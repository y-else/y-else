/**
 * 首页模块 — 完整类型定义
 * 关系卡片、公告、抽奖、SOS
 */

import type { RoleType } from './auth';

// ====== 关系绑定 ======

// 绑定关系类型（与角色色对应）
export type RelationType = 'family' | 'friend' | 'lover';

// 绑定状态
export type BindStatus = 'none' | 'pending' | 'bound';

// 关系卡片数据
export interface RelationCard {
  type: RelationType;
  role: RoleType;
  label: string; // 显示标签：家人/朋友/恋人
  color: string; // 对应角色色
  status: BindStatus;
  boundUser: BoundUser | null;
}

export interface BoundUser {
  userId: string;
  username: string;
  avatar: string | null;
  phone: string;
  boundAt: string; // ISO 8601
}

// ====== 公告 ======

export type AnnouncementLevel = 'normal' | 'important' | 'urgent';

export interface Announcement {
  id: string;
  title: string;
  content: string;
  level: AnnouncementLevel;
  publishedBy: string; // 管理员用户名
  publishedAt: string;
  // 用户已读状态（不跨设备同步，本地缓存）
}

// ====== 抽奖 ======

export type LotteryStatus = 'active' | 'inactive';

export interface LotteryPrize {
  id: string;
  name: string;
  type: 'virtual' | 'physical';
  imageUri?: string | null;
  totalCount: number; // 总数量
  remainingCount: number; // 剩余数量
  probability: number; // 中奖概率 0-1
}

export interface LotteryConfig {
  id: string;
  status: LotteryStatus;
  prizes: LotteryPrize[];
  maxDrawsPerDay: number; // 每人每天最大抽奖次数
  startAt: string;
  endAt: string;
}

// 用户抽奖申请记录（预留字段）
export interface LotteryApplication {
  id: string;
  userId: string;
  configId: string;
  appliedAt: string;
  result: 'pending' | 'won' | 'lost';
  prizeId: string | null;
}

// ====== SOS 求救 ======

export type SOSStatus = 'idle' | 'activating' | 'counting_down' | 'triggered' | 'cancelled';

export interface SOSAlert {
  id: string;
  senderId: string;
  senderName: string;
  senderPhone: string;
  location: {
    latitude: number;
    longitude: number;
  };
  address: string | null;
  triggeredAt: string;
  status: 'active' | 'resolved';
}

// SOS 接收者
export interface SOSReceiver {
  userId: string;
  type: 'bound' | 'admin'; // 绑定人或管理员
}
