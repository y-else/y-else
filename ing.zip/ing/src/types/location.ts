/**
 * 定位 + 权限 + 设置 — 类型定义
 */

// ====== 定位 ======

export interface UserLocation {
  userId: string;
  username: string;
  avatar: string | null;
  role: string;
  latitude: number;
  longitude: number;
  address: string | null;
  updatedAt: string;
  isOnline: boolean;
}

export interface LocationHistoryPoint {
  latitude: number;
  longitude: number;
  timestamp: string;
  address: string | null;
}

export interface LocationHistory {
  userId: string;
  username: string;
  points: LocationHistoryPoint[];
}

// ====== 权限设置 ======

export type PermissionStatus = 'granted' | 'denied' | 'blocked';

export interface AppPermissions {
  locationForeground: PermissionStatus;
  locationBackground: PermissionStatus;
  notification: PermissionStatus;
}

// ====== 互动权限开关 ======

export interface InteractionSettings {
  quickMessage: boolean;    // 快捷消息
  vibration: boolean;       // 振动
  popupNotify: boolean;     // 弹窗提醒
  sosAlert: boolean;        // SOS 求救
  onlineStatus: boolean;    // 在线状态可见
  locationVisible: boolean; // 定位可见
  messageReceive: boolean;  // 消息接收
}

// ====== 手机使用情况 ======

export interface PhoneUsage {
  screenTimeMinutes: number;
  unlockCount: number;
  topApps: { name: string; duration: number }[];
  lastUpdated: string;
}

// ====== 意见反馈 ======

export interface Feedback {
  id: string;
  userId: string;
  username: string;
  content: string;
  contact: string;
  createdAt: string;
  status: 'pending' | 'resolved';
}
