/**
 * 日程模块 — 类型定义
 */

export type ScheduleVisibility = 'private' | 'friends_only' | 'public';

export interface ScheduleItem {
  id: string;
  userId: string;
  username: string;
  title: string;
  content: string;
  scheduledAt: string;       // ISO 8601 日程时间
  reminderAt: string | null; // ISO 8601 提醒时间
  reminderEnabled: boolean;
  visibility: ScheduleVisibility;
  sharedTo: string[];        // 共享目标用户ID列表
  createdAt: string;
  updatedAt: string;
}

export interface ScheduleShareNotification {
  id: string;
  scheduleId: string;
  fromUserId: string;
  fromUsername: string;
  toUserId: string;
  scheduleTitle: string;
  createdAt: string;
  isRead: boolean;
}
