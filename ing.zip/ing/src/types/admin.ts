/**
 * 管理员后台 — 类型定义
 */

import type { PublicProfile } from './profile';
import type { Contact, BindRequest, BlockRecord } from './contacts';
import type { SOSAlert, LotteryConfig, LotteryApplication, LotteryPrize } from './home';
import type { UserLocation, LocationHistoryPoint } from './location';
import type { SpacePost } from './profile';
import type { RealNameInfo } from './auth';
import type { AuthLog } from './auth';
import type { Announcement } from './home';

// ====== 用户完整数据视图 ======

export interface UserFullData {
  userId: string;
  basicInfo: PublicProfile;
  realName: RealNameInfo | null;
  locationHistory: LocationHistoryPoint[];
  currentLocation: UserLocation | null;
  bindings: Contact[];
  bindRequests: BindRequest[];
  sosRecords: SOSAlert[];
  spacePosts: SpacePost[];
  blockRecords: BlockRecord[];
  authLogs: AuthLog[];
  phoneUsage: PhoneData | null;
}

// ====== 手机使用数据 ======

export interface ForegroundRecord {
  appName: string;
  startTime: string;
  endTime: string;
  durationMinutes: number;
}

export interface BackgroundRecord {
  appName: string;
  startTime: string;
  endTime: string;
  durationMinutes: number;
}

export interface PhoneData {
  userId: string;
  username: string;
  phone: string;
  chargeCount: number;              // 充电次数
  appUsageMinutes: number;          // APP 使用时长（分钟）
  appStartCount: number;            // APP 启停次数
  appStopCount: number;
  lastChargeAt: string;
  batteryHealth: string;            // 电池健康度
  screenTimePerDay: number;         // 日均屏幕时间（分钟）
  foregroundRecords: ForegroundRecord[];  // 前台驻留记录
  backgroundRecords: BackgroundRecord[];  // 后台驻留记录
  dataUpdatedAt: string;
}

// ====== 全站手机使用汇总 ======

export interface AllUsersPhoneUsage {
  totalUsers: number;
  avgScreenTimePerDay: number;
  avgAppUsageMinutes: number;
  users: PhoneData[];
}

// ====== 管理员操作审计 ======

export type AdminAction =
  | 'audit_register' | 'reset_password' | 'force_unbind'
  | 'grant_permission' | 'revoke_permission' | 'view_data'
  | 'publish_announcement' | 'config_lottery' | 'process_lottery'
  | 'approve_register' | 'reject_register' | 'update_lottery'
  | 'update_permission' | 'delete_user' | 'edit_user_info'
  | 'create_redemption' | 'deactivate_redemption' | 'cancel_redemption'
  | 'bind_admin' | 'unbind_admin' | 'regenerate_token';

export interface AdminOperationLog {
  id: string;
  adminId: string;
  adminName: string;
  action: AdminAction;
  targetUserId: string;
  targetUsername: string;
  detail: string;
  timestamp: string;
  ip: string;
}

// ====== 后台统计 ======

export interface AdminStats {
  totalUsers: number;
  onlineUsers: number;
  verifiedUsers: number;
  unverifiedUsers: number;
  sosToday: number;
  activeUsersToday: number;
  newUsersThisWeek: number;
  totalSpacePosts: number;
}

// ====== 公告发布表单 ======

export interface AnnouncementForm {
  title: string;
  content: string;
  level: 'normal' | 'important' | 'urgent';
}

// ====== 抽奖配置表单 ======

export interface LotteryConfigForm {
  status: 'active' | 'inactive';
  prizes: Omit<LotteryPrize, 'id' | 'remainingCount'>[];
  maxDrawsPerDay: number;
  startAt: string;
  endAt: string;
}

// ====== 功能授权 ======

export interface FunctionPermission {
  userId: string;
  canSOS: boolean;
  canLocation: boolean;
  canMessage: boolean;
  canDiary: boolean;
  canSpacePost: boolean;
}

// ====== 管理员密令绑定 ======

export interface AdminBinding {
  userId: string;
  username: string;
  adminId: string;
  adminName: string;
  boundAt: string;
  isActive: boolean;
  boundWithToken: string;  // 绑定时使用的密令（密令变更后自动失效）
}
