/**
 * 用户主页 + 个人空间 + 等级/点赞/留言/相册 — 类型定义
 */

// ====== 用户主页资料 ======

export interface PublicProfile {
  userId: string;
  username: string;
  avatar: string | null;
  bio: string;                    // 个人简介
  birthday: string | null;        // YYYY-MM-DD，一年仅可修改一次
  lastBirthdayEdit: string | null; // 上次修改生日的日期
  gender: 'male' | 'female' | 'other' | 'hidden';
  level: number;                  // 1-100 使用时长等级
  totalMinutes: number;           // 累计使用时长（分钟）
  location: string;               // 所在地
  createdAt: string;
}

// ====== 生日 ======

export interface BirthdayInfo {
  userId: string;
  birthday: string;              // MM-DD
  age: number;
  isToday: boolean;
}

export interface BirthdayReminder {
  friendUserId: string;
  friendUsername: string;
  birthday: string;
}

// ====== 等级系统 (1-100) ======

export interface LevelConfig {
  level: number;
  minMinutes: number;            // 达到该等级所需最低分钟数
  title: string;                 // 等级称号
}

// 等级梯度规则：每级所需分钟数递增
export const LEVEL_CONFIGS: LevelConfig[] = Array.from({ length: 100 }, (_, i) => {
  const level = i + 1;
  const minMinutes = level <= 10 ? level * 60
    : level <= 30 ? 600 + (level - 10) * 120
    : level <= 60 ? 3000 + (level - 30) * 300
    : level <= 80 ? 12000 + (level - 60) * 600
    : 24000 + (level - 80) * 1200;
  const title = level <= 10 ? '初识陪伴'
    : level <= 30 ? '常驻用户'
    : level <= 60 ? '忠实伙伴'
    : level <= 80 ? '守护者'
    : '传奇陪伴';
  return { level, minMinutes, title };
});

// ====== 主页点赞 ======

export interface ProfileLike {
  userId: string;
  username: string;
  avatar: string | null;
  likedAt: string;
}

export interface LikeRecord {
  targetUserId: string;
  totalLikes: number;            // 公开
  likeList: ProfileLike[];       // 仅本人可见
}

// ====== 留言墙 ======

export interface WallMessage {
  id: string;
  targetUserId: string;          // 留言目标用户（属于谁的空间）
  authorId: string;
  authorName: string;
  authorAvatar: string | null;
  content: string;
  createdAt: string;
  isDeleted: boolean;
  isReported?: boolean;          // 是否被举报
}

// ====== 个人空间动态 ======

export type SpaceVisibility = 'public' | 'friends_only' | 'private';

export interface SpacePost {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string | null;
  content: string;
  media: SpaceMedia[];
  visibility: SpaceVisibility;
  likes: SpaceLike[];
  comments: SpaceComment[];
  blockedBy: string[];           // 拉黑此动态发布者的用户ID列表
  reportCount: number;           // 被举报次数
  createdAt: string;
  updatedAt: string;
}

export interface SpaceMedia {
  uri: string;
  type: 'image' | 'video';
  thumbnailUri?: string;
}

export interface SpaceLike {
  userId: string;
  username: string;
  likedAt: string;
}

export interface SpaceComment {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string | null;
  content: string;
  createdAt: string;
  isDeleted: boolean;
  blockedBy?: string[];          // 拉黑此评论者的用户ID列表
  reportCount?: number;          // 被举报次数
}

// ====== 空间访问记录 ======

export interface SpaceVisit {
  visitorId: string;
  visitorName: string;
  visitorAvatar: string | null;
  visitedAt: string;
}

export interface VisitRecord {
  targetUserId: string;
  totalVisits: number;           // 公开
  visitorList: SpaceVisit[];     // 仅主人可见
}

// ====== 相册 ======

export type AlbumPermission = 'public' | 'friends_only' | 'private';

export interface AlbumItem {
  id: string;
  uri: string;
  type: 'image' | 'video';
  thumbnailUri?: string;
  source: 'auto' | 'manual';     // 自动同步 / 手动添加
  addedAt: string;
  permission: AlbumPermission;
}

export interface Album {
  ownerId: string;
  items: AlbumItem[];
}
