/**
 * 消息模块 — 类型定义
 */

export type MessageType = 'private' | 'quick' | 'announcement' | 'sos';

export interface Message {
  id: string;
  type: MessageType;
  fromUserId: string;
  fromUsername: string;
  fromAvatar: string | null;
  toUserId: string;
  content: string;
  isRead: boolean;
  createdAt: string;
  // 关联数据（可选）
  relatedId?: string;       // 关联的公告ID/SOS ID等
}

export interface UnreadCount {
  total: number;
  private: number;
  quick: number;
  announcement: number;
  sos: number;
}

export interface PrivateChatMessage {
  id: string;
  fromUserId: string;
  fromUsername: string;
  fromAvatar: string | null;
  toUserId: string;
  content: string;
  createdAt: string;
}
