/**
 * 兑换码 + 管理员绑定 — 类型定义
 */

export type RedemptionRewardType = 'virtual' | 'physical';
export type RedemptionCodeStatus = 'active' | 'inactive' | 'expired' | 'exhausted';

export interface RedemptionCode {
  id: string;
  code: string;
  rewardType: RedemptionRewardType;
  rewardName: string;
  rewardDescription: string;
  targetPhone: string | null;    // 指定用户手机号（null=全体可用）
  targetUserId: string | null;   // 指定用户ID（null=全体可用）
  maxRedemptions: number;        // 总可兑次数（1=单次）
  redeemedCount: number;         // 已兑次数
  perUserLimit: number;          // 每人限兑次数
  validFrom: string;
  validUntil: string;
  isActive: boolean;
  createdBy: string;
  createdAt: string;
}

export interface RedemptionRecord {
  id: string;
  codeId: string;
  code: string;
  userId: string;
  username: string;
  phone: string;
  rewardType: RedemptionRewardType;
  rewardName: string;
  shippingAddress?: ShippingAddress;
  redeemedAt: string;
  status: 'success' | 'cancelled';
  cancelledAt?: string;
  cancelledBy?: string;
}

export interface ShippingAddress {
  name: string;
  phone: string;
  province: string;
  city: string;
  district: string;
  detail: string;
}

// ====== 筛选/搜索 ======

export type RedemptionCodeFilterType = 'all' | 'virtual' | 'physical';
export type RedemptionCodeFilterStatus = 'all' | 'active' | 'inactive' | 'expired' | 'exhausted';

export interface RedemptionStats {
  totalCodes: number;
  activeCodes: number;
  exhaustedCodes: number;
  expiredCodes: number;
  inactiveCodes: number;
  totalRedemptions: number;
  totalCancelled: number;
}
