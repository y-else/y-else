/**
 * 账号体系 — 完整类型定义
 * 数据结构预留管理员查看日志字段
 */

// 角色类型（与全局角色色对应）
export type RoleType = 'family' | 'friend' | 'lover' | 'admin';

// 实名认证状态
export type RealNameStatus = 'unverified' | 'pending' | 'verified' | 'rejected';

// 账号状态
export type AccountStatus = 'active' | 'disabled' | 'deleted' | 'pending';

// 注册申请（管理员审核用）
export interface RegisterApplication {
  userId: string;
  username: string;
  phone: string;
  password: string;
  avatarUri: string | null;
  status: 'pending' | 'approved' | 'rejected';
  appliedAt: string;
  reviewedAt: string | null;
  reviewedBy: string | null;
}

// 登录/操作记录类型
export type LoginAction =
  | 'login' | 'logout'
  | 'password_change' | 'realname_submit'
  | 'register' | 'switch_account'
  | 'audit_register' | 'publish_announcement'
  | 'deactivate_account';

// 用户基本信息
export interface UserProfile {
  id: string;
  username: string;
  phone: string;
  avatar: string | null; // 头像 URI
  role: RoleType;
  status: AccountStatus;
  createdAt: string; // ISO 8601
  updatedAt: string;
}

// 实名认证信息
export interface RealNameInfo {
  userId: string;
  realName: string;
  idCardNumber: string;
  status: RealNameStatus;
  submittedAt: string;
  verifiedAt: string | null;
  frontImageUri: string | null; // 身份证正面
  backImageUri: string | null; // 身份证反面
}

// 登录/操作日志（管理员可查看）
export interface AuthLog {
  id: string;
  userId: string;
  phone: string;
  action: LoginAction;
  ip: string;
  deviceInfo: string;
  timestamp: string;
  success: boolean;
  detail: string; // 操作描述
}

// 已保存的账号（用于多账号切换 + 免密登录）
export interface SavedAccount {
  userId: string;
  phone: string;
  username: string;
  avatar: string | null;
  token: string;
  lastLoginAt: string;
  passwordChanged?: boolean; // 管理员重置密码后标记，需重新登录
}

// API 响应泛型
export interface ApiResponse<T = undefined> {
  code: number;
  message: string;
  data?: T;
}

// 登录请求
export interface LoginRequest {
  phone: string;
  password: string;
  role?: RoleType; // 管理员需指定 role='admin'
  sessionToken?: string; // 会话恢复令牌（免密登录恢复时传入）
}

// 登录响应
export interface LoginResponse {
  user: UserProfile;
  token: string;
}

// 注册请求
export interface RegisterRequest {
  phone: string;
  password: string;
  username: string;
  smsCode: string;
  avatarUri?: string;
}

// 实名认证请求
export interface RealNameRequest {
  realName: string;
  idCardNumber: string;
  frontImageUri?: string;
  backImageUri?: string;
}

// 改密请求
export interface ChangePasswordRequest {
  phone: string;
  smsCode: string;
  newPassword: string;
}

// 管理员改密请求
export interface AdminResetRequest {
  phone: string;
  reason: string;
}

// 版本信息
export interface AppVersion {
  version: string;
  buildNumber: number;
  releaseNotes: string;
  forceUpdate: boolean;
  releasedAt: string;
}

// 管理员后台日志汇总结构
export interface AdminAuditLog {
  logins: AuthLog[];
  passwordChanges: AuthLog[];
  realnameSubmissions: AuthLog[];
  totalUsers: number;
}
