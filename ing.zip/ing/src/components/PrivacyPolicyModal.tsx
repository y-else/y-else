/**
 * 隐私政策弹窗
 * 首次启动强制弹窗，必须同意才能进入 APP
 */

import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Modal as RNModal,
} from 'react-native';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import Button from './Button';

interface PrivacyPolicyModalProps {
  visible: boolean;
  onAgree: () => void;
  onDisagree: () => void;
}

const POLICY_TEXT = `
ing 陪伴 隐私政策

更新日期：2026年5月11日
生效日期：2026年5月11日

欢迎使用 ing 陪伴（以下简称"本应用"）。本应用由 y-else 工作室开发并运营。我们深知个人信息对您的重要性，我们将按法律法规要求，采取相应安全保护措施，尽力保护您的个人信息安全可控。

一、我们收集的信息
1. 注册信息：手机号码、用户名、密码
2. 实名认证信息：真实姓名、身份证号码、身份证照片
3. 设备信息：设备型号、操作系统版本、唯一设备标识符
4. 位置信息：经您授权后获取的地理位置信息（用于定位功能）
5. 相册权限：经您授权后访问相册（用于头像上传、实名认证照片）

二、信息的使用
1. 手机号码用于账号注册、登录验证、密码找回
2. 实名认证信息仅用于身份核实，确保用户真实性
3. 位置信息仅用于本应用内定位相关功能
4. 不会将您的信息出售给第三方

三、信息的存储
您的个人信息将存储在安全的服务器上，我们采取加密、访问控制等措施保护您的信息安全。

四、您的权利
您可以随时查看、更正您的个人信息，也可以申请删除账号及相关数据。

五、未成年人保护
本应用不对未满18周岁的未成年人开放。若发现未成年人注册，我们将立即删除相关信息。

六、政策更新
我们可能会适时更新本隐私政策，更新后的政策将在应用内公布。

七、联系我们
如有任何隐私相关问题，请联系：
y-else 工作室
联系邮箱：privacy@y-else.com

点击「同意并继续」即表示您已阅读并同意本隐私政策的全部条款。
`;

const PrivacyPolicyModal: React.FC<PrivacyPolicyModalProps> = ({
  visible,
  onAgree,
  onDisagree,
}) => {
  return (
    <RNModal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onDisagree}
    >
      <Pressable style={styles.overlay} onPress={onDisagree}>
        <Pressable style={styles.container} onPress={() => {}}>
          <Text style={styles.title}>隐私政策</Text>

          <ScrollView
            style={styles.scrollView}
            showsVerticalScrollIndicator
          >
            <Text style={styles.content}>{POLICY_TEXT}</Text>
          </ScrollView>

          <View style={styles.footer}>
            <Button
              title="同意并继续"
              onPress={onAgree}
              style={styles.agreeBtn}
            />
            <Pressable onPress={onDisagree} style={styles.disagreeBtn}>
              <Text style={styles.disagreeText}>不同意并退出</Text>
            </Pressable>
          </View>
        </Pressable>
      </Pressable>
    </RNModal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.lg,
  },
  container: {
    backgroundColor: Colors.bgWhite,
    borderRadius: BorderRadius.card,
    padding: Spacing.xl,
    maxHeight: '80%',
    width: '100%',
  },
  title: {
    fontSize: Typography.title,
    fontWeight: '600',
    color: Colors.textPrimary,
    textAlign: 'center',
    marginBottom: Spacing.lg,
  },
  scrollView: {
    maxHeight: 400,
    marginBottom: Spacing.lg,
  },
  content: {
    fontSize: Typography.body,
    color: Colors.textSecondary,
    lineHeight: 22,
  },
  footer: {
    gap: Spacing.sm,
  },
  agreeBtn: {
    width: '100%',
  },
  disagreeBtn: {
    alignItems: 'center',
    paddingVertical: Spacing.sm,
  },
  disagreeText: {
    fontSize: Typography.caption,
    color: Colors.textHint,
  },
});

export default PrivacyPolicyModal;
