/**
 * APP启动强制权限校验全屏拦截页（安卓专属）
 * 核心权限未授权 → 拦截页引导用户授权
 * 全部授权通过 → 自动放行
 */

import React, { useEffect, useState, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import Button from './Button';
import {
  checkAllPermissions,
  requestAllPermissions,
  areAllGranted,
  getMissingPermissions,
  hasBlockedPermission,
  openAppSettings,
} from '../services/permissions';
import type { UnifiedPermissions } from '../services/permissions';

interface StartupPermissionGateProps {
  children: React.ReactNode;
  onAllGranted: () => void;
}

const PERM_EXPLAIN: Record<string, string> = {
  '精准定位（前台）': 'SOS紧急求助时需要获取您的精确位置，用于快速救援。',
  '后台定位': 'APP关闭/锁屏时仍需持续保护您的安全，后台定位是SOS功能的核心保障。',
  '通知推送': '接收SOS求助提醒、管理员重要通知、安全预警消息。',
  '设备存储': '保存个人相册、数据缓存、离线内容，确保APP正常运行。',
};

const CHECK_TIMEOUT_MS = 12000;

const StartupPermissionGate: React.FC<StartupPermissionGateProps> = ({
  children, onAllGranted,
}) => {
  const [phase, setPhase] = useState<'checking' | 'denied' | 'granted'>('checking');
  const [missingPerms, setMissingPerms] = useState<string[]>([]);
  const [allPerms, setAllPerms] = useState<UnifiedPermissions | null>(null);
  const mountedRef = useRef(true);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  useEffect(() => {
    checkAndDecide();
  }, []);

  const checkAndDecide = async () => {
    setPhase('checking');

    // 超时保护
    timeoutRef.current = setTimeout(() => {
      if (mountedRef.current) {
        setPhase('granted');
        onAllGranted();
      }
    }, CHECK_TIMEOUT_MS);

    try {
      const perms = await checkAllPermissions();
      if (!mountedRef.current) return;

      if (timeoutRef.current) clearTimeout(timeoutRef.current);

      setAllPerms(perms);

      if (areAllGranted(perms)) {
        setPhase('granted');
        onAllGranted();
        return;
      }

      const missing = getMissingPermissions(perms);
      setMissingPerms(missing);
      setPhase('denied');
    } catch {
      if (mountedRef.current) {
        if (timeoutRef.current) clearTimeout(timeoutRef.current);
        setPhase('granted');
        onAllGranted();
      }
    }
  };

  const handleRequestPermissions = async () => {
    setPhase('checking');
    const result = await requestAllPermissions();

    if (!mountedRef.current) return;

    if (areAllGranted(result)) {
      setPhase('granted');
      onAllGranted();
    } else {
      const missing = getMissingPermissions(result);
      setAllPerms(result);
      setMissingPerms(missing);
      setPhase('denied');
    }
  };

  const handleGoSettings = () => {
    openAppSettings();
  };

  // ====== 加载中 ======
  if (phase === 'checking') {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={Colors.primary} />
        <Text style={styles.checkingText}>正在检测权限状态...</Text>
        <Text style={styles.checkingHint}>最多等待{CHECK_TIMEOUT_MS / 1000}秒</Text>
      </View>
    );
  }

  // ====== 已授权 → 放行 ======
  if (phase === 'granted') {
    return <>{children}</>;
  }

  // ====== 权限不足 → 拦截页 ======
  const isBlocked = allPerms ? hasBlockedPermission(allPerms) : false;

  return (
    <View style={styles.gateContainer}>
      <ScrollView contentContainerStyle={styles.gateContent}>
        <View style={styles.warnIcon}>
          <Ionicons name="shield-outline" size={56} color={Colors.lover} />
        </View>

        <Text style={styles.title}>需要授予全部权限</Text>
        <Text style={styles.subtitle}>
          为了保障您的安全和APP正常运行，需要授予以下核心权限。
          请全部选择"始终允许"。
        </Text>

        <View style={styles.permList}>
          {['精准定位（前台）', '后台定位', '通知推送', '设备存储'].map((perm) => {
            const isMissing = missingPerms.includes(perm);
            return (
              <View key={perm} style={styles.permItem}>
                <View style={styles.permHeader}>
                  <Ionicons
                    name={isMissing ? 'close-circle' : 'checkmark-circle'}
                    size={22}
                    color={isMissing ? Colors.lover : Colors.family}
                  />
                  <Text style={[styles.permName, !isMissing && { color: Colors.family }]}>
                    {perm}
                  </Text>
                  {isMissing && (
                    <View style={styles.missingTag}>
                      <Text style={styles.missingText}>未授权</Text>
                    </View>
                  )}
                </View>
                <Text style={styles.permDesc}>
                  {PERM_EXPLAIN[perm] || ''}
                </Text>
              </View>
            );
          })}
        </View>

        <View style={styles.actionArea}>
          {isBlocked ? (
            <>
              <Text style={styles.blockedHint}>
                部分权限已被系统禁用，请前往系统设置中手动开启"始终允许"。
              </Text>
              <Button
                title="前往系统设置"
                onPress={handleGoSettings}
                style={styles.actionBtn}
              />
            </>
          ) : (
            <Button
              title="授予全部权限"
              onPress={handleRequestPermissions}
              style={styles.actionBtn}
            />
          )}

          {isBlocked && (
            <Button
              title="已去设置，重新检查"
              variant="ghost"
              onPress={checkAndDecide}
            />
          )}
        </View>

        <Text style={styles.footerNote}>
          授权后，您的数据将严格加密存储，仅用于APP内功能服务。
        </Text>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  center: {
    flex: 1, justifyContent: 'center', alignItems: 'center',
    backgroundColor: Colors.bgPrimary,
  },
  checkingText: {
    fontSize: Typography.body, color: Colors.textHint, marginTop: Spacing.lg,
  },
  checkingHint: {
    fontSize: Typography.caption, color: Colors.textHint, marginTop: Spacing.sm, opacity: 0.6,
  },
  gateContainer: {
    flex: 1, backgroundColor: Colors.bgPrimary,
  },
  gateContent: {
    flexGrow: 1, padding: Spacing.xl,
    justifyContent: 'center', maxWidth: 420, alignSelf: 'center', width: '100%',
  },
  warnIcon: {
    width: 96, height: 96, borderRadius: 48,
    backgroundColor: '#FFF0F0', alignItems: 'center', justifyContent: 'center',
    alignSelf: 'center', marginBottom: Spacing.lg,
    borderWidth: 3, borderColor: Colors.lover + '40',
  },
  title: {
    fontSize: 22, fontWeight: '700', color: Colors.textPrimary,
    textAlign: 'center', marginBottom: Spacing.sm,
  },
  subtitle: {
    fontSize: Typography.body, color: Colors.textSecondary,
    textAlign: 'center', lineHeight: 22, marginBottom: Spacing.xl,
  },
  permList: {
    backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    padding: Spacing.lg, marginBottom: Spacing.xl,
  },
  permItem: {
    paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  permHeader: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    marginBottom: 4,
  },
  permName: {
    fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary,
    flex: 1,
  },
  missingTag: {
    backgroundColor: Colors.lover + '20', paddingHorizontal: 8, paddingVertical: 1, borderRadius: 4,
  },
  missingText: { fontSize: 10, color: Colors.lover, fontWeight: '600' },
  permDesc: {
    fontSize: Typography.caption, color: Colors.textHint,
    lineHeight: 17, marginLeft: 30,
  },
  actionArea: {
    alignItems: 'center', gap: Spacing.md,
  },
  blockedHint: {
    fontSize: Typography.caption, color: Colors.lover,
    textAlign: 'center', marginBottom: Spacing.sm, lineHeight: 18,
  },
  actionBtn: {
    width: '100%',
  },
  footerNote: {
    fontSize: Typography.caption, color: Colors.textHint,
    textAlign: 'center', marginTop: Spacing.xl, lineHeight: 18,
  },
});

export default StartupPermissionGate;
