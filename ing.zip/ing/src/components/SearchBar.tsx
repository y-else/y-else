/**
 * 模糊搜索栏
 * 搜索备注/用户名/手机号
 */

import React, { useState, useRef, useCallback } from 'react';
import {
  View,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Animated,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';

interface SearchBarProps {
  placeholder?: string;
  onSearch: (text: string) => void;
  onClear: () => void;
  debounceMs?: number;
}

const SearchBar: React.FC<SearchBarProps> = ({
  placeholder = '搜索备注/用户名/手机号',
  onSearch,
  onClear,
  debounceMs = 300,
}) => {
  const [text, setText] = useState('');
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleChange = useCallback(
    (value: string) => {
      setText(value);
      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => {
        if (value.trim()) {
          onSearch(value.trim());
        } else {
          onClear();
        }
      }, debounceMs);
    },
    [onSearch, onClear, debounceMs],
  );

  const handleClear = useCallback(() => {
    setText('');
    onClear();
    if (timerRef.current) clearTimeout(timerRef.current);
  }, [onClear]);

  return (
    <View style={styles.container}>
      <Ionicons name="search-outline" size={18} color={Colors.textHint} style={styles.icon} />
      <TextInput
        style={styles.input}
        placeholder={placeholder}
        placeholderTextColor={Colors.textHint}
        value={text}
        onChangeText={handleChange}
        returnKeyType="search"
        autoCorrect={false}
      />
      {text.length > 0 && (
        <TouchableOpacity onPress={handleClear} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Ionicons name="close-circle" size={18} color={Colors.textHint} />
        </TouchableOpacity>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.bgPrimary,
    borderRadius: BorderRadius.card,
    paddingHorizontal: Spacing.md,
    height: 40,
    marginBottom: Spacing.md,
  },
  icon: {
    marginRight: Spacing.sm,
  },
  input: {
    flex: 1,
    fontSize: Typography.body,
    color: Colors.textPrimary,
    paddingVertical: 0,
  },
});

export default SearchBar;
