/**
 * 异常断网提示横幅
 * 离线时顶部展示红色提示条
 */

import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing } from '../constants';
import { useNetworkStatus } from '../services/network';

interface NetworkBannerProps {
  onRetry?: () => void;
}

export const NetworkBanner: React.FC<NetworkBannerProps> = ({ onRetry }) => {
  const [visible, setVisible] = useState(false);
  const slideAnim = useRef(new Animated.Value(-60)).current;
  const networkStatus = useNetworkStatus();

  useEffect(() => {
    if (networkStatus === 'offline') {
      setVisible(true);
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }).start();
    } else if (visible) {
      Animated.timing(slideAnim, {
        toValue: -60,
        duration: 300,
        useNativeDriver: true,
      }).start(() => setVisible(false));
    }
  }, [networkStatus, visible]);

  if (!visible) return null;

  return (
    <Animated.View
      style={[styles.banner, { transform: [{ translateY: slideAnim }] }]}
      pointerEvents="box-none"
    >
      <View style={styles.content}>
        <Ionicons name="cloud-offline-outline" size={16} color="#FFF" />
        <Text style={styles.text}>当前网络不可用，部分功能受限</Text>
        {onRetry && (
          <TouchableOpacity onPress={onRetry} style={styles.retryBtn}>
            <Text style={styles.retryText}>重试</Text>
          </TouchableOpacity>
        )}
      </View>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  banner: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 9999,
    elevation: 10,
  },
  content: {
    backgroundColor: '#E74C3C',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.lg,
    gap: Spacing.sm,
    minHeight: 44,
  },
  text: {
    fontSize: Typography.caption,
    color: '#FFF',
    fontWeight: '500',
  },
  retryBtn: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: Spacing.md,
    paddingVertical: 2,
    borderRadius: 12,
  },
  retryText: {
    fontSize: Typography.caption,
    color: '#FFF',
    fontWeight: '600',
  },
});

export default NetworkBanner;
