/**
 * 骨架屏组件
 * 启动/加载占位，减少白屏感知
 */

import React, { useEffect, useRef } from 'react';
import { View, Animated, StyleSheet, type ViewStyle } from 'react-native';
import { Colors, BorderRadius, Spacing } from '../constants';

interface SkeletonProps {
  width?: number | string;
  height?: number;
  borderRadius?: number;
  style?: ViewStyle;
}

// 单个骨架块（带闪烁动画）
const SkeletonBlock: React.FC<SkeletonProps> = ({
  width = '100%',
  height = 16,
  borderRadius = 4,
  style,
}) => {
  const opacity = useRef(new Animated.Value(0.3)).current;

  useEffect(() => {
    const anim = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, { toValue: 1, duration: 800, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 0.3, duration: 800, useNativeDriver: true }),
      ]),
    );
    anim.start();
    return () => anim.stop();
  }, []);

  return (
    <Animated.View
      style={[
        { width: width as any, height, borderRadius, opacity, backgroundColor: '#E1E4E8' },
        style,
      ]}
    />
  );
};

// 卡片骨架屏
export const SkeletonCard: React.FC<{ lines?: number }> = ({ lines = 3 }) => (
  <View style={styles.card}>
    <View style={styles.cardHeader}>
      <SkeletonBlock width={40} height={40} borderRadius={20} />
      <View style={styles.cardHeaderText}>
        <SkeletonBlock width="60%" height={14} />
        <SkeletonBlock width="40%" height={10} style={{ marginTop: 6 }} />
      </View>
    </View>
    {Array.from({ length: lines }).map((_, i) => (
      <SkeletonBlock key={i} width={`${85 - i * 15}%`} height={12} style={{ marginTop: 8 }} />
    ))}
  </View>
);

// 列表项骨架屏
export const SkeletonListItem: React.FC = () => (
  <View style={styles.listItem}>
    <SkeletonBlock width={44} height={44} borderRadius={22} />
    <View style={styles.listItemText}>
      <SkeletonBlock width="50%" height={14} />
      <SkeletonBlock width="35%" height={10} style={{ marginTop: 6 }} />
    </View>
  </View>
);

// 页面骨架屏
export const SkeletonPage: React.FC<{ cardCount?: number; listCount?: number }> = ({
  cardCount = 2,
  listCount = 5,
}) => (
  <View style={styles.page}>
    <SkeletonBlock width="40%" height={20} style={{ marginBottom: 16 }} />
    {Array.from({ length: cardCount }).map((_, i) => (
      <SkeletonCard key={`card_${i}`} lines={3} />
    ))}
    <SkeletonBlock width="30%" height={16} style={{ marginTop: 20, marginBottom: 12 }} />
    {Array.from({ length: listCount }).map((_, i) => (
      <SkeletonListItem key={`item_${i}`} />
    ))}
  </View>
);

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.bgWhite,
    borderRadius: BorderRadius.card,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  cardHeaderText: {
    flex: 1,
    marginLeft: Spacing.md,
  },
  listItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.md,
  },
  listItemText: {
    flex: 1,
    marginLeft: Spacing.md,
  },
  page: {
    padding: Spacing.lg,
    paddingTop: Spacing.xl,
  },
});

export default SkeletonBlock;
