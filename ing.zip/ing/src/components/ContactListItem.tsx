/**
 * 联系人列表项（性能优化版）
 * 头像/名称/备注/状态/置顶标识/分组标签
 * React.memo 避免无效重渲染
 */

import React, { memo } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Image,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import StatusBadge from './StatusBadge';
import { maskPhone } from '../services/contacts';
import type { Contact } from '../types';

interface ContactListItemProps {
  contact: Contact;
  onPress: (contact: Contact) => void;
  onLongPress?: (contact: Contact) => void;
  isSelectMode?: boolean;
  isSelected?: boolean;
  showGroupTag?: boolean;
}

const GROUP_LABELS: Record<string, { label: string; color: string }> = {
  family: { label: '家人', color: '#5CB85C' },
  friend: { label: '朋友', color: '#F0AD4E' },
  lover: { label: '恋人', color: '#E74C3C' },
  blocked: { label: '已拉黑', color: '#999999' },
};

const ContactListItem: React.FC<ContactListItemProps> = ({
  contact,
  onPress,
  onLongPress,
  isSelectMode = false,
  isSelected = false,
  showGroupTag = false,
}) => {
  const groupInfo = GROUP_LABELS[contact.group] || GROUP_LABELS.friend;
  // 拉黑后手机号强制脱敏
  const displayPhone = contact.isBlocked ? maskPhone(contact.phone) : contact.phone;
  const displayName = contact.remark || contact.username;

  return (
    <TouchableOpacity
      style={[styles.container, contact.isPinned && styles.pinned]}
      onPress={() => onPress(contact)}
      onLongPress={() => onLongPress?.(contact)}
      activeOpacity={0.6}
    >
      {/* 多选复选框 */}
      {isSelectMode && (
        <View style={[styles.checkbox, isSelected && styles.checkboxSelected]}>
          {isSelected && <Ionicons name="checkmark" size={14} color="#FFF" />}
        </View>
      )}

      {/* 头像 */}
      <View style={[styles.avatar, { backgroundColor: contact.isBlocked ? '#EEE' : Colors.bgPrimary }]}>
        {contact.avatar ? (
          <Image source={{ uri: contact.avatar }} style={styles.avatarImg} />
        ) : (
          <Ionicons
            name="person"
            size={22}
            color={contact.isBlocked ? Colors.textHint : groupInfo.color}
          />
        )}
        {/* 在线状态徽标（拉黑用户不显示） */}
        {!contact.isBlocked && (
          <View style={styles.statusDot}>
            <StatusBadge status={contact.status} size={10} />
          </View>
        )}
      </View>

      {/* 信息 */}
      <View style={styles.info}>
        <View style={styles.nameRow}>
          {contact.isPinned && (
            <Ionicons name="push" size={12} color={Colors.primary} style={styles.pinIcon} />
          )}
          <Text
            style={[styles.name, contact.isBlocked && styles.blockedText]}
            numberOfLines={1}
          >
            {displayName}
          </Text>
          {showGroupTag && (
            <View style={[styles.groupTag, { backgroundColor: groupInfo.color + '20' }]}>
              <Text style={[styles.groupTagText, { color: groupInfo.color }]}>
                {groupInfo.label}
              </Text>
            </View>
          )}
        </View>
        <Text style={[styles.phone, contact.isBlocked && styles.blockedText]} numberOfLines={1}>
          {contact.remark ? contact.username : null}
          {contact.remark ? ' · ' : null}
          {displayPhone}
        </Text>
      </View>

      {/* 置顶标识 */}
      {contact.isPinned && !isSelectMode && (
        <Ionicons name="push" size={14} color={Colors.textHint} />
      )}
    </TouchableOpacity>
  );
};

// React.memo：仅在 contact 数据或交互状态变化时重渲染
export default memo(ContactListItem, (prev, next) => {
  return (
    prev.contact.userId === next.contact.userId &&
    prev.contact.isPinned === next.contact.isPinned &&
    prev.contact.status === next.contact.status &&
    prev.contact.remark === next.contact.remark &&
    prev.contact.isBlocked === next.contact.isBlocked &&
    prev.contact.group === next.contact.group &&
    prev.contact.lastContactAt === next.contact.lastContactAt &&
    prev.isSelectMode === next.isSelectMode &&
    prev.isSelected === next.isSelected
  );
});

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    backgroundColor: Colors.bgWhite,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: Colors.divider,
    height: 64,
  },
  pinned: { backgroundColor: '#F8F9FB' },
  checkbox: {
    width: 22, height: 22, borderRadius: 11,
    borderWidth: 2, borderColor: Colors.divider,
    marginRight: Spacing.md, alignItems: 'center', justifyContent: 'center',
  },
  checkboxSelected: {
    backgroundColor: Colors.primary, borderColor: Colors.primary,
  },
  avatar: {
    width: 44, height: 44, borderRadius: 22,
    alignItems: 'center', justifyContent: 'center',
    marginRight: Spacing.md, overflow: 'hidden',
  },
  avatarImg: { width: 44, height: 44, borderRadius: 22 },
  statusDot: {
    position: 'absolute', bottom: 0, right: 0,
    width: 14, height: 14, borderRadius: 7,
    backgroundColor: Colors.bgWhite, alignItems: 'center', justifyContent: 'center',
  },
  info: { flex: 1 },
  nameRow: { flexDirection: 'row', alignItems: 'center' },
  pinIcon: { marginRight: 4 },
  name: { fontSize: Typography.subtitle, fontWeight: '500', color: Colors.textPrimary },
  blockedText: { color: Colors.textHint },
  groupTag: {
    paddingHorizontal: 6, paddingVertical: 1, borderRadius: 3, marginLeft: Spacing.sm,
  },
  groupTagText: { fontSize: 10, fontWeight: '500' },
  phone: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
});
