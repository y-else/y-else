import React from 'react';
import { View, StyleSheet, ViewStyle } from 'react-native';
import { Colors, Spacing, BorderRadius } from '../constants';

interface CardProps {
  children: React.ReactNode;
  style?: ViewStyle | (ViewStyle | false | undefined)[];
  /** 是否去除内边距 */
  noPadding?: boolean;
  /** 是否去除下边距 */
  noMargin?: boolean;
  /** 扁平样式（无阴影，仅圆角边框） */
  flat?: boolean;
}

const Card: React.FC<CardProps> = ({ children, style, noPadding, noMargin, flat }) => {
  const extraStyle: ViewStyle = {};
  if (noPadding) extraStyle.padding = 0;
  if (noMargin) extraStyle.marginBottom = 0;

  const combinedStyle: any[] = [styles.card, extraStyle];
  if (flat) combinedStyle.push(styles.flat);
  if (style) combinedStyle.push(style);

  return <View style={combinedStyle}>{children}</View>;
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.bgWhite,
    borderRadius: BorderRadius.card,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    // 轻阴影
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 2,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.divider,
  },
  flat: {
    shadowOpacity: 0,
    elevation: 0,
    borderWidth: 1,
    borderColor: Colors.divider,
  },
});

export default Card;
