/**
 * 统一日期+时间选择器
 * 年月日时/分五列滚轮式 Picker
 */

import React, { useState, useMemo, useCallback } from 'react';
import {
  View, Text, Modal, TouchableOpacity, FlatList, StyleSheet,
  TouchableWithoutFeedback,
} from 'react-native';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';

const ITEM_HEIGHT = 44;
const VISIBLE_ITEMS = 5;

interface DateTimePickerProps {
  visible: boolean;
  value: string; // 'YYYY-MM-DD HH:mm' 或 ISO 字符串
  onConfirm: (isoStr: string) => void;
  onClose: () => void;
  minYear?: number;
  maxYear?: number;
  title?: string;
}

const DateTimePicker: React.FC<DateTimePickerProps> = ({
  visible, value, onConfirm, onClose,
  minYear = 2020, maxYear, title = '选择日期时间',
}) => {
  const now = new Date();
  const defaultMaxYear = maxYear || now.getFullYear() + 1;

  const parsed = useMemo(() => {
    try {
      // 尝试解析 ISO 或 'YYYY-MM-DD HH:mm' 格式
      const d = new Date(value);
      if (!isNaN(d.getTime())) {
        return { y: d.getFullYear(), m: d.getMonth() + 1, d: d.getDate(), h: d.getHours(), min: d.getMinutes() };
      }
    } catch {}
    return { y: now.getFullYear(), m: now.getMonth() + 1, d: now.getDate(), h: now.getHours(), min: now.getMinutes() };
  }, [value]);

  const [selYear, setSelYear] = useState(parsed.y);
  const [selMonth, setSelMonth] = useState(parsed.m);
  const [selDay, setSelDay] = useState(parsed.d);
  const [selHour, setSelHour] = useState(parsed.h);
  const [selMinute, setSelMinute] = useState(parsed.min);

  const years = useMemo(() =>
    Array.from({ length: defaultMaxYear - minYear + 1 }, (_, i) => defaultMaxYear - i),
  [minYear, defaultMaxYear]);

  const months = useMemo(() => Array.from({ length: 12 }, (_, i) => i + 1), []);

  const days = useMemo(() => {
    const maxDay = new Date(selYear, selMonth, 0).getDate();
    return Array.from({ length: maxDay }, (_, i) => i + 1);
  }, [selYear, selMonth]);

  const hours = useMemo(() => Array.from({ length: 24 }, (_, i) => i), []);
  const minutes = useMemo(() => Array.from({ length: 60 }, (_, i) => i), []);

  const handleConfirm = useCallback(() => {
    const mm = String(selMonth).padStart(2, '0');
    const dd = String(selDay).padStart(2, '0');
    const hh = String(selHour).padStart(2, '0');
    const mi = String(selMinute).padStart(2, '0');
    const dateStr = `${selYear}-${mm}-${dd}T${hh}:${mi}:00`;
    onConfirm(new Date(dateStr).toISOString());
  }, [selYear, selMonth, selDay, selHour, selMinute, onConfirm]);

  const renderColumn = (data: number[], selected: number, onSelect: (v: number) => void, label = '') => (
    <View style={styles.column} key={label}>
      <FlatList
        data={data}
        keyExtractor={(item) => String(item)}
        showsVerticalScrollIndicator={false}
        getItemLayout={(_, index) => ({ length: ITEM_HEIGHT, offset: ITEM_HEIGHT * index, index })}
        initialScrollIndex={data.indexOf(selected)}
        renderItem={({ item }) => {
          const isSelected = item === selected;
          return (
            <TouchableOpacity
              style={[styles.item, isSelected && styles.itemSelected]}
              onPress={() => onSelect(item)}
              activeOpacity={0.6}
            >
              <Text style={[styles.itemText, isSelected && styles.itemTextSelected]}>
                {String(item).padStart(2, '0')}{label}
              </Text>
            </TouchableOpacity>
          );
        }}
      />
    </View>
  );

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <TouchableWithoutFeedback onPress={onClose}>
        <View style={styles.overlay}>
          <TouchableWithoutFeedback>
            <View style={styles.container}>
              <View style={styles.header}>
                <TouchableOpacity onPress={onClose} style={styles.headerBtn}>
                  <Text style={styles.cancelText}>取消</Text>
                </TouchableOpacity>
                <Text style={styles.title}>{title}</Text>
                <TouchableOpacity onPress={handleConfirm} style={styles.headerBtn}>
                  <Text style={styles.confirmText}>确定</Text>
                </TouchableOpacity>
              </View>
              <View style={styles.pickerRow}>
                {renderColumn(years, selYear, setSelYear, '年')}
                {renderColumn(months, selMonth, setSelMonth, '月')}
                {renderColumn(days, selDay, setSelDay, '日')}
                {renderColumn(hours, selHour, setSelHour, '时')}
                {renderColumn(minutes, selMinute, setSelMinute, '分')}
              </View>
            </View>
          </TouchableWithoutFeedback>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end',
  },
  container: {
    backgroundColor: Colors.bgWhite,
    borderTopLeftRadius: BorderRadius.card + 4,
    borderTopRightRadius: BorderRadius.card + 4,
    paddingBottom: 34,
    maxHeight: 380,
  },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerBtn: { paddingHorizontal: Spacing.sm, paddingVertical: Spacing.xs },
  title: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  cancelText: { fontSize: Typography.body, color: Colors.textSecondary },
  confirmText: { fontSize: Typography.body, fontWeight: '600', color: Colors.primary },
  pickerRow: {
    flexDirection: 'row', height: ITEM_HEIGHT * VISIBLE_ITEMS,
    paddingHorizontal: Spacing.xs,
  },
  column: { flex: 1 },
  item: {
    height: ITEM_HEIGHT, justifyContent: 'center', alignItems: 'center',
  },
  itemSelected: {
    backgroundColor: '#EBF3FC', borderRadius: BorderRadius.input,
  },
  itemText: {
    fontSize: Typography.caption, color: Colors.textHint,
  },
  itemTextSelected: {
    fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary,
  },
});

export default DateTimePicker;
