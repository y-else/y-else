/**
 * 悬浮 SOS 求救按钮（弱化版）
 * 可拖拽移动、长按 2 秒激活、脉冲效果弱化、视觉不遮挡首页其他功能
 * 保留原有长按2秒激活、倒计时、振动业务逻辑
 */

import React, { useRef, useState, useCallback, useEffect } from 'react';
import {
  Animated,
  PanResponder,
  type PanResponderGestureState,
  type GestureResponderEvent,
  StyleSheet,
  Text,
  Dimensions,
  Vibration,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, BorderRadius } from '../constants';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');
const BUTTON_SIZE = 40; // 缩小尺寸：56→40

interface FloatingSOSButtonProps {
  onLongPressActivate: () => void;
  visible?: boolean;
}

const FloatingSOSButton: React.FC<FloatingSOSButtonProps> = ({
  onLongPressActivate,
  visible = true,
}) => {
  const pan = useRef(new Animated.ValueXY({
    x: SCREEN_WIDTH - BUTTON_SIZE - 16,
    y: SCREEN_HEIGHT * 0.5,
  })).current;
  const [isLongPressing, setIsLongPressing] = useState(false);

  // 弱化脉冲动画 (1.06幅度)
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const longPressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isLongPressTriggered = useRef(false);
  const pulseLoopRef = useRef<Animated.CompositeAnimation | null>(null);

  useEffect(() => {
    if (visible) {
      pulseLoopRef.current = Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.06, duration: 1200, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1, duration: 1200, useNativeDriver: true }),
        ]),
      );
      pulseLoopRef.current.start();
    } else {
      pulseLoopRef.current?.stop();
      pulseAnim.setValue(1);
    }
    return () => {
      pulseLoopRef.current?.stop();
      // 清理可能残留的长按定时器
      if (longPressTimer.current) {
        clearTimeout(longPressTimer.current);
        longPressTimer.current = null;
      }
    };
  }, [visible]);

  // 长按 2 秒逻辑（保留原有业务）
  const handlePressIn = useCallback(() => {
    isLongPressTriggered.current = false;
    setIsLongPressing(true);
    Vibration.vibrate(50);
    longPressTimer.current = setTimeout(() => {
      isLongPressTriggered.current = true;
      setIsLongPressing(false);
      Vibration.vibrate([0, 100, 50, 100]);
      onLongPressActivate();
    }, 2000);
  }, [onLongPressActivate]);

  const handlePressOut = useCallback(() => {
    setIsLongPressing(false);
    Vibration.cancel(); // C10修复：取消可能残留的触觉反馈
    if (longPressTimer.current && !isLongPressTriggered.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  }, []);

  // 拖拽手势（保留原有）
  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => false,
      onMoveShouldSetPanResponder: (_e: GestureResponderEvent, gestureState: PanResponderGestureState) =>
        Math.abs(gestureState.dx) > 5 || Math.abs(gestureState.dy) > 5,
      onPanResponderGrant: () => {
        handlePressOut();
      },
      onPanResponderMove: Animated.event([null, { dx: pan.x, dy: pan.y }], {
        useNativeDriver: true,
      }),
      onPanResponderRelease: (_e: GestureResponderEvent, gestureState: PanResponderGestureState) => {
        const finalX =
          gestureState.moveX > SCREEN_WIDTH / 2
            ? SCREEN_WIDTH - BUTTON_SIZE - 16
            : 16;
        const finalY = Math.max(80, Math.min(SCREEN_HEIGHT - BUTTON_SIZE - 120, gestureState.moveY - BUTTON_SIZE / 2));
        Animated.spring(pan, {
          toValue: { x: finalX, y: finalY },
          useNativeDriver: true,
          friction: 8,
        }).start();
      },
    }),
  ).current;

  if (!visible) return null;

  return (
    <Animated.View
      style={[
        styles.container,
        {
          transform: [
            { translateX: pan.x },
            { translateY: pan.y },
            { scale: isLongPressing ? 1.1 : pulseAnim },
          ],
          opacity: isLongPressing ? 0.7 : 0.65, // 降低基础透明度
        },
      ]}
      {...panResponder.panHandlers}
      onTouchStart={handlePressIn}
      onTouchEnd={handlePressOut}
      onTouchCancel={handlePressOut}
    >
      <Ionicons name="warning" size={20} color="#FFFFFF" />
      <Text style={styles.label}>SOS</Text>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    width: BUTTON_SIZE,
    height: BUTTON_SIZE,
    borderRadius: BUTTON_SIZE / 2,
    backgroundColor: '#E74C3C',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 3,           // 弱化阴影：8→3
    shadowColor: '#E74C3C',
    shadowOffset: { width: 0, height: 1 },  // 弱化：4→1
    shadowOpacity: 0.15,     // 弱化：0.4→0.15
    shadowRadius: 4,         // 弱化：8→4
    zIndex: 999,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  label: {
    fontSize: 7,
    color: '#FFFFFF',
    fontWeight: '700',
    marginTop: -2,
  },
});

export default FloatingSOSButton;
