/**
 * 统一下拉时间选择器
 * 时/分两列滚轮式 Picker，替代所有 TextInput 手动输入时间
 */

import React, { useState, useMemo, useCallback } from 'react';
import {
  View, Text, Modal, TouchableOpacity, FlatList, StyleSheet,
  TouchableWithoutFeedback,
} from 'react-native';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';

const ITEM_HEIGHT = 44;
const VISIBLE_ITEMS = 5;

interface TimePickerProps {
  visible: boolean;
  value: string; // 'HH:MM' 或 ''
  onConfirm: (timeStr: string) => void;
  onClose: () => void;
  title?: string;
}

const TimePicker: React.FC<TimePickerProps> = ({
  visible, value, onConfirm, onClose, title = '选择时间',
}) => {
  const parsed = useMemo(() => {
    if (!value) return { h: 12, m: 0 };
    const parts = value.split(':');
    return {
      h: parseInt(parts[0]) || 12,
      m: parseInt(parts[1]) || 0,
    };
  }, [value]);

  const [selHour, setSelHour] = useState(parsed.h);
  const [selMinute, setSelMinute] = useState(parsed.m);

  const hours = useMemo(() => Array.from({ length: 24 }, (_, i) => i), []);
  const minutes = useMemo(() => Array.from({ length: 60 }, (_, i) => i), []);

  const handleConfirm = useCallback(() => {
    const hh = String(selHour).padStart(2, '0');
    const mm = String(selMinute).padStart(2, '0');
    onConfirm(`${hh}:${mm}`);
  }, [selHour, selMinute, onConfirm]);

  const renderColumn = (data: number[], selected: number, onSelect: (v: number) => void, label = '') => (
    <View style={styles.column}>
      <FlatList
        data={data}
        keyExtractor={(item) => String(item)}
        showsVerticalScrollIndicator={false}
        getItemLayout={(_, index) => ({ length: ITEM_HEIGHT, offset: ITEM_HEIGHT * index, index })}
        initialScrollIndex={data.indexOf(selected)}
        renderItem={({ item }) => {
          const isSelected = item === selected;
          return (
            <TouchableOpacity
              style={[styles.item, isSelected && styles.itemSelected]}
              onPress={() => onSelect(item)}
              activeOpacity={0.6}
            >
              <Text style={[styles.itemText, isSelected && styles.itemTextSelected]}>
                {String(item).padStart(2, '0')}{label}
              </Text>
            </TouchableOpacity>
          );
        }}
      />
    </View>
  );

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <TouchableWithoutFeedback onPress={onClose}>
        <View style={styles.overlay}>
          <TouchableWithoutFeedback>
            <View style={styles.container}>
              <View style={styles.header}>
                <TouchableOpacity onPress={onClose} style={styles.headerBtn}>
                  <Text style={styles.cancelText}>取消</Text>
                </TouchableOpacity>
                <Text style={styles.title}>{title}</Text>
                <TouchableOpacity onPress={handleConfirm} style={styles.headerBtn}>
                  <Text style={styles.confirmText}>确定</Text>
                </TouchableOpacity>
              </View>
              <View style={styles.pickerRow}>
                {renderColumn(hours, selHour, setSelHour, '时')}
                {renderColumn(minutes, selMinute, setSelMinute, '分')}
              </View>
            </View>
          </TouchableWithoutFeedback>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end',
  },
  container: {
    backgroundColor: Colors.bgWhite,
    borderTopLeftRadius: BorderRadius.card + 4,
    borderTopRightRadius: BorderRadius.card + 4,
    paddingBottom: 34,
    maxHeight: 340,
  },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerBtn: { paddingHorizontal: Spacing.sm, paddingVertical: Spacing.xs },
  title: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  cancelText: { fontSize: Typography.body, color: Colors.textSecondary },
  confirmText: { fontSize: Typography.body, fontWeight: '600', color: Colors.primary },
  pickerRow: {
    flexDirection: 'row', height: ITEM_HEIGHT * VISIBLE_ITEMS,
    paddingHorizontal: Spacing.lg,
  },
  column: { flex: 1 },
  item: {
    height: ITEM_HEIGHT, justifyContent: 'center', alignItems: 'center',
  },
  itemSelected: {
    backgroundColor: '#EBF3FC', borderRadius: BorderRadius.input,
  },
  itemText: {
    fontSize: Typography.body, color: Colors.textHint,
  },
  itemTextSelected: {
    fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary,
  },
});

export default TimePicker;
