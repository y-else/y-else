/**
 * 版本更新公告弹窗
 * 登录页自动展示，支持强制更新
 */

import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal as RNModal,
  Pressable,
} from 'react-native';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import Button from './Button';
import type { AppVersion } from '../types';

interface VersionUpdateModalProps {
  visible: boolean;
  versionInfo: AppVersion | null;
  onUpdate: () => void;
  onDismiss: () => void;
}

const VersionUpdateModal: React.FC<VersionUpdateModalProps> = ({
  visible,
  versionInfo,
  onUpdate,
  onDismiss,
}) => {
  if (!versionInfo) return null;

  return (
    <RNModal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={versionInfo.forceUpdate ? onUpdate : onDismiss}
    >
      <Pressable style={styles.overlay} onPress={onDismiss}>
        <Pressable style={styles.container} onPress={() => {}}>
          <Text style={styles.title}>发现新版本</Text>

          <View style={styles.versionRow}>
            <Text style={styles.versionLabel}>版本号</Text>
            <Text style={styles.versionValue}>v{versionInfo.version}</Text>
          </View>

          <Text style={styles.notesTitle}>更新内容：</Text>
          <Text style={styles.notes}>{versionInfo.releaseNotes}</Text>

          <View style={styles.footer}>
            <Button
              title="立即更新"
              onPress={onUpdate}
              style={styles.updateBtn}
            />
            {!versionInfo.forceUpdate && (
              <Button
                title="稍后再说"
                variant="ghost"
                onPress={onDismiss}
              />
            )}
          </View>
        </Pressable>
      </Pressable>
    </RNModal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.lg,
  },
  container: {
    backgroundColor: Colors.bgWhite,
    borderRadius: BorderRadius.card,
    padding: Spacing.xl,
    width: '100%',
  },
  title: {
    fontSize: Typography.title,
    fontWeight: '600',
    color: Colors.textPrimary,
    textAlign: 'center',
    marginBottom: Spacing.lg,
  },
  versionRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Spacing.lg,
    gap: Spacing.sm,
  },
  versionLabel: {
    fontSize: Typography.body,
    color: Colors.textSecondary,
  },
  versionValue: {
    fontSize: Typography.subtitle,
    fontWeight: '600',
    color: Colors.primary,
  },
  notesTitle: {
    fontSize: Typography.body,
    fontWeight: '600',
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
  },
  notes: {
    fontSize: Typography.body,
    color: Colors.textSecondary,
    lineHeight: 22,
    marginBottom: Spacing.xl,
  },
  footer: {
    gap: Spacing.sm,
  },
  updateBtn: {
    width: '100%',
  },
});

export default VersionUpdateModal;
