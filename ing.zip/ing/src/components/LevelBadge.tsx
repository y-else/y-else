/**
 * 等级徽章 — 1-100级，带进度条
 */

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { getLevelConfig } from '../services/level';

interface LevelBadgeProps {
  level: number;
  progress?: number; // 0-1 下一级进度
  showProgress?: boolean;
}

const LevelBadge: React.FC<LevelBadgeProps> = ({ level, progress = 0, showProgress = true }) => {
  const config = getLevelConfig(level);
  // 等级颜色梯度
  const hue = Math.min(200, level * 2);
  const color = `hsl(${hue}, 70%, 50%)`;

  return (
    <View style={styles.container}>
      <View style={[styles.badge, { backgroundColor: color }]}>
        <Text style={styles.levelText}>LV.{level}</Text>
      </View>
      <Text style={styles.title}>{config.title}</Text>
      {showProgress && level < 100 && (
        <View style={styles.progressBg}>
          <View style={[styles.progressFill, { width: `${Math.round(progress * 100)}%`, backgroundColor: color }]} />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { alignItems: 'center' },
  badge: {
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.card, marginBottom: Spacing.xs,
  },
  levelText: { fontSize: Typography.caption, fontWeight: '800', color: '#FFF' },
  title: { fontSize: Typography.caption, color: Colors.textHint },
  progressBg: {
    width: 80, height: 3, backgroundColor: Colors.divider, borderRadius: 1.5,
    marginTop: Spacing.xs, overflow: 'hidden',
  },
  progressFill: { height: '100%', borderRadius: 1.5 },
});

export default LevelBadge;
