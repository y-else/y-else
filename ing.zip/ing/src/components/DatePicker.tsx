/**
 * 统一下拉日期选择器
 * 年月日三列滚轮式 Picker，替代所有 TextInput 手动输入日期
 */

import React, { useState, useMemo, useCallback } from 'react';
import {
  View, Text, Modal, TouchableOpacity, FlatList, StyleSheet,
  Dimensions, TouchableWithoutFeedback,
} from 'react-native';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';

const SCREEN_WIDTH = Dimensions.get('window').width;
const ITEM_HEIGHT = 44;
const VISIBLE_ITEMS = 5;

interface DatePickerProps {
  visible: boolean;
  value: string; // 'YYYY-MM-DD' 或 ''
  onConfirm: (dateStr: string) => void;
  onClose: () => void;
  minYear?: number;
  maxYear?: number;
  title?: string;
}

const DatePicker: React.FC<DatePickerProps> = ({
  visible, value, onConfirm, onClose,
  minYear = 1940, maxYear, title = '选择日期',
}) => {
  const now = new Date();
  const defaultMaxYear = maxYear || now.getFullYear();

  // 解析当前值
  const parsed = useMemo(() => {
    if (!value) return { y: now.getFullYear(), m: now.getMonth() + 1, d: 1 };
    const parts = value.split('-');
    return {
      y: parseInt(parts[0]) || now.getFullYear(),
      m: parseInt(parts[1]) || now.getMonth() + 1,
      d: parseInt(parts[2]) || 1,
    };
  }, [value]);

  const [selYear, setSelYear] = useState(parsed.y);
  const [selMonth, setSelMonth] = useState(parsed.m);
  const [selDay, setSelDay] = useState(parsed.d);

  const years = useMemo(() =>
    Array.from({ length: defaultMaxYear - minYear + 1 }, (_, i) => defaultMaxYear - i),
  [minYear, defaultMaxYear]);

  const months = useMemo(() => Array.from({ length: 12 }, (_, i) => i + 1), []);

  const days = useMemo(() => {
    const maxDay = new Date(selYear, selMonth, 0).getDate();
    return Array.from({ length: maxDay }, (_, i) => i + 1);
  }, [selYear, selMonth]);

  const handleConfirm = useCallback(() => {
    const mm = String(selMonth).padStart(2, '0');
    const dd = String(selDay).padStart(2, '0');
    onConfirm(`${selYear}-${mm}-${dd}`);
  }, [selYear, selMonth, selDay, onConfirm]);

  const renderColumn = (data: number[], selected: number, onSelect: (v: number) => void, label = '') => (
    <View style={styles.column}>
      <FlatList
        data={data}
        keyExtractor={(item) => String(item)}
        showsVerticalScrollIndicator={false}
        getItemLayout={(_, index) => ({ length: ITEM_HEIGHT, offset: ITEM_HEIGHT * index, index })}
        initialScrollIndex={data.indexOf(selected)}
        renderItem={({ item }) => {
          const isSelected = item === selected;
          return (
            <TouchableOpacity
              style={[styles.item, isSelected && styles.itemSelected]}
              onPress={() => onSelect(item)}
              activeOpacity={0.6}
            >
              <Text style={[styles.itemText, isSelected && styles.itemTextSelected]}>
                {String(item).padStart(2, '0')}{label}
              </Text>
            </TouchableOpacity>
          );
        }}
      />
    </View>
  );

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <TouchableWithoutFeedback onPress={onClose}>
        <View style={styles.overlay}>
          <TouchableWithoutFeedback>
            <View style={styles.container}>
              <View style={styles.header}>
                <TouchableOpacity onPress={onClose} style={styles.headerBtn}>
                  <Text style={styles.cancelText}>取消</Text>
                </TouchableOpacity>
                <Text style={styles.title}>{title}</Text>
                <TouchableOpacity onPress={handleConfirm} style={styles.headerBtn}>
                  <Text style={styles.confirmText}>确定</Text>
                </TouchableOpacity>
              </View>
              <View style={styles.pickerRow}>
                {renderColumn(years, selYear, setSelYear, '年')}
                {renderColumn(months, selMonth, setSelMonth, '月')}
                {renderColumn(days, selDay, setSelDay, '日')}
              </View>
            </View>
          </TouchableWithoutFeedback>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end',
  },
  container: {
    backgroundColor: Colors.bgWhite,
    borderTopLeftRadius: BorderRadius.card + 4,
    borderTopRightRadius: BorderRadius.card + 4,
    paddingBottom: 34,
    maxHeight: 380,
  },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.divider,
  },
  headerBtn: { paddingHorizontal: Spacing.sm, paddingVertical: Spacing.xs },
  title: { fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary },
  cancelText: { fontSize: Typography.body, color: Colors.textSecondary },
  confirmText: { fontSize: Typography.body, fontWeight: '600', color: Colors.primary },
  pickerRow: {
    flexDirection: 'row', height: ITEM_HEIGHT * VISIBLE_ITEMS,
    paddingHorizontal: Spacing.lg,
  },
  column: { flex: 1 },
  item: {
    height: ITEM_HEIGHT, justifyContent: 'center', alignItems: 'center',
  },
  itemSelected: {
    backgroundColor: '#EBF3FC', borderRadius: BorderRadius.input,
  },
  itemText: {
    fontSize: Typography.body, color: Colors.textHint,
  },
  itemTextSelected: {
    fontSize: Typography.subtitle, fontWeight: '600', color: Colors.textPrimary,
  },
});

export default DatePicker;
