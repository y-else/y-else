/**
 * 头像选择组件
 * 调用原生相册或拍照
 */

import React, { useState } from 'react';
import {
  TouchableOpacity,
  Image,
  Text,
  StyleSheet,
  View,
  ActivityIndicator,
  Alert,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';

interface AvatarPickerProps {
  uri: string | null;
  onPick: (uri: string) => void;
  size?: number;
}

const AvatarPicker: React.FC<AvatarPickerProps> = ({
  uri,
  onPick,
  size = 80,
}) => {
  const [loading, setLoading] = useState(false);

  const handlePick = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('权限提示', '需要相册权限才能选择头像，请在设置中开启');
      return;
    }

    setLoading(true);
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });
      if (!result.canceled && result.assets.length > 0) {
        onPick(result.assets[0].uri);
      }
    } catch {
      Alert.alert('错误', '选取图片失败');
    } finally {
      setLoading(false);
    }
  };

  return (
    <TouchableOpacity
      onPress={handlePick}
      style={[styles.container, { width: size, height: size, borderRadius: size / 2 }]}
      activeOpacity={0.7}
    >
      {loading ? (
        <ActivityIndicator color={Colors.primary} />
      ) : uri ? (
        <Image
          source={{ uri }}
          style={[styles.image, { width: size, height: size, borderRadius: size / 2 }]}
        />
      ) : (
        <View style={styles.placeholder}>
          <Ionicons name="camera-outline" size={size * 0.35} color={Colors.textHint} />
          <Text style={styles.placeholderText}>上传头像</Text>
        </View>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    alignSelf: 'center',
    backgroundColor: Colors.bgPrimary,
    borderWidth: 1,
    borderColor: Colors.divider,
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    marginBottom: Spacing.lg,
  },
  image: {
    position: 'absolute',
  },
  placeholder: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  placeholderText: {
    fontSize: Typography.caption,
    color: Colors.textHint,
    marginTop: 2,
  },
});

export default AvatarPicker;
