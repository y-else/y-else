/**
 * 设置项开关组件
 */

import React from 'react';
import { View, Text, Switch, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing } from '../constants';

interface SwitchSettingProps {
  label: string;
  description?: string;
  value: boolean;
  onValueChange: (value: boolean) => void;
  disabled?: boolean;
  icon?: React.ComponentProps<typeof Ionicons>['name'];
}

const SwitchSetting: React.FC<SwitchSettingProps> = ({
  label,
  description,
  value,
  onValueChange,
  disabled = false,
  icon,
}) => {
  return (
    <View style={[styles.row, disabled && styles.disabled]}>
      {icon && (
        <Ionicons
          name={icon}
          size={20}
          color={disabled ? Colors.textHint : Colors.textSecondary}
          style={styles.icon}
        />
      )}
      <View style={styles.info}>
        <Text style={[styles.label, disabled && styles.labelDisabled]}>
          {label}
        </Text>
        {description && (
          <Text style={styles.desc}>{description}</Text>
        )}
      </View>
      <Switch
        value={value}
        onValueChange={onValueChange}
        disabled={disabled}
        trackColor={{ false: Colors.divider, true: Colors.primary + '60' }}
        thumbColor={value ? Colors.primary : '#f4f3f4'}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#E5E6EB',
  },
  disabled: { opacity: 0.5 },
  icon: { marginRight: Spacing.md },
  info: { flex: 1, marginRight: Spacing.md },
  label: { fontSize: Typography.body, color: Colors.textPrimary },
  labelDisabled: { color: Colors.textHint },
  desc: { fontSize: Typography.caption, color: Colors.textHint, marginTop: 2 },
});

export default SwitchSetting;
