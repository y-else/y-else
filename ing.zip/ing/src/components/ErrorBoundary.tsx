/**
 * 全局错误边界
 * 捕获运行时错误并显示诊断信息
 */

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';

interface Props { children: React.ReactNode; }
interface State { hasError: boolean; error: Error | null; errorInfo: string; retryKey: number; }

export class ErrorBoundary extends React.Component<Props, State> {
  state: State = { hasError: false, error: null, errorInfo: '', retryKey: 0 };

  static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo): void {
    console.error('[ErrorBoundary]', error, errorInfo);
    this.setState({ errorInfo: errorInfo.componentStack || '' });
  }

  // 【修复8】重试时递增 key，强制子组件树完全卸载再重新挂载
  // 之前只 reset state 不改变组件树，原生模块注册失败的状态不会自动恢复
  handleReset = () => this.setState((prev) => ({
    hasError: false,
    error: null,
    errorInfo: '',
    retryKey: prev.retryKey + 1,
  }));

  render() {
    if (this.state.hasError) {
      return (
        <View style={styles.container}>
          <Text style={styles.title}>应用出现错误</Text>
          <Text style={styles.message}>{this.state.error?.message || '未知错误'}</Text>
          {this.state.errorInfo ? (
            <ScrollView style={styles.stackScroll}>
              <Text style={styles.stack}>{this.state.errorInfo}</Text>
            </ScrollView>
          ) : null}
          <TouchableOpacity style={styles.retryBtn} onPress={this.handleReset}>
            <Text style={styles.retryText}>重试</Text>
          </TouchableOpacity>
        </View>
      );
    }
    // retryKey 变化时 React 会完全卸载再重建整个子树，解决「重试」无效的问题
    return <React.Fragment key={this.state.retryKey}>{this.props.children}</React.Fragment>;
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.xl,
    backgroundColor: Colors.bgPrimary,
  },
  title: {
    fontSize: Typography.title,
    fontWeight: '700',
    color: Colors.lover,
    marginBottom: Spacing.md,
  },
  message: {
    fontSize: Typography.body,
    color: Colors.textSecondary,
    textAlign: 'center',
    marginBottom: Spacing.lg,
    lineHeight: 22,
  },
  stackScroll: {
    maxHeight: 200,
    width: '100%',
    backgroundColor: '#F5F5F5',
    borderRadius: BorderRadius.card,
    padding: Spacing.md,
    marginBottom: Spacing.lg,
  },
  stack: {
    fontSize: 10,
    color: Colors.textHint,
    lineHeight: 14,
  },
  retryBtn: {
    backgroundColor: Colors.primary,
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.card,
  },
  retryText: {
    fontSize: Typography.body,
    color: '#FFF',
    fontWeight: '600',
  },
});
