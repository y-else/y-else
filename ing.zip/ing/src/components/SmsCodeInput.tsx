/**
 * 验证码输入组件 — 带发送按钮和倒计时
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { sendSmsCode } from '../services/auth';

interface SmsCodeInputProps {
  phone: string;
  value: string;
  onChangeText: (text: string) => void;
  error?: string;
}

const SmsCodeInput: React.FC<SmsCodeInputProps> = ({
  phone,
  value,
  onChangeText,
  error,
}) => {
  const [countdown, setCountdown] = useState(0);
  const [sending, setSending] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (countdown <= 0 && timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, [countdown]);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const handleSendCode = async () => {
    if (countdown > 0 || sending) return;
    if (!/^1[3-9]\d{9}$/.test(phone)) return;

    setSending(true);
    try {
      const resp = await sendSmsCode(phone);
      if (resp.code === 200) {
        setCountdown(60);
        timerRef.current = setInterval(() => {
          setCountdown((prev) => prev - 1);
        }, 1000);
      }
    } finally {
      setSending(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>验证码</Text>
      <View style={styles.row}>
        <TextInput
          style={[styles.input, error ? styles.inputError : null]}
          placeholder="请输入验证码"
          placeholderTextColor={Colors.textHint}
          keyboardType="number-pad"
          maxLength={6}
          value={value}
          onChangeText={onChangeText}
        />
        <TouchableOpacity
          style={[styles.sendBtn, (countdown > 0 || !phone) && styles.sendBtnDisabled]}
          onPress={handleSendCode}
          disabled={countdown > 0 || sending || !phone}
          activeOpacity={0.7}
        >
          <Text style={styles.sendBtnText}>
            {sending
              ? '发送中...'
              : countdown > 0
                ? `${countdown}s`
                : '获取验证码'}
          </Text>
        </TouchableOpacity>
      </View>
      {error ? <Text style={styles.error}>{error}</Text> : null}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.lg,
  },
  label: {
    fontSize: Typography.body,
    color: Colors.textPrimary,
    marginBottom: Spacing.xs,
    fontWeight: '500',
  },
  row: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  input: {
    flex: 1,
    height: 48,
    borderWidth: 1,
    borderColor: Colors.divider,
    borderRadius: BorderRadius.input,
    paddingHorizontal: Spacing.md,
    fontSize: Typography.body,
    color: Colors.textPrimary,
    backgroundColor: Colors.bgWhite,
  },
  inputError: {
    borderColor: Colors.lover,
  },
  sendBtn: {
    height: 48,
    paddingHorizontal: Spacing.lg,
    backgroundColor: Colors.primary,
    borderRadius: BorderRadius.input,
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 100,
  },
  sendBtnDisabled: {
    backgroundColor: Colors.textHint,
  },
  sendBtnText: {
    fontSize: Typography.caption,
    color: Colors.white,
    fontWeight: '500',
  },
  error: {
    fontSize: Typography.caption,
    color: Colors.lover,
    marginTop: Spacing.xs,
  },
});

export default SmsCodeInput;
