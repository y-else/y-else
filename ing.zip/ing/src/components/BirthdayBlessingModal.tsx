/**
 * 生日祝福弹窗（F4修复）
 * 生日当天自动弹出祝福，展示年龄、好友生日提醒
 */

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import type { BirthdayInfo, BirthdayReminder } from '../types';

interface BirthdayBlessingModalProps {
  visible: boolean;
  birthday: BirthdayInfo | null;
  friendBirthdays: BirthdayReminder[];
  onClose: () => void;
}

const BirthdayBlessingModal: React.FC<BirthdayBlessingModalProps> = ({
  visible, birthday, friendBirthdays, onClose,
}) => {
  if (!visible || !birthday) return null;

  return (
    <View style={styles.overlay}>
      <View style={styles.card}>
        {/* 背景装饰 */}
        <View style={styles.confetti}>
          {['🎂', '🎉', '🎁', '🎈', '✨'].map((emoji, i) => (
            <Text key={i} style={[styles.confettiEmoji, {
              top: -20 + Math.random() * 30,
              left: 10 + i * 60,
              transform: [{ rotate: `${-20 + Math.random() * 40}deg` }],
            }]}>
              {emoji}
            </Text>
          ))}
        </View>

        <View style={styles.iconWrap}>
          <Ionicons name="gift" size={48} color="#FF6B6B" />
        </View>

        <Text style={styles.title}>生日快乐！🎂</Text>
        <Text style={styles.body}>
          今天是你的 {birthday.age} 岁生日，{'\n'}ing 陪伴祝你生日快乐、万事如意！
        </Text>

        {/* 好友生日提醒（F5修复） */}
        {friendBirthdays.length > 0 && (
          <View style={styles.friendSection}>
            <Text style={styles.friendTitle}>今日同生</Text>
            {friendBirthdays.map((f) => (
              <View key={f.friendUserId} style={styles.friendItem}>
                <Ionicons name="person" size={16} color={Colors.friend} />
                <Text style={styles.friendText}>
                  {f.friendUsername} 今天也过生日，记得送祝福哦
                </Text>
              </View>
            ))}
          </View>
        )}

        <TouchableOpacity style={styles.closeBtn} onPress={onClose} activeOpacity={0.8}>
          <Text style={styles.closeText}>谢谢！收起祝福</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 999,
    padding: Spacing.xl,
  },
  card: {
    backgroundColor: Colors.bgWhite,
    borderRadius: BorderRadius.card,
    padding: Spacing.xl,
    alignItems: 'center',
    width: '100%',
    maxWidth: 320,
    overflow: 'hidden',
  },
  confetti: {
    position: 'absolute',
    top: 10,
    left: 10,
    right: 10,
    height: 60,
  },
  confettiEmoji: {
    position: 'absolute',
    fontSize: 18,
  },
  iconWrap: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FFF0F0',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.md,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    color: '#FF6B6B',
    marginBottom: Spacing.sm,
  },
  body: {
    fontSize: Typography.body,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 24,
  },
  friendSection: {
    marginTop: Spacing.lg,
    paddingTop: Spacing.md,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: Colors.divider,
    width: '100%',
  },
  friendTitle: {
    fontSize: Typography.body,
    fontWeight: '600',
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
  },
  friendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.xs,
  },
  friendText: {
    fontSize: Typography.caption,
    color: Colors.friend,
    flex: 1,
  },
  closeBtn: {
    marginTop: Spacing.xl,
    backgroundColor: '#FF6B6B',
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.input,
    width: '100%',
    alignItems: 'center',
  },
  closeText: {
    fontSize: Typography.body,
    fontWeight: '600',
    color: Colors.white,
  },
});

export default BirthdayBlessingModal;
