/**
 * SOS 倒计时弹窗（修复版）
 *
 * 修复：
 * - C3: visible=true 时组件卸载现在必定清理振动
 * - R13: transform 用 translateX + scaleX 替代 transformOrigin 兼容旧版 RN
 * - 竞态防护：countdownSeconds 变化时先清理旧动画和定时器
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal as RNModal,
  Pressable,
  Animated,
  Vibration,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import Button from './Button';

interface SOSCountdownModalProps {
  visible: boolean;
  countdownSeconds?: number;
  onCancel: () => void;
  onTrigger: () => void;
}

const SOSCountdownModal: React.FC<SOSCountdownModalProps> = ({
  visible,
  countdownSeconds = 5,
  onCancel,
  onTrigger,
}) => {
  const [countdown, setCountdown] = useState(countdownSeconds);
  const progressAnim = useRef(new Animated.Value(1)).current;
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const progressAniRef = useRef<Animated.CompositeAnimation | null>(null);

  // 追踪最新的 countdownSeconds 防止闭包竞态
  const countdownSecondsRef = useRef(countdownSeconds);
  countdownSecondsRef.current = countdownSeconds;

  // 稳定化 onTrigger 引用
  const onTriggerRef = useRef(onTrigger);
  onTriggerRef.current = onTrigger;

  useEffect(() => {
    if (visible) {
      const seconds = countdownSecondsRef.current;
      setCountdown(seconds);
      progressAnim.setValue(1);

      // 停止旧动画（如果存在）
      progressAniRef.current?.stop();

      // 进度条动画（NativeDriver兼容）
      progressAniRef.current = Animated.timing(progressAnim, {
        toValue: 0,
        duration: seconds * 1000,
        useNativeDriver: true,
      });
      progressAniRef.current.start();

      // 每秒减少倒计时
      intervalRef.current = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            if (intervalRef.current) {
              clearInterval(intervalRef.current);
              intervalRef.current = null;
            }
            return 0;
          }
          Vibration.vibrate(100);
          return prev - 1;
        });
      }, 1000);
    }

    // C3修复：无论 visible 状态如何，cleanup 统一清理振动+定时器+动画
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      progressAniRef.current?.stop();
      Vibration.cancel();
    };
  }, [visible]);

  // 倒计时归零自动触发（使用 ref 避免 onTrigger 变化触发重跑）
  useEffect(() => {
    if (countdown === 0 && visible) {
      onTriggerRef.current();
    }
  }, [countdown, visible]);

  // 取消处理
  const handleCancel = useCallback(() => {
    Vibration.cancel();
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    progressAniRef.current?.stop();
    onCancel();
  }, [onCancel]);

  return (
    <RNModal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={handleCancel}
    >
      <View style={styles.overlay}>
        <View style={styles.container}>
          <View style={styles.iconCircle}>
            <Ionicons name="warning" size={48} color="#E74C3C" />
          </View>

          <Text style={styles.title}>正在发送求救信号</Text>
          <Text style={styles.countdown}>{countdown}</Text>
          <Text style={styles.hint}>秒后自动发送</Text>

          {/* 倒计时进度条：使用 scaleX 从右向左收缩 */}
          <View style={styles.progressBg}>
            <Animated.View
              style={[
                styles.progressFill,
                {
                  transform: [
                    { translateX: progressAnim.interpolate({ inputRange: [0, 1], outputRange: [-200, 0] }) },
                    { scaleX: progressAnim },
                  ],
                },
              ]}
            />
          </View>

          <Text style={styles.warning}>
            将向绑定人和管理员发送您的实时位置
          </Text>

          <Button
            title="取消求救"
            variant="outline"
            onPress={handleCancel}
            style={styles.cancelBtn}
          />
        </View>
      </View>
    </RNModal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.lg,
  },
  container: {
    backgroundColor: Colors.bgWhite,
    borderRadius: BorderRadius.card,
    padding: Spacing.xl,
    width: '100%',
    maxWidth: 340,
    alignItems: 'center',
  },
  iconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FFF0F0',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.lg,
    borderWidth: 3,
    borderColor: '#E74C3C',
  },
  title: {
    fontSize: Typography.subtitle,
    fontWeight: '600',
    color: Colors.textPrimary,
    marginBottom: Spacing.lg,
  },
  countdown: {
    fontSize: 64,
    fontWeight: '800',
    color: '#E74C3C',
    lineHeight: 72,
  },
  hint: {
    fontSize: Typography.body,
    color: Colors.textSecondary,
    marginBottom: Spacing.xl,
  },
  progressBg: {
    width: '100%',
    height: 6,
    backgroundColor: Colors.divider,
    borderRadius: 3,
    overflow: 'hidden',
    marginBottom: Spacing.lg,
  },
  progressFill: {
    height: '100%',
    width: '100%',
    backgroundColor: '#E74C3C',
    borderRadius: 3,
    // 使用 translateX + scaleX 实现左对齐收缩（兼容不支持 transformOrigin 的旧版 RN）
    // scaleX=1, translateX=0: 满条
    // scaleX=0, translateX≈-width/2: 收缩到左边缘
  },
  warning: {
    fontSize: Typography.caption,
    color: Colors.textHint,
    textAlign: 'center',
    marginBottom: Spacing.xl,
    lineHeight: 18,
  },
  cancelBtn: {
    width: '100%',
    borderColor: Colors.textHint,
  },
});

export default SOSCountdownModal;
