/**
 * 权限守卫组件
 * 检测定位+通知权限，拒绝则阻塞功能并引导跳转系统设置
 *
 * 权限服务统一来源: src/services/permissions.ts
 */

import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import Button from './Button';
import {
  checkAllPermissions,
  forceLocationAlwaysPermission,
  showPermissionBlockedAlert,
  openAppSettings,
} from '../services/permissions';

interface PermissionGuardProps {
  children: React.ReactNode;
  requiredPermissions?: ('location' | 'notification')[];
  onGranted?: () => void;
}

const PermissionGuard: React.FC<PermissionGuardProps> = ({
  children,
  requiredPermissions = ['location', 'notification'],
  onGranted,
}) => {
  const [checking, setChecking] = useState(true);
  const [blocked, setBlocked] = useState(false);
  const [blockedType, setBlockedType] = useState<'定位' | '通知'>('定位');

  useEffect(() => {
    checkPermissions();
  }, []);

  const checkPermissions = async () => {
    setChecking(true);
    const perms = await checkAllPermissions();

    if (requiredPermissions.includes('location')) {
      if (perms.locationForeground !== 'granted' || perms.locationBackground !== 'granted') {
        const result = await forceLocationAlwaysPermission();
        if (!result.granted) {
          setBlockedType('定位');
          setBlocked(true);
          setChecking(false);
          return;
        }
      }
    }

    if (requiredPermissions.includes('notification')) {
      if (perms.notification !== 'granted') {
        showPermissionBlockedAlert('通知');
        setBlockedType('通知');
        setBlocked(true);
        setChecking(false);
        return;
      }
    }

    setBlocked(false);
    setChecking(false);
    onGranted?.();
  };

  if (checking) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={Colors.primary} />
        <Text style={styles.checkingText}>正在检查权限...</Text>
      </View>
    );
  }

  if (blocked) {
    return (
      <View style={styles.center}>
        <Ionicons name="warning" size={64} color={Colors.lover} />
        <Text style={styles.blockedTitle}>{blockedType}权限未开启</Text>
        <Text style={styles.blockedDesc}>
          需要"始终允许"{blockedType}权限才能正常使用此功能。{'\n'}
          APP关闭/后台/锁屏状态下仍需要持续保护您的安全。
        </Text>
        <Button
          title="前往系统设置"
          onPress={openAppSettings}
          style={styles.settingsBtn}
        />
        <Button
          title="重新检查"
          variant="ghost"
          onPress={checkPermissions}
        />
      </View>
    );
  }

  return <>{children}</>;
};

const styles = StyleSheet.create({
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.bgPrimary,
    padding: Spacing.xl,
  },
  checkingText: {
    fontSize: Typography.body,
    color: Colors.textHint,
    marginTop: Spacing.lg,
  },
  blockedTitle: {
    fontSize: Typography.title,
    fontWeight: '600',
    color: Colors.textPrimary,
    marginTop: Spacing.lg,
  },
  blockedDesc: {
    fontSize: Typography.body,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
    marginTop: Spacing.md,
    marginBottom: Spacing.xl,
  },
  settingsBtn: {
    marginBottom: Spacing.md,
  },
});

export default PermissionGuard;
