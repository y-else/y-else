/**
 * 悬浮抽奖入口按钮
 * 支持全屏拖拽、边界限制、边缘吸附
 * 可关闭（点击X），重启后自动复原，保留后台配置逻辑
 */

import React, { useState, useRef } from 'react';
import {
  Animated,
  PanResponder,
  type PanResponderGestureState,
  type GestureResponderEvent,
  TouchableOpacity,
  StyleSheet,
  Text,
  View,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, BorderRadius } from '../constants';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');
const BUTTON_SIZE = 52;
const EDGE_MARGIN = 8;

interface FloatingLotteryButtonProps {
  onPress: () => void;
  visible?: boolean;
}

const FloatingLotteryButton: React.FC<FloatingLotteryButtonProps> = ({
  onPress,
  visible = true,
}) => {
  const [closed, setClosed] = useState(false);
  const mountedRef = useRef(true);

  // 初始位置：右下角SOS按钮上方
  const pan = useRef(
    new Animated.ValueXY({
      x: SCREEN_WIDTH - BUTTON_SIZE - 16,
      y: SCREEN_HEIGHT * 0.38,
    }),
  ).current;

  // 浮动动画（仅静止时播放）
  const floatAnim = useRef(new Animated.Value(0)).current;
  const isDragging = useRef(false);
  const floatLoopRef = useRef<Animated.CompositeAnimation | null>(null);

  const startFloat = () => {
    if (!mountedRef.current || isDragging.current) return;
    floatLoopRef.current?.stop();
    floatAnim.setValue(0);
    floatLoopRef.current = Animated.loop(
      Animated.sequence([
        Animated.timing(floatAnim, { toValue: -6, duration: 1200, useNativeDriver: true }),
        Animated.timing(floatAnim, { toValue: 0, duration: 1200, useNativeDriver: true }),
      ]),
    );
    floatLoopRef.current.start();
  };

  React.useEffect(() => {
    mountedRef.current = true;
    startFloat();
    return () => {
      mountedRef.current = false;
      floatLoopRef.current?.stop();
    };
  }, []);

  // 全屏拖拽手势
  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: (_e: GestureResponderEvent, gs: PanResponderGestureState) =>
        Math.abs(gs.dx) > 3 || Math.abs(gs.dy) > 3,
      onPanResponderGrant: () => {
        isDragging.current = true;
        floatAnim.setValue(0);
        pan.extractOffset();
      },
      onPanResponderMove: Animated.event([null, { dx: pan.x, dy: pan.y }], {
        useNativeDriver: true,
      }),
      onPanResponderRelease: (_e: GestureResponderEvent, gs: PanResponderGestureState) => {
        pan.flattenOffset();
        isDragging.current = false;

        const currentY = gs.moveY - BUTTON_SIZE / 2;
        const clampedY = Math.max(
          80,
          Math.min(SCREEN_HEIGHT - BUTTON_SIZE - 120, currentY),
        );
        const finalX =
          gs.moveX > SCREEN_WIDTH / 2
            ? SCREEN_WIDTH - BUTTON_SIZE - EDGE_MARGIN
            : EDGE_MARGIN;

        Animated.spring(pan, {
          toValue: { x: finalX, y: clampedY },
          useNativeDriver: true,
          friction: 8,
        }).start(() => {
          startFloat();
        });
      },
    }),
  ).current;

  const handleClose = () => {
    setClosed(true);
    // 本次会话关闭，重启后自动复原
  };

  if (!visible || closed) return null;

  return (
    <Animated.View
      style={[
        styles.container,
        {
          transform: [
            { translateX: pan.x },
            { translateY: Animated.add(pan.y, floatAnim) },
          ],
        },
      ]}
      {...panResponder.panHandlers}
    >
      <TouchableOpacity
        style={styles.button}
        onPress={onPress}
        activeOpacity={0.7}
      >
        <Ionicons name="gift" size={22} color="#FFFFFF" />
        <Text style={styles.label}>抽奖</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.closeBtn}
        onPress={handleClose}
        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
      >
        <Ionicons name="close" size={12} color={Colors.textHint} />
      </TouchableOpacity>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    zIndex: 998,
    alignItems: 'center',
  },
  button: {
    width: BUTTON_SIZE,
    height: BUTTON_SIZE,
    borderRadius: BUTTON_SIZE / 2,
    backgroundColor: '#FF6B35',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 6,
    shadowColor: '#FF6B35',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.35,
    shadowRadius: 6,
  },
  label: {
    fontSize: 8,
    color: '#FFFFFF',
    fontWeight: '700',
    marginTop: -2,
  },
  closeBtn: {
    position: 'absolute',
    top: -4,
    right: -4,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: Colors.bgWhite,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 7,
    borderWidth: 1,
    borderColor: Colors.divider,
  },
});

export default FloatingLotteryButton;
