/**
 * 公告弹窗
 * 用户下次启动自动弹窗，可选择关闭
 * 已关闭的公告不再弹出
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Modal as RNModal,
  Pressable,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import Button from './Button';
import { markAsRead, markAllAsRead } from '../services/announcement';
import type { Announcement } from '../types';

interface AnnouncementModalProps {
  announcements: Announcement[];
  visible: boolean;
  userId: string;
  onCloseAll: () => void;
}

const LEVEL_CONFIG: Record<string, { color: string; label: string }> = {
  urgent: { color: '#E74C3C', label: '紧急' },
  important: { color: '#F0AD4E', label: '重要' },
  normal: { color: '#4A90E2', label: '通知' },
};

const AnnouncementModal: React.FC<AnnouncementModalProps> = ({
  announcements,
  visible,
  userId,
  onCloseAll,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  if (announcements.length === 0) return null;

  const current = announcements[currentIndex];
  const levelCfg = LEVEL_CONFIG[current.level] || LEVEL_CONFIG.normal;
  const isLast = currentIndex >= announcements.length - 1;

  const handleClose = async () => {
    await markAsRead(userId, current.id);
    if (isLast) {
      onCloseAll();
    } else {
      setCurrentIndex((prev) => prev + 1);
    }
  };

  const handleCloseAll = async () => {
    await markAllAsRead(userId, announcements.map((a) => a.id));
    onCloseAll();
  };

  return (
    <RNModal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={handleCloseAll}
    >
      <Pressable style={styles.overlay} onPress={handleCloseAll}>
        <Pressable style={styles.container} onPress={() => {}}>
          {/* 顶部标签 */}
          <View style={styles.header}>
            <View style={[styles.levelBadge, { backgroundColor: levelCfg.color }]}>
              <Text style={styles.levelText}>{levelCfg.label}</Text>
            </View>
            <Text style={styles.annCount}>
              {currentIndex + 1} / {announcements.length}
            </Text>
            <TouchableOpacity onPress={handleCloseAll} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <Ionicons name="close" size={20} color={Colors.textHint} />
            </TouchableOpacity>
          </View>

          <Text style={styles.title}>{current.title}</Text>

          <View style={styles.meta}>
            <Ionicons name="person-outline" size={14} color={Colors.textHint} />
            <Text style={styles.metaText}>{current.publishedBy}</Text>
            <Text style={styles.metaText}>·</Text>
            <Text style={styles.metaText}>
              {new Date(current.publishedAt).toLocaleDateString('zh-CN')}
            </Text>
          </View>

          <ScrollView style={styles.contentScroll} showsVerticalScrollIndicator>
            <Text style={styles.content}>{current.content}</Text>
          </ScrollView>

          <View style={styles.footer}>
            <Button
              title={isLast ? '我知道了' : '下一条'}
              onPress={handleClose}
              style={styles.btn}
            />
            {announcements.length > 1 && (
              <Button
                title="全部关闭"
                variant="ghost"
                onPress={handleCloseAll}
              />
            )}
          </View>
        </Pressable>
      </Pressable>
    </RNModal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.lg,
  },
  container: {
    backgroundColor: Colors.bgWhite,
    borderRadius: BorderRadius.card,
    padding: Spacing.xl,
    width: '100%',
    maxWidth: 360,
    maxHeight: '80%',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: Spacing.lg,
    gap: Spacing.sm,
  },
  levelBadge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: 4,
  },
  levelText: {
    fontSize: Typography.caption,
    color: Colors.white,
    fontWeight: '600',
  },
  annCount: {
    fontSize: Typography.caption,
    color: Colors.textHint,
    flex: 1,
  },
  title: {
    fontSize: Typography.title,
    fontWeight: '600',
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
  },
  meta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    marginBottom: Spacing.lg,
  },
  metaText: {
    fontSize: Typography.caption,
    color: Colors.textHint,
  },
  contentScroll: {
    maxHeight: 200,
    marginBottom: Spacing.xl,
  },
  content: {
    fontSize: Typography.body,
    color: Colors.textSecondary,
    lineHeight: 24,
  },
  footer: {
    gap: Spacing.sm,
  },
  btn: {
    width: '100%',
  },
});

export default AnnouncementModal;
