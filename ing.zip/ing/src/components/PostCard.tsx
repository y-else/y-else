/**
 * 空间动态卡片（修复版）
 * 修复：S1点赞状态基于当前用户 + S2评论删除权限 + 举报/拉黑
 */

import React, { useState } from 'react';
import {
  View, Text, StyleSheet, Image, TouchableOpacity, Dimensions, TextInput, Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import type { SpacePost, SpaceVisibility } from '../types';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

interface PostCardProps {
  post: SpacePost;
  viewerId: string;
  viewerName: string;
  isOwner: boolean;
  isAdmin: boolean;
  onLike: (postId: string) => void;
  onComment: (postId: string, content: string) => void;
  onDelete: (postId: string) => void;
  onDeleteComment: (postId: string, commentId: string) => void;
  onReport: (postId: string) => void;
  onBlockAuthor: (postId: string) => void;
  onBlockCommentAuthor: (postId: string, commentId: string) => void;
}

const VIS_LABELS: Record<SpaceVisibility, { label: string; icon: React.ComponentProps<typeof Ionicons>['name']; color: string; bg: string }> = {
  public: { label: '公开', icon: 'earth', color: '#10B981', bg: '#ECFDF5' },
  friends_only: { label: '好友可见', icon: 'people', color: '#F59E0B', bg: '#FFFBEB' },
  private: { label: '仅自己', icon: 'lock-closed', color: '#9CA3AF', bg: '#F3F4F6' },
};

const PostCard: React.FC<PostCardProps> = ({
  post, viewerId, viewerName, isOwner, isAdmin,
  onLike, onComment, onDelete, onDeleteComment,
  onReport, onBlockAuthor, onBlockCommentAuthor,
}) => {
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');
  const vis = VIS_LABELS[post.visibility];

  // 当前用户是否已点赞此动态（S1修复）
  const hasLiked = post.likes.some((l) => l.userId === viewerId);
  const likeCount = post.likes.length;
  const visibleComments = post.comments.filter((c) => !c.isDeleted);

  const handleSubmitComment = () => {
    if (commentText.trim()) {
      onComment(post.id, commentText.trim());
      setCommentText('');
    }
  };

  // 评论删除权限（S2修复）：
  // - 空间主人(isOwner) 可删除任何评论
  // - 评论作者本人 可删除自己评论
  // - 动态作者(post.authorId === viewerId) 可删除任何评论
  const canDeleteComment = (commentAuthorId: string) => {
    if (isAdmin) return false; // 管理员只读
    if (isOwner) return true;
    if (post.authorId === viewerId) return true;
    if (commentAuthorId === viewerId) return true;
    return false;
  };

  // 动态删除权限：仅作者本人，管理员不可
  const canDeletePost = !isAdmin && (isOwner || post.authorId === viewerId);

  // 是否显示举报/拉黑：非主人、非管理员、非自己
  const showReportBlock = !isOwner && !isAdmin && post.authorId !== viewerId;

  const isPostAuthorBlocked = post.blockedBy?.includes(viewerId);

  return (
    <View style={styles.card}>
      {/* 头部 */}
      <View style={styles.header}>
        <View style={styles.authorRow}>
          <View style={styles.avatar}>
            <Ionicons name="person" size={16} color={Colors.textHint} />
          </View>
          <View>
            <Text style={styles.authorName}>{post.authorName}</Text>
            <Text style={styles.time}>
              {new Date(post.createdAt).toLocaleString('zh-CN')}
            </Text>
          </View>
        </View>
        <View style={styles.headerRight}>
          <View style={[styles.visTag, { backgroundColor: vis.bg }]}>
            <Ionicons name={vis.icon} size={10} color={vis.color} />
            <Text style={[styles.visText, { color: vis.color }]}>{vis.label}</Text>
          </View>
          {canDeletePost && (
            <TouchableOpacity onPress={() => onDelete(post.id)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <Ionicons name="trash-outline" size={16} color={Colors.lover} />
            </TouchableOpacity>
          )}
          {showReportBlock && (
            <>
              <TouchableOpacity onPress={() => onReport(post.id)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                <Ionicons name="flag-outline" size={14} color={Colors.textHint} />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => onBlockAuthor(post.id)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                <Ionicons name="ban-outline" size={14} color={Colors.textHint} />
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>

      {/* 内容 */}
      {post.content ? <Text style={styles.content}>{post.content}</Text> : null}

      {/* 媒体网格 */}
      {post.media.length > 0 && (
        <View style={styles.mediaGrid}>
          {post.media.map((m, i) => (
            <View key={i} style={styles.mediaItem}>
              <Image source={{ uri: m.thumbnailUri || m.uri }} style={styles.mediaImg} />
              {m.type === 'video' && (
                <Ionicons name="play-circle" size={20} color="#FFF" style={styles.videoIcon} />
              )}
            </View>
          ))}
        </View>
      )}

      {/* 互动栏 */}
      <View style={styles.actions}>
        <TouchableOpacity style={styles.actionBtn} onPress={() => onLike(post.id)}>
          <Ionicons
            name={hasLiked ? 'heart' : 'heart-outline'}
            size={18}
            color={hasLiked ? Colors.lover : Colors.textHint}
          />
          <Text style={[styles.actionText, hasLiked && { color: Colors.lover }]}>
            {likeCount > 0 ? likeCount : '赞'}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionBtn} onPress={() => setShowComments(!showComments)}>
          <Ionicons name="chatbubble-outline" size={18} color={Colors.textHint} />
          <Text style={styles.actionText}>{visibleComments.length > 0 ? visibleComments.length : '评论'}</Text>
        </TouchableOpacity>
      </View>

      {/* 评论列表 */}
      {showComments && (
        <View style={styles.commentsSection}>
          {visibleComments.map((c) => (
            <View key={c.id} style={styles.commentRow}>
              <Text style={styles.commentAuthor}>{c.authorName}: </Text>
              <Text style={styles.commentContent}>{c.content}</Text>
              <Text style={styles.commentTime}>
                {new Date(c.createdAt).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}
              </Text>
              <View style={styles.commentActions}>
                {canDeleteComment(c.authorId) && (
                  <TouchableOpacity onPress={() => onDeleteComment(post.id, c.id)} hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}>
                    <Ionicons name="close" size={12} color={Colors.textHint} />
                  </TouchableOpacity>
                )}
                {showReportBlock && c.authorId !== viewerId && (
                  <TouchableOpacity onPress={() => onBlockCommentAuthor(post.id, c.id)} hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}>
                    <Ionicons name="ban" size={10} color={Colors.textHint} />
                  </TouchableOpacity>
                )}
              </View>
            </View>
          ))}
          {/* 评论输入 */}
          <View style={styles.commentInputRow}>
            <TextInput
              style={styles.commentInput}
              placeholder="写评论..."
              placeholderTextColor={Colors.textHint}
              value={commentText}
              onChangeText={setCommentText}
              onSubmitEditing={handleSubmitComment}
            />
            <TouchableOpacity onPress={handleSubmitComment}>
              <Ionicons name="send" size={18} color={Colors.primary} />
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    padding: Spacing.lg, marginBottom: Spacing.md,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06, shadowRadius: 6, elevation: 2,
  },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: Spacing.md },
  authorRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  avatar: {
    width: 32, height: 32, borderRadius: 16, backgroundColor: '#7B68EE' + '15',
    alignItems: 'center', justifyContent: 'center',
  },
  authorName: { fontSize: Typography.body, fontWeight: '600', color: Colors.textPrimary },
  time: { fontSize: Typography.caption, color: Colors.textHint },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
  visTag: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6,
  },
  visText: { fontSize: 10, fontWeight: '600' },
  content: { fontSize: Typography.body, color: Colors.textPrimary, lineHeight: 22, marginBottom: Spacing.md },
  mediaGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 4, marginBottom: Spacing.md },
  mediaItem: {
    width: (SCREEN_WIDTH - Spacing.lg * 3) / 3,
    height: (SCREEN_WIDTH - Spacing.lg * 3) / 3,
    borderRadius: 4, overflow: 'hidden', backgroundColor: Colors.bgPrimary,
  },
  mediaImg: { width: '100%', height: '100%' },
  videoIcon: { position: 'absolute', top: '50%', left: '50%', marginLeft: -10, marginTop: -10 },
  actions: { flexDirection: 'row', gap: Spacing.xl, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider, paddingTop: Spacing.sm },
  actionBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  actionText: { fontSize: Typography.body, color: Colors.textHint },
  commentsSection: { marginTop: Spacing.md, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: Colors.divider, paddingTop: Spacing.sm },
  commentRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', paddingVertical: 3, gap: 2 },
  commentAuthor: { fontSize: Typography.caption, fontWeight: '600', color: Colors.textPrimary },
  commentContent: { fontSize: Typography.caption, color: Colors.textSecondary, flex: 1 },
  commentTime: { fontSize: 9, color: Colors.textHint, marginLeft: 4 },
  commentActions: { flexDirection: 'row', gap: 4, marginLeft: 2 },
  commentInputRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, marginTop: Spacing.sm },
  commentInput: {
    flex: 1, height: 32, borderWidth: 1, borderColor: Colors.divider, borderRadius: BorderRadius.input,
    paddingHorizontal: Spacing.md, fontSize: Typography.caption,
  },
});

export default PostCard;
