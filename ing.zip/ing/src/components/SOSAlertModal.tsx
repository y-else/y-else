/**
 * SOS 求救提醒弹窗（优化版）
 * 修复：振动清理/unmount销毁/持续振动安全限制
 * 扩展：SOS状态显示/误触标记
 */

import React, { useEffect, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, Modal as RNModal, Vibration, Linking,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import Button from './Button';
import type { SOSAlert } from '../types';

interface SOSAlertModalProps {
  visible: boolean;
  alert: SOSAlert | null;
  onResolve: () => void;
  isReceiver?: boolean;
}

const SOSAlertModal: React.FC<SOSAlertModalProps> = ({
  visible, alert, onResolve, isReceiver = false,
}) => {
  const vibrateTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // 接收端强制振动（安全限制15秒）
  useEffect(() => {
    if (visible && isReceiver) {
      Vibration.vibrate([1000, 500, 1000, 500, 1000], false);
      // 安全保护：15秒后强制停止
      vibrateTimerRef.current = setTimeout(() => {
        Vibration.cancel();
      }, 15000);
    }
    return () => {
      Vibration.cancel();
      if (vibrateTimerRef.current) {
        clearTimeout(vibrateTimerRef.current);
        vibrateTimerRef.current = null;
      }
    };
  }, [visible, isReceiver]);

  // 组件完全卸载时确保清理
  useEffect(() => {
    return () => {
      Vibration.cancel();
      if (vibrateTimerRef.current) {
        clearTimeout(vibrateTimerRef.current);
        vibrateTimerRef.current = null;
      }
    };
  }, []);

  // C8修复：接收端也允许Android返回键关闭（弹窗不应锁死用户）
  const handleBackRequest = useCallback(() => {
    Vibration.cancel();
    if (vibrateTimerRef.current) {
      clearTimeout(vibrateTimerRef.current);
      vibrateTimerRef.current = null;
    }
    onResolve();
  }, [onResolve]);

  if (!alert) return null;

  const handleCallPolice = () => {
    Linking.openURL('tel:110');
  };

  const handleClose = () => {
    Vibration.cancel();
    if (vibrateTimerRef.current) {
      clearTimeout(vibrateTimerRef.current);
    }
    onResolve();
  };

  return (
    <RNModal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={handleBackRequest}
    >
      <View style={styles.overlay}>
        <View style={styles.container}>
          <View style={styles.iconCircle}>
            <Ionicons name="alert-circle" size={48} color="#FFFFFF" />
          </View>

          <Text style={styles.title}>
            {isReceiver ? 'SOS 紧急求救！' : '求救已发送'}
          </Text>

          {isReceiver && (
            <Text style={styles.subtitle}>
              {alert.senderName} 发来紧急求救信号
            </Text>
          )}

          {/* 位置信息 */}
          <View style={styles.infoCard}>
            <View style={styles.infoRow}>
              <Ionicons name="person" size={16} color={Colors.textSecondary} />
              <Text style={styles.infoText}>{alert.senderName}</Text>
            </View>
            <View style={styles.infoRow}>
              <Ionicons name="call" size={16} color={Colors.textSecondary} />
              <Text style={styles.infoText}>{alert.senderPhone}</Text>
            </View>
            <View style={styles.infoRow}>
              <Ionicons name="location" size={16} color={Colors.lover} />
              <Text style={styles.infoText}>
                {alert.address || `${alert.location.latitude.toFixed(6)}, ${alert.location.longitude.toFixed(6)}`}
              </Text>
            </View>
            <View style={styles.infoRow}>
              <Ionicons name="time" size={16} color={Colors.textSecondary} />
              <Text style={styles.infoText}>
                {new Date(alert.triggeredAt).toLocaleString('zh-CN')}
              </Text>
            </View>
          </View>

          {/* GPS实时定位状态 */}
          <View style={styles.gpsBadge}>
            <View style={styles.gpsDot} />
            <Text style={styles.gpsText}>GPS 实时定位中...</Text>
          </View>

          <View style={styles.actions}>
            {isReceiver && (
              <Button title="拨打110" onPress={handleCallPolice} style={styles.policeBtn} />
            )}
            <Button
              title={isReceiver ? '已知晓' : '我知道了'}
              onPress={handleClose}
              variant={isReceiver ? 'outline' : 'primary'}
            />
          </View>
        </View>
      </View>
    </RNModal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center', alignItems: 'center', padding: Spacing.lg,
  },
  container: {
    backgroundColor: Colors.bgWhite, borderRadius: BorderRadius.card,
    padding: Spacing.xl, width: '100%', maxWidth: 360, maxHeight: '90%',
  },
  iconCircle: {
    width: 72, height: 72, borderRadius: 36, backgroundColor: '#E74C3C',
    alignItems: 'center', justifyContent: 'center', alignSelf: 'center', marginBottom: Spacing.lg,
  },
  title: { fontSize: Typography.title, fontWeight: '700', color: '#E74C3C', textAlign: 'center', marginBottom: Spacing.xs },
  subtitle: { fontSize: Typography.body, color: Colors.textSecondary, textAlign: 'center', marginBottom: Spacing.xl },
  infoCard: {
    backgroundColor: Colors.bgPrimary, borderRadius: BorderRadius.card,
    padding: Spacing.lg, marginBottom: Spacing.lg,
  },
  infoRow: { flexDirection: 'row', alignItems: 'center', marginBottom: Spacing.sm, gap: Spacing.sm },
  infoText: { fontSize: Typography.body, color: Colors.textPrimary, flex: 1 },
  gpsBadge: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    marginBottom: Spacing.xl, gap: Spacing.sm,
  },
  gpsDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#5CB85C' },
  gpsText: { fontSize: Typography.caption, color: '#5CB85C', fontWeight: '500' },
  actions: { gap: Spacing.md },
  policeBtn: { backgroundColor: '#E74C3C', borderColor: '#E74C3C' },
});

export default SOSAlertModal;
