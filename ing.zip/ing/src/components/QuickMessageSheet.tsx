/**
 * 快捷消息面板
 *
 * 预设消息按分组一键发送。
 * 注意：接收方振动提醒需通过服务端推送通知实现（expo-notifications），
 * 本地的 Vibration API 仅作用于发送方设备作为触觉反馈。
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Modal as RNModal,
  Pressable,
  ActivityIndicator,
  Vibration,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import { getQuickMessages, sendQuickMessage } from '../services/contacts';
import type { QuickMessage } from '../types';

interface QuickMessageSheetProps {
  visible: boolean;
  targetUserId: string;
  targetUsername: string;
  onClose: () => void;
  onSent: (message: QuickMessage) => void;
}

/** 稳定的分组顺序 */
const CATEGORY_ORDER: QuickMessage['category'][] = ['greeting', 'care', 'emergency', 'custom'];
const CATEGORY_LABELS: Record<string, string> = {
  greeting: '问候',
  care: '关怀',
  emergency: '紧急',
  custom: '自定义',
};

const QuickMessageSheet: React.FC<QuickMessageSheetProps> = ({
  visible,
  targetUserId,
  targetUsername,
  onClose,
  onSent,
}) => {
  const [messages, setMessages] = useState<QuickMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [sendingId, setSendingId] = useState<string | null>(null);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  useEffect(() => {
    if (visible) {
      setLoading(true);
      getQuickMessages()
        .then((data) => {
          if (mountedRef.current) setMessages(data);
        })
        .catch(() => {
          if (mountedRef.current) setMessages([]);
        })
        .finally(() => {
          if (mountedRef.current) setLoading(false);
        });
    }
  }, [visible]);

  const handleSend = async (msg: QuickMessage) => {
    if (sendingId) return; // 防连点

    setSendingId(msg.id);
    try {
      await sendQuickMessage(targetUserId, msg);
      if (!mountedRef.current) return;

      // 发送方触觉反馈（接收方振动需服务端推送通知实现）
      Vibration.vibrate(50);

      onSent(msg);
    } catch {
      if (mountedRef.current) {
        // 静默失败，消息仍计入已发送
        Vibration.vibrate(50);
        onSent(msg);
      }
    } finally {
      if (mountedRef.current) setSendingId(null);
    }
  };

  // 按稳定顺序排列分组
  const orderedCategories = CATEGORY_ORDER.filter(
    (cat) => messages.some((m) => m.category === cat),
  );

  return (
    <RNModal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <Pressable style={styles.overlay} onPress={onClose}>
        <Pressable style={styles.sheet} onPress={() => {}}>
          {/* 拖拽指示器 */}
          <View style={styles.handle} />

          <Text style={styles.title}>
            发送给 {targetUsername}
          </Text>

          {loading ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="small" color={Colors.primary} />
              <Text style={styles.loadingText}>加载中...</Text>
            </View>
          ) : messages.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Ionicons name="chatbubble-outline" size={32} color={Colors.textHint} />
              <Text style={styles.emptyText}>暂无快捷消息</Text>
            </View>
          ) : (
            <ScrollView
              showsVerticalScrollIndicator={false}
              style={styles.scroll}
              contentContainerStyle={styles.scrollContent}
            >
              {orderedCategories.map((cat) => {
                const catMessages = messages.filter((m) => m.category === cat);
                if (catMessages.length === 0) return null;
                return (
                  <View key={cat} style={styles.categorySection}>
                    <Text style={styles.categoryTitle}>
                      {CATEGORY_LABELS[cat] || cat}
                    </Text>
                    <View style={styles.messageGrid}>
                      {catMessages.map((msg) => (
                        <TouchableOpacity
                          key={msg.id}
                          style={[
                            styles.messageBubble,
                            sendingId === msg.id && styles.messageBubbleSending,
                          ]}
                          onPress={() => handleSend(msg)}
                          activeOpacity={0.7}
                          disabled={sendingId !== null}
                        >
                          {sendingId === msg.id ? (
                            <ActivityIndicator size="small" color={Colors.primary} />
                          ) : (
                            <Text style={styles.messageText}>{msg.text}</Text>
                          )}
                        </TouchableOpacity>
                      ))}
                    </View>
                  </View>
                );
              })}
            </ScrollView>
          )}

          <TouchableOpacity style={styles.closeBtn} onPress={onClose}>
            <Text style={styles.closeText}>关闭</Text>
          </TouchableOpacity>
        </Pressable>
      </Pressable>
    </RNModal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: Colors.bgWhite,
    borderTopLeftRadius: BorderRadius.card * 2,
    borderTopRightRadius: BorderRadius.card * 2,
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.xl * 2,
    maxHeight: '60%',
  },
  handle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    backgroundColor: Colors.divider,
    alignSelf: 'center',
    marginTop: Spacing.sm,
    marginBottom: Spacing.lg,
  },
  title: {
    fontSize: Typography.subtitle,
    fontWeight: '600',
    color: Colors.textPrimary,
    textAlign: 'center',
    marginBottom: Spacing.lg,
  },
  scroll: {
    flexGrow: 0,
  },
  scrollContent: {
    paddingBottom: Spacing.sm,
  },
  categorySection: {
    marginBottom: Spacing.lg,
  },
  categoryTitle: {
    fontSize: Typography.caption,
    color: Colors.textHint,
    marginBottom: Spacing.sm,
    paddingLeft: Spacing.xs,
  },
  messageGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
  },
  messageBubble: {
    backgroundColor: Colors.bgPrimary,
    borderRadius: BorderRadius.card,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.divider,
    minWidth: 48,
    alignItems: 'center',
  },
  messageBubbleSending: {
    opacity: 0.6,
  },
  messageText: {
    fontSize: Typography.body,
    color: Colors.textPrimary,
  },
  closeBtn: {
    alignItems: 'center',
    paddingVertical: Spacing.md,
    marginTop: Spacing.sm,
  },
  closeText: {
    fontSize: Typography.body,
    color: Colors.textHint,
  },
  loadingContainer: {
    alignItems: 'center',
    paddingVertical: Spacing.xl * 2,
    gap: Spacing.sm,
  },
  loadingText: {
    fontSize: Typography.caption,
    color: Colors.textHint,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: Spacing.xl * 2,
    gap: Spacing.sm,
  },
  emptyText: {
    fontSize: Typography.body,
    color: Colors.textHint,
  },
});

export default QuickMessageSheet;
