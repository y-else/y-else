/**
 * SafeAreaCompat — 零原生依赖的 SafeAreaProvider + SafeAreaView
 *
 * 背景：react-native-safe-area-context@5.6.2 在 RN 0.83.6 + Expo 55 上，
 * 原生组件 RNCSafeAreaProvider / RNCSafeAreaView 无法注册（codegenNativeComponent
 * -> requireNativeComponent 返回 undefined），导致 "Element type is invalid" 崩溃。
 *
 * 解决：利用原库导出的纯 JS Context 提供 insets，完全绕过原生组件。
 * SafeAreaInsetsContext 和 SafeAreaFrameContext 来自原库，无原生依赖。
 *
 * 关键：@react-navigation 的 SafeAreaProviderCompat 内部检测 context 中已有 insets 时
 * 会跳过原生 SafeAreaProvider，使用普通 View，从而彻底避免崩溃。
 */

import React, { useEffect, useState, useCallback } from 'react';
import {
  Dimensions,
  StatusBar,
  View,
  type ViewProps,
  type ViewStyle,
} from 'react-native';

// ---- 从原库导入纯 JS 部分（无原生依赖） ----
import {
  SafeAreaInsetsContext,
  SafeAreaFrameContext,
  useSafeAreaInsets as _useInsets,
  useSafeAreaFrame as _useFrame,
} from 'react-native-safe-area-context';

// 重新导出原库的 hook 和 context，下游无需改 import
export {
  SafeAreaInsetsContext,
  SafeAreaFrameContext,
  SafeAreaConsumer,
  SafeAreaContext,
  withSafeAreaInsets,
} from 'react-native-safe-area-context';

export const useSafeAreaInsets = _useInsets;
export const useSafeAreaFrame = _useFrame;

// ---- 类型 ----

interface EdgeInsets {
  top: number;
  right: number;
  bottom: number;
  left: number;
}

interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

// ---- 纯 JS 计算 insets ----

function computeInsets(): EdgeInsets {
  const h = StatusBar.currentHeight ?? 24;
  return { top: h, right: 0, bottom: 0, left: 0 };
}

function computeFrame(): Rect {
  const { width, height } = Dimensions.get('window');
  return { x: 0, y: 0, width, height };
}

// ---- SafeAreaProvider（纯 JS 版） ----

export function SafeAreaProvider({ children }: { children?: React.ReactNode }) {
  const [insets, setInsets] = useState<EdgeInsets>(computeInsets);
  const [frame, setFrame] = useState<Rect>(computeFrame);

  const updateLayout = useCallback(() => {
    setInsets(computeInsets());
    setFrame(computeFrame());
  }, []);

  useEffect(() => {
    const sub = Dimensions.addEventListener('change', updateLayout);
    return () => sub?.remove();
  }, [updateLayout]);

  return (
    <SafeAreaInsetsContext.Provider value={insets}>
      <SafeAreaFrameContext.Provider value={frame}>
        {children}
      </SafeAreaFrameContext.Provider>
    </SafeAreaInsetsContext.Provider>
  );
}

// ---- SafeAreaView（纯 JS 版） ----

type Edge = 'top' | 'right' | 'bottom' | 'left';

export interface SafeAreaViewProps extends ViewProps {
  children?: React.ReactNode;
  edges?: readonly Edge[];
  mode?: 'padding' | 'margin';
}

export const SafeAreaView = React.forwardRef<View, SafeAreaViewProps>(
  ({ children, edges, mode = 'padding', style, ...props }, ref) => {
    const insets = _useInsets();
    const appliedEdges = edges ?? (['top', 'right', 'bottom', 'left'] as Edge[]);

    const insetsStyle: ViewStyle = {};
    const propKey = mode === 'padding' ? 'padding' : 'margin';

    for (const edge of appliedEdges) {
      const val = insets[edge] ?? 0;
      if (val > 0) {
        const cap = edge.charAt(0).toUpperCase() + edge.slice(1);
        (insetsStyle as Record<string, number>)[`${propKey}${cap}`] = val;
      }
    }

    return (
      <View ref={ref} style={[insetsStyle, style]} {...props}>
        {children}
      </View>
    );
  },
);
