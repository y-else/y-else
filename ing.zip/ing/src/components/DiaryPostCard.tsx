/**
 * 日记帖子卡片（性能优化版）
 *
 * 图文视频预览、编辑/删除操作、双方可见锁标识。
 * React.memo 避免列表无效重渲染。
 */

import React, { memo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../constants';
import type { DiaryPost, DiaryMedia } from '../types';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const GAP = 4;
const MEDIA_SIZE = (SCREEN_WIDTH - Spacing.lg * 2 - GAP * 2) / 3;

interface DiaryPostCardProps {
  post: DiaryPost;
  isOwner: boolean;
  onDelete?: (post: DiaryPost) => void;
  onEdit?: (post: DiaryPost) => void;
  onMediaPress?: (media: DiaryMedia, index: number) => void;
}

/** 是否显示"已编辑"标记 */
function isEdited(post: DiaryPost): boolean {
  if (!post.updatedAt || post.updatedAt === post.createdAt) return false;
  const created = new Date(post.createdAt).getTime();
  const updated = new Date(post.updatedAt).getTime();
  return updated - created > 1000; // 超过1秒差异才算编辑过
}

const DiaryPostCard: React.FC<DiaryPostCardProps> = ({
  post,
  isOwner,
  onDelete,
  onEdit,
  onMediaPress,
}) => {
  const edited = isEdited(post);

  return (
    <View style={styles.card}>
      {/* 头部 */}
      <View style={styles.header}>
        <View style={styles.authorRow}>
          <View style={styles.avatar}>
            {post.authorAvatar ? (
              <Image source={{ uri: post.authorAvatar }} style={styles.avatarImg} />
            ) : (
              <Ionicons name="person" size={18} color={Colors.textHint} />
            )}
          </View>
          <View>
            <Text style={styles.authorName}>{post.authorName}</Text>
            <Text style={styles.time}>
              {new Date(post.createdAt).toLocaleString('zh-CN', {
                month: 'numeric',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              })}
              {edited && <Text style={styles.editedTag}> 已编辑</Text>}
            </Text>
          </View>
        </View>
        {isOwner && (
          <View style={styles.actions}>
            {onEdit && (
              <TouchableOpacity
                onPress={() => onEdit(post)}
                hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                style={styles.actionBtn}
              >
                <Ionicons name="pencil" size={16} color={Colors.textHint} />
              </TouchableOpacity>
            )}
            {onDelete && (
              <TouchableOpacity
                onPress={() => onDelete(post)}
                hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                style={styles.actionBtn}
              >
                <Ionicons name="trash-outline" size={16} color={Colors.lover} />
              </TouchableOpacity>
            )}
          </View>
        )}
      </View>

      {/* 文字内容 */}
      {post.content ? (
        <Text style={styles.content}>{post.content}</Text>
      ) : null}

      {/* 媒体网格 */}
      {post.media.length > 0 && (
        <View style={styles.mediaGrid}>
          {post.media.map((m, idx) => (
            <TouchableOpacity
              key={`${m.uri.slice(-20)}_${idx}`}
              style={styles.mediaItem}
              activeOpacity={0.8}
              onPress={() => onMediaPress?.(m, idx)}
            >
              {m.thumbnailUri || m.uri ? (
                <Image
                  source={{ uri: m.thumbnailUri || m.uri }}
                  style={styles.mediaImg}
                  resizeMode="cover"
                />
              ) : (
                <View style={styles.mediaPlaceholder}>
                  <Ionicons
                    name={m.type === 'video' ? 'videocam' : 'image'}
                    size={24}
                    color={Colors.textHint}
                  />
                </View>
              )}
              {/* 视频播放标记 */}
              {m.type === 'video' && (
                <View style={styles.videoOverlay}>
                  <Ionicons name="play-circle" size={28} color="rgba(255,255,255,0.95)" />
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* 双方可见锁标识 */}
      <View style={styles.visibilityTag}>
        <Ionicons name="lock-closed" size={12} color={Colors.family} />
        <Text style={styles.visibilityText}>
          仅 {post.authorName} 和 {post.partnerName} 可见
        </Text>
      </View>
    </View>
  );
};

// React.memo：仅在 post 数据或交互权限变化时重渲染
export default memo(DiaryPostCard, (prev, next) => {
  return (
    prev.post.id === next.post.id &&
    prev.post.content === next.post.content &&
    prev.post.media.length === next.post.media.length &&
    prev.post.updatedAt === next.post.updatedAt &&
    prev.isOwner === next.isOwner
  );
});

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.bgWhite,
    borderRadius: BorderRadius.card,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  authorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.bgPrimary,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  avatarImg: {
    width: 32,
    height: 32,
    borderRadius: 16,
  },
  authorName: {
    fontSize: Typography.body,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  time: {
    fontSize: Typography.caption,
    color: Colors.textHint,
    marginTop: 1,
  },
  editedTag: {
    color: Colors.primary,
    fontSize: Typography.caption,
  },
  actions: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  actionBtn: {
    padding: Spacing.xs,
  },
  content: {
    fontSize: Typography.body,
    color: Colors.textPrimary,
    lineHeight: 24,
    marginBottom: Spacing.md,
  },
  mediaGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: GAP,
    marginBottom: Spacing.md,
  },
  mediaItem: {
    width: MEDIA_SIZE,
    height: MEDIA_SIZE,
    borderRadius: 4,
    overflow: 'hidden',
    backgroundColor: Colors.bgPrimary,
  },
  mediaImg: {
    width: '100%',
    height: '100%',
  },
  mediaPlaceholder: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  videoOverlay: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.15)',
  },
  visibilityTag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingTop: Spacing.sm,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: Colors.divider,
  },
  visibilityText: {
    fontSize: Typography.caption,
    color: Colors.family,
  },
});
