/**
 * 在线/离线/忙碌 状态徽标
 */

import React from 'react';
import { View, StyleSheet } from 'react-native';
import type { OnlineStatus } from '../types';

interface StatusBadgeProps {
  status: OnlineStatus;
  size?: number;
}

const STATUS_COLORS: Record<string, string> = {
  online: '#5CB85C',
  offline: '#CCCCCC',
  busy: '#F0AD4E',
};

const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 10 }) => {
  const color = STATUS_COLORS[status] || STATUS_COLORS.offline;

  return (
    <View
      style={[
        styles.dot,
        { width: size, height: size, borderRadius: size / 2, backgroundColor: color },
      ]}
    />
  );
};

const styles = StyleSheet.create({
  dot: {
    borderWidth: 1.5,
    borderColor: '#FFFFFF',
  },
});

export default StatusBadge;
