/**
 * ing 陪伴 — 应用入口（安卓专属生产稳定版）
 * 启动链: polyfill → preventAutoHide(15s兜底) → SafeAreaProvider → 权限门 → hideAsync → 主页
 */

// ====== crypto polyfill（Hermes 不提供 global.crypto） ======
import { getRandomValues } from 'expo-crypto';

try {
  if (typeof globalThis.crypto === 'undefined' || !(globalThis.crypto as any).getRandomValues) {
    (globalThis as any).crypto = (globalThis as any).crypto || {};
    (globalThis as any).crypto.getRandomValues = getRandomValues;
  }
} catch {}

import React, { useCallback, useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { AuthProvider } from './src/context/AuthContext';
import { AppNavigator } from './src/navigation';
import { Colors } from './src/constants';
import { NetworkBanner } from './src/components';
import { ErrorBoundary } from './src/components/ErrorBoundary';
import { StartupPermissionGate } from './src/components';
import { initProductionMode } from './src/utils/secureStorage';

// ====== 模块顶层：必须最先执行 ======

// 1. 生产模式初始化
try { initProductionMode(); } catch {}

// 2. 阻止启动屏自动隐藏 → 等待权限门完成后手动关闭
SplashScreen.preventAutoHideAsync().catch(() => {});

// 3. 绝对兜底：15 秒后强制关闭启动屏（防止权限检查卡死导致永远蓝屏）
setTimeout(() => { SplashScreen.hideAsync().catch(() => {}); }, 15000);

// 4. 全局 JS 未捕获异常处理 → 兜底关闭启动屏
if (typeof globalThis !== 'undefined' && (globalThis as any).ErrorUtils) {
  const orig = (globalThis as any).ErrorUtils.getGlobalHandler?.();
  (globalThis as any).ErrorUtils.setGlobalHandler((error: Error, isFatal?: boolean) => {
    try { SplashScreen.hideAsync().catch(() => {}); } catch {}
    if (orig && isFatal !== false) {
      try { orig(error, isFatal); } catch {}
    }
  });
}

// ====== 主应用 ======
const App: React.FC = () => {
  const [permissionsGranted, setPermissionsGranted] = useState(false);
  const [appError, setAppError] = useState<string | null>(null);

  const handleAllGranted = useCallback(() => {
    try {
      setPermissionsGranted(true);
      SplashScreen.hideAsync().catch(() => {});
    } catch (e: any) {
      setAppError(e?.message || '启动异常');
      SplashScreen.hideAsync().catch(() => {});
    }
  }, []);

  // 异常兜底：显示重试界面
  if (appError) {
    return (
      <TouchableOpacity
        activeOpacity={0.7}
        style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: Colors.bgPrimary, padding: 24 }}
        onPress={() => { setAppError(null); setPermissionsGranted(true); SplashScreen.hideAsync().catch(() => {}); }}
      >
        <View style={{ marginBottom: 16, padding: 12, backgroundColor: '#FFF0F0', borderRadius: 8 }}>
          <Text style={{ fontSize: 13, color: Colors.lover }}>{appError}</Text>
        </View>
        <View style={{ paddingHorizontal: 24, paddingVertical: 12, backgroundColor: Colors.primary, borderRadius: 8 }}>
          <Text style={{ color: '#FFF', fontWeight: '600' }}>点击重试</Text>
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <ErrorBoundary>
      <SafeAreaProvider>
        <StartupPermissionGate onAllGranted={handleAllGranted}>
          {permissionsGranted ? (
            <>
              <NetworkBanner onRetry={() => {}} />
              <AuthProvider>
                <NavigationContainer>
                  <AppNavigator />
                </NavigationContainer>
              </AuthProvider>
            </>
          ) : (
            <View style={{ flex: 1, backgroundColor: Colors.bgPrimary }} />
          )}
        </StartupPermissionGate>
      </SafeAreaProvider>
    </ErrorBoundary>
  );
};

export default App;
